# -*- coding: utf-8 -*-
"""Where things live: the installed program folder and the per-user data folder."""
import hashlib
import json
import os
import re
import sys

CORE_DIR = os.path.dirname(os.path.abspath(__file__))
APP_ROOT = os.path.dirname(CORE_DIR)


def read_json(path, default=None):
    try:
        with open(path, encoding='utf-8-sig') as f:       # -sig: also reads files saved with a BOM (Windows PowerShell does that)
            v = json.load(f)
        return v if v is not None else default
    except Exception:
        return default


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def home():
    """Per-user TaskDesk folder (session, user data, logs)."""
    h = os.environ.get('TASKDESK_HOME')
    if h:
        return os.path.abspath(h)
    if os.name == 'nt':
        base = os.environ.get('LOCALAPPDATA') or os.path.join(os.path.expanduser('~'), 'AppData', 'Local')
        return os.path.join(base, 'TaskDesk')
    return os.path.join(os.environ.get('XDG_DATA_HOME') or os.path.join(os.path.expanduser('~'), '.local', 'share'), 'TaskDesk')


def run_dir():
    p = os.path.join(home(), 'run')
    os.makedirs(p, exist_ok=True)
    return p


def log_dir():
    p = os.path.join(home(), 'logs')
    os.makedirs(p, exist_ok=True)
    return p


def version():
    return (read_json(os.path.join(APP_ROOT, 'version.json'), {}) or {}).get('version', '0.0.0')


def baked_cloud_url():
    """The server address that was put into this installation when the installer was built (the environment wins for tests)."""
    if os.environ.get('TASKDESK_CLOUD'):
        return os.environ['TASKDESK_CLOUD'].strip()
    return str((read_json(os.path.join(APP_ROOT, 'taskdesk_config.json'), {}) or {}).get('cloud_url', '')).strip()


def config():
    """Merged settings: program folder < user override file.

    The server address comes from the installer. The only thing that may replace it is an address the server itself
    announced (see server_move.py); that is remembered together with the installer address it replaced, so a newer
    installer with a newer address is never overruled by an old announcement.
    """
    cfg = dict(read_json(os.path.join(APP_ROOT, 'taskdesk_config.json'), {}) or {})
    user = dict(read_json(os.path.join(home(), 'config.json'), {}) or {})
    moved = user.pop('cloud_url', '')
    base_then = user.pop('cloud_url_base', '')
    cfg.update(user)
    base = baked_cloud_url()
    cfg['cloud_url'] = moved if (moved and base_then == base) else base
    return cfg


def save_user_config(**kw):
    p = os.path.join(home(), 'config.json')
    cur = dict(read_json(p, {}) or {})
    cur.update(kw)
    write_json(p, cur)


def install_info():
    """What the setup program chose (the module picked in the wizard)."""
    info = read_json(os.path.join(APP_ROOT, 'install.json'), {}) or {}
    if os.environ.get('TASKDESK_INSTALL_MODULE'):
        info['module'] = os.environ['TASKDESK_INSTALL_MODULE']
    if not info.get('module'):
        info['module'] = config().get('default_module', 'mm')
    return info


def modules():
    """All module folders present in this installation: {id: meta + dir}."""
    out = {}
    base = os.path.join(APP_ROOT, 'modules')
    if not os.path.isdir(base):
        return out
    for name in sorted(os.listdir(base)):
        d = os.path.join(base, name)
        meta = read_json(os.path.join(d, 'module.json'))
        if meta and os.path.isfile(os.path.join(d, meta.get('entry', 'server.py'))):
            meta = dict(meta)
            meta['dir'] = d
            out[meta['id']] = meta
    return out


def server_key(url, server_id=''):
    """Short id of a server, used in the data folder name. The server's own id is stable when the address changes."""
    if server_id:
        return hashlib.sha1(('id:' + str(server_id)).encode('utf-8')).hexdigest()[:6]
    host = re.sub(r'^https?://', '', (url or '').strip().lower()).split('/')[0]
    return hashlib.sha1(host.encode('utf-8')).hexdigest()[:6]


def safe_name(s):
    return re.sub(r'[^a-z0-9._-]', '_', (s or '').lower())[:40] or 'user'


def user_root(user_id, username, url, server_id=''):
    return os.path.join(home(), 'users', 'u%s_%s_%s' % (int(user_id), safe_name(username), server_key(url, server_id)))


def user_data_dir(user_id, username, url, server_id=''):
    return os.path.join(user_root(user_id, username, url, server_id), 'data')


def python_exe(windowless=True):
    exe = sys.executable
    if os.name == 'nt' and windowless:
        w = os.path.join(os.path.dirname(exe), 'pythonw.exe')
        if os.path.exists(w):
            return w
    return exe


def popen_flags():
    if os.name == 'nt':
        return {'creationflags': 0x08000000 | 0x00000200}      # CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP
    return {'start_new_session': True}
