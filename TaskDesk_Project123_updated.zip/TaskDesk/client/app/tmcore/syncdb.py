# -*- coding: utf-8 -*-
"""
Local side of the sync: change tracking inside the module's own SQLite database.

* Every table of the module (any table that has a single column primary key) gets three triggers.
  They only write a note "row X of table T changed" into _td_outbox - the module code does not know about it.
* The engine later reads the CURRENT state of each noted row (or finds it gone = delete) and sends that.
  Many quick edits of one row therefore become one upload, and the order of notes does not matter.
* Rows that arrive from the cloud are written while the flag "applying" is 1, so they do not echo back.
"""
import hashlib
import json
import os
import sqlite3
import threading
import time

INTERNAL_SQL = """
CREATE TABLE IF NOT EXISTS _td_meta(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS _td_outbox(seq INTEGER PRIMARY KEY AUTOINCREMENT, t TEXT NOT NULL, rid TEXT NOT NULL, op TEXT NOT NULL, info TEXT);
CREATE TABLE IF NOT EXISTS _td_files(rel TEXT PRIMARY KEY, size INTEGER, mtime_ns INTEGER, sha TEXT);
CREATE TABLE IF NOT EXISTS _td_log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, kind TEXT, t TEXT, rid TEXT, msg TEXT);
"""


def qi(name):
    return '"' + str(name).replace('"', '""') + '"'


def now_ts():
    return time.strftime('%Y-%m-%d %H:%M:%S')


class SyncDB:
    def __init__(self, db_path, files_dir):
        self.db_path = db_path
        self.files_dir = files_dir
        self.tables = {}            # name -> {'pk': col, 'cols': [..]}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ connections
    def conn(self, fk=False):
        c = sqlite3.connect(self.db_path, timeout=30, isolation_level=None)
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA busy_timeout=30000')
        try:
            c.execute('PRAGMA journal_mode=WAL')
        except sqlite3.DatabaseError:
            pass
        c.execute('PRAGMA foreign_keys=%s' % ('ON' if fk else 'OFF'))
        return c

    # ------------------------------------------------------------------ install
    def install(self):
        c = self.conn()
        try:
            c.executescript(INTERNAL_SQL)
            c.execute("INSERT OR IGNORE INTO _td_meta(k,v) VALUES('applying','0')")
            c.execute("INSERT OR IGNORE INTO _td_meta(k,v) VALUES('last_rev','0')")
            c.execute("UPDATE _td_meta SET v='0' WHERE k='applying'")
            self.tables = self._discover(c)
            sig = hashlib.sha1(json.dumps(self.tables, sort_keys=True).encode()).hexdigest()
            if self.meta_get(c, 'trg_sig') != sig:
                c.execute('BEGIN IMMEDIATE')
                for r in c.execute("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE '\\_td\\_%' ESCAPE '\\'").fetchall():
                    c.execute('DROP TRIGGER IF EXISTS ' + qi(r['name']))
                for t, info in self.tables.items():
                    for sql in self._trigger_sql(t, info['pk'], info['cols']):
                        c.execute(sql)
                self.meta_set(c, 'trg_sig', sig)
                c.execute('COMMIT')
        finally:
            c.close()
        return self.tables

    def _discover(self, c):
        out = {}
        for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite\\_%' ESCAPE '\\'").fetchall():
            name = r['name']
            if name.startswith('_td_') or len(name) > 40:
                continue
            info = c.execute('PRAGMA table_info(%s)' % qi(name)).fetchall()
            pks = [i['name'] for i in info if i['pk'] > 0]
            if len(pks) != 1:
                continue
            out[name] = {'pk': pks[0], 'cols': [i['name'] for i in info]}
        return out

    def _trigger_sql(self, t, pk, cols):
        q, p = qi(t), qi(pk)
        guard = "WHEN (SELECT v FROM _td_meta WHERE k='applying')='0'"
        has_rel = 'rel_path' in cols
        tl = t.replace("'", "''")
        ai = 'CREATE TRIGGER %s AFTER INSERT ON %s %s BEGIN INSERT INTO _td_outbox(t,rid,op) VALUES(\'%s\', NEW.%s, \'u\'); END' % (qi('_td_ai_' + t), q, guard, tl, p)
        body = "INSERT INTO _td_outbox(t,rid,op) VALUES('%s', NEW.%s, 'u'); " % (tl, p)
        body += "INSERT INTO _td_outbox(t,rid,op) SELECT '%s', OLD.%s, 'u' WHERE OLD.%s IS NOT NEW.%s; " % (tl, p, p, p)
        if has_rel:
            body += "INSERT INTO _td_outbox(t,rid,op,info) SELECT '%s', NEW.%s, 'f', OLD.rel_path WHERE OLD.rel_path IS NOT NEW.rel_path; " % (tl, p)
        au = 'CREATE TRIGGER %s AFTER UPDATE ON %s %s BEGIN %s END' % (qi('_td_au_' + t), q, guard, body)
        info = 'OLD.rel_path' if has_rel else 'NULL'
        ad = 'CREATE TRIGGER %s AFTER DELETE ON %s %s BEGIN INSERT INTO _td_outbox(t,rid,op,info) VALUES(\'%s\', OLD.%s, \'d\', %s); END' % (qi('_td_ad_' + t), q, guard, tl, p, info)
        return [ai, au, ad]

    # ------------------------------------------------------------------ meta / log
    @staticmethod
    def meta_get(c, k, default=None):
        r = c.execute('SELECT v FROM _td_meta WHERE k=?', (k,)).fetchone()
        return r['v'] if r else default

    @staticmethod
    def meta_set(c, k, v):
        c.execute('INSERT INTO _td_meta(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v', (k, str(v)))

    def get_meta(self, k, default=None):
        c = self.conn()
        try:
            return self.meta_get(c, k, default)
        finally:
            c.close()

    def set_meta(self, k, v):
        c = self.conn()
        try:
            self.meta_set(c, k, v)
        finally:
            c.close()

    def last_rev(self):
        return int(self.get_meta('last_rev', '0') or 0)

    def log(self, kind, t, rid, msg):
        c = self.conn()
        try:
            c.execute('INSERT INTO _td_log(ts,kind,t,rid,msg) VALUES(?,?,?,?,?)', (now_ts(), kind, t, str(rid), str(msg)[:500]))
            c.execute('DELETE FROM _td_log WHERE id NOT IN (SELECT id FROM _td_log ORDER BY id DESC LIMIT 200)')
        finally:
            c.close()

    def recent_problems(self, limit=20):
        c = self.conn()
        try:
            return [dict(r) for r in c.execute('SELECT ts,kind,t,rid,msg FROM _td_log ORDER BY id DESC LIMIT ?', (limit,)).fetchall()]
        finally:
            c.close()

    def local_row_count(self):
        c = self.conn()
        try:
            n = 0
            for t in self.tables:
                n += c.execute('SELECT COUNT(*) FROM %s' % qi(t)).fetchone()[0]
            return n
        finally:
            c.close()

    # ------------------------------------------------------------------ outbox
    def pending_count(self):
        c = self.conn()
        try:
            return c.execute("SELECT COUNT(*) FROM (SELECT 1 FROM _td_outbox GROUP BY t, rid)").fetchone()[0]
        finally:
            c.close()

    def collect(self, limit_rows=2000):
        """Reads the next notes. Returns (max_seq, items) where items = {(t, rid): {'dels': set(old rel paths)}}."""
        c = self.conn()
        try:
            rows = c.execute('SELECT seq,t,rid,op,info FROM _td_outbox ORDER BY seq LIMIT ?', (limit_rows,)).fetchall()
        finally:
            c.close()
        items = {}
        mx = 0
        for r in rows:
            mx = max(mx, r['seq'])
            it = items.setdefault((r['t'], str(r['rid'])), {'dels': set()})
            if r['op'] in ('d', 'f') and r['info']:
                it['dels'].add(r['info'])
        return mx, items

    def build_ops(self, items):
        """Current state of every noted row -> put / del operations. Returns (ops, upload_rels, delete_rels)."""
        c = self.conn()
        ops, uploads, dels = [], [], set()
        try:
            for (t, rid), it in items.items():
                info = self.tables.get(t)
                if not info:
                    continue
                dels.update(it['dels'])
                row = c.execute('SELECT * FROM %s WHERE %s=?' % (qi(t), qi(info['pk'])), (rid,)).fetchone()
                if row is None:
                    ops.append({'op': 'del', 't': t, 'id': rid})
                    continue
                d = {}
                for k in row.keys():
                    v = row[k]
                    if isinstance(v, (bytes, bytearray, memoryview)):
                        continue
                    d[k] = v
                ops.append({'op': 'put', 't': t, 'id': str(row[info['pk']]), 'd': d})
                if 'rel_path' in d and d['rel_path']:
                    uploads.append(d['rel_path'])
        finally:
            c.close()
        return ops, uploads, dels

    def drop_outbox_upto(self, seq):
        c = self.conn()
        try:
            c.execute('DELETE FROM _td_outbox WHERE seq<=?', (seq,))
        finally:
            c.close()

    def rel_in_use(self, rel):
        c = self.conn()
        try:
            for t, info in self.tables.items():
                if 'rel_path' in info['cols']:
                    if c.execute('SELECT 1 FROM %s WHERE rel_path=? LIMIT 1' % qi(t), (rel,)).fetchone():
                        return True
            return False
        finally:
            c.close()

    def all_file_rels(self):
        c = self.conn()
        out = []
        try:
            for t, info in self.tables.items():
                if 'rel_path' in info['cols']:
                    out += [r[0] for r in c.execute('SELECT rel_path FROM %s WHERE rel_path IS NOT NULL AND rel_path<>\'\'' % qi(t)).fetchall()]
        finally:
            c.close()
        return out

    # ------------------------------------------------------------------ file cache
    def cache_get(self, rel):
        c = self.conn()
        try:
            r = c.execute('SELECT size,mtime_ns,sha FROM _td_files WHERE rel=?', (rel,)).fetchone()
            return dict(r) if r else None
        finally:
            c.close()

    def cache_set(self, rel, size, mtime_ns, sha):
        c = self.conn()
        try:
            c.execute('INSERT INTO _td_files(rel,size,mtime_ns,sha) VALUES(?,?,?,?) ON CONFLICT(rel) DO UPDATE SET size=excluded.size, mtime_ns=excluded.mtime_ns, sha=excluded.sha',
                      (rel, size, mtime_ns, sha))
        finally:
            c.close()

    def cache_del(self, rel):
        c = self.conn()
        try:
            c.execute('DELETE FROM _td_files WHERE rel=?', (rel,))
        finally:
            c.close()

    # ------------------------------------------------------------------ apply what the cloud sent
    def apply_records(self, records, last_rev):
        """
        Writes cloud records into the local tables in ONE transaction.
        Rows that still have an unsent local change are left alone (the local change is sent first and wins).
        Returns a dict: applied, skipped_pending, unknown_table, conflicts, files_to_fetch, files_to_remove.
        """
        res = {'applied': 0, 'skipped_pending': 0, 'unknown_table': 0, 'conflicts': 0, 'files_to_fetch': [], 'files_to_remove': [], 'deleted_rows': 0}
        c = self.conn(fk=False)
        try:
            c.execute('BEGIN IMMEDIATE')
            try:
                self.meta_set(c, 'applying', '1')
                pending = set((r['t'], str(r['rid'])) for r in c.execute('SELECT DISTINCT t, rid FROM _td_outbox').fetchall())
                for rec in records:
                    t = rec.get('t')
                    rid = str(rec.get('id'))
                    info = self.tables.get(t)
                    if not info:
                        res['unknown_table'] += 1
                        continue
                    if (t, rid) in pending:
                        res['skipped_pending'] += 1
                        continue
                    pk = info['pk']
                    has_rel = 'rel_path' in info['cols']
                    old_rel = None
                    if has_rel:
                        r0 = c.execute('SELECT rel_path FROM %s WHERE %s=?' % (qi(t), qi(pk)), (rid,)).fetchone()
                        old_rel = r0['rel_path'] if r0 else None
                    if rec.get('del'):
                        n = c.execute('DELETE FROM %s WHERE %s=?' % (qi(t), qi(pk)), (rid,)).rowcount
                        res['deleted_rows'] += n
                        if has_rel and old_rel:
                            res['files_to_remove'].append(old_rel)
                        res['applied'] += 1
                        continue
                    d = rec.get('d') or {}
                    cols = [k for k in d.keys() if k in info['cols']]
                    if pk not in cols:
                        d[pk] = int(rid) if rid.lstrip('-').isdigit() and pk == 'id' else rid
                        cols.append(pk)
                    vals = [self._val(d[k]) for k in cols]
                    sets = ','.join('%s=excluded.%s' % (qi(k), qi(k)) for k in cols if k != pk)
                    sql = 'INSERT INTO %s(%s) VALUES(%s)' % (qi(t), ','.join(qi(k) for k in cols), ','.join('?' * len(cols)))
                    sql += ' ON CONFLICT(%s) DO UPDATE SET %s' % (qi(pk), sets) if sets else ' ON CONFLICT(%s) DO NOTHING' % qi(pk)
                    try:
                        c.execute(sql, vals)
                    except sqlite3.IntegrityError as e:
                        res['conflicts'] += 1
                        c.execute('INSERT INTO _td_log(ts,kind,t,rid,msg) VALUES(?,?,?,?,?)', (now_ts(), 'conflict', t, rid, str(e)[:300]))
                        continue
                    res['applied'] += 1
                    if has_rel:
                        new_rel = d.get('rel_path')
                        if old_rel and old_rel != new_rel:
                            res['files_to_remove'].append(old_rel)
                        if new_rel:
                            res['files_to_fetch'].append(new_rel)
                self.meta_set(c, 'last_rev', last_rev)
                self.meta_set(c, 'applying', '0')
                c.execute('COMMIT')
            except BaseException:
                try:
                    c.execute('ROLLBACK')
                except sqlite3.Error:
                    pass
                raise
        finally:
            c.close()
        return res

    @staticmethod
    def _val(v):
        if isinstance(v, (dict, list)):
            return json.dumps(v, ensure_ascii=False)
        if isinstance(v, bool):
            return 1 if v else 0
        return v

    def set_last_rev(self, rev):
        c = self.conn()
        try:
            self.meta_set(c, 'last_rev', rev)
        finally:
            c.close()

    def abs_path(self, rel):
        p = os.path.abspath(os.path.join(self.files_dir, rel))
        base = os.path.abspath(self.files_dir)
        if p != base and not p.startswith(base + os.sep):
            return None
        return p
