# -*- coding: utf-8 -*-
"""
Background sync between the local module database / files and the TaskDesk cloud.

Rules (kept simple on purpose):
  1. Local first: the app always works on the local copy, so every click is instant.
  2. Push before pull: a change you made is sent first, so a fresh pull can never overwrite it.
  3. Files go up BEFORE the row that points to them, so another PC never sees a row without its file.
  4. A server change is applied to rows that have no unsent local change.
  5. Offline is normal: changes wait in the outbox and go up when the connection is back.
"""
import os
import queue
import threading
import time

from . import paths, server_move
from .cloud import AccountBlocked, AuthExpired, CloudError, Offline, UpgradeRequired, sha256_file


def _chunks(ops, max_ops=200, max_bytes=3 * 1024 * 1024):
    cur, size = [], 0
    for op in ops:
        n = len(str(op.get('d', ''))) + 80
        if cur and (len(cur) >= max_ops or size + n > max_bytes):
            yield cur
            cur, size = [], 0
        cur.append(op)
        size += n
    if cur:
        yield cur


class Engine:
    def __init__(self, sdb, cloud, user, cats=None, on_auth_lost=None, fast_seconds=20, slow_seconds=90, on_moved=None, account_seconds=60, health_seconds=600,
                 folder_tables=None):
        self.sdb = sdb
        self.cloud = cloud
        self.user = user
        self.cats = list(cats or [])
        self.folder_tables = list(folder_tables or ['tasks'])   # tables whose rows own a 'folder' column (modules may list more than 'tasks')
        self.on_auth_lost = on_auth_lost
        self.on_moved = on_moved                  # called with the new address when the server announced a move
        self.perms = {}                           # what the owner allows this account (from the server)
        self._acct_at = 0                         # when the account was last checked
        self._health_at = 0
        self.account_seconds = account_seconds    # how often the server is asked whether the account is still allowed
        self.health_seconds = health_seconds      # how often the app looks for a new server address
        self.fast = fast_seconds
        self.slow = slow_seconds
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._cycle_lock = threading.RLock()
        self.first_done = threading.Event()       # set when the first sync attempt after start has finished (success or not)
        self._state_lock = threading.Lock()
        self._thread = None
        self._dl_thread = None
        self._dl_queue = queue.Queue()
        self._dl_queued = set()
        self._inflight = {}
        self._last_touch = time.time()
        self._backoff = 0
        self.s = {
            'state': 'starting', 'last_sync': 0, 'last_error': '', 'restore_active': False, 'restore_done': 0, 'restore_total': 0,
            'dl_queued': 0, 'dl_done': 0, 'dl_failed': 0, 'data_version': 0, 'problems': 0, 'upgrade_message': '',
            'blocked_code': '', 'maintenance': False, 'uploads_off': False,
        }

    # ------------------------------------------------------------------ state
    def _set(self, **kw):
        with self._state_lock:
            self.s.update(kw)

    def snapshot(self):
        with self._state_lock:
            s = dict(self.s)
        try:
            s['pending'] = self.sdb.pending_count()
        except Exception:
            s['pending'] = -1
        s['dl_left'] = max(0, s['dl_queued'] - s['dl_done'] - s['dl_failed'])
        return s

    def touch(self):
        self._last_touch = time.time()

    # ------------------------------------------------------------------ control
    def start(self):
        self._clean_partial_downloads()
        self._thread = threading.Thread(target=self._loop, name='td-sync', daemon=True)
        self._thread.start()
        self._dl_thread = threading.Thread(target=self._dl_loop, name='td-download', daemon=True)
        self._dl_thread.start()

    def poke(self):
        self._wake.set()

    def stop(self):
        self._stop.set()
        self._wake.set()

    def flush(self, timeout=25):
        """Sends everything that is waiting. Returns True when nothing is left to send."""
        deadline = time.time() + timeout
        got = self._cycle_lock.acquire(timeout=max(0.1, timeout))
        if not got:
            return False
        try:
            if time.time() > deadline:
                return self.sdb.pending_count() == 0
            self.push_all()
            return self.sdb.pending_count() == 0
        except CloudError:
            return False
        finally:
            self._cycle_lock.release()

    def _clean_partial_downloads(self):
        try:
            for root, _d, files in os.walk(self.sdb.files_dir):
                for f in files:
                    if f.endswith('.tdpart'):
                        try:
                            os.remove(os.path.join(root, f))
                        except OSError:
                            pass
        except Exception:
            pass

    # ------------------------------------------------------------------ main loop
    def _interval(self):
        return self.fast if time.time() - self._last_touch < 300 else self.slow

    def _loop(self):
        first = True
        while not self._stop.is_set():
            if not first:
                woke = self._wake.wait(timeout=max(self._interval(), self._backoff))
                if self._stop.is_set():
                    break
                if woke:
                    time.sleep(0.4)             # let quick follow-up edits join the same upload
                self._wake.clear()
            first = False
            try:
                with self._cycle_lock:
                    self.cycle()
                self._backoff = 0
            except Offline as e:
                self._backoff = min(90, (self._backoff or 5) * 2)
                self._set(state='offline', last_error=e.message, maintenance=(e.code == 'maintenance'))
            except AccountBlocked as e:
                self._backoff = 60                                  # keep asking: the owner may switch the account on again
                self._acct_at = 0
                self._set(state='blocked', last_error=e.message, blocked_code=e.code)
            except AuthExpired:
                self._set(state='auth', last_error='Your sign-in has expired. Please sign in again.')
                if self.on_auth_lost:
                    try:
                        self.on_auth_lost()
                    except Exception:
                        pass
                break
            except UpgradeRequired as e:
                self._set(state='upgrade', last_error=e.message, upgrade_message=e.message)
                self._backoff = 600
            except CloudError as e:
                self._backoff = min(120, (self._backoff or 10) * 2)
                self._set(state='error', last_error=e.message)
            except Exception as e:      # never let the thread die
                self._backoff = 60
                self._set(state='error', last_error='Unexpected problem: %s' % e)
                try:
                    self.sdb.log('problem', '', '', 'sync loop: %r' % (e,))
                except Exception:
                    pass
            finally:
                self.first_done.set()

    def cycle(self):
        self._set(state='syncing')
        self._check_account()
        self.push_all()
        self.pull_all()
        self._maybe_verify()
        self._set(state='idle', last_sync=int(time.time()), last_error='', problems=self._count_problems(), blocked_code='', maintenance=False)

    def _adopt_saved_address(self):
        """The login screen is another process: when it already followed the server to a new address, use that address here too."""
        try:
            cur = (paths.config().get('cloud_url') or '').strip()
        except Exception:
            return
        if cur and cur.rstrip('/').lower() != (self.cloud.base or '').rstrip('/').lower():
            self.cloud.base = cur
            if self.on_moved:
                try:
                    self.on_moved(cur)
                except Exception:
                    pass

    def _check_account(self):
        """Once a minute: is the account still allowed, did the module change, what may it upload. Now and then: did the server move."""
        now = time.time()
        self._adopt_saved_address()
        if now - self._acct_at >= self.account_seconds:
            r = self.cloud.me(timeout=20)
            self._acct_at = now
            fresh = r.get('user') or {}
            if fresh.get('module') and fresh['module'] != self.user.get('module'):
                raise AccountBlocked('module_changed', 'The administrator changed the type of your account. Please sign out and sign in again.')
            old = self.perms.get('can_upload', True)
            self.perms = r.get('perms') or {}
            if self.perms.get('can_upload', True) and not old:
                self.sdb.set_meta('last_verify', 0)               # uploads are back: send the files that had to wait
            self._set(uploads_off=not self.perms.get('can_upload', True))
        if now - self._health_at >= self.health_seconds:
            self._health_at = now
            try:
                moved = server_move.follow(self.cloud.base, self.cloud.health(timeout=8))
            except Exception:
                moved = ''
            if moved:
                self.cloud.base = moved
                if self.on_moved:
                    try:
                        self.on_moved(moved)
                    except Exception:
                        pass

    def _count_problems(self):
        try:
            return sum(1 for r in self.sdb.recent_problems(50) if r['kind'] == 'problem')
        except Exception:
            return 0

    def sync_now(self, wait=20):
        """Used by the 'Sync now' button: runs one cycle and waits for it."""
        ok = self._cycle_lock.acquire(timeout=wait)
        if not ok:
            return self.snapshot()
        try:
            self.cycle()
            if self._backoff:
                self._backoff = 0
                self._wake.set()                    # the background loop was waiting out a long pause: let it start its normal rhythm again
        except Offline as e:
            self._set(state='offline', last_error=e.message, maintenance=(e.code == 'maintenance'))
        except AccountBlocked as e:
            self._acct_at = 0
            self._set(state='blocked', last_error=e.message, blocked_code=e.code)
        except AuthExpired:
            self._set(state='auth', last_error='Your sign-in has expired. Please sign in again.')
        except CloudError as e:
            self._set(state='error', last_error=e.message)
        finally:
            self._cycle_lock.release()
        return self.snapshot()

    # ------------------------------------------------------------------ push
    def push_all(self):
        while not self._stop.is_set():
            mx, items = self.sdb.collect(1500)
            if not items:
                return
            ops, uploads, dels = self.sdb.build_ops(items)
            uploaded = set()
            for rel in uploads:
                if rel not in uploaded:
                    self._upload(rel)
                    uploaded.add(rel)
            for chunk in _chunks(ops):
                self._push_chunk(chunk)
            for rel in dels:
                if not self.sdb.rel_in_use(rel):
                    try:
                        self.cloud.file_del(rel)
                    except CloudError as e:
                        if isinstance(e, AccountBlocked) or e.code in ('offline', 'not_signed_in', 'upgrade_required') or e.status >= 500 or e.status in (0, 429):
                            raise
                    self.sdb.cache_del(rel)
            self.sdb.drop_outbox_upto(mx)

    def _push_chunk(self, chunk):
        try:
            r = self.cloud.push(chunk)
        except (Offline, AuthExpired, UpgradeRequired, AccountBlocked):
            raise
        except CloudError as e:
            if e.status >= 500 or e.status in (0, 429):
                raise
            if len(chunk) > 1:                      # one bad record must not block the others
                mid = len(chunk) // 2
                self._push_chunk(chunk[:mid])
                self._push_chunk(chunk[mid:])
                return
            op = chunk[0]
            self.sdb.log('problem', op.get('t'), op.get('id'), 'Not uploaded: %s' % e.message)
            return
        rev, n = int(r.get('rev', 0)), int(r.get('applied', 0))
        if rev - n == self.sdb.last_rev():          # nobody else wrote in between: no need to pull our own changes back
            self.sdb.set_last_rev(rev)

    def _upload(self, rel):
        if self.perms and not self.perms.get('can_upload', True):
            return False                            # the owner switched file uploads off: the file stays on this PC only
        p = self.sdb.abs_path(rel)
        if not p or not os.path.isfile(p):
            return False                            # not on this PC (yet): nothing to upload
        st = os.stat(p)
        cache = self.sdb.cache_get(rel)
        if cache and cache['size'] == st.st_size and cache['mtime_ns'] == st.st_mtime_ns:
            return True
        sha = sha256_file(p)
        if cache and cache['sha'] == sha:
            self.sdb.cache_set(rel, st.st_size, st.st_mtime_ns, sha)
            return True
        try:
            self.cloud.file_put(rel, p, sha)
        except CloudError as e:
            if e.code in ('quota_exceeded', 'file_too_large'):
                self.sdb.log('problem', 'files', rel, e.message)
                return False
            if e.code == 'uploads_disabled':
                self.perms = dict(self.perms or {}, can_upload=False)
                self._set(uploads_off=True)
                return False
            raise
        self.sdb.cache_set(rel, st.st_size, st.st_mtime_ns, sha)
        return True

    # ------------------------------------------------------------------ pull
    def pull_all(self):
        rev = self.sdb.last_rev()
        restoring = rev == 0
        total = 0
        if restoring:
            try:
                total = int(self.cloud.status().get('records', 0))
            except CloudError as e:
                if e.code in ('offline', 'not_signed_in', 'upgrade_required'):
                    raise
            if total > 0:
                self._set(restore_active=True, restore_done=0, restore_total=total)
        changed = False
        try:
            while not self._stop.is_set():
                d = self.cloud.pull(rev, 500)
                recs = d.get('records', [])
                if recs:
                    res = self.sdb.apply_records(recs, int(d['last']))
                    rev = int(d['last'])
                    changed = changed or res['applied'] > 0
                    self._after_apply(res)
                    if restoring:
                        with self._state_lock:
                            self.s['restore_done'] += len(recs)
                elif int(d.get('server_rev', 0)) < rev:
                    # the cloud was reset (restored from an old backup): start from zero to stay consistent
                    self.sdb.set_last_rev(0)
                    self.sdb.log('problem', '', '', 'The cloud has older data than this PC; syncing again from the start.')
                    rev = 0
                if not d.get('more'):
                    break
        finally:
            if restoring:
                self._set(restore_active=False)
        if changed:
            with self._state_lock:
                self.s['data_version'] += 1

    def _after_apply(self, res):
        for rel in res['files_to_remove']:
            if not self.sdb.rel_in_use(rel):
                p = self.sdb.abs_path(rel)
                if p and os.path.isfile(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
                self.sdb.cache_del(rel)
        if res['deleted_rows'] or res['files_to_remove']:
            self._prune_empty_dirs()
        self.ensure_folders()
        self.enqueue_downloads(res['files_to_fetch'])

    def _prune_empty_dirs(self):
        base = self.sdb.files_dir
        try:
            for root, dirs, files in os.walk(base, topdown=False):
                if root != base and not os.listdir(root):
                    try:
                        os.rmdir(root)
                    except OSError:
                        pass
        except Exception:
            pass

    def ensure_folders(self):
        """Re-creates the record folders and the category sub folders, as they were when the records were created."""
        folders = []
        for t in self.folder_tables:
            info = self.sdb.tables.get(t)
            if not info or 'folder' not in info['cols']:
                continue
            c = self.sdb.conn()
            try:
                folders += [r[0] for r in c.execute('SELECT folder FROM "%s" WHERE folder IS NOT NULL AND folder<>\'\'' % t.replace('"', '')).fetchall()]
            finally:
                c.close()
        for f in folders:
            base = self.sdb.abs_path(f)
            if not base:
                continue
            try:
                os.makedirs(base, exist_ok=True)
                for cat in self.cats:
                    os.makedirs(os.path.join(base, cat), exist_ok=True)
            except OSError:
                pass

    # ------------------------------------------------------------------ downloads
    def enqueue_downloads(self, rels):
        n = 0
        for rel in rels:
            p = self.sdb.abs_path(rel)
            if not p or os.path.isfile(p) or rel in self._dl_queued:
                continue
            self._dl_queued.add(rel)
            self._dl_queue.put(rel)
            n += 1
        if n:
            with self._state_lock:
                self.s['dl_queued'] += n

    def _dl_loop(self):
        while not self._stop.is_set():
            try:
                rel = self._dl_queue.get(timeout=1)
            except queue.Empty:
                continue
            try:
                ok = self.download(rel)
                with self._state_lock:
                    self.s['dl_done' if ok else 'dl_failed'] += 1
            except Offline:
                self._dl_queue.put(rel)             # try again later
                time.sleep(10)
                continue
            except AuthExpired:
                with self._state_lock:
                    self.s['dl_failed'] += 1
            except AccountBlocked:
                self._dl_queue.put(rel)             # not allowed right now: wait until the owner allows it again
                time.sleep(30)
                continue
            except CloudError as e:
                self.sdb.log('problem', 'files', rel, 'Download failed: %s' % e.message)
                with self._state_lock:
                    self.s['dl_failed'] += 1
            except Exception as e:
                self.sdb.log('problem', 'files', rel, 'Download failed: %r' % (e,))
                with self._state_lock:
                    self.s['dl_failed'] += 1
            self._dl_queued.discard(rel)

    def download(self, rel):
        """Returns True when the file is on disk afterwards."""
        p = self.sdb.abs_path(rel)
        if not p:
            return False
        if os.path.isfile(p):
            return True
        ev = None
        with self._state_lock:
            ev = self._inflight.get(rel)
            mine = ev is None
            if mine:
                ev = self._inflight[rel] = threading.Event()
        if not mine:
            ev.wait(120)
            return os.path.isfile(p)
        try:
            try:
                sha = self.cloud.file_get(rel, p)
            except CloudError as e:
                if e.status == 404:
                    self.sdb.log('problem', 'files', rel, 'This file is not in the cloud any more.')
                    return False
                raise
            st = os.stat(p)
            self.sdb.cache_set(rel, st.st_size, st.st_mtime_ns, sha)
            return True
        finally:
            with self._state_lock:
                self._inflight.pop(rel, None)
            ev.set()

    def ensure_local(self, rel, timeout=90):
        """Called when the user opens a file that has not been downloaded yet."""
        p = self.sdb.abs_path(rel)
        if p and os.path.isfile(p):
            return True
        try:
            return self.download(rel)
        except CloudError:
            return False

    # ------------------------------------------------------------------ self healing
    def _maybe_verify(self):
        last = float(self.sdb.get_meta('last_verify', '0') or 0)
        if time.time() - last < 12 * 3600:
            return
        self.verify_files()
        self.sdb.set_meta('last_verify', time.time())

    def verify_files(self):
        """Compares the file list with the cloud and fixes both directions."""
        remote = {f['rel']: f for f in self.cloud.file_list()}
        for rel in set(self.sdb.all_file_rels()):
            p = self.sdb.abs_path(rel)
            if not p:
                continue
            have = os.path.isfile(p)
            if rel in remote and not have:
                self.enqueue_downloads([rel])
            elif rel not in remote and have:
                self.sdb.cache_del(rel)
                self._upload(rel)
