# -*- coding: utf-8 -*-
"""
The TaskDesk gate: the sign-in / create-account / About screen, and the starter of the module process.

It runs as a small local web server. The launcher opens it in an app window. After a successful sign-in the gate
starts the module that belongs to the ACCOUNT (not the one chosen at installation) and sends the window there.
"""
import argparse
import hmac
import json
import mimetypes
import os
import secrets
import socket
import subprocess
import sys
import threading
import time
import traceback
import urllib.request
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tmcore import paths, server_move, session          # noqa: E402
from tmcore.cloud import AccountBlocked, AuthExpired, Cloud, CloudError, Offline   # noqa: E402

def quiet_std():
    for n in ('stdout', 'stderr'):
        if getattr(sys, n) is None:          # pythonw.exe has no console
            setattr(sys, n, open(os.devnull, 'w'))


GATE_STATIC = os.path.join(paths.APP_ROOT, 'gate_static')
PORT_RANGE = list(range(8750, 8760))
TYPES = {'.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.svg': 'image/svg+xml',
         '.ico': 'image/x-icon', '.png': 'image/png', '.json': 'application/json', '.woff2': 'font/woff2'}


class G:
    key = ''
    port = 0
    last_seen = time.time()
    child = None            # subprocess.Popen
    child_info = None       # {'module','user_id','port','key'}
    lock = threading.RLock()
    health = None
    health_at = 0
    httpd = None
    pending = {}            # sign-ins that must first choose a new password: ticket -> {resp, old, at}


def gate_url():
    return 'http://127.0.0.1:%d/__enter?k=%s' % (G.port, G.key)


def cloud(token=None):
    return Cloud(paths.config().get('cloud_url', ''), token, paths.version(), device_name())


def device_name():
    try:
        return '%s (%s)' % (socket.gethostname(), os.environ.get('USERNAME') or os.environ.get('USER') or 'user')
    except Exception:
        return 'This PC'


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def ping(port, path='/__td/ping', want='taskdesk-module', timeout=1.5):
    try:
        with urllib.request.urlopen('http://127.0.0.1:%d%s' % (port, path), timeout=timeout) as r:
            return json.loads(r.read().decode('utf-8')).get('app') == want
    except Exception:
        return False


# ---------------------------------------------------------------------- module process
def child_alive():
    return G.child is not None and G.child.poll() is None


def stop_child():
    """Asks the module to finish (it uploads what is waiting), then makes sure the process is gone."""
    with G.lock:
        p, info = G.child, G.child_info
        G.child, G.child_info = None, None
    if p is None or p.poll() is not None:
        return
    if info:
        try:
            req = urllib.request.Request('http://127.0.0.1:%d/__td/stop' % info['port'], data=b'{}', method='POST',
                                         headers={'X-TM': '1', 'Cookie': 'tdk_%d=%s' % (info['port'], info['key']), 'Content-Type': 'application/json'})
            urllib.request.urlopen(req, timeout=5).read()
        except Exception:
            pass
    try:
        p.wait(timeout=35)
    except Exception:
        try:
            p.terminate()
            p.wait(timeout=10)
        except Exception:
            try:
                p.kill()
            except Exception:
                pass


def log_tail(path, n=12):
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            return ''.join(f.readlines()[-n:])
    except Exception:
        return ''


def start_module(user):
    """Starts (or reuses) the module process for this user. Returns the URL the window must open."""
    mid = user['module']
    mods = paths.modules()
    if mid not in mods:
        raise CloudError(0, 'module_missing', 'This account uses the "%s" module, which is not part of this TaskDesk version. Please install the latest TaskDesk.' % mid)
    with G.lock:
        info = G.child_info
        if child_alive() and info and info['module'] == mid and info['user_id'] == user['id'] and ping(info['port']):
            return 'http://127.0.0.1:%d/__td/enter?k=%s&next=/' % (info['port'], info['key'])
        stop_child()
        port = free_port()
        key = secrets.token_hex(16)
        env = dict(os.environ)
        env['TD_LOCAL_KEY'] = key
        env['TD_GATE_URL'] = gate_url()
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUTF8'] = '1'
        logp = os.path.join(paths.log_dir(), 'module-%s.log' % mid)
        lf = open(logp, 'a', encoding='utf-8', errors='replace')
        lf.write('\n--- start %s module=%s port=%d ---\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), mid, port))
        lf.flush()
        cmd = [paths.python_exe(), os.path.join(paths.CORE_DIR, 'module_host.py'), '--module', mid, '--port', str(port), '--idle-exit', '900']
        G.child = subprocess.Popen(cmd, cwd=paths.APP_ROOT, env=env, stdout=lf, stderr=lf, stdin=subprocess.DEVNULL, **paths.popen_flags())
        G.child_info = {'module': mid, 'user_id': user['id'], 'port': port, 'key': key}
        proc = G.child
    for _ in range(120):
        if proc.poll() is not None:
            break
        if ping(port):
            return 'http://127.0.0.1:%d/__td/enter?k=%s&next=/' % (port, key)
        time.sleep(0.25)
    raise CloudError(0, 'start_failed', 'The workspace could not start.\n%s' % log_tail(logp))


# ---------------------------------------------------------------------- state helpers
def health(force=False):
    if not force and G.health is not None and time.time() - G.health_at < 20:
        return G.health
    c = cloud()
    if not c.configured():
        h = {'ok': False, 'error': 'not_configured', 'message': 'This copy of TaskDesk was not set up with a server. Please install TaskDesk again with the official setup file.'}
    else:
        try:
            h = c.health(timeout=6)
            if server_move.follow(c.base, h):               # the owner moved the server: use the new address from now on
                h = cloud().health(timeout=6)
        except CloudError as e:
            h = {'ok': False, 'error': e.code, 'message': e.message}
        except Exception as e:
            h = {'ok': False, 'error': 'error', 'message': str(e)}
    G.health, G.health_at = h, time.time()
    return h


def update_info(h):
    def tup(v):
        try:
            return tuple(int(x) for x in str(v).split('.'))
        except Exception:
            return (0,)
    latest = (h or {}).get('latest_client') or ''
    return {'available': bool(latest) and tup(latest) > tup(paths.version()), 'latest': latest,
            'url': (h or {}).get('download_url') or '', 'notice': (h or {}).get('notice') or ''}


def state_json():
    mods = paths.modules()
    inst = paths.install_info()
    cfg = paths.config()
    h = health()
    sess = session.load()
    return {
        'ok': True,
        'version': paths.version(),
        'install_module': inst.get('module') if inst.get('module') in mods else (sorted(mods)[0] if mods else ''),
        'modules': [{k: m.get(k) for k in ('id', 'title', 'short', 'tagline', 'accent', 'shell', 'order')} for m in sorted(mods.values(), key=lambda m: m.get('order', 99))],
        'configured': cloud().configured(),
        'health': {k: h.get(k) for k in ('ok', 'error', 'message', 'registration', 'approval_required', 'invite_required', 'max_file_mb', 'quota_mb',
                                         'maintenance', 'maintenance_message')},
        'update': update_info(h),
        'session': {'user': sess['user']} if sess else None,
    }


def finish_auth(resp, c):
    """After login / register: keep the sign-in (encrypted), start the module, return where to go."""
    user = resp['user']
    token = resp['token']
    if user['module'] not in paths.modules():
        try:
            c.token = token
            c.logout()
        except Exception:
            pass
        raise CloudError(0, 'module_missing', 'This account uses the "%s" module, which is not part of this TaskDesk version. Please install the latest TaskDesk%s.' % (
            user['module'], (' from ' + (health().get('download_url') or '')) if health().get('download_url') else ''))
    session.save(c.base, user, token, health().get('server_id') or '')
    url = start_module(user)
    out = {'ok': True, 'url': url, 'user': user}
    if resp.get('recovery_key'):
        out['recovery_key'] = resp['recovery_key']
    return out


# ---------------------------------------------------------------------- HTTP
class Handler(BaseHTTPRequestHandler):
    server_version = 'TaskDeskGate/1'
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    def host_ok(self):
        host = (self.headers.get('Host') or '').split(':')[0].lower()
        return host in ('127.0.0.1', 'localhost', '[::1]', '')

    def authorized(self):
        raw = self.headers.get('Cookie') or ''
        try:
            m = SimpleCookie(raw).get('tdk_%d' % G.port)
        except Exception:
            return False
        return bool(m) and hmac.compare_digest(m.value, G.key)

    def send_json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def json_body(self):
        n = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(n) if n else b''
        self.body_read = True
        try:
            return json.loads(raw.decode('utf-8')) if raw else {}
        except Exception:
            return {}

    def handle_any(self, method):
        G.last_seen = time.time()
        self.body_read = False
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        try:
            if not self.host_ok():
                return self.send_json({'error': 'Forbidden host'}, 403)
            if path == '/__gate/ping':
                return self.send_json({'ok': True, 'app': 'taskdesk-gate'})
            if path == '/__enter' and method == 'GET':
                q = {k: v[0] for k, v in parse_qs(parsed.query).items()}
                if not hmac.compare_digest(q.get('k', ''), G.key):
                    return self.send_json({'error': 'Forbidden'}, 403)
                self.send_response(302)
                self.send_header('Location', '/')
                self.send_header('Set-Cookie', 'tdk_%d=%s; Path=/; HttpOnly; SameSite=Strict' % (G.port, G.key))
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
            if not self.authorized():
                self.close_connection = True
                return self.send_json({'error': 'Open TaskDesk from its desktop icon.'}, 403)
            if path.startswith('/api/'):
                if method != 'GET' and self.headers.get('X-TM') != '1':
                    self.close_connection = True
                    return self.send_json({'error': 'Missing X-TM header'}, 403)
                return self.api(method, path)
            if method == 'GET':
                return self.static(path)
            self.close_connection = True
            return self.send_json({'error': 'Method not allowed'}, 405)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
        except CloudError as e:
            self.send_json({'ok': False, 'error': e.code, 'message': e.message}, 400 if e.status in (0, 401) else e.status)
        except Exception as e:
            traceback.print_exc()
            try:
                self.send_json({'ok': False, 'error': 'server_error', 'message': 'Something went wrong: %s' % e}, 500)
            except Exception:
                self.close_connection = True
        finally:
            if method == 'POST' and not self.body_read:
                self.close_connection = True

    def static(self, path):
        if path in ('', '/'):
            path = '/index.html'
        full = os.path.abspath(os.path.join(GATE_STATIC, path.lstrip('/')))
        if not full.startswith(os.path.abspath(GATE_STATIC) + os.sep) or not os.path.isfile(full):
            return self.send_json({'error': 'Not found'}, 404)
        ext = os.path.splitext(full)[1].lower()
        ctype = TYPES.get(ext) or mimetypes.guess_type(full)[0] or 'application/octet-stream'
        if ctype.startswith('text/') or ctype in ('application/javascript', 'application/json'):
            ctype += '; charset=utf-8'
        with open(full, 'rb') as f:
            data = f.read()
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        self.wfile.write(data)

    def api(self, method, path):
        if method == 'GET' and path == '/api/state':
            return self.send_json(state_json())
        if method == 'GET' and path == '/api/about':
            a = paths.read_json(os.path.join(paths.APP_ROOT, 'about.json'), {}) or {}
            a['version'] = paths.version()
            return self.send_json(a)
        if method != 'POST':
            return self.send_json({'error': 'Unknown endpoint'}, 404)
        b = self.json_body()
        c = cloud()
        if path == '/api/open':
            sess = session.load()
            if not sess:
                raise CloudError(0, 'not_signed_in', 'Please sign in.')
            user = sess['user']
            try:
                me = cloud(sess['token']).me(timeout=6)             # ask the server first: is this account still allowed?
                user = me.get('user') or user
                if user != sess['user']:
                    session.update(user=user)
            except Offline:
                pass                                                # no internet: open with the saved account, it syncs later
            except (AuthExpired, AccountBlocked) as e:
                stop_child()
                session.clear()
                raise CloudError(0, getattr(e, 'code', 'not_signed_in'), e.message)
            return self.send_json({'ok': True, 'url': start_module(user), 'user': user})
        if path == '/api/signout':
            sess = session.load()
            stop_child()
            if sess:
                try:
                    cloud(sess['token']).logout()
                except Exception:
                    pass
            session.clear()
            return self.send_json({'ok': True})
        if path == '/api/quit':
            self.send_json({'ok': True})
            threading.Thread(target=quit_all, daemon=True).start()
            return
        if path == '/api/refresh':
            G.health = None
            return self.send_json(state_json())
        if not c.configured():
            raise CloudError(0, 'not_configured', 'This copy of TaskDesk was not set up with a server. Please install TaskDesk again with the official setup file.')
        if path == '/api/login':
            r = c.login(str(b.get('username', '')), str(b.get('password', '')))
            if r.get('must_change_password'):
                # the owner gave a temporary password: choose a new one before anything else
                now = time.time()
                for k in [k for k, v in G.pending.items() if now - v['at'] > 600]:
                    G.pending.pop(k, None)
                ticket = secrets.token_hex(16)
                G.pending[ticket] = {'resp': r, 'old': str(b.get('password', '')), 'at': now}
                return self.send_json({'ok': True, 'must_change': True, 'ticket': ticket, 'name': r['user'].get('display_name') or r['user']['username']})
            return self.send_json(finish_auth(r, c))
        if path == '/api/change_password':
            p = G.pending.get(str(b.get('ticket', '')))
            if not p or time.time() - p['at'] > 600:
                raise CloudError(0, 'ticket_expired', 'This step took too long. Please sign in again.')
            c.token = p['resp']['token']
            c.change_password(p['old'], str(b.get('new_password', '')))
            G.pending.pop(str(b.get('ticket', '')), None)
            return self.send_json(finish_auth(p['resp'], c))
        if path == '/api/register':
            r = c.register(str(b.get('username', '')), str(b.get('password', '')), str(b.get('module', '')),
                           str(b.get('display_name', '')), str(b.get('invite', '')))
            if r.get('pending'):
                return self.send_json({'ok': True, 'pending': True, 'recovery_key': r.get('recovery_key', ''), 'user': r.get('user')})
            return self.send_json(finish_auth(r, c))
        if path == '/api/recover':
            r = c.recover(str(b.get('username', '')), str(b.get('recovery_key', '')), str(b.get('new_password', '')))
            return self.send_json({'ok': True, 'recovery_key': r.get('recovery_key', '')})
        return self.send_json({'error': 'Unknown endpoint'}, 404)

    def do_GET(self):
        self.handle_any('GET')

    def do_POST(self):
        self.handle_any('POST')

    def do_PUT(self):
        self.handle_any('PUT')

    def do_DELETE(self):
        self.handle_any('DELETE')


class GateServer(ThreadingHTTPServer):
    allow_reuse_address = not sys.platform.startswith('win')
    daemon_threads = True

    def server_bind(self):
        if sys.platform.startswith('win') and hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        ThreadingHTTPServer.server_bind(self)


def quit_all():
    time.sleep(0.3)
    stop_child()
    if G.httpd:
        G.httpd.shutdown()


def run_file():
    return os.path.join(paths.run_dir(), 'gate.json')


def existing_gate():
    info = paths.read_json(run_file())
    if info and info.get('port') and ping(info['port'], '/__gate/ping', 'taskdesk-gate'):
        return info
    return None


def watchdog(idle_seconds):
    while True:
        time.sleep(15)
        if child_alive():
            G.last_seen = time.time()
            continue
        if time.time() - G.last_seen > idle_seconds:
            threading.Thread(target=G.httpd.shutdown, daemon=True).start()
            return


def main():
    quiet_std()
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=0)
    ap.add_argument('--idle-exit', type=int, default=300)
    a = ap.parse_args()
    if existing_gate():
        return 0                                    # another gate is already running: the launcher will use it
    httpd = None
    for p in ([a.port] if a.port else PORT_RANGE + [0]):
        try:
            httpd = GateServer(('127.0.0.1', p), Handler)
            break
        except OSError:
            continue
    if httpd is None:
        sys.stderr.write('No free port for the TaskDesk gate.\n')
        return 1
    G.httpd = httpd
    G.port = httpd.server_address[1]
    G.key = secrets.token_hex(16)
    paths.write_json(run_file(), {'port': G.port, 'key': G.key, 'pid': os.getpid(), 'started': int(time.time())})
    threading.Thread(target=watchdog, args=(a.idle_exit,), daemon=True).start()
    sys.stdout.write('TASKDESK_GATE port=%d\n' % G.port)
    sys.stdout.flush()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop_child()
        try:
            info = paths.read_json(run_file())
            if info and info.get('pid') == os.getpid():
                os.remove(run_file())
        except Exception:
            pass
        httpd.server_close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
