# -*- coding: utf-8 -*-
"""
Checks that this Python can run TaskDesk. Used by the build script on the packaged Python, and handy for support:
    python selftest.py
Prints one line per check and exits with 1 when something is missing.
"""
import os
import sqlite3
import ssl
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

bad = 0


def ok(name, cond, extra=''):
    global bad
    print(('ok    ' if cond else 'FAIL  ') + name + (('  ' + str(extra)) if extra else ''))
    if not cond:
        bad += 1


def main():
    ok('Python 3.8 or newer', sys.version_info >= (3, 8), sys.version.split()[0])
    ok('SQLite 3.24 or newer (needed for upserts)', sqlite3.sqlite_version_info >= (3, 24), sqlite3.sqlite_version)
    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE t(id INTEGER PRIMARY KEY, v TEXT)')
    c.execute('INSERT INTO t(id,v) VALUES(1,"a") ON CONFLICT(id) DO UPDATE SET v=excluded.v')
    ok('SQLite upsert works', c.execute('SELECT v FROM t').fetchone()[0] == 'a')
    try:
        ctx = ssl.create_default_context()
        ok('HTTPS support and certificate store', ctx.verify_mode == ssl.CERT_REQUIRED and len(ctx.get_ca_certs()) >= 0)
    except Exception as e:
        ok('HTTPS support', False, e)
    from tmcore import paths, secure, session
    tmp = tempfile.mkdtemp(prefix='tdself_')
    os.environ['TASKDESK_HOME'] = tmp
    blob = secure.protect('secret-token-123')
    ok('sign-in protection round trip (%s)' % blob.split(':')[0], secure.unprotect(blob) == 'secret-token-123' and 'secret-token-123' not in blob)
    session.save('https://example.invalid/api.php', {'id': 1, 'username': 'x', 'module': 'mm'}, 'tok')
    ok('session save/load', (session.load() or {}).get('token') == 'tok')
    session.clear()
    ok('session clear', session.load() is None)
    bom = os.path.join(tmp, 'bom.json')
    with open(bom, 'wb') as f:
        f.write(b'\xef\xbb\xbf{"a": 1}')
    ok('JSON files saved with a BOM can be read', (paths.read_json(bom) or {}).get('a') == 1)
    mods = paths.modules()
    ok('modules found: %s' % ', '.join(sorted(mods)), len(mods) >= 1)
    for mid, m in mods.items():
        ok('module %s has screens and server' % mid, os.path.isfile(os.path.join(m['dir'], 'static', 'index.html')))
    ok('gate and shell screens present', os.path.isfile(os.path.join(paths.APP_ROOT, 'gate_static', 'index.html')) and os.path.isfile(os.path.join(paths.APP_ROOT, 'shell_static', 'shell.js')))
    ok('about.json readable', bool((paths.read_json(os.path.join(paths.APP_ROOT, 'about.json')) or {}).get('author')))
    ok('configuration found', bool(paths.config().get('cloud_url')), paths.config().get('cloud_url'))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(main())
