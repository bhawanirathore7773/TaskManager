# -*- coding: utf-8 -*-
"""Keeps the sign-in token unreadable for other Windows users and other programs.

Windows: DPAPI (CryptProtectData) - the token can only be opened by the same Windows user on the same PC.
Other systems (development only): a file with owner-only permissions.
"""
import base64
import os

_ENTROPY = b'TaskDesk.session.v1'


_BLOB = []


def _blob_class():
    if not _BLOB:
        import ctypes
        from ctypes import wintypes

        class DATA_BLOB(ctypes.Structure):
            _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_char))]
        _BLOB.append(DATA_BLOB)
    return _BLOB[0]


def _to_blob(data):
    import ctypes
    DATA_BLOB = _blob_class()
    buf = ctypes.create_string_buffer(data, len(data))
    return DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))), buf


def _dpapi(data, protect):
    import ctypes
    DATA_BLOB = _blob_class()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    src, keep1 = _to_blob(data)
    ent, keep2 = _to_blob(_ENTROPY)
    out = DATA_BLOB()
    if protect:
        ok = crypt32.CryptProtectData(ctypes.byref(src), 'TaskDesk', ctypes.byref(ent), None, None, 0, ctypes.byref(out))
    else:
        ok = crypt32.CryptUnprotectData(ctypes.byref(src), None, ctypes.byref(ent), None, None, 0, ctypes.byref(out))
    if not ok:
        raise OSError('Windows could not %s the saved sign-in.' % ('protect' if protect else 'open'))
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)
        del keep1, keep2


def protect(text):
    raw = text.encode('utf-8')
    if os.name == 'nt':
        return 'dpapi:' + base64.b64encode(_dpapi(raw, True)).decode('ascii')
    return 'plain:' + base64.b64encode(raw).decode('ascii')


def unprotect(blob):
    kind, _, body = (blob or '').partition(':')
    raw = base64.b64decode(body.encode('ascii'))
    if kind == 'dpapi':
        return _dpapi(raw, False).decode('utf-8')
    if kind == 'plain':
        return raw.decode('utf-8')
    raise ValueError('unknown protection type')
