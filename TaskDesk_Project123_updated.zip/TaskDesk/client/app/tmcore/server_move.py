# -*- coding: utf-8 -*-
"""
Follows the owner when the server moves to another address.

The server can announce a new address in its health answer (the owner sets it on the owner site). The app only
believes it after it has asked the new address and received the SAME server id, so a typing mistake on the owner
site, or a stranger's website, can never take the app away from the real server.
"""
from . import paths, session
from .cloud import Cloud


def _norm(u):
    return (u or '').strip().rstrip('/').lower()


def _allowed(url):
    u = (url or '').strip().lower()
    return u.startswith('https://') or u.startswith('http://127.0.0.1') or u.startswith('http://localhost')


def follow(current_base, health):
    """Returns the new address when the app switched to it, otherwise ''."""
    new = ((health or {}).get('api_url') or '').strip()
    sid = (health or {}).get('server_id') or ''
    if not new or not sid or _norm(new) == _norm(current_base) or not _allowed(new):
        return ''
    try:
        other = Cloud(new, None, paths.version()).health(timeout=8)
    except Exception:
        return ''
    if not other.get('ok') or other.get('server_id') != sid:
        return ''
    paths.save_user_config(cloud_url=new, cloud_url_base=paths.baked_cloud_url())
    sess = session.load()
    if sess:
        session.update(server=new)
    return new
