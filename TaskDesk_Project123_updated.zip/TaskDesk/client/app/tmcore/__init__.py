"""TaskDesk desktop core: session, cloud client, sync engine, gate and module host."""
