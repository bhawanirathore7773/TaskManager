# -*- coding: utf-8 -*-
"""
SAP BASIS / IT Task Manager - local server.

Pure Python standard library (no pip install needed). Python 3.9+.
Everything is stored locally in the "data" folder next to this file:
  data/taskmanager.db            -> SQLite database
  data/files/<kind>/<record>/..  -> photos, invoices, handover forms, documents of every record
  data/backups/                  -> automatic daily copies of the database

What it manages for the IT / BASIS lead of a multi-plant company:
  tickets (hardware, software, SAP, mail, network ...) and who in the team does them,
  stock + asset register with a full issue / return history,
  employees (joiner / leaver steps, mail id, SAP user, what was issued to whom),
  transport requests (TR) up to production, purchases, renewals (AMC, licences, warranty),
  daily / weekly / monthly checks per plant, and a report for the IT head.
"""
import contextlib
import datetime as dt
import io
import json
import mimetypes
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import traceback
import zipfile
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urlparse

APP_ID = 'basis-task-manager'
APP_VERSION = '1.0'
APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(APP_DIR, 'static')
DATA_DIR = os.environ.get('BASIS_TM_DATA') or os.path.join(APP_DIR, 'data')
FILES_DIR = os.path.join(DATA_DIR, 'files')
BACKUP_DIR = os.path.join(DATA_DIR, 'backups')
TRASH_DIR = os.path.join(DATA_DIR, 'trash')
DB_PATH = os.path.join(DATA_DIR, 'taskmanager.db')
DEFAULT_PORT = 8820            # launcher tries 8820-8830
MAX_UPLOAD = 500 * 1024 * 1024

# ----------------------------------------------------------------------------- vocabulary
TICKET_CATS = [
    ('hardware', 'Hardware (PC, laptop, mouse, keyboard...)'), ('software', 'Software / Windows / Office'), ('sap', 'SAP issue'),
    ('sap_user', 'SAP user request'), ('email', 'Email / mail id'), ('network', 'Network / Internet / WiFi / VPN'),
    ('camera', 'CCTV / Camera'), ('printer', 'Printer / Scanner / Barcode'), ('phone', 'Phone / Intercom / Mobile'),
    ('access', 'New joiner / Leaver / Access'), ('purchase', 'Purchase / Procurement'), ('other', 'Other'),
]
CAT_KEYS = [k for k, _ in TICKET_CATS]
SAP_REQ = [('create', 'Create user'), ('delete', 'Delete user'), ('lock', 'Lock user'), ('unlock', 'Unlock user'),
           ('password', 'Reset password'), ('role', 'Add / remove role'), ('extend', 'Extend validity'), ('other', 'Other')]
TICKET_STATUSES = [
    {'key': 'new', 'label': 'New', 'open': True},
    {'key': 'assigned', 'label': 'Assigned', 'open': True},
    {'key': 'progress', 'label': 'In progress', 'open': True},
    {'key': 'waiting', 'label': 'Waiting', 'open': True},
    {'key': 'done', 'label': 'Done - to be checked', 'open': False},
    {'key': 'closed', 'label': 'Closed', 'open': False},
    {'key': 'cancelled', 'label': 'Cancelled', 'open': False},
]
TS_MAP = {s['key']: s for s in TICKET_STATUSES}
OPEN_ST = ('new', 'assigned', 'progress', 'waiting')
PRIORITIES = ['critical', 'high', 'medium', 'low']
SOURCES = [('phone', 'Phone call'), ('whatsapp', 'WhatsApp'), ('walkin', 'Walk-in'), ('email', 'Email'), ('sap', 'SAP / system'), ('self', 'Found by IT')]
ASSET_KINDS = [
    ('laptop', 'Laptop', 0), ('desktop', 'Desktop PC', 0), ('monitor', 'Monitor', 0), ('printer', 'Printer / Scanner', 0),
    ('barcode', 'Barcode scanner', 0), ('phone', 'Phone / Mobile', 0), ('camera', 'CCTV camera', 0), ('recorder', 'DVR / NVR', 0),
    ('network', 'Switch / Router / AP', 0), ('ups', 'UPS', 0), ('mouse', 'Mouse', 1), ('keyboard', 'Keyboard', 1),
    ('cable', 'Cable / Adapter', 1), ('storage', 'Pen drive / HDD', 1), ('other', 'Other', 0),
]
KIND_KEYS = [k for k, _, _ in ASSET_KINDS]
BULK_KINDS = {k for k, _, b in ASSET_KINDS if b}
ASSET_STATUS = [('in_stock', 'In stock'), ('issued', 'Issued'), ('deployed', 'Deployed at a place'), ('repair', 'In repair'), ('scrap', 'Scrapped'), ('lost', 'Lost')]
CONDITIONS = [('new', 'New'), ('good', 'Good'), ('fair', 'Fair'), ('poor', 'Poor')]
PERSON_KINDS = [('employee', 'Employee'), ('operator', 'Operator / shop floor'), ('contractor', 'Contractor'), ('trainee', 'Trainee')]
ACCOUNT_KINDS = [('email', 'Mail id'), ('sap', 'SAP user'), ('domain', 'Windows / domain login'), ('vpn', 'VPN / WiFi'), ('other', 'Other')]
TR_STATUS = [('requested', 'Requested'), ('approved', 'Approved'), ('qas', 'In QAS (testing)'), ('prd', 'Moved to PRD'),
             ('failed', 'Failed'), ('rejected', 'Rejected'), ('hold', 'On hold')]
BUY_STATUS = [('requested', 'Requested'), ('approved', 'Approved'), ('ordered', 'Ordered'), ('received', 'Received'), ('cancelled', 'Cancelled')]
RENEW_KINDS = [('amc', 'AMC / service contract'), ('licence', 'Software licence'), ('domain', 'Domain / hosting'), ('ssl', 'SSL certificate'),
               ('isp', 'Internet line'), ('antivirus', 'Antivirus'), ('warranty', 'Warranty'), ('other', 'Other')]
FREQ = [('daily', 'Every working day'), ('weekly', 'Weekly'), ('monthly', 'Monthly')]

CATS = {'photo': '1_Photos', 'invoice': '2_Invoice_Warranty', 'handover': '3_Handover_Forms', 'doc': '4_Documents', 'other': '5_Other'}
CAT_LABELS = {'photo': 'Photo / screenshot', 'invoice': 'Invoice / warranty', 'handover': 'Handover form', 'doc': 'Document', 'other': 'Other'}
FOLDER_TABLES = ['tickets', 'assets', 'people', 'transports', 'purchases', 'renewals']      # tables that own a 'folder' column (restored on a new PC)
PARENT_TABLE = {'ticket': 'tickets', 'asset': 'assets', 'person': 'people', 'transport': 'transports', 'purchase': 'purchases', 'renewal': 'renewals'}

DEFAULT_PLANTS = [{'code': '1100', 'name': 'Jaitpura Plant'}, {'code': '1200', 'name': 'Dhodhsar Plant'}, {'code': '1600', 'name': 'Gavalior Plant'}]
TPL_JOIN = ['Laptop / PC issued', 'Mouse and keyboard issued', 'Mail id created', 'SAP user created (roles as approved by HOD)',
            'Windows / domain login', 'Phone / extension', 'VPN / WiFi access (if needed)', 'Handover slip signed by the employee']
TPL_LEAVE = ['Laptop / PC and accessories collected', 'Mail id disabled (mails forwarded to the manager)', 'SAP user locked / deleted',
             'Windows / domain / VPN login disabled', 'Data backed up and handed over', 'Removed from mail groups', 'Handover slip closed']
DEFAULT_SETTINGS = {
    'manager': 'Hameer Singh', 'hod': '', 'company': '',
    'plants': json.dumps(DEFAULT_PLANTS),
    'sla_critical': '4', 'sla_high': '8', 'sla_medium': '24', 'sla_low': '72',
    'min_stock': json.dumps({'laptop': 2, 'desktop': 2, 'monitor': 2}),
    'renew_days': '30', 'tr_need_approval': '1', 'work_days': '0,1,2,3,4,5', 'wa_prefix': '91',
    'tpl_join': '\n'.join(TPL_JOIN), 'tpl_leave': '\n'.join(TPL_LEAVE),
}
SERVER = {'last_seen': time.time(), 'httpd': None}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS team(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, plant TEXT DEFAULT '', role TEXT DEFAULT '', mobile TEXT DEFAULT '', email TEXT DEFAULT '',
  active INTEGER DEFAULT 1, note TEXT DEFAULT '', is_demo INTEGER DEFAULT 0, created_at TEXT
);
CREATE TABLE IF NOT EXISTS people(
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, folder TEXT,
  emp_code TEXT DEFAULT '', name TEXT NOT NULL, department TEXT DEFAULT '', designation TEXT DEFAULT '',
  plant TEXT DEFAULT '', kind TEXT DEFAULT 'employee', status TEXT DEFAULT 'active',
  mobile TEXT DEFAULT '', email TEXT DEFAULT '', reports_to TEXT DEFAULT '', location TEXT DEFAULT '',
  joined_on TEXT, left_on TEXT, note TEXT DEFAULT '', is_demo INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS accounts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  person_id INTEGER, owner_name TEXT DEFAULT '', kind TEXT DEFAULT 'email', identifier TEXT NOT NULL, system TEXT DEFAULT '',
  roles TEXT DEFAULT '', status TEXT DEFAULT 'active', created_on TEXT, valid_to TEXT, ended_on TEXT, created_by TEXT DEFAULT '',
  ticket_id INTEGER, note TEXT DEFAULT '', is_demo INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS steps(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  person_id INTEGER NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  flow TEXT DEFAULT 'join', text TEXT NOT NULL, done INTEGER DEFAULT 0, done_at TEXT, done_by TEXT DEFAULT '',
  sort INTEGER DEFAULT 0, note TEXT DEFAULT '', is_demo INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS assets(
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, folder TEXT,
  kind TEXT DEFAULT 'laptop', name TEXT DEFAULT '', tag TEXT DEFAULT '', serial TEXT DEFAULT '',
  tracked INTEGER DEFAULT 1, qty INTEGER DEFAULT 1, qty_free INTEGER DEFAULT 1, min_qty INTEGER DEFAULT 0,
  status TEXT DEFAULT 'in_stock', cond TEXT DEFAULT 'new', plant TEXT DEFAULT '', location TEXT DEFAULT '',
  person_id INTEGER, since TEXT, purchase_date TEXT, vendor TEXT DEFAULT '', cost REAL, warranty_until TEXT,
  specs TEXT DEFAULT '', note TEXT DEFAULT '', is_demo INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS asset_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  asset_id INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  person_id INTEGER, location TEXT DEFAULT '', ts TEXT, kind TEXT, qty INTEGER DEFAULT 1, cond TEXT DEFAULT '',
  text TEXT DEFAULT '', who TEXT DEFAULT '', ticket_id INTEGER, is_demo INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS tickets(
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, folder TEXT,
  title TEXT NOT NULL, details TEXT DEFAULT '', category TEXT DEFAULT 'hardware', sub TEXT DEFAULT '', req_type TEXT DEFAULT '',
  plant TEXT DEFAULT '', requester TEXT DEFAULT '', person_id INTEGER, department TEXT DEFAULT '', contact TEXT DEFAULT '', asset_id INTEGER,
  priority TEXT DEFAULT 'medium', status TEXT DEFAULT 'new', assigned_to INTEGER, assigned_on TEXT, source TEXT DEFAULT 'phone',
  received_at TEXT, due_at TEXT, started_at TEXT, waiting_for TEXT DEFAULT '', follow_up_on TEXT,
  done_at TEXT, closed_at TEXT, resolution TEXT DEFAULT '', verify_note TEXT DEFAULT '',
  is_demo INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS transports(
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, folder TEXT,
  tr_number TEXT DEFAULT '', description TEXT NOT NULL, owner_name TEXT DEFAULT '', requested_by TEXT DEFAULT '', requested_on TEXT,
  source_sys TEXT DEFAULT 'DEV', priority TEXT DEFAULT 'normal', depends_on TEXT DEFAULT '',
  approver TEXT DEFAULT '', approved_on TEXT, status TEXT DEFAULT 'requested',
  qas_on TEXT, qas_by TEXT DEFAULT '', prd_on TEXT, prd_by TEXT DEFAULT '', rc TEXT DEFAULT '',
  ticket_id INTEGER, note TEXT DEFAULT '', is_demo INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS purchases(
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, folder TEXT,
  item TEXT NOT NULL, kind TEXT DEFAULT 'laptop', qty INTEGER DEFAULT 1, reason TEXT DEFAULT '', person_id INTEGER, ticket_id INTEGER,
  plant TEXT DEFAULT '', requested_on TEXT, approved_by TEXT DEFAULT '', approved_on TEXT, status TEXT DEFAULT 'requested',
  vendor TEXT DEFAULT '', po_no TEXT DEFAULT '', expected_on TEXT, received_on TEXT, cost REAL, note TEXT DEFAULT '',
  is_demo INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS renewals(
  id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE, folder TEXT,
  title TEXT NOT NULL, kind TEXT DEFAULT 'amc', vendor TEXT DEFAULT '', plant TEXT DEFAULT '', starts_on TEXT, expires_on TEXT,
  remind_days INTEGER, cost REAL, owner_id INTEGER, status TEXT DEFAULT 'active', note TEXT DEFAULT '',
  is_demo INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS routines(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL, plant TEXT DEFAULT '', frequency TEXT DEFAULT 'daily', weekday INTEGER DEFAULT 0, month_day INTEGER DEFAULT 1,
  assigned_to INTEGER, active INTEGER DEFAULT 1, note TEXT DEFAULT '', sort INTEGER DEFAULT 0, created_on TEXT, is_demo INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS routine_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  routine_id INTEGER NOT NULL REFERENCES routines(id) ON DELETE CASCADE,
  on_date TEXT, status TEXT DEFAULT 'ok', by_id INTEGER, note TEXT DEFAULT '', ts TEXT, ticket_id INTEGER, is_demo INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS files(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_kind TEXT, parent_id INTEGER, category TEXT, filename TEXT, rel_path TEXT, size INTEGER,
  note TEXT DEFAULT '', uploaded_at TEXT
);
CREATE TABLE IF NOT EXISTS history(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT, ent TEXT, ent_id INTEGER, kind TEXT, text TEXT, who TEXT DEFAULT '',
  person_id INTEGER, asset_id INTEGER, ticket_id INTEGER, is_demo INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_t_status ON tickets(status);
CREATE INDEX IF NOT EXISTS ix_t_person ON tickets(person_id);
CREATE INDEX IF NOT EXISTS ix_t_asset ON tickets(asset_id);
CREATE INDEX IF NOT EXISTS ix_al_asset ON asset_log(asset_id);
CREATE INDEX IF NOT EXISTS ix_al_person ON asset_log(person_id);
CREATE INDEX IF NOT EXISTS ix_acc_person ON accounts(person_id);
CREATE INDEX IF NOT EXISTS ix_st_person ON steps(person_id);
CREATE INDEX IF NOT EXISTS ix_rl_routine ON routine_log(routine_id, on_date);
CREATE INDEX IF NOT EXISTS ix_f_parent ON files(parent_kind, parent_id);
CREATE INDEX IF NOT EXISTS ix_h_ent ON history(ent, ent_id);
CREATE INDEX IF NOT EXISTS ix_h_person ON history(person_id);
CREATE INDEX IF NOT EXISTS ix_h_asset ON history(asset_id);
CREATE INDEX IF NOT EXISTS ix_h_ticket ON history(ticket_id);
"""

# column types for every field a client may write:  t text  T long text  d date  m date+time  i integer  k link to another record (0/blank = none)
#   a assignee (0 = the manager himself, blank = nobody)  r real  b 0/1
FIELDS = {
    'team': {'name': 't', 'plant': 't', 'role': 't', 'mobile': 't', 'email': 't', 'active': 'b', 'note': 'T'},
    'people': {'emp_code': 't', 'name': 't', 'department': 't', 'designation': 't', 'plant': 't', 'kind': 't', 'status': 't', 'mobile': 't', 'email': 't',
               'reports_to': 't', 'location': 't', 'joined_on': 'd', 'left_on': 'd', 'note': 'T'},
    'accounts': {'person_id': 'k', 'owner_name': 't', 'kind': 't', 'identifier': 't', 'system': 't', 'roles': 'T', 'status': 't', 'created_on': 'd',
                 'valid_to': 'd', 'ended_on': 'd', 'created_by': 't', 'ticket_id': 'k', 'note': 'T'},
    'assets': {'kind': 't', 'name': 't', 'tag': 't', 'serial': 't', 'tracked': 'b', 'qty': 'i', 'min_qty': 'i', 'cond': 't', 'plant': 't', 'location': 't',
               'purchase_date': 'd', 'vendor': 't', 'cost': 'r', 'warranty_until': 'd', 'specs': 'T', 'note': 'T'},
    'tickets': {'title': 't', 'details': 'T', 'category': 't', 'sub': 't', 'req_type': 't', 'plant': 't', 'requester': 't', 'person_id': 'k', 'department': 't',
                'contact': 't', 'asset_id': 'k', 'priority': 't', 'source': 't', 'received_at': 'm', 'due_at': 'm', 'waiting_for': 't', 'follow_up_on': 'd',
                'resolution': 'T'},
    'transports': {'tr_number': 't', 'description': 't', 'owner_name': 't', 'requested_by': 't', 'requested_on': 'd', 'source_sys': 't', 'priority': 't',
                   'depends_on': 't', 'approver': 't', 'ticket_id': 'k', 'note': 'T', 'rc': 't'},
    'purchases': {'item': 't', 'kind': 't', 'qty': 'i', 'reason': 'T', 'person_id': 'k', 'ticket_id': 'k', 'plant': 't', 'requested_on': 'd', 'approved_by': 't',
                  'vendor': 't', 'po_no': 't', 'expected_on': 'd', 'cost': 'r', 'note': 'T'},
    'renewals': {'title': 't', 'kind': 't', 'vendor': 't', 'plant': 't', 'starts_on': 'd', 'expires_on': 'd', 'remind_days': 'i', 'cost': 'r', 'owner_id': 'a',
                 'note': 'T'},
    'routines': {'title': 't', 'plant': 't', 'frequency': 't', 'weekday': 'i', 'month_day': 'i', 'assigned_to': 'a', 'active': 'b', 'note': 'T', 'sort': 'i'},
}
ENUMS = {
    ('tickets', 'category'): CAT_KEYS, ('tickets', 'priority'): PRIORITIES, ('tickets', 'source'): [k for k, _ in SOURCES],
    ('tickets', 'req_type'): [''] + [k for k, _ in SAP_REQ],
    ('people', 'kind'): [k for k, _ in PERSON_KINDS], ('people', 'status'): ['joining', 'active', 'left'],
    ('accounts', 'kind'): [k for k, _ in ACCOUNT_KINDS], ('accounts', 'status'): ['active', 'locked', 'deleted'],
    ('assets', 'kind'): KIND_KEYS, ('assets', 'cond'): [k for k, _ in CONDITIONS],
    ('transports', 'priority'): ['normal', 'urgent'],
    ('purchases', 'kind'): KIND_KEYS,
    ('renewals', 'kind'): [k for k, _ in RENEW_KINDS],
    ('routines', 'frequency'): [k for k, _ in FREQ],
}


# ----------------------------------------------------------------------------- xlsx writer / reader (stdlib only)
ILLEGAL_XML = re.compile('[\x00-\x08\x0b\x0c\x0e-\x1f]')


def xl_col(i):
    s = ''
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def xl_idx(letters):
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def xesc(v):
    v = ILLEGAL_XML.sub('', str(v))
    return v.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def sheet_xml(headers, rows):
    all_rows = [headers] + rows
    n = len(headers)
    widths = []
    for i in range(n):
        longest = 0
        for r in all_rows[:300]:
            v = r[i] if i < len(r) else None
            if v is None:
                continue
            longest = max(longest, max(len(x) for x in str(v).split('\n')))
        widths.append(min(60, max(8, longest + 2)))
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>',
           '<sheetFormatPr defaultRowHeight="15"/>',
           '<cols>%s</cols>' % ''.join('<col min="%d" max="%d" width="%d" customWidth="1"/>' % (i + 1, i + 1, w) for i, w in enumerate(widths)),
           '<sheetData>']
    for ri, row in enumerate(all_rows, 1):
        out.append('<row r="%d">' % ri)
        for ci in range(n):
            v = row[ci] if ci < len(row) else None
            ref = '%s%d' % (xl_col(ci), ri)
            if ri == 1:
                out.append('<c r="%s" t="inlineStr" s="1"><is><t xml:space="preserve">%s</t></is></c>' % (ref, xesc(v)))
            elif v is None or v == '':
                continue
            elif isinstance(v, (int, float)) and not isinstance(v, bool):
                out.append('<c r="%s"><v>%s</v></c>' % (ref, repr(v)))
            else:
                out.append('<c r="%s" t="inlineStr" s="2"><is><t xml:space="preserve">%s</t></is></c>' % (ref, xesc(v)))
        out.append('</row>')
    out.append('</sheetData>')
    out.append('<autoFilter ref="A1:%s%d"/>' % (xl_col(n - 1), len(all_rows)))
    out.append('</worksheet>')
    return ''.join(out)


STYLES_XML = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
              '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>'
              '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>'
              '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FF1F3A5F"/><bgColor indexed="64"/></patternFill></fill></fills>'
              '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
              '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'
              '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>'
              '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')


def build_xlsx(sheets):
    """sheets = [(name, headers, rows)]"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
              '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
              '<Default Extension="xml" ContentType="application/xml"/>',
              '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
              '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
        wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
              '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>']
        rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
        for i, (name, headers, rows) in enumerate(sheets, 1):
            nm = re.sub(r'[\[\]:*?/\\]', ' ', name)[:31]
            ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % i)
            wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (xesc(nm), i, i))
            rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i, i))
            z.writestr('xl/worksheets/sheet%d.xml' % i, sheet_xml(headers, rows))
        n = len(sheets)
        rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (n + 1))
        ct.append('</Types>')
        wb.append('</sheets></workbook>')
        z.writestr('[Content_Types].xml', ''.join(ct))
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', ''.join(wb))
        z.writestr('xl/_rels/workbook.xml.rels', ''.join(rels))
        z.writestr('xl/styles.xml', STYLES_XML)
    return buf.getvalue()


def read_xlsx(path, sheet_idx=0, max_rows=300, max_cols=40):
    ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
          'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    M = '{%s}' % ns['m']
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        sheets = [(s.get('name'), s.get('{%s}id' % ns['r'])) for s in wb.find('m:sheets', ns)]
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        rmap = {r.get('Id'): r.get('Target') for r in rels}
        sheet_idx = max(0, min(sheet_idx, len(sheets) - 1))
        target = rmap[sheets[sheet_idx][1]]
        spath = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        shared = []
        if 'xl/sharedStrings.xml' in names:
            sst = ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in sst.findall('m:si', ns):
                shared.append(''.join(t.text or '' for t in si.iter(M + 't')))
        ws = ET.fromstring(z.read(spath))
        rows = []
        for row in ws.find('m:sheetData', ns).findall('m:row', ns)[:max_rows]:
            cells = {}
            for c in row.findall('m:c', ns):
                ref = c.get('r') or ''
                m = re.match(r'[A-Z]+', ref)
                if not m:
                    continue
                ci = xl_idx(m.group())
                t = c.get('t')
                v = c.find('m:v', ns)
                if t == 's' and v is not None and v.text is not None:
                    val = shared[int(v.text)] if int(v.text) < len(shared) else ''
                elif t == 'inlineStr':
                    val = ''.join(x.text or '' for x in c.iter(M + 't'))
                elif v is not None and v.text is not None:
                    val = v.text
                    if re.fullmatch(r'-?\d+\.0+', val):
                        val = val.split('.')[0]
                else:
                    val = ''
                cells[ci] = val
            width = (max(cells) + 1) if cells else 0
            rows.append([cells.get(i, '') for i in range(min(width, max_cols))])
        return {'type': 'sheet', 'sheets': [s[0] for s in sheets], 'sheet': sheet_idx, 'rows': rows}



# ----------------------------------------------------------------------------- routing
# ----------------------------------------------------------------------------- routing
ROUTES = []


def route(method, pattern):
    def deco(fn):
        ROUTES.append((method, re.compile('^' + pattern + '$'), fn))
        return fn
    return deco


class ApiError(Exception):
    def __init__(self, status, msg):
        Exception.__init__(self, msg)
        self.status = status
        self.msg = msg



# ----------------------------------------------------------------------------- helpers
def now_ts():
    return dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def now_min():
    return dt.datetime.now().strftime('%Y-%m-%d %H:%M')


def today_date():
    return dt.date.today()


def today_iso():
    return today_date().isoformat()


def jloads(s, default=None):
    try:
        v = json.loads(s) if s else None
    except Exception:
        v = None
    if v is None:
        return {} if default is None else default
    return v


def parse_d(s):
    try:
        return dt.date.fromisoformat(str(s)[:10]) if s else None
    except Exception:
        return None


def clean_date(v):
    d = parse_d(v) if isinstance(v, str) else None
    return d.isoformat() if d else None


def parse_dt(s):
    if not s:
        return None
    s = str(s).replace('T', ' ')[:19]
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d'):
        try:
            return dt.datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def clean_dt(v):
    d = parse_dt(v) if isinstance(v, str) else None
    return d.strftime('%Y-%m-%d %H:%M') if d else None


def safe_name(name, default='file'):
    name = os.path.basename((name or '').replace('\\', '/'))
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name).strip(' .')
    return name[:150] or default


def unique_path(folder, name):
    base, ext = os.path.splitext(name)
    p = os.path.join(folder, name)
    n = 2
    while os.path.exists(p):
        p = os.path.join(folder, '%s_%d%s' % (base, n, ext))
        n += 1
    return p


def guess_category(name):
    ext = os.path.splitext(name)[1].lower()
    if ext in ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.heic'):
        return 'photo'
    if ext in ('.pdf', '.doc', '.docx', '.xls', '.xlsx', '.csv', '.txt', '.ppt', '.pptx'):
        return 'doc'
    return 'other'


@contextlib.contextmanager
def dbc():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def row_dicts(rows):
    return [dict(r) for r in rows]


def lc(s):
    return str(s or '').strip().lower()


# ----------------------------------------------------------------------------- settings
def get_settings(conn):
    s = dict(DEFAULT_SETTINGS)
    for r in conn.execute('SELECT key,value FROM settings'):
        s[r['key']] = r['value']
    return s


def plants_of(st):
    try:
        v = json.loads(st.get('plants') or '[]')
        out = [{'code': str(p.get('code', '')).strip(), 'name': str(p.get('name', '')).strip()} for p in v if isinstance(p, dict) and str(p.get('code', '')).strip()]
        return out or list(DEFAULT_PLANTS)
    except Exception:
        return list(DEFAULT_PLANTS)


def plant_label(st, code):
    for p in plants_of(st):
        if p['code'] == code:
            return '%s - %s' % (p['code'], p['name']) if p['name'] else p['code']
    return code or ''


def work_days_of(st):
    out = set()
    for x in str(st.get('work_days', '')).split(','):
        x = x.strip()
        if x.isdigit() and 0 <= int(x) <= 6:
            out.add(int(x))
    return out or {0, 1, 2, 3, 4, 5}


def min_stock_of(st):
    try:
        v = json.loads(st.get('min_stock') or '{}')
        return {k: int(n) for k, n in v.items() if k in KIND_KEYS and int(n) > 0}
    except Exception:
        return {}


def sla_due(st, prio, start=None):
    try:
        h = float(st.get('sla_' + prio) or 24)
    except ValueError:
        h = 24.0
    return ((start or dt.datetime.now()) + dt.timedelta(hours=h)).strftime('%Y-%m-%d %H:%M')


def team_map(conn):
    return {r['id']: dict(r) for r in conn.execute('SELECT * FROM team')}


def who_name(tm, st, tid):
    if tid is None or tid == '':
        return ''
    tid = int(tid)
    if tid == 0:
        return st.get('manager') or 'Me'
    r = tm.get(tid)
    return r['name'] if r else '(removed)'


def need(row, what='Record'):
    if not row:
        raise ApiError(404, '%s not found' % what)
    return row


# ----------------------------------------------------------------------------- generic record helpers
_COLS = {}


def cols_of(conn, t):
    if t not in _COLS:
        _COLS[t] = [r[1] for r in conn.execute('PRAGMA table_info(%s)' % t)]
    return _COLS[t]


def clean(table, d):
    """Takes only the fields a client may write, trims and validates them."""
    out = {}
    for k, t in FIELDS[table].items():
        if k not in d:
            continue
        v = d[k]
        if t in ('t', 'T'):
            v = '' if v is None else str(v).strip()
            v = v[:200] if t == 't' else v[:20000]
            en = ENUMS.get((table, k))
            if en is not None and v not in en:
                raise ApiError(400, 'Invalid value "%s" for %s' % (v, k.replace('_', ' ')))
        elif t == 'd':
            if v in (None, ''):
                v = None
            else:
                v = clean_date(str(v))
                if not v:
                    raise ApiError(400, 'Invalid date in "%s"' % k.replace('_', ' '))
        elif t == 'm':
            if v in (None, ''):
                v = None
            else:
                v = clean_dt(str(v))
                if not v:
                    raise ApiError(400, 'Invalid date / time in "%s"' % k.replace('_', ' '))
        elif t in ('i', 'k', 'a'):
            if v in (None, ''):
                v = None
            else:
                try:
                    v = int(float(v))
                except (TypeError, ValueError):
                    raise ApiError(400, 'Invalid number in "%s"' % k.replace('_', ' '))
                if t == 'k' and v == 0:
                    v = None
                if t == 'i' and v < 0:
                    raise ApiError(400, '"%s" cannot be negative' % k.replace('_', ' '))
        elif t == 'r':
            if v in (None, ''):
                v = None
            else:
                try:
                    v = float(v)
                except (TypeError, ValueError):
                    raise ApiError(400, 'Invalid amount in "%s"' % k.replace('_', ' '))
        elif t == 'b':
            v = 1 if v in (1, True, '1', 'true', 'on', 'yes') else 0
        out[k] = v
    return out


def ins(conn, table, vals, demo=False):
    cols = cols_of(conn, table)
    v = dict(vals)
    ts = now_ts()
    if 'created_at' in cols:
        v.setdefault('created_at', ts)
    if 'updated_at' in cols:
        v.setdefault('updated_at', ts)
    if 'is_demo' in cols:
        v['is_demo'] = 1 if demo else 0
    names = list(v.keys())
    cur = conn.execute('INSERT INTO %s(%s) VALUES(%s)' % (table, ','.join(names), ','.join('?' * len(names))), [v[n] for n in names])
    return cur.lastrowid


def upd(conn, table, rid, vals):
    v = dict(vals)
    if 'updated_at' in cols_of(conn, table):
        v['updated_at'] = now_ts()
    if not v:
        return
    conn.execute('UPDATE %s SET %s WHERE id=?' % (table, ','.join('%s=?' % k for k in v)), list(v.values()) + [rid])


def make_dirs(folder):
    base = os.path.join(FILES_DIR, folder)
    for sub in CATS.values():
        os.makedirs(os.path.join(base, sub), exist_ok=True)


def finish_code(conn, table, rid, prefix, slug_src):
    code = '%s-%04d' % (prefix, rid)
    slug = re.sub(r'[^A-Za-z0-9]+', '_', slug_src or '').strip('_')[:40] or 'item'
    folder = '%s/%s_%s' % (table, code, slug)
    conn.execute('UPDATE %s SET code=?, folder=? WHERE id=?' % table, (code, folder, rid))
    make_dirs(folder)
    return code


def hist(conn, ent, ent_id, kind, text, who='', person_id=None, asset_id=None, ticket_id=None, demo=False):
    if ent == 'ticket' and ticket_id is None:
        ticket_id = ent_id
    if ent == 'asset' and asset_id is None:
        asset_id = ent_id
    if ent == 'person' and person_id is None:
        person_id = ent_id
    conn.execute('INSERT INTO history(ts,ent,ent_id,kind,text,who,person_id,asset_id,ticket_id,is_demo) VALUES(?,?,?,?,?,?,?,?,?,?)',
                 (now_ts(), ent, ent_id, kind, text, who or '', person_id, asset_id, ticket_id, 1 if demo else 0))


def diff_text(old, new, labels):
    out = []
    for k, label in labels.items():
        if k in new and (old[k] if old[k] is not None else '') != (new[k] if new[k] is not None else ''):
            a = '' if old[k] is None else str(old[k])
            b = '' if new[k] is None else str(new[k])
            out.append('%s: %s → %s' % (label, a[:60] or '(empty)', b[:60] or '(empty)'))
    return out


def person_brief(conn, pid):
    if not pid:
        return None
    r = conn.execute('SELECT id, code, name, emp_code, department, plant, status, email, mobile FROM people WHERE id=?', (pid,)).fetchone()
    return dict(r) if r else None


def list_files(conn, kind, pid):
    return row_dicts(conn.execute('SELECT * FROM files WHERE parent_kind=? AND parent_id=? ORDER BY id DESC', (kind, pid)))


def history_of(conn, where, params, limit=300):
    return row_dicts(conn.execute('SELECT * FROM history WHERE %s ORDER BY id DESC LIMIT %d' % (where, limit), params))


def trash_folder(folder):
    if not folder:
        return
    p = os.path.abspath(os.path.join(FILES_DIR, folder))
    if p.startswith(os.path.abspath(FILES_DIR) + os.sep) and os.path.isdir(p):
        try:
            os.makedirs(TRASH_DIR, exist_ok=True)
            shutil.move(p, unique_path(TRASH_DIR, '%s__%s' % (dt.datetime.now().strftime('%Y%m%d_%H%M%S'), os.path.basename(p))))
        except Exception:
            shutil.rmtree(p, ignore_errors=True)


def drop_record_files(conn, kind, rid, folder):
    conn.execute('DELETE FROM files WHERE parent_kind=? AND parent_id=?', (kind, rid))
    trash_folder(folder)


# ----------------------------------------------------------------------------- tickets
TICKET_SQL = """
SELECT t.*, p.name AS person_name, p.code AS person_code, a.code AS asset_code, a.name AS asset_name, a.tag AS asset_tag,
 (SELECT COUNT(*) FROM files f WHERE f.parent_kind='ticket' AND f.parent_id=t.id) AS n_files
FROM tickets t LEFT JOIN people p ON p.id=t.person_id LEFT JOIN assets a ON a.id=t.asset_id
"""
TICKET_LABELS = {'title': 'Title', 'category': 'Category', 'sub': 'Item', 'priority': 'Priority', 'plant': 'Plant', 'requester': 'Requested by',
                 'department': 'Department', 'due_at': 'Due', 'person_id': 'Employee', 'asset_id': 'Asset', 'req_type': 'Request type',
                 'contact': 'Contact', 'source': 'Received by'}


def enrich_ticket(r, tm, st, now=None):
    t = dict(r)
    now = now or dt.datetime.now()
    t['assignee'] = who_name(tm, st, t['assigned_to'])
    t['is_open'] = t['status'] in OPEN_ST
    due = parse_dt(t['due_at'])
    t['overdue'] = bool(t['is_open'] and due and due < now)
    t['hours_left'] = round((due - now).total_seconds() / 3600.0, 1) if (t['is_open'] and due) else None
    rec = parse_dt(t['received_at']) or parse_dt(t['created_at']) or now
    end = parse_dt(t['closed_at']) if t['closed_at'] else (now if t['status'] not in ('cancelled',) else None)
    t['age_hours'] = round((end - rec).total_seconds() / 3600.0, 1) if end else None
    t['sla_met'] = None
    if t['status'] == 'closed' and due and t['closed_at']:
        t['sla_met'] = bool(parse_dt(t['closed_at']) <= due)
    t['follow_due'] = bool(t['follow_up_on'] and t['follow_up_on'] <= today_iso() and t['status'] in OPEN_ST + ('done',))
    upd_at = parse_dt(t['updated_at'])
    t['quiet_days'] = int((now - upd_at).total_seconds() // 86400) if (upd_at and t['status'] in ('assigned', 'progress')) else 0
    return t


def list_tickets(conn, where='', params=()):
    st = get_settings(conn)
    tm = team_map(conn)
    now = dt.datetime.now()
    return [enrich_ticket(r, tm, st, now) for r in conn.execute(TICKET_SQL + where, params)]


def ticket_detail(conn, tid):
    st = get_settings(conn)
    tm = team_map(conn)
    r = need(conn.execute(TICKET_SQL + ' WHERE t.id=?', (tid,)).fetchone(), 'Ticket')
    t = enrich_ticket(r, tm, st)
    t['history'] = history_of(conn, "ent='ticket' AND ent_id=?", (tid,))
    t['files'] = list_files(conn, 'ticket', tid)
    t['person'] = person_brief(conn, t['person_id'])
    t['asset'] = None
    if t['asset_id']:
        a = conn.execute('SELECT id, code, name, tag, serial, kind, status FROM assets WHERE id=?', (t['asset_id'],)).fetchone()
        t['asset'] = dict(a) if a else None
    rel_q, rel_p = [], [tid]
    if t['person_id']:
        rel_q.append('t.person_id=?')
        rel_p.append(t['person_id'])
    if t['asset_id']:
        rel_q.append('t.asset_id=?')
        rel_p.append(t['asset_id'])
    t['related'] = []
    if rel_q:
        rows = conn.execute(TICKET_SQL + ' WHERE t.id<>? AND (%s) ORDER BY t.id DESC LIMIT 12' % ' OR '.join(rel_q), rel_p)
        t['related'] = [enrich_ticket(x, tm, st) for x in rows]
    t['wa_text'] = None
    return t


def check_assignee(conn, to):
    if to in (None, ''):
        return None
    to = int(to)
    if to == 0:
        return 0
    r = conn.execute('SELECT id, active FROM team WHERE id=?', (to,)).fetchone()
    if not r:
        raise ApiError(400, 'That team member does not exist')
    return to


def create_ticket(conn, d, demo=False):
    st = get_settings(conn)
    vals = clean('tickets', d)
    if not (vals.get('title') or '').strip():
        raise ApiError(400, 'Write what the problem is (title)')
    vals.setdefault('category', 'hardware')
    vals.setdefault('priority', 'medium')
    vals.setdefault('source', 'phone')
    if vals.get('person_id'):
        p = need(conn.execute('SELECT * FROM people WHERE id=?', (vals['person_id'],)).fetchone(), 'Employee')
        vals['requester'] = vals.get('requester') or p['name']
        vals['plant'] = vals.get('plant') or p['plant']
        vals['department'] = vals.get('department') or p['department']
        vals['contact'] = vals.get('contact') or p['mobile']
    if vals.get('asset_id'):
        a = need(conn.execute('SELECT * FROM assets WHERE id=?', (vals['asset_id'],)).fetchone(), 'Asset')
        vals['plant'] = vals.get('plant') or a['plant']
    if vals['category'] != 'sap_user':
        vals['req_type'] = ''
    vals['received_at'] = vals.get('received_at') or now_min()
    vals['due_at'] = vals.get('due_at') or sla_due(st, vals['priority'], parse_dt(vals['received_at']))
    vals['status'] = 'new'
    to = check_assignee(conn, d.get('assigned_to')) if 'assigned_to' in d else None
    if to is not None:
        vals['assigned_to'] = to
        vals['assigned_on'] = now_ts()
        vals['status'] = 'assigned'
    solved = bool(d.get('solved'))
    if solved:
        res = str(d.get('resolution') or '').strip()
        if not res:
            raise ApiError(400, 'Write what you did to solve it')
        vals['status'] = 'closed'
        vals['closed_at'] = vals['done_at'] = now_min()
        vals['resolution'] = res
    tid = ins(conn, 'tickets', vals, demo)
    code = finish_code(conn, 'tickets', tid, 'T', vals['title'])
    hist(conn, 'ticket', tid, 'created', 'Ticket created (%s)' % code, person_id=vals.get('person_id'), asset_id=vals.get('asset_id'), demo=demo)
    if to is not None:
        hist(conn, 'ticket', tid, 'assign', 'Assigned to %s' % who_name(team_map(conn), st, to), demo=demo)
    if solved:
        hist(conn, 'ticket', tid, 'status', 'Solved and closed: %s' % vals['resolution'], demo=demo)
    return tid


def update_ticket(conn, tid, d):
    old = need(conn.execute('SELECT * FROM tickets WHERE id=?', (tid,)).fetchone(), 'Ticket')
    vals = clean('tickets', d)
    if 'title' in vals and not vals['title']:
        raise ApiError(400, 'Title cannot be empty')
    if vals.get('person_id'):
        need(conn.execute('SELECT 1 FROM people WHERE id=?', (vals['person_id'],)).fetchone(), 'Employee')
    if vals.get('asset_id'):
        need(conn.execute('SELECT 1 FROM assets WHERE id=?', (vals['asset_id'],)).fetchone(), 'Asset')
    cat = vals.get('category', old['category'])
    if cat != 'sap_user':
        vals['req_type'] = ''
    changes = diff_text(old, vals, TICKET_LABELS)
    upd(conn, 'tickets', tid, vals)
    if changes:
        hist(conn, 'ticket', tid, 'edit', '; '.join(changes), person_id=vals.get('person_id', old['person_id']), asset_id=vals.get('asset_id', old['asset_id']))


def do_ticket(conn, tid, d):
    st = get_settings(conn)
    tm = team_map(conn)
    t = need(conn.execute('SELECT * FROM tickets WHERE id=?', (tid,)).fetchone(), 'Ticket')
    act = str(d.get('do') or '')
    who = str(d.get('who') or '').strip()[:80]
    ts = now_ts()
    note = str(d.get('note') or d.get('text') or '').strip()
    if act == 'assign':
        to = check_assignee(conn, d.get('to'))
        sets = {'assigned_to': to, 'assigned_on': ts if to is not None else None}
        if d.get('due_at'):
            sets['due_at'] = clean_dt(d['due_at']) or t['due_at']
        if to is None:
            if t['status'] in ('assigned', 'progress'):
                sets['status'] = 'new'
            text = 'Taken back (nobody is assigned now)'
        else:
            if t['status'] in ('new',):
                sets['status'] = 'assigned'
            text = 'Assigned to %s' % who_name(tm, st, to)
            if sets.get('due_at') and sets['due_at'] != t['due_at']:
                text += ' (due %s)' % sets['due_at']
        if t['status'] in ('closed', 'cancelled'):
            raise ApiError(409, 'This ticket is already %s. Re-open it first.' % t['status'])
        upd(conn, 'tickets', tid, sets)
        hist(conn, 'ticket', tid, 'assign', text + (' - ' + note if note else ''), who=who, person_id=t['person_id'], asset_id=t['asset_id'])
    elif act == 'status':
        new = str(d.get('status') or '')
        if new not in ('new', 'assigned', 'progress', 'waiting', 'done'):
            raise ApiError(400, 'Use Close or Cancel for that')
        if t['status'] in ('closed', 'cancelled'):
            raise ApiError(409, 'This ticket is already %s. Re-open it first.' % t['status'])
        sets = {'status': new}
        if new == 'progress' and not t['started_at']:
            sets['started_at'] = now_min()
        if new == 'waiting':
            sets['waiting_for'] = str(d.get('waiting_for') or note or t['waiting_for'] or '')[:200]
            if d.get('follow_up_on'):
                sets['follow_up_on'] = clean_date(d['follow_up_on'])
        if new == 'done':
            sets['done_at'] = now_min()
            if d.get('resolution'):
                sets['resolution'] = str(d['resolution']).strip()[:20000]
        if new != 'waiting':
            sets['waiting_for'] = ''
        upd(conn, 'tickets', tid, sets)
        text = 'Status: %s → %s' % (TS_MAP[t['status']]['label'], TS_MAP[new]['label'])
        if new == 'waiting' and sets.get('waiting_for'):
            text += ' (waiting for: %s)' % sets['waiting_for']
        hist(conn, 'ticket', tid, 'status', text + (' - ' + note if note and new != 'waiting' else ''), who=who, person_id=t['person_id'], asset_id=t['asset_id'])
    elif act == 'close':
        res = str(d.get('resolution') or t['resolution'] or '').strip()
        if len(res) < 3:
            raise ApiError(400, 'Write in one line what was done (resolution) before closing')
        if t['status'] == 'closed':
            raise ApiError(409, 'Already closed')
        sets = {'status': 'closed', 'closed_at': now_min(), 'resolution': res[:20000], 'waiting_for': '', 'follow_up_on': None,
                'verify_note': str(d.get('verify_note') or '')[:500]}
        if not t['done_at']:
            sets['done_at'] = sets['closed_at']
        upd(conn, 'tickets', tid, sets)
        hist(conn, 'ticket', tid, 'status', 'Closed (checked): %s' % res[:300], who=who, person_id=t['person_id'], asset_id=t['asset_id'])
    elif act == 'reopen':
        if t['status'] not in ('closed', 'cancelled', 'done'):
            raise ApiError(409, 'Only a finished ticket can be re-opened')
        upd(conn, 'tickets', tid, {'status': 'progress' if t['assigned_to'] is not None else 'new', 'closed_at': None, 'done_at': None})
        hist(conn, 'ticket', tid, 'status', 'Re-opened' + (': ' + note if note else ''), who=who, person_id=t['person_id'], asset_id=t['asset_id'])
    elif act == 'cancel':
        if t['status'] in ('closed', 'cancelled'):
            raise ApiError(409, 'Already %s' % t['status'])
        upd(conn, 'tickets', tid, {'status': 'cancelled', 'closed_at': now_min(), 'follow_up_on': None})
        hist(conn, 'ticket', tid, 'status', 'Cancelled' + (': ' + note if note else ''), who=who, person_id=t['person_id'], asset_id=t['asset_id'])
    elif act == 'note':
        if not note:
            raise ApiError(400, 'Write the note first')
        upd(conn, 'tickets', tid, {})
        hist(conn, 'ticket', tid, 'note', note[:5000], who=who, person_id=t['person_id'], asset_id=t['asset_id'])
    elif act == 'follow':
        fd = clean_date(str(d.get('date') or '')) if d.get('date') else None
        upd(conn, 'tickets', tid, {'follow_up_on': fd})
        hist(conn, 'ticket', tid, 'follow', ('Follow-up set for %s' % fd) if fd else 'Follow-up cleared', who=who, person_id=t['person_id'], asset_id=t['asset_id'])
    else:
        raise ApiError(400, 'Unknown action')


def delete_ticket(conn, tid):
    t = need(conn.execute('SELECT * FROM tickets WHERE id=?', (tid,)).fetchone(), 'Ticket')
    conn.execute('DELETE FROM tickets WHERE id=?', (tid,))
    conn.execute("DELETE FROM history WHERE ent='ticket' AND ent_id=?", (tid,))
    conn.execute('UPDATE history SET ticket_id=NULL WHERE ticket_id=?', (tid,))
    for tbl in ('accounts', 'transports', 'purchases'):
        conn.execute('UPDATE %s SET ticket_id=NULL WHERE ticket_id=?' % tbl, (tid,))
    conn.execute('UPDATE asset_log SET ticket_id=NULL WHERE ticket_id=?', (tid,))
    conn.execute('UPDATE routine_log SET ticket_id=NULL WHERE ticket_id=?', (tid,))
    drop_record_files(conn, 'ticket', tid, t['folder'])


# ----------------------------------------------------------------------------- employees, accounts, joiner / leaver steps
PEOPLE_SQL = """
SELECT p.*,
 (SELECT COUNT(*) FROM assets a WHERE a.person_id=p.id AND a.tracked=1 AND a.status IN ('issued','repair','lost')) AS n_assets,
 (SELECT COALESCE(SUM(CASE WHEN l.kind='issue' THEN l.qty WHEN l.kind='return' THEN -l.qty ELSE 0 END),0)
    FROM asset_log l JOIN assets a ON a.id=l.asset_id WHERE l.person_id=p.id AND a.tracked=0) AS n_bulk,
 (SELECT COUNT(*) FROM accounts c WHERE c.person_id=p.id AND c.status IN ('active','locked')) AS n_accounts,
 (SELECT COUNT(*) FROM tickets t WHERE t.person_id=p.id AND t.status IN ('new','assigned','progress','waiting','done')) AS n_open_tickets,
 (SELECT COUNT(*) FROM steps s WHERE s.person_id=p.id AND s.done=0 AND s.flow=CASE WHEN p.status='left' THEN 'leave' ELSE 'join' END) AS n_steps_open
FROM people p
"""
PERSON_LABELS = {'name': 'Name', 'emp_code': 'Employee code', 'department': 'Department', 'designation': 'Designation', 'plant': 'Plant',
                 'kind': 'Type', 'status': 'Status', 'mobile': 'Mobile', 'email': 'Mail id', 'reports_to': 'Reports to', 'location': 'Works at',
                 'joined_on': 'Joining date', 'left_on': 'Leaving date'}


def enrich_person(r):
    p = dict(r)
    p['n_bulk'] = max(0, int(p.get('n_bulk') or 0))
    p['has_items'] = bool(p['n_assets'] or p['n_bulk'])
    p['leaver_pending'] = bool(p['status'] == 'left' and (p['has_items'] or p['n_accounts']))
    return p


def holdings(conn, pid):
    """Everything an employee holds right now: single items + counted items (mouse, keyboard...)."""
    out = []
    for a in conn.execute("SELECT * FROM assets WHERE person_id=? AND tracked=1 AND status IN ('issued','repair','lost') ORDER BY kind, id", (pid,)):
        last = conn.execute("SELECT ts, cond FROM asset_log WHERE asset_id=? AND person_id=? AND kind='issue' ORDER BY id DESC LIMIT 1", (a['id'], pid)).fetchone()
        out.append({'asset_id': a['id'], 'code': a['code'], 'kind': a['kind'], 'name': a['name'], 'tag': a['tag'], 'serial': a['serial'], 'qty': 1,
                    'status': a['status'], 'since': a['since'] or (last['ts'][:10] if last else ''), 'cond': a['cond'], 'tracked': 1})
    for r in conn.execute("""SELECT l.asset_id, SUM(CASE WHEN l.kind='issue' THEN l.qty WHEN l.kind='return' THEN -l.qty ELSE 0 END) AS q, MIN(l.ts) AS first_ts
                             FROM asset_log l JOIN assets a ON a.id=l.asset_id WHERE l.person_id=? AND a.tracked=0 GROUP BY l.asset_id""", (pid,)):
        if (r['q'] or 0) > 0:
            a = conn.execute('SELECT * FROM assets WHERE id=?', (r['asset_id'],)).fetchone()
            out.append({'asset_id': a['id'], 'code': a['code'], 'kind': a['kind'], 'name': a['name'], 'tag': '', 'serial': '', 'qty': r['q'],
                        'status': 'issued', 'since': (r['first_ts'] or '')[:10], 'cond': a['cond'], 'tracked': 0})
    return out


def list_people(conn, where='', params=()):
    return [enrich_person(r) for r in conn.execute(PEOPLE_SQL + where, params)]


def person_detail(conn, pid):
    r = need(conn.execute(PEOPLE_SQL + ' WHERE p.id=?', (pid,)).fetchone(), 'Employee')
    p = enrich_person(r)
    st = get_settings(conn)
    tm = team_map(conn)
    p['holdings'] = holdings(conn, pid)
    p['accounts'] = row_dicts(conn.execute('SELECT * FROM accounts WHERE person_id=? ORDER BY kind, id', (pid,)))
    p['steps'] = row_dicts(conn.execute('SELECT * FROM steps WHERE person_id=? ORDER BY flow, sort, id', (pid,)))
    p['history'] = history_of(conn, 'person_id=?', (pid,))
    p['tickets'] = [enrich_ticket(x, tm, st) for x in conn.execute(TICKET_SQL + ' WHERE t.person_id=? ORDER BY t.id DESC LIMIT 40', (pid,))]
    p['files'] = list_files(conn, 'person', pid)
    return p


def add_steps(conn, pid, flow, st, demo=False):
    tpl = st.get('tpl_join' if flow == 'join' else 'tpl_leave') or ''
    lines = [x.strip() for x in tpl.splitlines() if x.strip()]
    base = conn.execute('SELECT COALESCE(MAX(sort),0) FROM steps WHERE person_id=? AND flow=?', (pid, flow)).fetchone()[0]
    for i, text in enumerate(lines, 1):
        ins(conn, 'steps', {'person_id': pid, 'flow': flow, 'text': text[:200], 'done': 0, 'sort': base + i}, demo)


def check_emp_code(conn, emp_code, exclude=None):
    if not emp_code:
        return
    r = conn.execute('SELECT id, name FROM people WHERE lower(emp_code)=? AND id<>?', (lc(emp_code), exclude or 0)).fetchone()
    if r:
        raise ApiError(409, 'Employee code %s is already used by %s' % (emp_code, r['name']))


def account_conflict(conn, kind, identifier, system, exclude=None):
    r = conn.execute("""SELECT c.id, c.person_id, c.owner_name, p.name FROM accounts c LEFT JOIN people p ON p.id=c.person_id
                        WHERE c.kind=? AND lower(c.identifier)=? AND lower(c.system)=? AND c.status<>'deleted' AND c.id<>?""",
                     (kind, lc(identifier), lc(system), exclude or 0)).fetchone()
    return r


def create_account(conn, d, demo=False, who=''):
    vals = clean('accounts', d)
    ident = (vals.get('identifier') or '').strip()
    if not ident:
        raise ApiError(400, 'Write the mail id / user id')
    vals.setdefault('kind', 'email')
    vals.setdefault('status', 'active')
    vals['created_on'] = vals.get('created_on') or today_iso()
    if vals['status'] == 'deleted':
        vals['ended_on'] = vals.get('ended_on') or today_iso()
    p = None
    if vals.get('person_id'):
        p = need(conn.execute('SELECT * FROM people WHERE id=?', (vals['person_id'],)).fetchone(), 'Employee')
        if p['status'] == 'left' and vals['status'] != 'deleted':
            raise ApiError(409, '%s has left the company - no new account can be given' % p['name'])
    elif not vals.get('owner_name'):
        raise ApiError(400, 'Choose the employee, or write the name of the shared account owner (for example "Plant mail")')
    c = account_conflict(conn, vals['kind'], ident, vals.get('system', ''))
    if c and vals['status'] != 'deleted':
        raise ApiError(409, '%s already exists (%s)' % (ident, c['name'] or c['owner_name'] or 'another owner'))
    aid = ins(conn, 'accounts', vals, demo)
    if vals.get('person_id') and vals['status'] != 'deleted':
        auto_for(conn, vals['person_id'], 'account', vals['kind'])
    label = dict(ACCOUNT_KINDS).get(vals['kind'], vals['kind'])
    hist(conn, 'account', aid, 'account', '%s created: %s%s' % (label, ident, (' (%s)' % vals['system']) if vals.get('system') else ''),
         who=who or vals.get('created_by', ''), person_id=vals.get('person_id'), ticket_id=vals.get('ticket_id'), demo=demo)
    return aid


def update_account(conn, aid, d):
    old = need(conn.execute('SELECT * FROM accounts WHERE id=?', (aid,)).fetchone(), 'Account')
    vals = clean('accounts', d)
    if 'identifier' in vals and not vals['identifier']:
        raise ApiError(400, 'The mail id / user id cannot be empty')
    if vals.get('status') == 'deleted' and not vals.get('ended_on') and old['status'] != 'deleted':
        vals['ended_on'] = today_iso()
    if vals.get('status') in ('active', 'locked') and old['status'] == 'deleted':
        vals['ended_on'] = None
        c = account_conflict(conn, vals.get('kind', old['kind']), vals.get('identifier', old['identifier']), vals.get('system', old['system']), aid)
        if c:
            raise ApiError(409, 'The same id is already in use by %s' % (c['name'] or c['owner_name']))
    if ('identifier' in vals or 'kind' in vals or 'system' in vals) and vals.get('status', old['status']) != 'deleted':
        c = account_conflict(conn, vals.get('kind', old['kind']), vals.get('identifier', old['identifier']), vals.get('system', old['system']), aid)
        if c:
            raise ApiError(409, '%s already exists (%s)' % (vals.get('identifier', old['identifier']), c['name'] or c['owner_name']))
    labels = {'identifier': 'Id', 'status': 'Status', 'system': 'System', 'roles': 'Roles', 'valid_to': 'Valid until', 'kind': 'Type', 'owner_name': 'Owner'}
    changes = diff_text(old, vals, labels)
    upd(conn, 'accounts', aid, vals)
    if old['person_id'] and vals.get('status') in ('locked', 'deleted') and old['status'] != vals['status']:
        auto_for(conn, old['person_id'], 'account', vals.get('kind', old['kind']))
    if changes:
        kind = dict(ACCOUNT_KINDS).get(vals.get('kind', old['kind']), '')
        hist(conn, 'account', aid, 'account', '%s %s - %s' % (kind, vals.get('identifier', old['identifier']), '; '.join(changes)),
             person_id=vals.get('person_id', old['person_id']), ticket_id=vals.get('ticket_id', old['ticket_id']))


def create_person(conn, d, demo=False):
    st = get_settings(conn)
    vals = clean('people', d)
    if not (vals.get('name') or '').strip():
        raise ApiError(400, 'Write the name')
    vals.setdefault('kind', 'employee')
    check_emp_code(conn, vals.get('emp_code'))
    vals['joined_on'] = vals.get('joined_on') or today_iso()
    vals.setdefault('status', 'joining' if vals['joined_on'] > today_iso() else 'active')
    if vals['status'] == 'left':
        vals['left_on'] = vals.get('left_on') or today_iso()
    pid = ins(conn, 'people', vals, demo)
    code = finish_code(conn, 'people', pid, 'P', vals['name'])
    hist(conn, 'person', pid, 'created', '%s added (%s)' % (vals['name'], code), demo=demo)
    if vals['status'] != 'left' and not d.get('no_steps'):
        add_steps(conn, pid, 'join', st, demo)
    return pid


def update_person(conn, pid, d):
    old = need(conn.execute('SELECT * FROM people WHERE id=?', (pid,)).fetchone(), 'Employee')
    vals = clean('people', d)
    if 'name' in vals and not vals['name']:
        raise ApiError(400, 'Name cannot be empty')
    if vals.get('emp_code'):
        check_emp_code(conn, vals['emp_code'], pid)
    if vals.get('status') == 'left' and old['status'] != 'left':
        raise ApiError(400, 'Use "Mark as left" so the leaver steps and pending items are handled')
    if vals.get('status') in ('active', 'joining') and old['status'] == 'left':
        vals['left_on'] = None
    changes = diff_text(old, vals, PERSON_LABELS)
    upd(conn, 'people', pid, vals)
    if changes:
        hist(conn, 'person', pid, 'edit', '; '.join(changes))


def leave_person(conn, pid, d):
    st = get_settings(conn)
    p = need(conn.execute('SELECT * FROM people WHERE id=?', (pid,)).fetchone(), 'Employee')
    if p['status'] == 'left':
        raise ApiError(409, '%s is already marked as left' % p['name'])
    left_on = clean_date(str(d.get('left_on') or '')) or today_iso()
    upd(conn, 'people', pid, {'status': 'left', 'left_on': left_on})
    if not conn.execute("SELECT 1 FROM steps WHERE person_id=? AND flow='leave' LIMIT 1", (pid,)).fetchone():
        add_steps(conn, pid, 'leave', st)
    held = holdings(conn, pid)
    accs = row_dicts(conn.execute("SELECT * FROM accounts WHERE person_id=? AND status IN ('active','locked')", (pid,)))
    text = 'Marked as left on %s' % left_on
    if held or accs:
        text += ' - still pending: %s' % ', '.join(['%s%s' % (h['code'], (' x%d' % h['qty']) if h['qty'] > 1 else '') for h in held] + [a['identifier'] for a in accs])
    hist(conn, 'person', pid, 'leave', text)
    return {'held': held, 'accounts': accs}


def delete_person(conn, pid):
    p = need(conn.execute('SELECT * FROM people WHERE id=?', (pid,)).fetchone(), 'Employee')
    refs = 0
    for q in ('SELECT COUNT(*) FROM assets WHERE person_id=?', 'SELECT COUNT(*) FROM accounts WHERE person_id=?', 'SELECT COUNT(*) FROM tickets WHERE person_id=?',
              'SELECT COUNT(*) FROM asset_log WHERE person_id=?', 'SELECT COUNT(*) FROM purchases WHERE person_id=?'):
        refs += conn.execute(q, (pid,)).fetchone()[0]
    if refs:
        raise ApiError(409, '%s has records (items, accounts or tickets). Mark the person as "left" instead - the history stays.' % p['name'])
    conn.execute('DELETE FROM people WHERE id=?', (pid,))
    conn.execute("DELETE FROM history WHERE ent='person' AND ent_id=?", (pid,))
    conn.execute('UPDATE history SET person_id=NULL WHERE person_id=?', (pid,))
    drop_record_files(conn, 'person', pid, p['folder'])


# ----------------------------------------------------------------------------- assets and stock
ASSET_SQL = """
SELECT a.*, p.name AS holder, p.code AS holder_code, p.status AS holder_status, p.plant AS holder_plant,
 (SELECT COUNT(*) FROM asset_log l WHERE l.asset_id=a.id AND l.kind='issue') AS times_issued,
 (SELECT MAX(l.ts) FROM asset_log l WHERE l.asset_id=a.id AND l.kind='return') AS last_return,
 (SELECT COUNT(*) FROM files f WHERE f.parent_kind='asset' AND f.parent_id=a.id) AS n_files,
 (SELECT COUNT(*) FROM tickets t WHERE t.asset_id=a.id) AS n_tickets,
 (SELECT COUNT(*) FROM tickets t WHERE t.asset_id=a.id AND t.status IN ('new','assigned','progress','waiting','done')) AS n_open_tickets
FROM assets a LEFT JOIN people p ON p.id=a.person_id
"""
ASSET_LABELS = {'kind': 'Type', 'name': 'Make / model', 'tag': 'Asset tag', 'serial': 'Serial no.', 'cond': 'Condition', 'plant': 'Plant', 'location': 'Place',
                'purchase_date': 'Purchase date', 'vendor': 'Vendor', 'cost': 'Cost', 'warranty_until': 'Warranty until', 'min_qty': 'Minimum stock'}
KIND_LABEL = {k: l for k, l, _ in ASSET_KINDS}


def enrich_asset(r):
    a = dict(r)
    a['qty_out'] = (a['qty'] or 0) - (a['qty_free'] or 0) if not a['tracked'] else 0
    a['is_new'] = not a['times_issued']
    wu = parse_d(a['warranty_until'])
    a['warranty_left'] = (wu - today_date()).days if wu else None
    a['label'] = ('%s %s' % (KIND_LABEL.get(a['kind'], a['kind']), a['name'] or '')).strip()
    return a


def list_assets(conn, where='', params=()):
    return [enrich_asset(r) for r in conn.execute(ASSET_SQL + where, params)]


def asset_detail(conn, aid):
    r = need(conn.execute(ASSET_SQL + ' WHERE a.id=?', (aid,)).fetchone(), 'Asset')
    a = enrich_asset(r)
    st = get_settings(conn)
    tm = team_map(conn)
    a['history'] = history_of(conn, 'asset_id=?', (aid,))
    a['files'] = list_files(conn, 'asset', aid)
    a['tickets'] = [enrich_ticket(x, tm, st) for x in conn.execute(TICKET_SQL + ' WHERE t.asset_id=? ORDER BY t.id DESC LIMIT 40', (aid,))]
    a['holders'] = []
    if not a['tracked']:
        for x in conn.execute("""SELECT l.person_id, l.location, SUM(CASE WHEN l.kind='issue' THEN l.qty WHEN l.kind='return' THEN -l.qty ELSE 0 END) AS q
                                 FROM asset_log l WHERE l.asset_id=? GROUP BY l.person_id, l.location""", (aid,)):
            if (x['q'] or 0) > 0:
                nm = conn.execute('SELECT name, code FROM people WHERE id=?', (x['person_id'],)).fetchone() if x['person_id'] else None
                a['holders'].append({'person_id': x['person_id'], 'name': nm['name'] if nm else '', 'code': nm['code'] if nm else '', 'location': x['location'], 'qty': x['q']})
    return a


def check_asset_dupes(conn, tag, serial, exclude=None):
    for fld, v, label in (('serial', serial, 'Serial no.'), ('tag', tag, 'Asset tag')):
        v = (v or '').strip()
        if not v or lc(v) in ('na', 'n/a', '-', 'none', 'nil'):
            continue
        r = conn.execute("SELECT code, name FROM assets WHERE lower(%s)=? AND id<>? AND tracked=1 AND status<>'scrap'" % fld, (lc(v), exclude or 0)).fetchone()
        if r:
            raise ApiError(409, '%s %s already exists as %s %s' % (label, v, r['code'], r['name']))


def create_asset(conn, d, demo=False, who=''):
    vals = clean('assets', d)
    vals.setdefault('kind', 'laptop')
    if 'tracked' not in d:
        vals['tracked'] = 0 if vals['kind'] in BULK_KINDS else 1
    if not (vals.get('name') or '').strip() and not (vals.get('serial') or vals.get('tag')):
        vals['name'] = KIND_LABEL.get(vals['kind'], '')
    if vals['tracked']:
        vals['qty'] = vals['qty_free'] = 1
        check_asset_dupes(conn, vals.get('tag'), vals.get('serial'))
    else:
        q = vals.get('qty')
        if q is None:
            q = 1
        if q < 1:
            raise ApiError(400, 'Quantity must be at least 1')
        vals['qty'] = vals['qty_free'] = q
        vals['serial'] = ''
    vals.setdefault('cond', 'new')
    vals['status'] = 'in_stock'
    aid = ins(conn, 'assets', vals, demo)
    code = finish_code(conn, 'assets', aid, 'A', '%s_%s' % (vals['kind'], vals.get('name') or vals.get('serial') or ''))
    conn.execute('INSERT INTO asset_log(asset_id,ts,kind,qty,cond,text,who,is_demo) VALUES(?,?,?,?,?,?,?,?)',
                 (aid, now_ts(), 'stock_in', vals['qty'], vals['cond'], 'Added to stock', who, 1 if demo else 0))
    hist(conn, 'asset', aid, 'created', 'Added to stock: %s%s (%s)' % (KIND_LABEL.get(vals['kind'], ''), (' ' + vals['name']) if vals.get('name') else '', code)
         + ((' x%d' % vals['qty']) if vals['qty'] > 1 else ''), who=who, demo=demo)
    return aid


def update_asset(conn, aid, d):
    old = need(conn.execute('SELECT * FROM assets WHERE id=?', (aid,)).fetchone(), 'Asset')
    vals = clean('assets', d)
    vals.pop('tracked', None)
    vals.pop('qty', None)
    if old['tracked'] and ('serial' in vals or 'tag' in vals):
        check_asset_dupes(conn, vals.get('tag', old['tag']), vals.get('serial', old['serial']), aid)
    if not old['tracked']:
        vals.pop('serial', None)
    if 'kind' in vals and vals['kind'] != old['kind'] and conn.execute('SELECT 1 FROM asset_log WHERE asset_id=? AND kind=? LIMIT 1', (aid, 'issue')).fetchone():
        raise ApiError(409, 'This item was already issued once, so its type cannot be changed')
    changes = diff_text(old, vals, ASSET_LABELS)
    upd(conn, 'assets', aid, vals)
    if changes:
        hist(conn, 'asset', aid, 'edit', '; '.join(changes), person_id=old['person_id'])


def held_qty(conn, aid, pid, location):
    r = conn.execute("""SELECT COALESCE(SUM(CASE WHEN kind='issue' THEN qty WHEN kind='return' THEN -qty ELSE 0 END),0)
                        FROM asset_log WHERE asset_id=? AND COALESCE(person_id,0)=? AND location=?""", (aid, pid or 0, location or '')).fetchone()
    return r[0] or 0


def asset_op(conn, aid, d, demo=False):
    a = need(conn.execute('SELECT * FROM assets WHERE id=?', (aid,)).fetchone(), 'Asset')
    op = str(d.get('op') or '')
    who = str(d.get('who') or '').strip()[:80]
    note = str(d.get('note') or '').strip()[:2000]
    tid = int(d['ticket_id']) if str(d.get('ticket_id') or '').isdigit() and int(d['ticket_id']) else None
    cond = str(d.get('cond') or '')
    if cond and cond not in dict(CONDITIONS):
        raise ApiError(400, 'Invalid condition')
    lbl = '%s %s' % (a['code'], KIND_LABEL.get(a['kind'], '')) + ((' ' + a['name']) if a['name'] else '')
    ts = now_ts()
    flag = 1 if demo else 0

    def log(kind, qty=1, pid=None, loc='', text=''):
        conn.execute('INSERT INTO asset_log(asset_id,person_id,location,ts,kind,qty,cond,text,who,ticket_id,is_demo) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                     (aid, pid, loc, ts, kind, qty, cond or a['cond'], text, who, tid, flag))

    if op == 'issue':
        pid = int(d['person_id']) if str(d.get('person_id') or '').isdigit() and int(d['person_id']) else None
        loc = str(d.get('location') or '').strip()[:200]
        if not pid and not loc:
            raise ApiError(400, 'Choose who gets it - or write the place where it is installed (for example "Calendering line 2")')
        p = None
        if pid:
            p = need(conn.execute('SELECT * FROM people WHERE id=?', (pid,)).fetchone(), 'Employee')
            if p['status'] == 'left':
                raise ApiError(409, '%s has left the company - nothing can be issued' % p['name'])
        target = p['name'] if p else loc
        if a['tracked']:
            if a['status'] != 'in_stock':
                holder = conn.execute('SELECT name FROM people WHERE id=?', (a['person_id'],)).fetchone() if a['person_id'] else None
                raise ApiError(409, '%s is not in stock (%s%s)' % (a['code'], dict(ASSET_STATUS).get(a['status'], a['status']), (' - ' + holder['name']) if holder else ''))
            upd(conn, 'assets', aid, {'status': 'issued' if p else 'deployed', 'person_id': pid, 'location': loc if loc else (a['location'] if not p else ''),
                                      'since': today_iso(), 'cond': cond or a['cond']})
            log('issue', 1, pid, loc, note)
            hist(conn, 'asset', aid, 'issue', 'Issued %s to %s%s' % (lbl, target, (' - ' + note) if note else ''), who=who, person_id=pid, ticket_id=tid, demo=demo)
            if pid:
                auto_for(conn, pid, 'issue', a['kind'])
        else:
            q = int(d.get('qty') or 1)
            if q < 1:
                raise ApiError(400, 'Quantity must be at least 1')
            if q > (a['qty_free'] or 0):
                raise ApiError(409, 'Only %d %s in stock' % (a['qty_free'] or 0, KIND_LABEL.get(a['kind'], 'items')))
            upd(conn, 'assets', aid, {'qty_free': a['qty_free'] - q})
            log('issue', q, pid, loc, note)
            hist(conn, 'asset', aid, 'issue', 'Issued %d x %s to %s%s' % (q, lbl, target, (' - ' + note) if note else ''), who=who, person_id=pid, ticket_id=tid, demo=demo)
            if pid:
                auto_for(conn, pid, 'issue', a['kind'])
    elif op == 'return':
        to = str(d.get('to') or 'stock')
        if to not in ('stock', 'repair', 'scrap', 'lost'):
            raise ApiError(400, 'Choose where the returned item goes')
        if a['tracked']:
            if a['status'] not in ('issued', 'deployed', 'repair', 'lost'):
                raise ApiError(409, '%s is not issued to anyone' % a['code'])
            pid = a['person_id']
            holder = conn.execute('SELECT name FROM people WHERE id=?', (pid,)).fetchone() if pid else None
            from_txt = holder['name'] if holder else (a['location'] or 'its place')
            new = {'stock': 'in_stock', 'repair': 'repair', 'scrap': 'scrap', 'lost': 'lost'}[to]
            upd(conn, 'assets', aid, {'status': new, 'person_id': None if to != 'lost' else pid, 'location': '', 'since': None, 'cond': cond or a['cond']})
            log('return', 1, pid, a['location'] or '', note + ((' [' + to + ']') if to != 'stock' else ''))
            hist(conn, 'asset', aid, 'return', 'Returned %s from %s → %s%s' % (lbl, from_txt, {'stock': 'back in stock', 'repair': 'sent for repair', 'scrap': 'scrapped',
                                                                                  'lost': 'marked lost'}[to], (' - ' + note) if note else ''), who=who, person_id=pid, ticket_id=tid, demo=demo)
            if pid:
                auto_for(conn, pid, 'return', a['kind'])
        else:
            pid = int(d['person_id']) if str(d.get('person_id') or '').isdigit() and int(d['person_id']) else None
            loc = str(d.get('location') or '').strip()[:200]
            q = int(d.get('qty') or 1)
            have = held_qty(conn, aid, pid, loc)
            if q < 1 or q > have:
                raise ApiError(409, 'Only %d of these were issued to that employee / place' % have)
            if to == 'stock':
                upd(conn, 'assets', aid, {'qty_free': a['qty_free'] + q})
            else:
                upd(conn, 'assets', aid, {'qty': a['qty'] - q})
            log('return', q, pid, loc, note + ((' [' + to + ']') if to != 'stock' else ''))
            nm = conn.execute('SELECT name FROM people WHERE id=?', (pid,)).fetchone() if pid else None
            hist(conn, 'asset', aid, 'return', 'Returned %d x %s from %s → %s' % (q, lbl, nm['name'] if nm else loc, 'back in stock' if to == 'stock' else to),
                 who=who, person_id=pid, ticket_id=tid, demo=demo)
            if pid:
                auto_for(conn, pid, 'return', a['kind'])
    elif op == 'swap':
        # replace a broken item of an employee with another one in one step
        if not a['tracked'] or a['status'] not in ('issued', 'deployed'):
            raise ApiError(409, 'Only an issued single item can be swapped')
        nid = int(d.get('new_asset_id') or 0)
        b = need(conn.execute('SELECT * FROM assets WHERE id=?', (nid,)).fetchone(), 'Replacement item')
        if not b['tracked'] or b['status'] != 'in_stock':
            raise ApiError(409, '%s is not in stock' % b['code'])
        to = str(d.get('to') or 'repair')
        if to not in ('stock', 'repair', 'scrap'):
            raise ApiError(400, 'Choose where the old item goes')
        pid, loc = a['person_id'], a['location']
        asset_op(conn, aid, {'op': 'return', 'to': to, 'cond': cond or ('poor' if to != 'stock' else ''), 'note': 'Swapped for %s. %s' % (b['code'], note), 'who': who,
                             'ticket_id': tid}, demo)
        asset_op(conn, nid, {'op': 'issue', 'person_id': pid, 'location': loc, 'note': 'Replacement for %s. %s' % (a['code'], note), 'who': who, 'ticket_id': tid}, demo)
        return
    elif op == 'repair':
        if not a['tracked'] or a['status'] not in ('in_stock', 'issued', 'deployed'):
            raise ApiError(409, '%s cannot be sent for repair now (%s)' % (a['code'], dict(ASSET_STATUS).get(a['status'], a['status'])))
        upd(conn, 'assets', aid, {'status': 'repair'})
        log('repair', 1, a['person_id'], '', note)
        hist(conn, 'asset', aid, 'repair', 'Sent for repair: %s%s' % (lbl, (' - ' + note) if note else ''), who=who, person_id=a['person_id'], ticket_id=tid, demo=demo)
    elif op == 'repaired':
        if a['status'] != 'repair':
            raise ApiError(409, '%s is not in repair' % a['code'])
        back = 'issued' if a['person_id'] else ('deployed' if a['location'] else 'in_stock')
        upd(conn, 'assets', aid, {'status': back, 'cond': cond or a['cond']})
        log('repaired', 1, a['person_id'], '', note)
        hist(conn, 'asset', aid, 'repair', 'Back from repair: %s%s' % (lbl, (' - ' + note) if note else ''), who=who, person_id=a['person_id'], ticket_id=tid, demo=demo)
    elif op == 'scrap':
        if not a['tracked'] or a['status'] in ('issued', 'deployed'):
            raise ApiError(409, 'Take the item back from the user first, then scrap it')
        upd(conn, 'assets', aid, {'status': 'scrap', 'person_id': None, 'cond': 'poor'})
        log('scrap', 1, None, '', note)
        hist(conn, 'asset', aid, 'scrap', 'Scrapped: %s%s' % (lbl, (' - ' + note) if note else ''), who=who, ticket_id=tid, demo=demo)
    elif op == 'lost':
        if not a['tracked']:
            raise ApiError(400, 'For counted items use Return > Lost')
        upd(conn, 'assets', aid, {'status': 'lost'})
        log('lost', 1, a['person_id'], '', note)
        hist(conn, 'asset', aid, 'lost', 'Marked lost: %s%s' % (lbl, (' - ' + note) if note else ''), who=who, person_id=a['person_id'], ticket_id=tid, demo=demo)
    elif op == 'found':
        if a['status'] != 'lost':
            raise ApiError(409, 'Not marked as lost')
        upd(conn, 'assets', aid, {'status': 'issued' if a['person_id'] else 'in_stock'})
        log('found', 1, a['person_id'], '', note)
        hist(conn, 'asset', aid, 'found', 'Found again: %s' % lbl, who=who, person_id=a['person_id'], demo=demo)
    elif op == 'restock':
        if a['tracked']:
            raise ApiError(400, 'Only counted items can be restocked')
        q = int(d.get('qty') or 0)
        if q < 1:
            raise ApiError(400, 'Quantity must be at least 1')
        upd(conn, 'assets', aid, {'qty': a['qty'] + q, 'qty_free': a['qty_free'] + q})
        log('stock_in', q, None, '', note)
        hist(conn, 'asset', aid, 'stock', 'Added %d to stock: %s%s' % (q, lbl, (' - ' + note) if note else ''), who=who, demo=demo)
    elif op == 'note':
        if not note:
            raise ApiError(400, 'Write the note first')
        upd(conn, 'assets', aid, {})
        hist(conn, 'asset', aid, 'note', note, who=who, person_id=a['person_id'], ticket_id=tid, demo=demo)
    else:
        raise ApiError(400, 'Unknown action')


def delete_asset(conn, aid):
    a = need(conn.execute('SELECT * FROM assets WHERE id=?', (aid,)).fetchone(), 'Asset')
    if conn.execute("SELECT 1 FROM asset_log WHERE asset_id=? AND kind<>'stock_in' LIMIT 1", (aid,)).fetchone() or \
            conn.execute('SELECT 1 FROM tickets WHERE asset_id=? LIMIT 1', (aid,)).fetchone():
        raise ApiError(409, '%s has history (issued, repaired or used in a ticket). Use "Scrap" so the history stays.' % a['code'])
    conn.execute('DELETE FROM assets WHERE id=?', (aid,))
    conn.execute("DELETE FROM history WHERE ent='asset' AND ent_id=?", (aid,))
    conn.execute('UPDATE history SET asset_id=NULL WHERE asset_id=?', (aid,))
    drop_record_files(conn, 'asset', aid, a['folder'])


def stock_summary(conn, st):
    mins = min_stock_of(st)
    kinds = {}
    for a in conn.execute('SELECT kind, plant, tracked, status, qty, qty_free FROM assets'):
        k = kinds.setdefault(a['kind'], {'kind': a['kind'], 'label': KIND_LABEL.get(a['kind'], a['kind']), 'total': 0, 'in_stock': 0, 'issued': 0, 'deployed': 0, 'repair': 0,
                                         'scrap': 0, 'lost': 0, 'by_plant': {}})
        if a['tracked']:
            k['total'] += 0 if a['status'] in ('scrap', 'lost') else 1
            k[a['status']] = k.get(a['status'], 0) + 1
            if a['status'] == 'in_stock':
                k['by_plant'][a['plant'] or '-'] = k['by_plant'].get(a['plant'] or '-', 0) + 1
        else:
            k['total'] += a['qty']
            k['in_stock'] += a['qty_free']
            k['issued'] += a['qty'] - a['qty_free']
            k['by_plant'][a['plant'] or '-'] = k['by_plant'].get(a['plant'] or '-', 0) + a['qty_free']
    out = []
    for key in KIND_KEYS:
        k = kinds.get(key) or {'kind': key, 'label': KIND_LABEL[key], 'total': 0, 'in_stock': 0, 'issued': 0, 'deployed': 0, 'repair': 0, 'scrap': 0, 'lost': 0, 'by_plant': {}}
        k['min'] = mins.get(key, 0)
        k['low'] = bool(k['min'] and k['in_stock'] < k['min'])
        pend = conn.execute("SELECT COALESCE(SUM(qty),0) FROM purchases WHERE kind=? AND status IN ('requested','approved','ordered')", (key,)).fetchone()[0]
        k['on_order'] = pend
        if k['total'] or k['min'] or k['on_order']:
            out.append(k)
    return out


def stock_suggest(conn, kind, plant):
    """Best items to give to a new person: returned (used) ones first, same plant first, new ones after, poor ones last."""
    if kind not in KIND_KEYS:
        raise ApiError(400, 'Choose the item type')
    rows = list_assets(conn, " WHERE a.kind=? AND ((a.tracked=1 AND a.status='in_stock') OR (a.tracked=0 AND a.qty_free>0))", (kind,))
    cond_rank = {'good': 0, 'new': 0, 'fair': 1, 'poor': 2}

    def key(a):
        # poor ones last; returned (used) items before new ones; then the same plant; then the better condition; oldest return first
        return (1 if a['cond'] == 'poor' else 0, 1 if a['is_new'] else 0, 0 if (plant and a['plant'] == plant) else 1, cond_rank.get(a['cond'], 1), a['last_return'] or '', a['id'])
    rows.sort(key=key)
    used = sum(1 for a in rows if not a['is_new'])
    for a in rows:
        if a['cond'] == 'poor':
            a['advice'] = 'Poor condition - check or repair first'
        elif not a['is_new']:
            a['advice'] = 'Returned item - give this first'
        else:
            a['advice'] = 'New'
        a['same_plant'] = bool(plant and a['plant'] == plant)
    free = sum((a['qty_free'] if not a['tracked'] else 1) for a in rows)
    return {'kind': kind, 'label': KIND_LABEL.get(kind, kind), 'free': free, 'used': used, 'new': len(rows) - used, 'items': rows,
            'in_plant': sum((a['qty_free'] if not a['tracked'] else 1) for a in rows if plant and a['plant'] == plant)}


# ----------------------------------------------------------------------------- transport requests (TR)
TR_LABELS = {'tr_number': 'TR number', 'description': 'Description', 'owner_name': 'Made by', 'requested_by': 'Requested by', 'source_sys': 'From system',
             'priority': 'Priority', 'depends_on': 'Depends on', 'approver': 'Approver', 'rc': 'Return code'}
TR_LABEL = dict(TR_STATUS)


def check_tr_number(conn, number, exclude=None):
    number = (number or '').strip()
    if not number:
        return
    r = conn.execute('SELECT code, description FROM transports WHERE lower(tr_number)=? AND id<>?', (lc(number), exclude or 0)).fetchone()
    if r:
        raise ApiError(409, 'TR %s is already in the list as %s' % (number, r['code']))


def create_transport(conn, d, demo=False):
    vals = clean('transports', d)
    if not (vals.get('description') or '').strip():
        raise ApiError(400, 'Write what this transport contains (description)')
    if vals.get('tr_number'):
        vals['tr_number'] = vals['tr_number'].upper()
    check_tr_number(conn, vals.get('tr_number'))
    vals['requested_on'] = vals.get('requested_on') or today_iso()
    vals['status'] = 'requested'
    rid = ins(conn, 'transports', vals, demo)
    code = finish_code(conn, 'transports', rid, 'R', vals.get('tr_number') or vals['description'])
    hist(conn, 'transport', rid, 'created', 'Transport requested (%s) %s' % (code, vals.get('tr_number', '')), who=vals.get('requested_by', ''),
         ticket_id=vals.get('ticket_id'), demo=demo)
    return rid


def update_transport(conn, rid, d):
    old = need(conn.execute('SELECT * FROM transports WHERE id=?', (rid,)).fetchone(), 'Transport')
    vals = clean('transports', d)
    if 'description' in vals and not vals['description']:
        raise ApiError(400, 'Description cannot be empty')
    if vals.get('tr_number'):
        vals['tr_number'] = vals['tr_number'].upper()
        check_tr_number(conn, vals['tr_number'], rid)
    changes = diff_text(old, vals, TR_LABELS)
    upd(conn, 'transports', rid, vals)
    if changes:
        hist(conn, 'transport', rid, 'edit', '; '.join(changes), ticket_id=vals.get('ticket_id', old['ticket_id']))


def do_transport(conn, rid, d):
    st = get_settings(conn)
    t = need(conn.execute('SELECT * FROM transports WHERE id=?', (rid,)).fetchone(), 'Transport')
    act = str(d.get('do') or '')
    by = str(d.get('by') or '').strip()[:80]
    on = clean_date(str(d.get('on') or '')) or today_iso()
    note = str(d.get('note') or '').strip()[:2000]
    cur = t['status']
    if act == 'qas':
        if cur in ('prd', 'rejected'):
            raise ApiError(409, 'This transport is already %s' % TR_LABEL[cur].lower())
        upd(conn, 'transports', rid, {'status': 'qas', 'qas_on': on, 'qas_by': by})
        hist(conn, 'transport', rid, 'tr', 'Imported to QAS on %s%s' % (on, (' - ' + note) if note else ''), who=by, ticket_id=t['ticket_id'])
    elif act == 'approve':
        if cur in ('prd', 'rejected'):
            raise ApiError(409, 'This transport is already %s' % TR_LABEL[cur].lower())
        who = str(d.get('approver') or by or t['approver'] or '').strip()
        if not who:
            raise ApiError(400, 'Write who approved it (for example the HOD or the functional owner)')
        upd(conn, 'transports', rid, {'status': 'approved', 'approved_on': on, 'approver': who[:80]})
        hist(conn, 'transport', rid, 'tr', 'Approved by %s on %s%s' % (who, on, (' - ' + note) if note else ''), who=by, ticket_id=t['ticket_id'])
    elif act == 'prd':
        if cur in ('prd', 'rejected'):
            raise ApiError(409, 'This transport is already %s' % TR_LABEL[cur].lower())
        if st.get('tr_need_approval', '1') == '1' and not t['approved_on']:
            raise ApiError(409, 'Approval is missing. Get the approval first (or switch the rule off in Settings).')
        rc = str(d.get('rc') if d.get('rc') not in (None, '') else '0').strip()[:10]
        failed = rc.isdigit() and int(rc) >= 8
        upd(conn, 'transports', rid, {'status': 'failed' if failed else 'prd', 'prd_on': on, 'prd_by': by, 'rc': rc})
        hist(conn, 'transport', rid, 'tr', ('Import to PRD FAILED (return code %s)' if failed else 'Moved to PRD on ' + on + ' (return code %s)') % rc + ((' - ' + note) if note else ''),
             who=by, ticket_id=t['ticket_id'])
    elif act == 'fail':
        upd(conn, 'transports', rid, {'status': 'failed', 'rc': str(d.get('rc') or t['rc'] or '')[:10]})
        hist(conn, 'transport', rid, 'tr', 'Marked as failed' + ((': ' + note) if note else ''), who=by, ticket_id=t['ticket_id'])
    elif act == 'reject':
        if cur == 'prd':
            raise ApiError(409, 'It is already in production')
        upd(conn, 'transports', rid, {'status': 'rejected'})
        hist(conn, 'transport', rid, 'tr', 'Rejected' + ((': ' + note) if note else ''), who=by, ticket_id=t['ticket_id'])
    elif act == 'hold':
        if cur in ('prd', 'rejected'):
            raise ApiError(409, 'This transport is already %s' % TR_LABEL[cur].lower())
        upd(conn, 'transports', rid, {'status': 'hold'})
        hist(conn, 'transport', rid, 'tr', 'Put on hold' + ((': ' + note) if note else ''), who=by, ticket_id=t['ticket_id'])
    elif act == 'reopen':
        if cur not in ('failed', 'rejected', 'hold'):
            raise ApiError(409, 'Only a failed, rejected or held transport can be re-opened')
        upd(conn, 'transports', rid, {'status': 'approved' if t['approved_on'] else ('qas' if t['qas_on'] else 'requested')})
        hist(conn, 'transport', rid, 'tr', 'Re-opened' + ((': ' + note) if note else ''), who=by, ticket_id=t['ticket_id'])
    elif act == 'note':
        if not note:
            raise ApiError(400, 'Write the note first')
        upd(conn, 'transports', rid, {})
        hist(conn, 'transport', rid, 'note', note, who=by, ticket_id=t['ticket_id'])
    else:
        raise ApiError(400, 'Unknown action')


def transport_detail(conn, rid):
    t = dict(need(conn.execute('SELECT * FROM transports WHERE id=?', (rid,)).fetchone(), 'Transport'))
    t['history'] = history_of(conn, "ent='transport' AND ent_id=?", (rid,))
    t['files'] = list_files(conn, 'transport', rid)
    t['age_days'] = (today_date() - parse_d(t['requested_on'])).days if parse_d(t['requested_on']) else None
    return t


def list_transports(conn):
    out = []
    for r in conn.execute('SELECT * FROM transports ORDER BY id DESC'):
        t = dict(r)
        rq = parse_d(t['requested_on'])
        t['age_days'] = (today_date() - rq).days if rq else None
        t['open'] = t['status'] in ('requested', 'qas', 'approved', 'hold', 'failed')
        out.append(t)
    return out


# ----------------------------------------------------------------------------- purchases
BUY_LABELS = {'item': 'Item', 'kind': 'Type', 'qty': 'Quantity', 'vendor': 'Vendor', 'po_no': 'PO number', 'expected_on': 'Expected on', 'cost': 'Cost', 'plant': 'Plant'}


def create_purchase(conn, d, demo=False):
    vals = clean('purchases', d)
    if not (vals.get('item') or '').strip():
        raise ApiError(400, 'Write what has to be bought')
    vals.setdefault('kind', 'other')
    q = vals.get('qty')
    vals['qty'] = q if q and q > 0 else 1
    vals['requested_on'] = vals.get('requested_on') or today_iso()
    vals['status'] = 'requested'
    if vals.get('person_id'):
        need(conn.execute('SELECT 1 FROM people WHERE id=?', (vals['person_id'],)).fetchone(), 'Employee')
    pid = ins(conn, 'purchases', vals, demo)
    code = finish_code(conn, 'purchases', pid, 'B', vals['item'])
    hist(conn, 'purchase', pid, 'created', 'Purchase requested (%s): %d x %s' % (code, vals['qty'], vals['item']), person_id=vals.get('person_id'), ticket_id=vals.get('ticket_id'), demo=demo)
    return pid


def update_purchase(conn, pid, d):
    old = need(conn.execute('SELECT * FROM purchases WHERE id=?', (pid,)).fetchone(), 'Purchase')
    vals = clean('purchases', d)
    if 'item' in vals and not vals['item']:
        raise ApiError(400, 'Item cannot be empty')
    if 'qty' in vals and (not vals['qty'] or vals['qty'] < 1):
        raise ApiError(400, 'Quantity must be at least 1')
    changes = diff_text(old, vals, BUY_LABELS)
    upd(conn, 'purchases', pid, vals)
    if changes:
        hist(conn, 'purchase', pid, 'edit', '; '.join(changes), person_id=old['person_id'], ticket_id=old['ticket_id'])


def do_purchase(conn, pid, d, demo=False):
    b = need(conn.execute('SELECT * FROM purchases WHERE id=?', (pid,)).fetchone(), 'Purchase')
    act = str(d.get('do') or '')
    note = str(d.get('note') or '').strip()[:2000]
    on = clean_date(str(d.get('on') or '')) or today_iso()
    cur = b['status']
    link = {'person_id': b['person_id'], 'ticket_id': b['ticket_id']}
    created = []
    if act == 'approve':
        if cur not in ('requested', 'cancelled'):
            raise ApiError(409, 'Already %s' % cur)
        who = str(d.get('approved_by') or b['approved_by'] or '').strip()
        if not who:
            raise ApiError(400, 'Write who approved the purchase')
        upd(conn, 'purchases', pid, {'status': 'approved', 'approved_by': who[:80], 'approved_on': on})
        hist(conn, 'purchase', pid, 'purchase', 'Approved by %s on %s' % (who, on), **link)
    elif act == 'order':
        if cur not in ('requested', 'approved'):
            raise ApiError(409, 'Cannot order now (%s)' % cur)
        vals = clean('purchases', d)
        sets = {'status': 'ordered'}
        for k in ('vendor', 'po_no', 'expected_on', 'cost'):
            if k in vals:
                sets[k] = vals[k]
        upd(conn, 'purchases', pid, sets)
        hist(conn, 'purchase', pid, 'purchase', 'Ordered%s%s%s' % ((' from ' + sets['vendor']) if sets.get('vendor') else '', (' (PO %s)' % sets['po_no']) if sets.get('po_no') else '',
                                                                   (', expected %s' % sets['expected_on']) if sets.get('expected_on') else ''), **link)
    elif act == 'receive':
        if cur in ('received', 'cancelled'):
            raise ApiError(409, 'Already %s' % cur)
        upd(conn, 'purchases', pid, {'status': 'received', 'received_on': on})
        text = 'Received %d x %s on %s' % (b['qty'], b['item'], on)
        if d.get('add_to_stock'):
            serials = d.get('serials') or []
            if isinstance(serials, str):
                serials = [x.strip() for x in re.split(r'[\r\n,;]+', serials) if x.strip()]
            cond = str(d.get('cond') or 'new')
            base = {'kind': b['kind'], 'name': b['item'], 'plant': b['plant'], 'vendor': b['vendor'], 'purchase_date': on, 'cond': cond,
                    'warranty_until': d.get('warranty_until') or None}
            if b['kind'] in BULK_KINDS:
                ex = conn.execute("SELECT id FROM assets WHERE tracked=0 AND kind=? AND plant=? AND lower(name)=? LIMIT 1", (b['kind'], b['plant'], lc(b['item']))).fetchone()
                if ex:
                    asset_op(conn, ex['id'], {'op': 'restock', 'qty': b['qty'], 'note': 'Purchase %s' % b['code']}, demo)
                    created.append(ex['id'])
                else:
                    created.append(create_asset(conn, dict(base, tracked=0, qty=b['qty']), demo))
            else:
                for i in range(b['qty']):
                    created.append(create_asset(conn, dict(base, tracked=1, serial=serials[i] if i < len(serials) else ''), demo))
            codes = [conn.execute('SELECT code FROM assets WHERE id=?', (x,)).fetchone()['code'] for x in created]
            text += ' - added to stock: %s' % ', '.join(codes)
        hist(conn, 'purchase', pid, 'purchase', text, **link)
    elif act == 'cancel':
        if cur in ('received', 'cancelled'):
            raise ApiError(409, 'Already %s' % cur)
        upd(conn, 'purchases', pid, {'status': 'cancelled'})
        hist(conn, 'purchase', pid, 'purchase', 'Cancelled' + ((': ' + note) if note else ''), **link)
    elif act == 'reopen':
        if cur != 'cancelled':
            raise ApiError(409, 'Only a cancelled request can be re-opened')
        upd(conn, 'purchases', pid, {'status': 'requested'})
        hist(conn, 'purchase', pid, 'purchase', 'Re-opened', **link)
    elif act == 'note':
        if not note:
            raise ApiError(400, 'Write the note first')
        upd(conn, 'purchases', pid, {})
        hist(conn, 'purchase', pid, 'note', note, **link)
    else:
        raise ApiError(400, 'Unknown action')
    return created


def list_purchases(conn):
    out = []
    for r in conn.execute("SELECT b.*, p.name AS person_name FROM purchases b LEFT JOIN people p ON p.id=b.person_id ORDER BY b.id DESC"):
        b = dict(r)
        b['open'] = b['status'] in ('requested', 'approved', 'ordered')
        ex = parse_d(b['expected_on'])
        b['late'] = bool(b['status'] == 'ordered' and ex and ex < today_date())
        out.append(b)
    return out


def purchase_detail(conn, pid):
    r = need(conn.execute("SELECT b.*, p.name AS person_name FROM purchases b LEFT JOIN people p ON p.id=b.person_id WHERE b.id=?", (pid,)).fetchone(), 'Purchase')
    b = dict(r)
    b['history'] = history_of(conn, "ent='purchase' AND ent_id=?", (pid,))
    b['files'] = list_files(conn, 'purchase', pid)
    return b


# ----------------------------------------------------------------------------- renewals (AMC, licence, domain...) and warranty
def list_renewals(conn, st):
    tm = team_map(conn)
    default = int(st.get('renew_days') or 30)
    out = []
    for r in conn.execute('SELECT * FROM renewals ORDER BY expires_on, id'):
        x = dict(r)
        ex = parse_d(x['expires_on'])
        x['days_left'] = (ex - today_date()).days if ex else None
        x['remind'] = x['remind_days'] if x['remind_days'] else default
        x['state'] = 'closed' if x['status'] == 'closed' else ('expired' if x['days_left'] is not None and x['days_left'] < 0 else
                                                                'due' if x['days_left'] is not None and x['days_left'] <= x['remind'] else 'ok')
        x['owner'] = who_name(tm, st, x['owner_id'])
        out.append(x)
    return out


def warranty_list(conn, within=90):
    out = []
    for r in conn.execute("SELECT id, code, kind, name, serial, tag, plant, warranty_until, status, person_id FROM assets WHERE warranty_until IS NOT NULL AND warranty_until<>'' AND status NOT IN ('scrap','lost')"):
        wu = parse_d(r['warranty_until'])
        if not wu:
            continue
        left = (wu - today_date()).days
        if left <= within:
            x = dict(r)
            x['days_left'] = left
            out.append(x)
    out.sort(key=lambda x: x['days_left'])
    return out


def create_renewal(conn, d, demo=False):
    vals = clean('renewals', d)
    if not (vals.get('title') or '').strip():
        raise ApiError(400, 'Write what is renewed (for example "CCTV AMC - Jaitpura")')
    if not vals.get('expires_on'):
        raise ApiError(400, 'Choose the expiry date')
    vals.setdefault('kind', 'amc')
    vals['status'] = 'active'
    if vals.get('owner_id') not in (None, 0):
        need(conn.execute('SELECT 1 FROM team WHERE id=?', (vals['owner_id'],)).fetchone(), 'Team member')
    rid = ins(conn, 'renewals', vals, demo)
    code = finish_code(conn, 'renewals', rid, 'N', vals['title'])
    hist(conn, 'renewal', rid, 'created', 'Added: %s, expires %s' % (vals['title'], vals['expires_on']), demo=demo)
    return rid


def update_renewal(conn, rid, d):
    old = need(conn.execute('SELECT * FROM renewals WHERE id=?', (rid,)).fetchone(), 'Renewal')
    vals = clean('renewals', d)
    if 'title' in vals and not vals['title']:
        raise ApiError(400, 'Title cannot be empty')
    if 'expires_on' in vals and not vals['expires_on']:
        raise ApiError(400, 'Choose the expiry date')
    if d.get('status') in ('active', 'closed'):
        vals['status'] = d['status']
    changes = diff_text(old, vals, {'title': 'Title', 'vendor': 'Vendor', 'expires_on': 'Expires on', 'cost': 'Cost', 'plant': 'Plant', 'status': 'Status'})
    upd(conn, 'renewals', rid, vals)
    if changes:
        hist(conn, 'renewal', rid, 'edit', '; '.join(changes))


def renew_renewal(conn, rid, d):
    old = need(conn.execute('SELECT * FROM renewals WHERE id=?', (rid,)).fetchone(), 'Renewal')
    new_exp = clean_date(str(d.get('expires_on') or ''))
    if not new_exp:
        raise ApiError(400, 'Choose the new expiry date')
    if old['expires_on'] and new_exp <= old['expires_on']:
        raise ApiError(400, 'The new expiry date must be after %s' % old['expires_on'])
    sets = {'expires_on': new_exp, 'status': 'active'}
    if d.get('cost') not in (None, ''):
        try:
            sets['cost'] = float(d['cost'])
        except (TypeError, ValueError):
            raise ApiError(400, 'Invalid amount')
    upd(conn, 'renewals', rid, sets)
    hist(conn, 'renewal', rid, 'renew', 'Renewed: %s → %s%s' % (old['expires_on'], new_exp, (' (cost %s)' % sets['cost']) if 'cost' in sets else '') +
         ((' - ' + str(d.get('note')).strip()) if str(d.get('note') or '').strip() else ''))


def renewal_detail(conn, rid):
    r = dict(need(conn.execute('SELECT * FROM renewals WHERE id=?', (rid,)).fetchone(), 'Renewal'))
    r['history'] = history_of(conn, "ent='renewal' AND ent_id=?", (rid,))
    r['files'] = list_files(conn, 'renewal', rid)
    return r


# ----------------------------------------------------------------------------- team
def create_team(conn, d, demo=False):
    vals = clean('team', d)
    if not (vals.get('name') or '').strip():
        raise ApiError(400, 'Write the name')
    vals.setdefault('active', 1)
    return ins(conn, 'team', vals, demo)


def update_team(conn, tid, d):
    need(conn.execute('SELECT 1 FROM team WHERE id=?', (tid,)).fetchone(), 'Team member')
    vals = clean('team', d)
    if 'name' in vals and not vals['name']:
        raise ApiError(400, 'Name cannot be empty')
    upd(conn, 'team', tid, vals)


def delete_team(conn, tid):
    need(conn.execute('SELECT 1 FROM team WHERE id=?', (tid,)).fetchone(), 'Team member')
    n = conn.execute('SELECT COUNT(*) FROM tickets WHERE assigned_to=?', (tid,)).fetchone()[0] + conn.execute('SELECT COUNT(*) FROM routines WHERE assigned_to=?', (tid,)).fetchone()[0] + \
        conn.execute('SELECT COUNT(*) FROM renewals WHERE owner_id=?', (tid,)).fetchone()[0]
    if n:
        raise ApiError(409, 'This person has work on record. Switch him to "not active" instead - the history stays.')
    conn.execute('DELETE FROM team WHERE id=?', (tid,))


def team_with_load(conn, st):
    out = []
    since = (today_date() - dt.timedelta(days=30)).isoformat()
    for r in conn.execute('SELECT * FROM team ORDER BY active DESC, name'):
        m = dict(r)
        tid = m['id']
        q = lambda sql, *p: conn.execute(sql, p).fetchone()[0]
        m['open'] = q("SELECT COUNT(*) FROM tickets WHERE assigned_to=? AND status IN ('assigned','progress','waiting')", tid)
        m['new_open'] = q("SELECT COUNT(*) FROM tickets WHERE assigned_to=? AND status IN ('assigned')", tid)
        m['waiting'] = q("SELECT COUNT(*) FROM tickets WHERE assigned_to=? AND status='waiting'", tid)
        m['to_check'] = q("SELECT COUNT(*) FROM tickets WHERE assigned_to=? AND status='done'", tid)
        m['overdue'] = q("SELECT COUNT(*) FROM tickets WHERE assigned_to=? AND status IN ('assigned','progress','waiting') AND due_at<?", tid, now_min())
        m['closed_30'] = q("SELECT COUNT(*) FROM tickets WHERE assigned_to=? AND status='closed' AND closed_at>=?", tid, since)
        m['routines'] = q('SELECT COUNT(*) FROM routines WHERE assigned_to=? AND active=1', tid)
        out.append(m)
    return out


# ----------------------------------------------------------------------------- daily / weekly / monthly checks
def routine_cur_prev(r, today, wd):
    f = r['frequency']
    if f == 'weekly':
        w = int(r['weekday'] or 0) % 7
        cur = today - dt.timedelta(days=(today.weekday() - w) % 7)
        prev = cur - dt.timedelta(days=7)
    elif f == 'monthly':
        day = max(1, min(28, int(r['month_day'] or 1)))
        y, m = today.year, today.month
        if today.day < day:
            m -= 1
            if m == 0:
                y, m = y - 1, 12
        cur = dt.date(y, m, day)
        py, pm = (y, m - 1) if m > 1 else (y - 1, 12)
        prev = dt.date(py, pm, day)
    else:
        d = today
        for _ in range(8):
            if d.weekday() in wd:
                break
            d -= dt.timedelta(days=1)
        cur = d
        p = cur - dt.timedelta(days=1)
        for _ in range(8):
            if p.weekday() in wd:
                break
            p -= dt.timedelta(days=1)
        prev = p
    return cur, prev


def due_dates_between(r, d1, d2, wd):
    out = []
    created = parse_d(r['created_on'])
    if created and d1 < created:
        d1 = created
    d = d1
    day = max(1, min(28, int(r['month_day'] or 1)))
    n = 0
    while d <= d2 and n < 800:
        if r['frequency'] == 'weekly':
            ok = d.weekday() == int(r['weekday'] or 0) % 7
        elif r['frequency'] == 'monthly':
            ok = d.day == day
        else:
            ok = d.weekday() in wd
        if ok:
            out.append(d)
        d += dt.timedelta(days=1)
        n += 1
    return out


def list_routines(conn, st):
    wd = work_days_of(st)
    today = today_date()
    tm = team_map(conn)
    since = (today - dt.timedelta(days=75)).isoformat()
    logs = {}
    for l in conn.execute('SELECT * FROM routine_log WHERE on_date>=? ORDER BY id', (since,)):
        logs[(l['routine_id'], l['on_date'])] = dict(l)
    out = []
    for r in conn.execute('SELECT * FROM routines ORDER BY active DESC, sort, id'):
        x = dict(r)
        cur, prev = routine_cur_prev(x, today, wd)
        created = parse_d(x['created_on'])

        def state(day):
            if created and day < created:
                return None
            lg = logs.get((x['id'], day.isoformat()))
            if lg:
                return lg['status']
            return 'pending' if day == today else 'missed'
        x['cur_due'] = cur.isoformat()
        x['prev_due'] = prev.isoformat()
        x['state'] = state(cur)
        x['prev_state'] = state(prev)
        x['cur_log'] = logs.get((x['id'], cur.isoformat()))
        if x['cur_log']:
            x['cur_log']['by_name'] = who_name(tm, st, x['cur_log']['by_id'])
        x['assignee'] = who_name(tm, st, x['assigned_to'])
        out.append(x)
    return out


def routine_logs(conn, rid, limit=40):
    st = get_settings(conn)
    tm = team_map(conn)
    rows = row_dicts(conn.execute('SELECT * FROM routine_log WHERE routine_id=? ORDER BY on_date DESC, id DESC LIMIT ?', (rid, limit)))
    for x in rows:
        x['by_name'] = who_name(tm, st, x['by_id'])
    return rows


def create_routine(conn, d, demo=False):
    vals = clean('routines', d)
    if not (vals.get('title') or '').strip():
        raise ApiError(400, 'Write what has to be checked (for example "SAP backup finished OK")')
    vals.setdefault('frequency', 'daily')
    vals['weekday'] = max(0, min(6, vals.get('weekday') or 0))
    vals['month_day'] = max(1, min(28, vals.get('month_day') or 1))
    vals.setdefault('active', 1)
    vals['created_on'] = today_iso()
    check_assignee(conn, vals.get('assigned_to'))
    return ins(conn, 'routines', vals, demo)


def update_routine(conn, rid, d):
    need(conn.execute('SELECT 1 FROM routines WHERE id=?', (rid,)).fetchone(), 'Check')
    vals = clean('routines', d)
    if 'title' in vals and not vals['title']:
        raise ApiError(400, 'Title cannot be empty')
    if 'weekday' in vals:
        vals['weekday'] = max(0, min(6, vals['weekday'] or 0))
    if 'month_day' in vals:
        vals['month_day'] = max(1, min(28, vals['month_day'] or 1))
    if 'assigned_to' in vals:
        check_assignee(conn, vals['assigned_to'])
    upd(conn, 'routines', rid, vals)


def log_routine(conn, rid, d, demo=False):
    st = get_settings(conn)
    r = need(conn.execute('SELECT * FROM routines WHERE id=?', (rid,)).fetchone(), 'Check')
    wd = work_days_of(st)
    cur, _prev = routine_cur_prev(dict(r), today_date(), wd)
    day = clean_date(str(d.get('on_date') or '')) or cur.isoformat()
    if day > today_iso():
        raise ApiError(400, 'A check cannot be marked for a future date')
    status = str(d.get('status') or 'ok')
    if status not in ('ok', 'issue', 'skipped'):
        raise ApiError(400, 'Invalid status')
    note = str(d.get('note') or '').strip()[:2000]
    if status in ('issue', 'skipped') and not note:
        raise ApiError(400, 'Write in one line what the problem was' if status == 'issue' else 'Write why it was skipped')
    by = check_assignee(conn, d.get('by_id')) if d.get('by_id') not in (None, '') else r['assigned_to']
    ex = conn.execute('SELECT id FROM routine_log WHERE routine_id=? AND on_date=? ORDER BY id DESC LIMIT 1', (rid, day)).fetchone()
    tid = int(d['ticket_id']) if str(d.get('ticket_id') or '').isdigit() and int(d['ticket_id']) else None
    if ex:
        conn.execute('UPDATE routine_log SET status=?, note=?, by_id=?, ts=?, ticket_id=COALESCE(?,ticket_id) WHERE id=?', (status, note, by, now_ts(), tid, ex['id']))
    else:
        conn.execute('INSERT INTO routine_log(routine_id,on_date,status,by_id,note,ts,ticket_id,is_demo) VALUES(?,?,?,?,?,?,?,?)', (rid, day, status, by, note, now_ts(), tid, 1 if demo else 0))
    if status != 'ok':
        hist(conn, 'routine', rid, 'routine', '%s (%s): %s' % (r['title'], day, ('PROBLEM - ' if status == 'issue' else 'Skipped - ') + note), demo=demo)
    return day


def delete_routine(conn, rid):
    need(conn.execute('SELECT 1 FROM routines WHERE id=?', (rid,)).fetchone(), 'Check')
    conn.execute('DELETE FROM routines WHERE id=?', (rid,))
    conn.execute("DELETE FROM history WHERE ent='routine' AND ent_id=?", (rid,))


# ----------------------------------------------------------------------------- dashboard
def in_plant(row, plant, key='plant'):
    return (not plant) or (row.get(key) in (plant, '', None))


def dashboard(conn, plant=''):
    st = get_settings(conn)
    tm = team_map(conn)
    today = today_iso()
    now = dt.datetime.now()
    all_tickets = list_tickets(conn)
    tickets = [t for t in all_tickets if (not plant or t['plant'] == plant)]
    open_t = [t for t in tickets if t['is_open']]
    to_check = [t for t in tickets if t['status'] == 'done']
    since30 = (today_date() - dt.timedelta(days=30)).isoformat()
    since7 = (today_date() - dt.timedelta(days=7)).isoformat()
    closed30 = [t for t in tickets if t['status'] == 'closed' and (t['closed_at'] or '') >= since30]
    tats = [t['age_hours'] for t in closed30 if t['age_hours'] is not None]
    kpi = {
        'open': len(open_t), 'overdue': sum(1 for t in open_t if t['overdue']),
        'unassigned': sum(1 for t in open_t if t['assigned_to'] is None), 'to_check': len(to_check),
        'waiting': sum(1 for t in open_t if t['status'] == 'waiting'), 'critical': sum(1 for t in open_t if t['priority'] == 'critical'),
        'closed_7': sum(1 for t in tickets if t['status'] == 'closed' and (t['closed_at'] or '') >= since7),
        'avg_tat_h': round(sum(tats) / len(tats), 1) if tats else None,
        'sla_pct': (round(100.0 * sum(1 for t in closed30 if t['sla_met']) / len([t for t in closed30 if t['sla_met'] is not None]))
                    if [t for t in closed30 if t['sla_met'] is not None] else None),
    }

    def tk(t, extra=''):
        sub = ' / '.join(x for x in [t['requester'], t['assignee'] and 'with ' + t['assignee'], extra] if x)
        return {'label': t['code'] + '  ' + t['title'], 'sub': sub, 'go': {'view': 'tickets', 'id': t['id']}}
    att = []

    def grp(key, title, sev, items, go=None, more=None):
        if items:
            att.append({'key': key, 'title': title, 'sev': sev, 'count': len(items) if more is None else more, 'items': items[:6], 'go': go})
    ovd = sorted([t for t in open_t if t['overdue']], key=lambda t: t['due_at'] or '')
    grp('overdue', 'Overdue tickets', 'high', [tk(t, 'due ' + (t['due_at'] or '')) for t in ovd], {'view': 'tickets', 'filter': 'overdue'})
    grp('unassigned', 'Nobody is assigned yet', 'mid', [tk(t) for t in open_t if t['assigned_to'] is None], {'view': 'tickets', 'filter': 'unassigned'})
    grp('tocheck', 'Team says done - check and close', 'mid', [tk(t, 'done ' + (t['done_at'] or '')) for t in to_check], {'view': 'tickets', 'filter': 'tocheck'})
    grp('follow', 'Follow-up due today', 'mid', [tk(t, 'follow-up ' + (t['follow_up_on'] or '')) for t in open_t + to_check if t['follow_due']], {'view': 'tickets', 'filter': 'follow'})
    quiet = [t for t in open_t if t['quiet_days'] >= 2]
    grp('quiet', 'No update for 2+ days', 'low', [tk(t, '%d days quiet' % t['quiet_days']) for t in quiet], {'view': 'tickets', 'filter': 'quiet'})

    people = [p for p in list_people(conn) if (not plant or p['plant'] == plant)]
    lv = [p for p in people if p['leaver_pending']]
    grp('leavers', 'Left the company but still hold items / accounts', 'high',
        [{'label': p['name'], 'sub': '%s - %s%s' % (p['plant'], ('%d item(s) ' % (p['n_assets'] + p['n_bulk'])) if p['has_items'] else '', ('%d account(s)' % p['n_accounts']) if p['n_accounts'] else ''),
          'go': {'view': 'people', 'id': p['id']}} for p in lv], {'view': 'people', 'filter': 'leaver'})
    recent = (today_date() - dt.timedelta(days=21)).isoformat()
    jn = [p for p in people if p['status'] in ('joining', 'active') and (p['joined_on'] or '') >= recent and p['n_steps_open']]
    grp('joiners', 'New joiners - setup not finished', 'mid', [{'label': p['name'], 'sub': '%s - %d step(s) open' % (p['plant'], p['n_steps_open']), 'go': {'view': 'people', 'id': p['id']}} for p in jn],
        {'view': 'people', 'filter': 'joiner'})

    ss = [k for k in stock_summary(conn, st) if k['low']]
    grp('stock', 'Stock is low', 'mid', [{'label': '%s: %d in stock (minimum %d)' % (k['label'], k['in_stock'], k['min']),
                                          'sub': ('%d on order' % k['on_order']) if k['on_order'] else 'nothing on order', 'go': {'view': 'stock', 'kind': k['kind']}} for k in ss], {'view': 'stock'})

    trs = [t for t in list_transports(conn)]
    pend = [t for t in trs if t['status'] in ('requested', 'qas', 'approved', 'hold', 'failed')]
    need_ap = [t for t in pend if not t['approved_on'] and t['status'] in ('requested', 'qas')]
    ready = [t for t in pend if t['status'] == 'approved']
    bad = [t for t in pend if t['status'] == 'failed']
    trk = lambda t, extra: {'label': '%s  %s' % (t['tr_number'] or t['code'], t['description']), 'sub': '%s - %s%s' % (t['requested_by'] or '-', extra, (' - %d days' % t['age_days']) if t['age_days'] else ''),
                            'go': {'view': 'transports', 'id': t['id']}}
    grp('tr_fail', 'Transport failed in production', 'high', [trk(t, 'failed (rc %s)' % t['rc']) for t in bad], {'view': 'transports', 'filter': 'failed'})
    grp('tr_ready', 'Approved - ready to move to production', 'mid', [trk(t, 'approved by ' + (t['approver'] or '?')) for t in ready], {'view': 'transports', 'filter': 'approved'})
    grp('tr_need', 'Transport waiting for approval', 'low', [trk(t, t['status']) for t in need_ap], {'view': 'transports', 'filter': 'requested'})

    rn = [r for r in list_renewals(conn, st) if r['state'] in ('expired', 'due') and (not plant or r['plant'] in ('', plant))]
    grp('renew', 'Contracts / licences expiring', 'high' if any(r['state'] == 'expired' for r in rn) else 'mid',
        [{'label': r['title'], 'sub': ('expired %d days ago' % -r['days_left']) if r['days_left'] < 0 else ('%d days left' % r['days_left']), 'go': {'view': 'buy', 'tab': 'renew', 'id': r['id']}}
         for r in sorted(rn, key=lambda r: r['days_left'])], {'view': 'buy', 'tab': 'renew'})
    wl = [w for w in warranty_list(conn, 30) if (not plant or w['plant'] in ('', plant))]
    grp('warranty', 'Warranty ending (items)', 'low', [{'label': '%s %s' % (w['code'], w['name'] or KIND_LABEL.get(w['kind'], '')),
                                                         'sub': ('ended %d days ago' % -w['days_left']) if w['days_left'] < 0 else ('%d days left' % w['days_left']),
                                                         'go': {'view': 'stock', 'id': w['id']}} for w in wl], {'view': 'buy', 'tab': 'renew'})

    rt = [r for r in list_routines(conn, st) if r['active'] and (not plant or r['plant'] in ('', plant))]
    rbad = [r for r in rt if r['state'] in ('missed', 'issue')]
    rpend = [r for r in rt if r['state'] == 'pending']
    grp('routine_bad', 'Daily checks missed or with a problem', 'high', [{'label': r['title'], 'sub': '%s - %s (%s)' % (r['plant'] or 'all plants', 'PROBLEM' if r['state'] == 'issue' else 'not done', r['cur_due']),
                                                                         'go': {'view': 'checks'}} for r in rbad], {'view': 'checks'})
    grp('routine_pend', "Today's checks still to do", 'low', [{'label': r['title'], 'sub': '%s - %s' % (r['plant'] or 'all plants', r['assignee'] or 'nobody assigned'), 'go': {'view': 'checks'}} for r in rpend], {'view': 'checks'})

    bys = [b for b in list_purchases(conn) if b['open'] and (not plant or b['plant'] in ('', plant))]
    grp('buy', 'Purchases to follow up', 'low', [{'label': '%s  %d x %s' % (b['code'], b['qty'], b['item']), 'sub': ('LATE - expected ' + b['expected_on']) if b['late'] else b['status'],
                                                 'go': {'view': 'buy', 'tab': 'buy', 'id': b['id']}} for b in sorted(bys, key=lambda b: not b['late'])], {'view': 'buy', 'tab': 'buy'})

    soon = (today_date() + dt.timedelta(days=14)).isoformat()
    ae = [a for a in conn.execute("SELECT c.*, p.name AS pname, p.plant AS pplant FROM accounts c LEFT JOIN people p ON p.id=c.person_id WHERE c.status='active' AND c.valid_to IS NOT NULL AND c.valid_to<>'' AND c.valid_to<=?", (soon,))
          if (not plant or (a['pplant'] or '') in ('', plant))]
    grp('acc', 'User ids expiring in 14 days', 'low', [{'label': '%s (%s)' % (a['identifier'], a['pname'] or a['owner_name']), 'sub': 'valid until ' + a['valid_to'], 'go': {'view': 'people', 'tab': 'accounts'}} for a in ae],
        {'view': 'people', 'tab': 'accounts'})

    inactive = [t for t in open_t if t['assigned_to'] and tm.get(t['assigned_to']) and not tm[t['assigned_to']]['active']]
    grp('inactive', 'Work is with a team member who is not active', 'mid', [tk(t) for t in inactive], {'view': 'tickets'})

    load = []
    for m in tm.values():
        if not m['active']:
            continue
        mine = [t for t in open_t if t['assigned_to'] == m['id']]
        load.append({'id': m['id'], 'name': m['name'], 'plant': m['plant'], 'role': m['role'], 'open': len(mine), 'overdue': sum(1 for t in mine if t['overdue']),
                     'to_check': sum(1 for t in to_check if t['assigned_to'] == m['id'])})
    mine = [t for t in open_t if t['assigned_to'] == 0]
    if mine or not load:
        load.insert(0, {'id': 0, 'name': (st.get('manager') or 'Me') + ' (me)', 'plant': '', 'role': 'Lead', 'open': len(mine), 'overdue': sum(1 for t in mine if t['overdue']),
                        'to_check': sum(1 for t in to_check if t['assigned_to'] == 0)})
    load.sort(key=lambda x: (-x['open'], x['name']))
    by_plant = []
    for p in plants_of(st):
        pt = [t for t in all_tickets if t['plant'] == p['code']]
        by_plant.append({'code': p['code'], 'name': p['name'], 'open': sum(1 for t in pt if t['is_open']), 'overdue': sum(1 for t in pt if t['overdue'])})
    recent_h = row_dicts(conn.execute('SELECT * FROM history ORDER BY id DESC LIMIT 14'))
    return {'kpi': kpi, 'attention': att, 'load': load, 'by_plant': by_plant, 'recent': recent_h, 'team_empty': conn.execute('SELECT COUNT(*) FROM team').fetchone()[0] == 0,
            'empty': conn.execute('SELECT (SELECT COUNT(*) FROM tickets)+(SELECT COUNT(*) FROM people)+(SELECT COUNT(*) FROM assets)').fetchone()[0] == 0}


# ----------------------------------------------------------------------------- report for the IT head
def report(conn, d1, d2, plant=''):
    st = get_settings(conn)
    tm = team_map(conn)
    a, b = d1.isoformat(), d2.isoformat()
    inr = lambda s: bool(s) and a <= s[:10] <= b
    tickets = [t for t in list_tickets(conn) if (not plant or t['plant'] == plant)]
    opened = [t for t in tickets if inr(t['received_at'])]
    closed = [t for t in tickets if t['status'] == 'closed' and inr(t['closed_at'])]
    open_now = [t for t in tickets if t['is_open']]
    tats = [t['age_hours'] for t in closed if t['age_hours'] is not None]
    sla_c = [t for t in closed if t['sla_met'] is not None]
    cats = dict(TICKET_CATS)
    by_cat = {}
    for t in opened:
        by_cat[t['category']] = by_cat.get(t['category'], 0) + 1
    by_plant = {}
    for p in plants_of(st):
        po = [t for t in opened if t['plant'] == p['code']]
        pc = [t for t in closed if t['plant'] == p['code']]
        by_plant[p['code']] = {'code': p['code'], 'name': p['name'], 'opened': len(po), 'closed': len(pc), 'open_now': sum(1 for t in open_now if t['plant'] == p['code']),
                               'overdue_now': sum(1 for t in open_now if t['plant'] == p['code'] and t['overdue'])}
    by_member = []
    ids = sorted({t['assigned_to'] for t in opened + closed if t['assigned_to'] is not None})
    for mid in ids:
        mc = [t for t in closed if t['assigned_to'] == mid]
        mt = [t['age_hours'] for t in mc if t['age_hours'] is not None]
        by_member.append({'name': who_name(tm, st, mid), 'assigned': sum(1 for t in opened if t['assigned_to'] == mid), 'closed': len(mc),
                          'open_now': sum(1 for t in open_now if t['assigned_to'] == mid), 'avg_tat_h': round(sum(mt) / len(mt), 1) if mt else None})
    people = [p for p in list_people(conn) if (not plant or p['plant'] == plant)]
    joined = [p for p in people if inr(p['joined_on'])]
    left = [p for p in people if inr(p['left_on'])]
    flows = row_dicts(conn.execute("SELECT l.kind, l.qty, a.kind AS akind FROM asset_log l JOIN assets a ON a.id=l.asset_id WHERE substr(l.ts,1,10)>=? AND substr(l.ts,1,10)<=? AND l.kind IN ('issue','return','scrap')", (a, b)))
    stock = {'issued': sum(f['qty'] for f in flows if f['kind'] == 'issue'), 'returned': sum(f['qty'] for f in flows if f['kind'] == 'return'),
             'scrapped': sum(f['qty'] for f in flows if f['kind'] == 'scrap')}
    trs = list_transports(conn)
    tr = {'moved_prd': sum(1 for t in trs if t['prd_on'] and inr(t['prd_on']) and t['status'] == 'prd'), 'requested': sum(1 for t in trs if inr(t['requested_on'])),
          'failed': sum(1 for t in trs if t['status'] == 'failed'), 'pending': sum(1 for t in trs if t['status'] in ('requested', 'qas', 'approved', 'hold'))}
    buys = list_purchases(conn)
    bp = {'requested': sum(1 for x in buys if inr(x['requested_on'])), 'received': sum(1 for x in buys if inr(x['received_on'])), 'open': sum(1 for x in buys if x['open'])}
    wd = work_days_of(st)
    exp = done = prob = 0
    rt = [r for r in conn.execute('SELECT * FROM routines WHERE active=1') if (not plant or r['plant'] in ('', plant))]
    for r in rt:
        r = dict(r)
        dd = [x for x in due_dates_between(r, d1, min(d2, today_date()), wd)]
        exp += len(dd)
        for day in dd:
            lg = conn.execute('SELECT status FROM routine_log WHERE routine_id=? AND on_date=? ORDER BY id DESC LIMIT 1', (r['id'], day.isoformat())).fetchone()
            if lg and lg['status'] in ('ok', 'issue'):
                done += 1
                if lg['status'] == 'issue':
                    prob += 1
    rn = [r for r in list_renewals(conn, st) if r['state'] in ('expired', 'due')]
    return {
        'from': a, 'to': b, 'plant': plant, 'plant_label': plant_label(st, plant) if plant else 'All plants', 'manager': st.get('manager'), 'hod': st.get('hod'), 'company': st.get('company'),
        'tickets': {'opened': len(opened), 'closed': len(closed), 'open_now': len(open_now), 'overdue_now': sum(1 for t in open_now if t['overdue']),
                    'to_check': sum(1 for t in tickets if t['status'] == 'done'), 'avg_tat_h': round(sum(tats) / len(tats), 1) if tats else None,
                    'sla_pct': round(100.0 * sum(1 for t in sla_c if t['sla_met']) / len(sla_c)) if sla_c else None,
                    'by_category': [{'key': k, 'label': cats.get(k, k), 'n': n} for k, n in sorted(by_cat.items(), key=lambda x: -x[1])],
                    'critical_closed': sum(1 for t in closed if t['priority'] == 'critical')},
        'by_plant': list(by_plant.values()), 'by_member': by_member,
        'people': {'joined': [{'name': p['name'], 'plant': p['plant'], 'department': p['department'], 'on': p['joined_on'], 'steps_open': p['n_steps_open']} for p in joined],
                   'left': [{'name': p['name'], 'plant': p['plant'], 'on': p['left_on'], 'pending': p['leaver_pending']} for p in left]},
        'stock': {'moves': stock, 'summary': [k for k in stock_summary(conn, st)]},
        'transports': tr, 'purchases': bp,
        'checks': {'expected': exp, 'done': done, 'problems': prob, 'pct': round(100.0 * done / exp) if exp else None},
        'renewals': [{'title': r['title'], 'days_left': r['days_left'], 'expires_on': r['expires_on']} for r in rn],
        'overdue_list': [{'code': t['code'], 'title': t['title'], 'assignee': t['assignee'], 'due_at': t['due_at'], 'plant': t['plant']} for t in sorted([t for t in open_now if t['overdue']], key=lambda t: t['due_at'] or '')[:15]],
    }


# ----------------------------------------------------------------------------- search
def search_all(conn, q):
    q = (q or '').strip()
    if len(q) < 2:
        return []
    like = '%' + q.replace('%', '').replace('_', '') + '%'
    out = []
    for r in conn.execute("SELECT id, code, title, requester, status FROM tickets WHERE code LIKE ? OR title LIKE ? OR requester LIKE ? OR details LIKE ? ORDER BY id DESC LIMIT 6", (like,) * 4):
        out.append({'kind': 'ticket', 'id': r['id'], 'title': '%s  %s' % (r['code'], r['title']), 'sub': '%s - %s' % (r['requester'], TS_MAP.get(r['status'], {}).get('label', ''))})
    for r in conn.execute("SELECT id, code, name, emp_code, department, status FROM people WHERE name LIKE ? OR emp_code LIKE ? OR code LIKE ? OR email LIKE ? OR mobile LIKE ? ORDER BY name LIMIT 6", (like,) * 5):
        out.append({'kind': 'person', 'id': r['id'], 'title': r['name'], 'sub': '%s %s%s' % (r['emp_code'], r['department'], ' - LEFT' if r['status'] == 'left' else '')})
    for r in conn.execute("SELECT id, code, kind, name, serial, tag, status FROM assets WHERE code LIKE ? OR name LIKE ? OR serial LIKE ? OR tag LIKE ? ORDER BY id DESC LIMIT 6", (like,) * 4):
        out.append({'kind': 'asset', 'id': r['id'], 'title': '%s  %s %s' % (r['code'], KIND_LABEL.get(r['kind'], ''), r['name']), 'sub': '%s %s - %s' % (r['serial'], r['tag'], dict(ASSET_STATUS).get(r['status'], ''))})
    for r in conn.execute("SELECT id, code, tr_number, description, status FROM transports WHERE code LIKE ? OR tr_number LIKE ? OR description LIKE ? ORDER BY id DESC LIMIT 5", (like,) * 3):
        out.append({'kind': 'transport', 'id': r['id'], 'title': '%s  %s' % (r['tr_number'] or r['code'], r['description']), 'sub': TR_LABEL.get(r['status'], '')})
    for r in conn.execute("SELECT c.id, c.person_id, c.kind, c.identifier, c.status, p.name FROM accounts c LEFT JOIN people p ON p.id=c.person_id WHERE c.identifier LIKE ? ORDER BY c.id DESC LIMIT 5", (like,)):
        out.append({'kind': 'person' if r['person_id'] else 'account', 'id': r['person_id'] or r['id'], 'title': r['identifier'], 'sub': '%s - %s (%s)' % (dict(ACCOUNT_KINDS).get(r['kind'], ''), r['name'] or 'shared', r['status'])})
    return out


# ----------------------------------------------------------------------------- settings
def save_settings(conn, d):
    for k in DEFAULT_SETTINGS:
        if k not in d:
            continue
        v = d[k]
        if k == 'plants':
            if isinstance(v, str):
                try:
                    v = json.loads(v)
                except Exception:
                    raise ApiError(400, 'Invalid plant list')
            seen, out = set(), []
            for p in v if isinstance(v, list) else []:
                code = str(p.get('code', '')).strip()[:10]
                if not code:
                    continue
                if code in seen:
                    raise ApiError(400, 'Plant code %s is written twice' % code)
                seen.add(code)
                out.append({'code': code, 'name': str(p.get('name', '')).strip()[:60]})
            if not out:
                raise ApiError(400, 'Keep at least one plant')
            v = json.dumps(out)
        elif k == 'min_stock':
            if isinstance(v, str):
                try:
                    v = json.loads(v)
                except Exception:
                    raise ApiError(400, 'Invalid minimum stock list')
            v = json.dumps({kk: max(0, int(n)) for kk, n in (v or {}).items() if kk in KIND_KEYS and str(n).strip() not in ('', 'None') and int(n) > 0})
        elif k.startswith('sla_'):
            try:
                f = float(v)
            except (TypeError, ValueError):
                raise ApiError(400, 'Hours must be a number')
            if f <= 0 or f > 2000:
                raise ApiError(400, 'Hours must be between 1 and 2000')
            v = ('%g' % f)
        elif k == 'renew_days':
            v = str(max(1, min(365, int(float(v or 30)))))
        elif k == 'tr_need_approval':
            v = '1' if str(v) in ('1', 'true', 'True') else '0'
        elif k == 'work_days':
            v = ','.join(str(x) for x in sorted(work_days_of({'work_days': v})))
        elif k == 'wa_prefix':
            v = re.sub(r'\D', '', str(v))[:4]
        elif k.startswith('tpl_'):
            v = '\n'.join(x.strip()[:200] for x in str(v).splitlines() if x.strip())[:4000]
        else:
            v = str(v).strip()[:200]
        conn.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (k, v))
    return get_settings(conn)


def meta_settings(st):
    out = dict(st)
    out['plants'] = plants_of(st)
    out['min_stock'] = min_stock_of(st)
    out['wa_prefix'] = st.get('wa_prefix', '91')
    return out


# ----------------------------------------------------------------------------- joiner / leaver steps tick themselves
JOIN_WORDS = {'laptop': ['laptop', 'pc'], 'desktop': ['laptop', 'pc'], 'mouse': ['mouse'], 'keyboard': ['keyboard'], 'phone': ['phone'],
              'email': ['mail id'], 'sap': ['sap user'], 'domain': ['domain'], 'vpn': ['vpn']}


def auto_for(conn, pid, event, kind):
    p = conn.execute('SELECT status FROM people WHERE id=?', (pid,)).fetchone()
    if not p:
        return
    if p['status'] == 'left':
        flow = 'leave'
        if event == 'return':
            if holdings(conn, pid):
                return
            words = ['collected', 'laptop', 'accessories']
        elif event == 'account':
            words = JOIN_WORDS.get(kind, [])
        else:
            return
    else:
        flow = 'join'
        if event == 'return':
            return
        words = JOIN_WORDS.get(kind, [])
    if not words:
        return
    for s in conn.execute('SELECT * FROM steps WHERE person_id=? AND flow=? AND done=0 ORDER BY sort', (pid, flow)).fetchall():
        if any(w in s['text'].lower() for w in words):
            conn.execute('UPDATE steps SET done=1, done_at=?, done_by=?, note=? WHERE id=?', (now_ts(), 'automatic', 'Ticked automatically', s['id']))
            hist(conn, 'person', pid, 'step', 'Step done: %s (automatic)' % s['text'])
            if event != 'return':
                break


# ----------------------------------------------------------------------------- demo data
def seed_demo(conn):
    n_before = conn.execute('SELECT COUNT(*) FROM tickets WHERE is_demo=1').fetchone()[0]
    if n_before:
        return 0
    D = True
    day = lambda n: (today_date() + dt.timedelta(days=n)).isoformat()
    ago = lambda h: (dt.datetime.now() - dt.timedelta(hours=h)).strftime('%Y-%m-%d %H:%M')
    t_ramesh = create_team(conn, {'name': 'Ramesh Kumar', 'plant': '1100', 'role': 'Hardware & network', 'mobile': '9800000001'}, D)
    t_sunil = create_team(conn, {'name': 'Sunil Meena', 'plant': '1100', 'role': 'SAP user support', 'mobile': '9800000002'}, D)
    t_anil = create_team(conn, {'name': 'Anil Sharma', 'plant': '1200', 'role': 'IT support', 'mobile': '9800000003'}, D)
    t_deepak = create_team(conn, {'name': 'Deepak Jat', 'plant': '1600', 'role': 'IT support', 'mobile': '9800000004'}, D)
    P = {}
    for key, nm, dep, des, plant, kind, ecode, mail, joined in [
            ('neha', 'Neha Verma', 'Accounts', 'Accountant', '1100', 'employee', 'E1001', 'neha.verma', day(-400)),
            ('rakesh', 'Rakesh Gurjar', 'Stores', 'Store keeper', '1200', 'employee', 'E1002', 'rakesh.gurjar', day(-300)),
            ('pooja', 'Pooja Saini', 'HR', 'HR executive', '1100', 'employee', 'E1003', 'pooja.saini', day(-200)),
            ('mohan', 'Mohan Lal', 'Coating line', 'Line operator', '1100', 'operator', 'E2001', '', day(-500)),
            ('imran', 'Imran Khan', 'Quality', 'QC engineer', '1600', 'employee', 'E1004', 'imran.khan', day(-150)),
            ('vikas', 'Vikas Rathore', 'Production', 'Shift incharge', '1200', 'employee', 'E1005', 'vikas.rathore', day(-90))]:
        P[key] = create_person(conn, {'name': nm, 'department': dep, 'designation': des, 'plant': plant, 'kind': kind, 'emp_code': 'DEMO-' + ecode,
                                      'email': (mail + '@demo.example') if mail else '', 'joined_on': joined, 'mobile': '98100000%02d' % len(P)}, D)
        conn.execute("UPDATE steps SET done=1, done_at=?, done_by='demo' WHERE person_id=?", (now_ts(), P[key]))
    L = {}
    for key, name, serial, plant, cond in [('l1', 'Dell Latitude 5420', 'DEMO-DL5420A01', '1100', 'good'), ('l2', 'Dell Latitude 5420', 'DEMO-DL5420A02', '1100', 'good'),
                                           ('l3', 'HP ProBook 450', 'DEMO-HP450B07', '1200', 'good'), ('l4', 'Lenovo ThinkPad E14', 'DEMO-LTE14C11', '1100', 'new'),
                                           ('l5', 'HP ProBook 440', 'DEMO-HP440D03', '1600', 'fair'), ('l6', 'Dell Latitude 3420', 'DEMO-DL3420E09', '1200', 'poor')]:
        L[key] = create_asset(conn, {'kind': 'laptop', 'name': name, 'serial': serial, 'plant': plant, 'cond': cond, 'purchase_date': day(-700), 'vendor': 'Demo Computers',
                                     'warranty_until': day(-20) if key == 'l1' else day(300)}, D)
    desk = create_asset(conn, {'kind': 'desktop', 'name': 'Dell OptiPlex 3080', 'serial': 'DEMO-OP3080F21', 'plant': '1100', 'cond': 'good'}, D)
    plc = create_asset(conn, {'kind': 'desktop', 'name': 'HP shop-floor PC', 'serial': 'DEMO-HPSF0099', 'plant': '1100', 'cond': 'fair'}, D)
    mouse = create_asset(conn, {'kind': 'mouse', 'name': 'Logitech B100', 'plant': '1100', 'qty': 12, 'min_qty': 4}, D)
    kb = create_asset(conn, {'kind': 'keyboard', 'name': 'Logitech K120', 'plant': '1100', 'qty': 6}, D)
    cam = create_asset(conn, {'kind': 'camera', 'name': 'Hikvision 2MP dome', 'serial': 'DEMO-HK2MP4401', 'plant': '1200', 'cond': 'good'}, D)
    mon = create_asset(conn, {'kind': 'monitor', 'name': 'Dell 22 inch', 'serial': 'DEMO-DM22G05', 'plant': '1100', 'cond': 'good'}, D)
    ops = lambda aid, **k: asset_op(conn, aid, k, D)
    ops(L['l1'], op='issue', person_id=P['neha'], who='Ramesh Kumar', note='Issued with bag')
    ops(L['l2'], op='issue', person_id=P['pooja'], who='Ramesh Kumar')
    ops(L['l3'], op='issue', person_id=P['rakesh'], who='Anil Sharma')
    ops(L['l2'], op='return', to='stock', cond='good', note='Pooja got a new one (demo)')
    ops(L['l5'], op='issue', person_id=P['imran'], who='Deepak Jat')
    ops(L['l5'], op='repair', note='Screen flickers')
    ops(L['l6'], op='issue', person_id=P['vikas'], who='Anil Sharma')
    ops(L['l6'], op='return', to='stock', cond='poor', note='Battery dead')
    ops(plc, op='issue', location='Coating line 2 - shop-floor terminal', who='Ramesh Kumar')
    ops(mouse, op='issue', person_id=P['mohan'], qty=1, who='Ramesh Kumar')
    ops(mouse, op='issue', person_id=P['neha'], qty=1)
    ops(kb, op='issue', person_id=P['neha'], qty=1)
    ops(cam, op='issue', location='Main gate - Dhodhsar', who='Anil Sharma')
    ops(mon, op='issue', person_id=P['neha'], who='Ramesh Kumar')
    create_account(conn, {'person_id': P['neha'], 'kind': 'sap', 'identifier': 'DEMO.NEHA', 'system': 'PRD 100', 'roles': 'FI_AP_CLERK, FI_DISPLAY', 'valid_to': day(400)}, D)
    create_account(conn, {'person_id': P['rakesh'], 'kind': 'sap', 'identifier': 'DEMO.RAKESH', 'system': 'PRD 100', 'roles': 'MM_STORE', 'valid_to': day(10)}, D)
    create_account(conn, {'person_id': P['pooja'], 'kind': 'email', 'identifier': 'pooja.saini@demo.example', 'system': 'Company mail'}, D)
    create_account(conn, {'person_id': P['neha'], 'kind': 'email', 'identifier': 'neha.verma@demo.example', 'system': 'Company mail'}, D)
    # a leaver who still holds items and accounts (the thing that goes wrong most often)
    P['sanjay'] = create_person(conn, {'name': 'Sanjay Dutt', 'department': 'Dispatch', 'designation': 'Executive', 'plant': '1200', 'emp_code': 'DEMO-E1006',
                                       'joined_on': day(-600), 'email': 'sanjay.dutt@demo.example'}, D)
    conn.execute("UPDATE steps SET done=1, done_at=?, done_by='demo' WHERE person_id=?", (now_ts(), P['sanjay']))
    lx = create_asset(conn, {'kind': 'laptop', 'name': 'HP ProBook 430', 'serial': 'DEMO-HP430X88', 'plant': '1200', 'cond': 'good'}, D)
    ops(lx, op='issue', person_id=P['sanjay'])
    create_account(conn, {'person_id': P['sanjay'], 'kind': 'sap', 'identifier': 'DEMO.SANJAY', 'system': 'PRD 100', 'roles': 'SD_DISPATCH'}, D)
    leave_person(conn, P['sanjay'], {'left_on': day(-3)})
    # tickets in every state
    def tk(title, cat, plant, who, prio='medium', rec_h=2, assign=None, status=None, details='', **extra):
        d = {'title': title, 'category': cat, 'plant': plant, 'requester': who, 'priority': prio, 'details': details, 'received_at': ago(rec_h)}
        d.update(extra)
        if assign is not None:
            d['assigned_to'] = assign
        tid = create_ticket(conn, d, D)
        if status in ('progress', 'waiting', 'done', 'closed'):
            do_ticket(conn, tid, {'do': 'status', 'status': 'progress', 'who': 'demo'})
        if status == 'waiting':
            do_ticket(conn, tid, {'do': 'status', 'status': 'waiting', 'waiting_for': 'Vendor to send the part', 'follow_up_on': day(0)})
        if status == 'done':
            do_ticket(conn, tid, {'do': 'status', 'status': 'done', 'resolution': 'Replaced and tested', 'who': 'demo'})
        if status == 'closed':
            do_ticket(conn, tid, {'do': 'close', 'resolution': 'Fixed on site, user confirmed', 'who': 'demo'})
        return tid
    tk('Laptop not starting - black screen', 'hardware', '1100', 'Neha Verma', 'high', 30, t_ramesh, 'progress', person_id=P['neha'], asset_id=L['l1'], sub='Laptop')
    tk('Mouse not working at counter 2', 'hardware', '1100', 'Mohan Lal', 'low', 5, t_ramesh, 'assigned', person_id=P['mohan'], sub='Mouse')
    tk('SAP: FB60 gives authorization error', 'sap', '1100', 'Neha Verma', 'high', 4, t_sunil, 'progress', person_id=P['neha'])
    tk('Create SAP user for new store clerk', 'sap_user', '1200', 'Rakesh Gurjar', 'medium', 20, t_sunil, 'assigned', req_type='create')
    tk('CCTV camera at gate shows no picture', 'camera', '1200', 'Security office', 'critical', 3, t_anil, 'waiting', asset_id=cam)
    tk('Printer in HR is not printing', 'printer', '1100', 'Pooja Saini', 'medium', 52, None, None, person_id=P['pooja'])
    tk('Mail not syncing on phone', 'email', '1600', 'Imran Khan', 'low', 8, t_deepak, 'done', person_id=P['imran'])
    tk('Internet slow in dispatch office', 'network', '1200', 'Sanjay Dutt', 'medium', 80, t_anil, 'closed')
    tk('Install Excel add-in on 3 PCs', 'software', '1600', 'Imran Khan', 'low', 6, 0, 'progress')
    tk('WiFi password reset for visitors', 'network', '1100', 'HR desk', 'low', 1, None, None)
    # transports
    r1 = create_transport(conn, {'tr_number': 'DEMOK900231', 'description': 'ZGATE_OUT partial out logic', 'owner_name': 'Bhawani Singh', 'requested_by': 'Bhawani Singh', 'source_sys': 'DEV'}, D)
    do_transport(conn, r1, {'do': 'qas', 'by': 'Hameer Singh'})
    do_transport(conn, r1, {'do': 'approve', 'approver': 'Uday sir'})
    r2 = create_transport(conn, {'tr_number': 'DEMOK900244', 'description': 'MM: new PO print form changes', 'owner_name': 'Bhawani Singh', 'requested_by': 'Kashish', 'priority': 'urgent'}, D)
    do_transport(conn, r2, {'do': 'qas', 'by': 'Hameer Singh'})
    r3 = create_transport(conn, {'tr_number': 'DEMOK900198', 'description': 'FI: vendor ageing report fix', 'owner_name': 'Bhawani Singh', 'requested_by': 'Neha Verma'}, D)
    do_transport(conn, r3, {'do': 'qas', 'by': 'Hameer Singh'})
    do_transport(conn, r3, {'do': 'approve', 'approver': 'HOD'})
    do_transport(conn, r3, {'do': 'prd', 'by': 'Hameer Singh', 'rc': '0'})
    create_transport(conn, {'tr_number': 'DEMOK900252', 'description': 'Gate pass print layout', 'owner_name': 'Bhawani Singh', 'requested_by': 'Gate office'}, D)
    # purchases
    b1 = create_purchase(conn, {'item': 'Laptop for new joiner (Accounts)', 'kind': 'laptop', 'qty': 1, 'plant': '1100', 'reason': 'No spare laptop in stock at Jaitpura'}, D)
    do_purchase(conn, b1, {'do': 'approve', 'approved_by': 'HOD'}, D)
    do_purchase(conn, b1, {'do': 'order', 'vendor': 'Demo Computers', 'po_no': 'PO-4521', 'expected_on': day(-2)}, D)
    create_purchase(conn, {'item': 'Logitech B100 mouse', 'kind': 'mouse', 'qty': 20, 'plant': '1100', 'reason': 'Stock is low'}, D)
    # renewals
    create_renewal(conn, {'title': 'CCTV AMC - Dhodhsar', 'kind': 'amc', 'vendor': 'SecureVision', 'plant': '1200', 'expires_on': day(12), 'owner_id': t_anil}, D)
    create_renewal(conn, {'title': 'Antivirus licences (60 PCs)', 'kind': 'antivirus', 'vendor': 'Demo Antivirus', 'expires_on': day(-5)}, D)
    create_renewal(conn, {'title': 'Company domain + mail hosting', 'kind': 'domain', 'vendor': 'Demo Host', 'expires_on': day(200)}, D)
    # daily checks
    for title, plant, who, freq in [('SAP backup finished OK (check log)', '', t_sunil, 'daily'), ('Server room temperature and UPS', '1100', t_ramesh, 'daily'),
                                    ('CCTV recording running (all cameras)', '1200', t_anil, 'daily'), ('Antivirus update status', '', 0, 'weekly'),
                                    ('Restore test of the SAP backup', '', t_sunil, 'monthly')]:
        rid = create_routine(conn, {'title': title, 'plant': plant, 'assigned_to': who, 'frequency': freq, 'weekday': 0, 'month_day': 1}, D)
        conn.execute('UPDATE routines SET created_on=? WHERE id=?', (day(-30), rid))
        if freq == 'daily' and 'SAP' in title:
            for back in range(1, 6):
                dd = today_date() - dt.timedelta(days=back)
                if dd.weekday() in work_days_of(DEFAULT_SETTINGS):
                    conn.execute("INSERT INTO routine_log(routine_id,on_date,status,by_id,note,ts,is_demo) VALUES(?,?,?,?,?,?,1)", (rid, dd.isoformat(), 'ok', who, '', now_ts()))
    return 1


def demo_clear(conn):
    ids = {}
    for t in ('team', 'people', 'accounts', 'assets', 'tickets', 'transports', 'purchases', 'renewals', 'routines'):
        ids[t] = [r['id'] for r in conn.execute('SELECT id FROM %s WHERE is_demo=1' % t)]
    folders = [r['folder'] for t in ('people', 'assets', 'tickets', 'transports', 'purchases', 'renewals') for r in conn.execute('SELECT folder FROM %s WHERE is_demo=1' % t)]
    hid = lambda col, t: ('%s IN (%s)' % (col, ','.join(str(i) for i in ids[t]))) if ids[t] else '0'
    conn.execute("DELETE FROM history WHERE is_demo=1 OR (ent='ticket' AND %s) OR (ent='person' AND %s) OR (ent='asset' AND %s) OR (ent='transport' AND %s) OR (ent='purchase' AND %s) OR (ent='renewal' AND %s) OR (ent='routine' AND %s) OR (ent='account' AND %s)"
                 % (hid('ent_id', 'tickets'), hid('ent_id', 'people'), hid('ent_id', 'assets'), hid('ent_id', 'transports'), hid('ent_id', 'purchases'), hid('ent_id', 'renewals'),
                    hid('ent_id', 'routines'), hid('ent_id', 'accounts')))
    for kind, t in PARENT_TABLE.items():
        if ids[t]:
            conn.execute('DELETE FROM files WHERE parent_kind=? AND parent_id IN (%s)' % ','.join(str(i) for i in ids[t]), (kind,))
    for t in ('routines', 'assets', 'people'):      # children (log lines, steps) go with them
        conn.execute('DELETE FROM %s WHERE is_demo=1' % t)
    for t in ('accounts', 'tickets', 'transports', 'purchases', 'renewals', 'team'):
        conn.execute('DELETE FROM %s WHERE is_demo=1' % t)
    conn.execute('DELETE FROM asset_log WHERE is_demo=1')
    conn.execute('DELETE FROM routine_log WHERE is_demo=1')
    conn.execute('DELETE FROM steps WHERE is_demo=1')
    return folders


# ----------------------------------------------------------------------------- init / backup
def init_all():
    for p in (DATA_DIR, FILES_DIR, BACKUP_DIR):
        os.makedirs(p, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()
    try:
        daily_backup()
    except Exception:
        pass


def backup_db(label='manual'):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    dst = os.path.join(BACKUP_DIR, 'taskmanager_%s_%s.db' % (dt.datetime.now().strftime('%Y%m%d_%H%M%S'), label))
    src = sqlite3.connect(DB_PATH)
    out = sqlite3.connect(dst)
    src.backup(out)
    out.close()
    src.close()
    files = sorted(f for f in os.listdir(BACKUP_DIR) if f.endswith('.db'))
    for old in files[:-30]:
        try:
            os.remove(os.path.join(BACKUP_DIR, old))
        except Exception:
            pass
    return dst


def daily_backup():
    tag = dt.datetime.now().strftime('%Y%m%d')
    if not any(f.startswith('taskmanager_' + tag) for f in os.listdir(BACKUP_DIR)):
        backup_db('auto')


def open_path(path):
    path = os.path.abspath(path)
    if sys.platform.startswith('win'):
        os.startfile(path)  # noqa
    elif sys.platform == 'darwin':
        subprocess.Popen(['open', path])
    else:
        subprocess.Popen(['xdg-open', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ----------------------------------------------------------------------------- API
def vocab():
    return {
        'categories': [{'key': k, 'label': l} for k, l in TICKET_CATS], 'sap_req': [{'key': k, 'label': l} for k, l in SAP_REQ],
        'statuses': TICKET_STATUSES, 'priorities': PRIORITIES, 'sources': [{'key': k, 'label': l} for k, l in SOURCES],
        'asset_kinds': [{'key': k, 'label': l, 'bulk': b} for k, l, b in ASSET_KINDS], 'asset_status': [{'key': k, 'label': l} for k, l in ASSET_STATUS],
        'conditions': [{'key': k, 'label': l} for k, l in CONDITIONS], 'person_kinds': [{'key': k, 'label': l} for k, l in PERSON_KINDS],
        'account_kinds': [{'key': k, 'label': l} for k, l in ACCOUNT_KINDS], 'tr_status': [{'key': k, 'label': l} for k, l in TR_STATUS],
        'buy_status': [{'key': k, 'label': l} for k, l in BUY_STATUS], 'renew_kinds': [{'key': k, 'label': l} for k, l in RENEW_KINDS],
        'freq': [{'key': k, 'label': l} for k, l in FREQ], 'file_cats': [{'key': k, 'label': CAT_LABELS[k]} for k in CATS],
    }


@route('GET', r'/api/ping')
def api_ping(h):
    return {'app': APP_ID, 'version': APP_VERSION}


@route('GET', r'/api/meta')
def api_meta(h):
    with dbc() as c:
        st = get_settings(c)
        team = team_map(c)
        return {'app': APP_ID, 'version': APP_VERSION, 'today': today_iso(), 'now': now_min(), 'settings': meta_settings(st), 'vocab': vocab(),
                'team': list(team.values()), 'data_dir': os.path.abspath(DATA_DIR),
                'departments': [r[0] for r in c.execute("SELECT DISTINCT department FROM people WHERE department<>'' ORDER BY department")],
                'badges': nav_badges(c)}


def nav_badges(c):
    now = now_min()
    return {'tickets': c.execute("SELECT COUNT(*) FROM tickets WHERE status IN ('new','assigned','progress','waiting') AND due_at<?", (now,)).fetchone()[0] +
            c.execute("SELECT COUNT(*) FROM tickets WHERE status='done'").fetchone()[0],
            'people': c.execute("""SELECT COUNT(*) FROM people p WHERE p.status='left' AND (EXISTS(SELECT 1 FROM assets a WHERE a.person_id=p.id AND a.tracked=1 AND a.status IN ('issued','repair','lost'))
                                    OR EXISTS(SELECT 1 FROM accounts x WHERE x.person_id=p.id AND x.status IN ('active','locked')))""").fetchone()[0]}


@route('GET', r'/api/dashboard')
def api_dashboard(h):
    with dbc() as c:
        return dashboard(c, h.query.get('plant', ''))


@route('GET', r'/api/search')
def api_search(h):
    with dbc() as c:
        return search_all(c, h.query.get('q', ''))


@route('GET', r'/api/history')
def api_history(h):
    lim = max(1, min(500, int(h.query.get('limit', 60))))
    with dbc() as c:
        return history_of(c, '1=1', (), lim)


# -- tickets
@route('GET', r'/api/tickets')
def api_tickets(h):
    with dbc() as c:
        return list_tickets(c, ' ORDER BY t.id DESC')


@route('POST', r'/api/tickets')
def api_ticket_create(h):
    d = h.json_body()
    with dbc() as c:
        tid = create_ticket(c, d)
        return ticket_detail(c, tid)


@route('GET', r'/api/tickets/(\d+)')
def api_ticket_get(h, tid):
    with dbc() as c:
        return ticket_detail(c, int(tid))


@route('PUT', r'/api/tickets/(\d+)')
def api_ticket_put(h, tid):
    d = h.json_body()
    with dbc() as c:
        update_ticket(c, int(tid), d)
        return ticket_detail(c, int(tid))


@route('POST', r'/api/tickets/(\d+)/do')
def api_ticket_do(h, tid):
    d = h.json_body()
    with dbc() as c:
        do_ticket(c, int(tid), d)
        return ticket_detail(c, int(tid))


@route('DELETE', r'/api/tickets/(\d+)')
def api_ticket_del(h, tid):
    with dbc() as c:
        delete_ticket(c, int(tid))
        return {'ok': True}


# -- people, accounts, steps
@route('GET', r'/api/people')
def api_people(h):
    with dbc() as c:
        return list_people(c, ' ORDER BY p.name')


@route('POST', r'/api/people')
def api_person_create(h):
    """New joiner in one go: the person + optional items from stock + mail / SAP ids + purchase requests for what is not in stock."""
    d = h.json_body()
    with dbc() as c:
        pid = create_person(c, d)
        who = str(d.get('who') or '')
        for a in d.get('accounts') or []:
            if isinstance(a, dict) and str(a.get('identifier') or '').strip():
                create_account(c, dict(a, person_id=pid, created_by=who))
        for it in d.get('issue') or []:
            asset_op(c, int(it['asset_id']), {'op': 'issue', 'person_id': pid, 'qty': it.get('qty', 1), 'who': who, 'note': 'Joining'})
        for b in d.get('buy') or []:
            kind = b.get('kind') if b.get('kind') in KIND_KEYS else 'other'
            create_purchase(c, {'item': b.get('item') or '%s for %s' % (KIND_LABEL.get(kind, 'Item'), d.get('name')), 'kind': kind, 'qty': b.get('qty') or 1,
                                'plant': d.get('plant', ''), 'person_id': pid, 'reason': 'Not in stock when %s joined' % d.get('name')})
        return person_detail(c, pid)


@route('GET', r'/api/people/(\d+)')
def api_person_get(h, pid):
    with dbc() as c:
        return person_detail(c, int(pid))


@route('PUT', r'/api/people/(\d+)')
def api_person_put(h, pid):
    d = h.json_body()
    with dbc() as c:
        update_person(c, int(pid), d)
        return person_detail(c, int(pid))


@route('POST', r'/api/people/(\d+)/leave')
def api_person_leave(h, pid):
    d = h.json_body()
    with dbc() as c:
        res = leave_person(c, int(pid), d)
        out = person_detail(c, int(pid))
        out['pending'] = res
        return out


@route('DELETE', r'/api/people/(\d+)')
def api_person_del(h, pid):
    with dbc() as c:
        delete_person(c, int(pid))
        return {'ok': True}


@route('POST', r'/api/people/(\d+)/steps')
def api_step_add(h, pid):
    d = h.json_body()
    text = str(d.get('text') or '').strip()[:200]
    flow = 'leave' if d.get('flow') == 'leave' else 'join'
    if not text:
        raise ApiError(400, 'Write the step')
    with dbc() as c:
        need(c.execute('SELECT 1 FROM people WHERE id=?', (int(pid),)).fetchone(), 'Employee')
        sort = c.execute('SELECT COALESCE(MAX(sort),0)+1 FROM steps WHERE person_id=? AND flow=?', (int(pid), flow)).fetchone()[0]
        ins(c, 'steps', {'person_id': int(pid), 'flow': flow, 'text': text, 'done': 0, 'sort': sort})
        return person_detail(c, int(pid))


@route('POST', r'/api/people/(\d+)/note')
def api_person_note(h, pid):
    d = h.json_body()
    text = str(d.get('text') or '').strip()[:2000]
    if not text:
        raise ApiError(400, 'Write the note first')
    with dbc() as c:
        need(c.execute('SELECT 1 FROM people WHERE id=?', (int(pid),)).fetchone(), 'Employee')
        hist(c, 'person', int(pid), 'note', text, who=str(d.get('who') or '')[:80])
        return person_detail(c, int(pid))


@route('PUT', r'/api/steps/(\d+)')
def api_step_put(h, sid):
    d = h.json_body()
    with dbc() as c:
        s = need(c.execute('SELECT * FROM steps WHERE id=?', (int(sid),)).fetchone(), 'Step')
        sets = {}
        if 'done' in d:
            done = 1 if d['done'] else 0
            sets['done'] = done
            sets['done_at'] = now_ts() if done else None
            sets['done_by'] = str(d.get('done_by') or '')[:80] if done else ''
        if 'note' in d:
            sets['note'] = str(d['note'])[:500]
        if 'text' in d and str(d['text']).strip():
            sets['text'] = str(d['text']).strip()[:200]
        c.execute('UPDATE steps SET %s WHERE id=?' % ','.join('%s=?' % k for k in sets), list(sets.values()) + [s['id']]) if sets else None
        if 'done' in d and bool(d['done']) != bool(s['done']):
            hist(c, 'person', s['person_id'], 'step', ('Step done: %s' if d['done'] else 'Step re-opened: %s') % s['text'], who=str(d.get('done_by') or ''))
        return person_detail(c, s['person_id'])


@route('DELETE', r'/api/steps/(\d+)')
def api_step_del(h, sid):
    with dbc() as c:
        s = need(c.execute('SELECT * FROM steps WHERE id=?', (int(sid),)).fetchone(), 'Step')
        c.execute('DELETE FROM steps WHERE id=?', (s['id'],))
        return person_detail(c, s['person_id'])


@route('GET', r'/api/accounts')
def api_accounts(h):
    with dbc() as c:
        return row_dicts(c.execute("""SELECT c.*, p.name AS person_name, p.code AS person_code, p.plant AS plant, p.status AS person_status
                                      FROM accounts c LEFT JOIN people p ON p.id=c.person_id ORDER BY c.id DESC"""))


@route('POST', r'/api/accounts')
def api_account_create(h):
    d = h.json_body()
    with dbc() as c:
        aid = create_account(c, d, who=str(d.get('who') or ''))
        return dict(c.execute('SELECT * FROM accounts WHERE id=?', (aid,)).fetchone())


@route('PUT', r'/api/accounts/(\d+)')
def api_account_put(h, aid):
    d = h.json_body()
    with dbc() as c:
        update_account(c, int(aid), d)
        return dict(c.execute('SELECT * FROM accounts WHERE id=?', (int(aid),)).fetchone())


@route('DELETE', r'/api/accounts/(\d+)')
def api_account_del(h, aid):
    with dbc() as c:
        a = need(c.execute('SELECT * FROM accounts WHERE id=?', (int(aid),)).fetchone(), 'Account')
        c.execute('DELETE FROM accounts WHERE id=?', (a['id'],))
        hist(c, 'account', a['id'], 'account', 'Record removed (entered by mistake): %s' % a['identifier'], person_id=a['person_id'])
        return {'ok': True}


# -- stock and assets
@route('GET', r'/api/assets')
def api_assets(h):
    with dbc() as c:
        return list_assets(c, ' ORDER BY a.id DESC')


@route('POST', r'/api/assets')
def api_asset_create(h):
    d = h.json_body()
    with dbc() as c:
        aid = create_asset(c, d, who=str(d.get('who') or ''))
        # several identical single items: the extra serial numbers, one per line
        ids = [aid]
        extra = [x.strip() for x in re.split(r'[\r\n,;]+', str(d.get('more_serials') or '')) if x.strip()]
        for s in extra[:200]:
            ids.append(create_asset(c, dict(d, serial=s, tag=''), who=str(d.get('who') or '')))
        if d.get('issue_to'):
            asset_op(c, aid, {'op': 'issue', 'person_id': d['issue_to'], 'who': d.get('who', '')})
        out = asset_detail(c, aid)
        out['created_ids'] = ids
        return out


@route('GET', r'/api/assets/(\d+)')
def api_asset_get(h, aid):
    with dbc() as c:
        return asset_detail(c, int(aid))


@route('PUT', r'/api/assets/(\d+)')
def api_asset_put(h, aid):
    d = h.json_body()
    with dbc() as c:
        update_asset(c, int(aid), d)
        return asset_detail(c, int(aid))


@route('POST', r'/api/assets/(\d+)/op')
def api_asset_op(h, aid):
    d = h.json_body()
    with dbc() as c:
        asset_op(c, int(aid), d)
        return asset_detail(c, int(aid))


@route('DELETE', r'/api/assets/(\d+)')
def api_asset_del(h, aid):
    with dbc() as c:
        delete_asset(c, int(aid))
        return {'ok': True}


@route('GET', r'/api/stock/summary')
def api_stock_summary(h):
    with dbc() as c:
        return stock_summary(c, get_settings(c))


@route('GET', r'/api/stock/suggest')
def api_stock_suggest(h):
    with dbc() as c:
        return stock_suggest(c, h.query.get('kind', ''), h.query.get('plant', ''))


# -- transports
@route('GET', r'/api/transports')
def api_transports(h):
    with dbc() as c:
        return list_transports(c)


@route('POST', r'/api/transports')
def api_transport_create(h):
    d = h.json_body()
    with dbc() as c:
        return transport_detail(c, create_transport(c, d))


@route('GET', r'/api/transports/(\d+)')
def api_transport_get(h, rid):
    with dbc() as c:
        return transport_detail(c, int(rid))


@route('PUT', r'/api/transports/(\d+)')
def api_transport_put(h, rid):
    d = h.json_body()
    with dbc() as c:
        update_transport(c, int(rid), d)
        return transport_detail(c, int(rid))


@route('POST', r'/api/transports/(\d+)/do')
def api_transport_do(h, rid):
    d = h.json_body()
    with dbc() as c:
        do_transport(c, int(rid), d)
        return transport_detail(c, int(rid))


@route('DELETE', r'/api/transports/(\d+)')
def api_transport_del(h, rid):
    with dbc() as c:
        t = need(c.execute('SELECT * FROM transports WHERE id=?', (int(rid),)).fetchone(), 'Transport')
        if t['status'] == 'prd':
            raise ApiError(409, 'A transport that went to production stays in the record. Nothing is deleted.')
        c.execute('DELETE FROM transports WHERE id=?', (t['id'],))
        c.execute("DELETE FROM history WHERE ent='transport' AND ent_id=?", (t['id'],))
        drop_record_files(c, 'transport', t['id'], t['folder'])
        return {'ok': True}


# -- purchases
@route('GET', r'/api/purchases')
def api_purchases(h):
    with dbc() as c:
        return list_purchases(c)


@route('POST', r'/api/purchases')
def api_purchase_create(h):
    d = h.json_body()
    with dbc() as c:
        return purchase_detail(c, create_purchase(c, d))


@route('GET', r'/api/purchases/(\d+)')
def api_purchase_get(h, pid):
    with dbc() as c:
        return purchase_detail(c, int(pid))


@route('PUT', r'/api/purchases/(\d+)')
def api_purchase_put(h, pid):
    d = h.json_body()
    with dbc() as c:
        update_purchase(c, int(pid), d)
        return purchase_detail(c, int(pid))


@route('POST', r'/api/purchases/(\d+)/do')
def api_purchase_do(h, pid):
    d = h.json_body()
    with dbc() as c:
        created = do_purchase(c, int(pid), d)
        out = purchase_detail(c, int(pid))
        out['created_assets'] = created
        return out


@route('DELETE', r'/api/purchases/(\d+)')
def api_purchase_del(h, pid):
    with dbc() as c:
        b = need(c.execute('SELECT * FROM purchases WHERE id=?', (int(pid),)).fetchone(), 'Purchase')
        if b['status'] == 'received':
            raise ApiError(409, 'A received purchase stays in the record')
        c.execute('DELETE FROM purchases WHERE id=?', (b['id'],))
        c.execute("DELETE FROM history WHERE ent='purchase' AND ent_id=?", (b['id'],))
        drop_record_files(c, 'purchase', b['id'], b['folder'])
        return {'ok': True}


# -- renewals
@route('GET', r'/api/renewals')
def api_renewals(h):
    with dbc() as c:
        st = get_settings(c)
        return {'renewals': list_renewals(c, st), 'warranties': warranty_list(c, 90)}


@route('POST', r'/api/renewals')
def api_renewal_create(h):
    d = h.json_body()
    with dbc() as c:
        return renewal_detail(c, create_renewal(c, d))


@route('GET', r'/api/renewals/(\d+)')
def api_renewal_get(h, rid):
    with dbc() as c:
        return renewal_detail(c, int(rid))


@route('PUT', r'/api/renewals/(\d+)')
def api_renewal_put(h, rid):
    d = h.json_body()
    with dbc() as c:
        update_renewal(c, int(rid), d)
        return renewal_detail(c, int(rid))


@route('POST', r'/api/renewals/(\d+)/renew')
def api_renewal_renew(h, rid):
    d = h.json_body()
    with dbc() as c:
        renew_renewal(c, int(rid), d)
        return renewal_detail(c, int(rid))


@route('DELETE', r'/api/renewals/(\d+)')
def api_renewal_del(h, rid):
    with dbc() as c:
        r = need(c.execute('SELECT * FROM renewals WHERE id=?', (int(rid),)).fetchone(), 'Renewal')
        c.execute('DELETE FROM renewals WHERE id=?', (r['id'],))
        c.execute("DELETE FROM history WHERE ent='renewal' AND ent_id=?", (r['id'],))
        drop_record_files(c, 'renewal', r['id'], r['folder'])
        return {'ok': True}


# -- team
@route('GET', r'/api/team')
def api_team(h):
    with dbc() as c:
        return team_with_load(c, get_settings(c))


@route('POST', r'/api/team')
def api_team_create(h):
    d = h.json_body()
    with dbc() as c:
        tid = create_team(c, d)
        return dict(c.execute('SELECT * FROM team WHERE id=?', (tid,)).fetchone())


@route('PUT', r'/api/team/(\d+)')
def api_team_put(h, tid):
    d = h.json_body()
    with dbc() as c:
        update_team(c, int(tid), d)
        return dict(c.execute('SELECT * FROM team WHERE id=?', (int(tid),)).fetchone())


@route('DELETE', r'/api/team/(\d+)')
def api_team_del(h, tid):
    with dbc() as c:
        delete_team(c, int(tid))
        return {'ok': True}


# -- daily checks
@route('GET', r'/api/routines')
def api_routines(h):
    with dbc() as c:
        return list_routines(c, get_settings(c))


@route('POST', r'/api/routines')
def api_routine_create(h):
    d = h.json_body()
    with dbc() as c:
        create_routine(c, d)
        return list_routines(c, get_settings(c))


@route('PUT', r'/api/routines/(\d+)')
def api_routine_put(h, rid):
    d = h.json_body()
    with dbc() as c:
        update_routine(c, int(rid), d)
        return list_routines(c, get_settings(c))


@route('DELETE', r'/api/routines/(\d+)')
def api_routine_del(h, rid):
    with dbc() as c:
        delete_routine(c, int(rid))
        return list_routines(c, get_settings(c))


@route('POST', r'/api/routines/(\d+)/log')
def api_routine_log(h, rid):
    d = h.json_body()
    with dbc() as c:
        log_routine(c, int(rid), d)
        return list_routines(c, get_settings(c))


@route('GET', r'/api/routines/(\d+)/logs')
def api_routine_logs(h, rid):
    with dbc() as c:
        return routine_logs(c, int(rid))


# -- report + export
@route('GET', r'/api/report')
def api_report(h):
    today = today_date()
    d2 = parse_d(h.query.get('to')) or today
    d1 = parse_d(h.query.get('from')) or (d2 - dt.timedelta(days=6))
    if d1 > d2:
        d1, d2 = d2, d1
    if (d2 - d1).days > 800:
        raise ApiError(400, 'Choose a period of less than 2 years')
    with dbc() as c:
        return report(c, d1, d2, h.query.get('plant', ''))


@route('GET', r'/api/export\.xlsx')
def api_export(h):
    with dbc() as c:
        st = get_settings(c)
        tm = team_map(c)
        cats = dict(TICKET_CATS)
        tickets = list_tickets(c, ' ORDER BY t.id')
        s_t = [[t['code'], t['title'], cats.get(t['category'], t['category']), t['sub'], t['plant'], t['requester'], t['department'], t['person_code'] or '', t['asset_code'] or '',
                t['priority'], TS_MAP[t['status']]['label'], t['assignee'], t['source'], t['received_at'], t['due_at'], t['done_at'] or '', t['closed_at'] or '', t['age_hours'],
                'Yes' if t['sla_met'] else ('No' if t['sla_met'] is False else ''), 'Yes' if t['overdue'] else '', t['resolution'], t['details']] for t in tickets]
        h_t = ['Code', 'Problem', 'Category', 'Item', 'Plant', 'Requested by', 'Department', 'Employee code', 'Asset', 'Priority', 'Status', 'Assigned to', 'Received by',
               'Received at', 'Due', 'Done at', 'Closed at', 'Hours taken', 'Within time', 'Overdue now', 'What was done', 'Details']
        s_p = [[p['code'], p['emp_code'], p['name'], p['department'], p['designation'], p['plant'], p['kind'], p['status'], p['joined_on'], p['left_on'] or '', p['email'], p['mobile'],
                p['n_assets'] + p['n_bulk'], p['n_accounts'], 'YES - items / accounts pending' if p['leaver_pending'] else ''] for p in list_people(c, ' ORDER BY p.name')]
        h_p = ['Code', 'Employee code', 'Name', 'Department', 'Designation', 'Plant', 'Type', 'Status', 'Joined', 'Left', 'Mail id', 'Mobile', 'Items held', 'Accounts', 'Leaver pending']
        s_a = [[a['code'], KIND_LABEL.get(a['kind'], a['kind']), a['name'], a['tag'], a['serial'], dict(ASSET_STATUS).get(a['status'], a['status']), a['holder'] or a['location'], a['plant'],
                a['cond'], a['qty'] if not a['tracked'] else 1, a['qty_free'] if not a['tracked'] else (1 if a['status'] == 'in_stock' else 0), a['purchase_date'] or '', a['vendor'],
                a['cost'], a['warranty_until'] or '', a['times_issued'], a['note']] for a in list_assets(c, ' ORDER BY a.kind, a.id')]
        h_a = ['Code', 'Type', 'Make / model', 'Asset tag', 'Serial no.', 'Status', 'With / at', 'Plant', 'Condition', 'Quantity', 'In stock', 'Purchased', 'Vendor', 'Cost', 'Warranty until',
               'Times issued', 'Note']
        s_h = [[r['ts'], r['code'], r['kind'], r['text'], r['who'], r['pname'] or '', r['tcode'] or ''] for r in c.execute(
            """SELECT h.ts, a.code, h.kind, h.text, h.who, p.name AS pname, t.code AS tcode FROM history h JOIN assets a ON a.id=h.asset_id
               LEFT JOIN people p ON p.id=h.person_id LEFT JOIN tickets t ON t.id=h.ticket_id WHERE h.ent='asset' ORDER BY h.id""")]
        h_h = ['When', 'Asset', 'Event', 'Details', 'Handled by', 'Employee', 'Ticket']
        s_acc = []
        for x in c.execute("""SELECT c.*, p.name AS person_name, p.code AS person_code, p.status AS person_status FROM accounts c LEFT JOIN people p ON p.id=c.person_id ORDER BY c.id"""):
            s_acc.append([x['person_name'] or x['owner_name'], x['person_code'] or '', dict(ACCOUNT_KINDS).get(x['kind'], x['kind']), x['identifier'], x['system'], x['roles'], x['status'],
                          x['created_on'], x['valid_to'] or '', x['ended_on'] or '', 'YES' if (x['person_status'] == 'left' and x['status'] != 'deleted') else ''])
        h_acc = ['Owner', 'Employee code', 'Type', 'Id', 'System', 'Roles', 'Status', 'Created', 'Valid until', 'Ended', 'Owner has left but id is open']
        s_tr = [[t['code'], t['tr_number'], t['description'], t['owner_name'], t['requested_by'], t['requested_on'], TR_LABEL.get(t['status'], t['status']), t['qas_on'] or '', t['approver'],
                 t['approved_on'] or '', t['prd_on'] or '', t['prd_by'], t['rc'], t['note']] for t in list_transports(c)]
        h_tr = ['Code', 'TR number', 'Description', 'Made by', 'Requested by', 'Requested on', 'Status', 'In QAS on', 'Approved by', 'Approved on', 'Moved to PRD on', 'Moved by', 'Return code', 'Note']
        s_b = [[b['code'], b['item'], b['kind'], b['qty'], b['plant'], b['person_name'] or '', b['reason'], b['status'], b['requested_on'], b['approved_by'], b['vendor'], b['po_no'],
                b['expected_on'] or '', b['received_on'] or '', b['cost']] for b in list_purchases(c)]
        h_b = ['Code', 'Item', 'Type', 'Qty', 'Plant', 'For', 'Reason', 'Status', 'Requested', 'Approved by', 'Vendor', 'PO no.', 'Expected', 'Received', 'Cost']
        s_r = [[r['title'], dict(RENEW_KINDS).get(r['kind'], r['kind']), r['vendor'], r['plant'], r['starts_on'] or '', r['expires_on'], r['days_left'], r['state'], r['cost'], r['owner']]
               for r in list_renewals(c, st)]
        h_r = ['Title', 'Type', 'Vendor', 'Plant', 'Starts', 'Expires', 'Days left', 'State', 'Cost', 'Owner']
        s_c = [[r['title'], r['plant'] or 'All', l['on_date'], l['status'], l['note'], who_name(tm, st, l['by_id'])] for r in c.execute('SELECT * FROM routines ORDER BY id')
               for l in c.execute('SELECT * FROM routine_log WHERE routine_id=? ORDER BY on_date', (r['id'],))]
        h_c = ['Check', 'Plant', 'For date', 'Result', 'Note', 'Done by']
        s_team = [[m['name'], m['plant'], m['role'], m['mobile'], 'Yes' if m['active'] else 'No', m['open'], m['overdue'], m['closed_30']] for m in team_with_load(c, st)]
        h_team = ['Name', 'Plant', 'Role', 'Mobile', 'Active', 'Open work', 'Overdue', 'Closed in 30 days']
    data = build_xlsx([('Tickets', h_t, s_t), ('Employees', h_p, s_p), ('Accounts', h_acc, s_acc), ('Assets', h_a, s_a), ('Asset history', h_h, s_h), ('Transports', h_tr, s_tr),
                       ('Purchases', h_b, s_b), ('Renewals', h_r, s_r), ('Daily checks', h_c, s_c), ('Team', h_team, s_team)])
    h.send_bytes(data, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'BASIS_TaskManager_Export_%s.xlsx' % dt.datetime.now().strftime('%Y%m%d_%H%M'), inline=False)
    return None


# -- files (photos, invoices, handover forms ... on any record)
def parent_row(conn, kind, pid):
    tbl = PARENT_TABLE.get(kind)
    if not tbl:
        raise ApiError(400, 'Unknown record type')
    r = need(conn.execute('SELECT * FROM %s WHERE id=?' % tbl, (int(pid),)).fetchone(), 'Record')
    return tbl, r


@route('POST', r'/api/files')
def api_upload(h):
    q = h.query
    name = safe_name(q.get('name'), 'file')
    length = int(h.headers.get('Content-Length') or 0)
    if length <= 0:
        raise ApiError(400, 'Empty upload')
    if length > MAX_UPLOAD:
        raise ApiError(413, 'File too large (max 500 MB)')
    kind = q.get('kind', '')
    pid = int(q.get('id') or 0)
    with dbc() as c:
        tbl, rec = parent_row(c, kind, pid)
        cat = q.get('category', 'auto')
        if cat not in CATS:
            cat = guess_category(name)
        if not rec['folder']:
            raise ApiError(409, 'This record has no folder yet')
        folder = os.path.join(FILES_DIR, rec['folder'], CATS[cat])
        os.makedirs(folder, exist_ok=True)
        path = unique_path(folder, name)
        remaining = length
        with open(path, 'wb') as f:
            while remaining > 0:
                chunk = h.rfile.read(min(1 << 20, remaining))
                if not chunk:
                    break
                f.write(chunk)
                remaining -= len(chunk)
        h.body_consumed = True
        if remaining > 0:
            os.remove(path)
            raise ApiError(400, 'Upload interrupted')
        rel = os.path.relpath(path, FILES_DIR).replace('\\', '/')
        fid = ins(c, 'files', {'parent_kind': kind, 'parent_id': pid, 'category': cat, 'filename': os.path.basename(path), 'rel_path': rel, 'size': os.path.getsize(path),
                               'note': q.get('note', ''), 'uploaded_at': now_ts()})
        hist(c, kind, pid, 'file', 'Added file %s (%s)' % (os.path.basename(path), CAT_LABELS[cat]))
        return dict(c.execute('SELECT * FROM files WHERE id=?', (fid,)).fetchone())


def file_row(conn, fid):
    return need(conn.execute('SELECT * FROM files WHERE id=?', (int(fid),)).fetchone(), 'File')


def file_abs(row):
    p = os.path.abspath(os.path.join(FILES_DIR, row['rel_path']))
    if not p.startswith(os.path.abspath(FILES_DIR)) or not os.path.isfile(p):
        raise ApiError(404, 'File missing on disk')
    return p


@route('PUT', r'/api/files/(\d+)')
def api_file_put(h, fid):
    d = h.json_body()
    with dbc() as c:
        r = file_row(c, fid)
        note = str(d.get('note', r['note']))[:500]
        cat = d.get('category', r['category'])
        rel = r['rel_path']
        if cat in CATS and cat != r['category']:
            src = file_abs(r)
            _t, rec = parent_row(c, r['parent_kind'], r['parent_id'])
            dst_dir = os.path.join(FILES_DIR, rec['folder'], CATS[cat])
            os.makedirs(dst_dir, exist_ok=True)
            dst = unique_path(dst_dir, r['filename'])
            shutil.move(src, dst)
            rel = os.path.relpath(dst, FILES_DIR).replace('\\', '/')
        else:
            cat = r['category']
        c.execute('UPDATE files SET note=?, category=?, rel_path=?, filename=? WHERE id=?', (note, cat, rel, os.path.basename(rel), r['id']))
        return dict(c.execute('SELECT * FROM files WHERE id=?', (r['id'],)).fetchone())


@route('DELETE', r'/api/files/(\d+)')
def api_file_del(h, fid):
    with dbc() as c:
        r = file_row(c, fid)
        try:
            p = file_abs(r)
            os.makedirs(TRASH_DIR, exist_ok=True)
            shutil.move(p, unique_path(TRASH_DIR, '%s__%s' % (dt.datetime.now().strftime('%Y%m%d_%H%M%S'), r['filename'])))
        except ApiError:
            pass
        c.execute('DELETE FROM files WHERE id=?', (r['id'],))
        hist(c, r['parent_kind'], r['parent_id'], 'file', 'Removed file %s' % r['filename'])
        return {'ok': True}


@route('GET', r'/files/(\d+)')
def file_get(h, fid):
    with dbc() as c:
        r = file_row(c, fid)
    p = file_abs(r)
    ctype = mimetypes.guess_type(r['filename'])[0] or 'application/octet-stream'
    inline = ctype.startswith('image/') or ctype in ('application/pdf', 'text/plain')
    if ctype == 'image/svg+xml':
        inline = False
    if h.query.get('dl'):
        inline = False
    h.send_file(p, ctype, r['filename'], inline)
    return None


@route('GET', r'/api/files/(\d+)/preview')
def file_preview(h, fid):
    with dbc() as c:
        r = file_row(c, fid)
    p = file_abs(r)
    ext = os.path.splitext(r['filename'])[1].lower()
    size = os.path.getsize(p)
    try:
        if ext in ('.xlsx', '.xlsm'):
            if size > 25 * 1024 * 1024:
                return {'type': 'none', 'reason': 'File too large for preview - open it in Excel.'}
            out = read_xlsx(p, int(h.query.get('sheet', 0)))
            out['name'] = r['filename']
            return out
        if ext in ('.csv', '.txt', '.log', '.json', '.xml', '.ini', '.cfg', '.md'):
            with open(p, 'rb') as f:
                raw = f.read(400 * 1024)
            if b'\x00' in raw[:2000]:
                return {'type': 'none', 'reason': 'Binary file - cannot preview.'}
            for enc in ('utf-8-sig', 'cp1252', 'latin-1'):
                try:
                    text = raw.decode(enc)
                    break
                except Exception:
                    continue
            if ext == '.csv':
                import csv
                rows = list(csv.reader(io.StringIO(text)))[:300]
                return {'type': 'sheet', 'sheets': [r['filename']], 'sheet': 0, 'rows': [x[:40] for x in rows], 'name': r['filename']}
            return {'type': 'text', 'text': text, 'truncated': size > 400 * 1024, 'name': r['filename']}
    except Exception as e:
        return {'type': 'none', 'reason': 'Preview failed (%s). Use Download.' % e}
    return {'type': 'none', 'reason': 'No preview for this file type - use Open / Download.'}


@route('POST', r'/api/open-folder')
def api_open_folder(h):
    d = h.json_body()
    with dbc() as c:
        _t, rec = parent_row(c, str(d.get('kind') or ''), int(d.get('id') or 0))
    make_dirs(rec['folder'])
    p = os.path.join(FILES_DIR, rec['folder'])
    try:
        open_path(p)
    except Exception as e:
        raise ApiError(500, 'Could not open folder: %s' % e)
    return {'ok': True, 'path': os.path.abspath(p)}


@route('POST', r'/api/open-data-folder')
def api_open_data(h):
    open_path(DATA_DIR)
    return {'ok': True, 'path': os.path.abspath(DATA_DIR)}


# -- settings, backup, demo
@route('GET', r'/api/settings')
def api_settings_get(h):
    with dbc() as c:
        return meta_settings(get_settings(c))


@route('PUT', r'/api/settings')
def api_settings_put(h):
    d = h.json_body()
    with dbc() as c:
        return meta_settings(save_settings(c, d))


@route('POST', r'/api/backup')
def api_backup(h):
    p = backup_db('manual')
    return {'ok': True, 'file': os.path.basename(p), 'path': p}


@route('GET', r'/api/backups')
def api_backups(h):
    out = []
    if os.path.isdir(BACKUP_DIR):
        for f in sorted(os.listdir(BACKUP_DIR), reverse=True):
            if f.endswith('.db'):
                p = os.path.join(BACKUP_DIR, f)
                out.append({'name': f, 'size': os.path.getsize(p)})
    return out[:15]


@route('POST', r'/api/demo')
def api_demo_load(h):
    with dbc() as c:
        n = seed_demo(c)
    return {'ok': True, 'added': n}


@route('DELETE', r'/api/demo')
def api_demo_del(h):
    with dbc() as c:
        folders = demo_clear(c)
    for f in folders:
        trash_folder_hard(f)
    return {'ok': True}


def trash_folder_hard(folder):
    if folder:
        p = os.path.abspath(os.path.join(FILES_DIR, folder))
        if p.startswith(os.path.abspath(FILES_DIR) + os.sep):
            shutil.rmtree(p, ignore_errors=True)


@route('POST', r'/api/shutdown')
def api_shutdown(h):
    httpd = SERVER.get('httpd')
    if httpd:
        threading.Thread(target=httpd.shutdown, daemon=True).start()
    return {'ok': True}


# ----------------------------------------------------------------------------- HTTP handler
class Handler(BaseHTTPRequestHandler):
    server_version = 'BasisTaskManager/' + APP_VERSION
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    # -- helpers
    def json_body(self):
        length = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(length) if length else b''
        self.body_consumed = True
        if not raw:
            return {}
        try:
            return json.loads(raw.decode('utf-8'))
        except Exception:
            raise ApiError(400, 'Invalid JSON')

    def send_json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, data, ctype, filename=None, inline=True):
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        if filename:
            self.send_header('Content-Disposition', "%s; filename*=UTF-8''%s" % ('inline' if inline else 'attachment', quote(filename)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)
        self.responded = True

    def send_file(self, path, ctype, filename=None, inline=True):
        size = os.path.getsize(path)
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(size))
        self.send_header('X-Content-Type-Options', 'nosniff')
        if filename:
            # uploaded user files: never let them run as part of the app page
            self.send_header('Content-Security-Policy', 'sandbox')
        if filename:
            self.send_header('Content-Disposition', "%s; filename*=UTF-8''%s" % ('inline' if inline else 'attachment', quote(filename)))
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        with open(path, 'rb') as f:
            while True:
                chunk = f.read(1 << 20)
                if not chunk:
                    break
                self.wfile.write(chunk)
        self.responded = True

    def host_ok(self):
        host = (self.headers.get('Host') or '').split(':')[0].lower()
        return host in ('127.0.0.1', 'localhost', '[::1]', '')

    def handle_any(self, method):
        SERVER['last_seen'] = time.time()
        self.body_consumed = False
        self.responded = False
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        self.query = {k: v[0] for k, v in parse_qs(parsed.query, keep_blank_values=True).items()}
        try:
            if not self.host_ok():
                raise ApiError(403, 'Forbidden host')
            if path.startswith('/api/') or path.startswith('/files/'):
                if method != 'GET' and self.headers.get('X-TM') != '1':
                    raise ApiError(403, 'Missing X-TM header')
                for m, rx, fn in ROUTES:
                    if m != method:
                        continue
                    mt = rx.match(path)
                    if mt:
                        res = fn(self, *mt.groups())
                        if res is not None and not self.responded:
                            self.send_json(res)
                        return
                raise ApiError(404, 'Unknown endpoint')
            if method == 'GET':
                return self.serve_static(path)
            raise ApiError(405, 'Method not allowed')
        except ApiError as e:
            self.fail(e.status, e.msg)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
        except Exception as e:
            traceback.print_exc()
            self.fail(500, 'Server error: %s' % e)
        finally:
            if method in ('POST', 'PUT', 'DELETE') and not self.body_consumed:
                self.close_connection = True

    def fail(self, status, msg):
        if self.responded:
            return
        try:
            self.send_json({'error': msg}, status)
        except Exception:
            self.close_connection = True

    def serve_static(self, path):
        if path in ('', '/'):
            path = '/index.html'
        full = os.path.abspath(os.path.join(STATIC_DIR, path.lstrip('/')))
        if not full.startswith(os.path.abspath(STATIC_DIR)) or not os.path.isfile(full):
            raise ApiError(404, 'Not found')
        # fixed types: the Windows registry sometimes maps .js to text/plain, which browsers refuse to run
        ext = os.path.splitext(full)[1].lower()
        ctype = STATIC_TYPES.get(ext) or mimetypes.guess_type(full)[0] or 'application/octet-stream'
        if ctype.startswith('text/') or ctype in ('application/javascript', 'application/json'):
            ctype += '; charset=utf-8'
        self.send_file(full, ctype)

    def do_GET(self):
        self.handle_any('GET')

    def do_POST(self):
        self.handle_any('POST')

    def do_PUT(self):
        self.handle_any('PUT')

    def do_DELETE(self):
        self.handle_any('DELETE')


mimetypes.add_type('application/javascript', '.js')
mimetypes.add_type('image/x-icon', '.ico')
STATIC_TYPES = {'.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
                '.png': 'image/png', '.json': 'application/json'}


# ----------------------------------------------------------------------------- run
def idle_watch(httpd, seconds):
    """Stop the server when the browser window has been closed for `seconds`."""
    poll = min(15, max(1, seconds // 3))
    prev = time.time()
    while True:
        time.sleep(poll)
        now = time.time()
        if now - prev > poll + 45:
            # the PC was asleep / suspended: give the open window time to reconnect before judging idleness
            SERVER['last_seen'] = now
        prev = now
        if now - SERVER['last_seen'] > seconds:
            httpd.shutdown()
            return


class LocalServer(ThreadingHTTPServer):
    # On Windows SO_REUSEADDR lets a second copy bind the same port, so use exclusive binding there.
    allow_reuse_address = not sys.platform.startswith('win')

    def server_bind(self):
        if sys.platform.startswith('win') and hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        ThreadingHTTPServer.server_bind(self)


def serve(port=DEFAULT_PORT, idle_exit=0):
    init_all()
    httpd = LocalServer(('127.0.0.1', port), Handler)
    httpd.daemon_threads = True
    SERVER['httpd'] = httpd
    SERVER['last_seen'] = time.time()
    if idle_exit:
        threading.Thread(target=idle_watch, args=(httpd, idle_exit), daemon=True).start()
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description='BASIS Task Manager server')
    ap.add_argument('--port', type=int, default=DEFAULT_PORT)
    ap.add_argument('--idle-exit', type=int, default=0, help='stop automatically after N idle seconds (0 = never)')
    a = ap.parse_args()
    try:
        print('BASIS Task Manager running on http://127.0.0.1:%d  (Ctrl+C to stop)' % a.port)
        print('Data folder: %s' % os.path.abspath(DATA_DIR), flush=True)
    except Exception:
        pass    # no console (pythonw) or a console that cannot show the path characters
    try:
        serve(a.port, a.idle_exit)
    except KeyboardInterrupt:
        pass

