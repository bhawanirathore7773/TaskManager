/* People: list, mail / SAP ids, new joiner (one dialog), issue an item, employee drawer, leaver, handover slip. */
(function () {
  'use strict';
  const { h, ico, GET, POST, PUT, DEL, toast, modal, confirmBox, fmtTs, fmtD, load } = App;
  const me = () => App.settings().manager || '';
  const lbl = (list, key) => App.label(list, key);
  const itemCount = (p) => (p.n_assets || 0) + (p.n_bulk || 0);

  function pStatus(p) {
    if (p.status === 'left') return h('span', { class: 'row wrap', style: { gap: '4px', display: 'inline-flex' } }, App.chip('Left' + (p.left_on ? ' ' + fmtD(p.left_on) : ''), 'var(--ink-3)'), p.leaver_pending ? App.chip('Items / ids pending', 'var(--c-overdue)') : null);
    if (p.status === 'joining') return App.chip('Joining ' + fmtD(p.joined_on), 'var(--c-warning)');
    return App.chip('Working', 'var(--c-ok)');
  }
  const accStatus = (a) => App.chip({ active: 'Active', locked: 'Locked', deleted: 'Deleted' }[a.status] || a.status, { active: 'var(--c-ok)', locked: 'var(--c-warning)', deleted: 'var(--ink-3)' }[a.status]);

  /* ====================== list ====================== */
  App.V.people = async function (root, params) {
    const st = App.S.pp = App.S.pp || { tab: 'people', filter: 'working', dept: '', q: '', af: 'active', ak: '', aq: '' };
    if (params.tab) st.tab = params.tab; else if (params.filter) st.tab = 'people';
    if (params.filter) st.filter = params.filter;
    const [people, accounts] = await Promise.all([load('people'), load('accounts')]);
    const plantPeople = people.filter((p) => App.inPlant(p));
    const recent = App.iso(App.addDays(new Date(), -21));
    const PF = { working: (p) => p.status !== 'left', joiner: (p) => p.status !== 'left' && p.n_steps_open > 0 && (p.joined_on || '') >= recent, leaver: (p) => p.leaver_pending, left: (p) => p.status === 'left', all: () => true };
    const PL = [['working', 'Working'], ['joiner', 'New joiners'], ['leaver', 'Left - items pending'], ['left', 'Left'], ['all', 'All']];
    const plantAcc = accounts.filter((a) => !App.plantFilter() || !a.person_id || a.plant === App.plantFilter());
    const AF = { active: (a) => a.status === 'active', locked: (a) => a.status === 'locked', orphan: (a) => a.status !== 'deleted' && a.person_status === 'left', deleted: (a) => a.status === 'deleted', all: () => true };
    const AL = [['active', 'Active'], ['locked', 'Locked'], ['orphan', 'Owner has left'], ['deleted', 'Deleted'], ['all', 'All']];

    const tabs = h('div', { class: 'tabs' });
    const holder = h('div');
    const head = h('div', { class: 'page-h' });
    const tools = h('div', { class: 'tools' });
    function drawTabs() {
      tabs.replaceChildren(
        h('button', { type: 'button', class: st.tab === 'people' ? 'on' : '', onclick: () => { st.tab = 'people'; draw(); } }, 'People', h('span', { class: 'muted small' }, plantPeople.filter(PF.working).length)),
        h('button', { type: 'button', class: st.tab === 'accounts' ? 'on' : '', onclick: () => { st.tab = 'accounts'; draw(); } }, 'Mail & SAP ids', h('span', { class: 'muted small' }, plantAcc.filter(AF.active).length)));
    }
    function draw() {
      drawTabs();
      head.replaceChildren(h('div', null, h('h1', null, 'People'), h('div', { class: 'sub' }, 'Employees and operators: what IT items and ids each one has - joining to leaving, with full history.')), h('span', { class: 'grow' }),
        st.tab === 'accounts' ? App.btn('Add mail / SAP id', () => accountDialog({}), '', 'key') : null, App.btn('New joiner', () => App.newJoiner(), 'primary', 'plus'));
      tools.replaceChildren();
      holder.replaceChildren();
      if (st.tab === 'people') drawPeople(); else drawAccounts();
    }

    function drawPeople() {
      const seg = h('div', { class: 'seg' });
      const q = h('input', { type: 'search', placeholder: 'Search name, code, department…', value: st.q });
      const depts = Array.from(new Set(people.map((p) => p.department).filter(Boolean))).sort();
      const dsel = App.sel([['', 'All departments']].concat(depts.map((d) => [d, d])), st.dept, (v) => { st.dept = v; rows(); });
      function segs() { seg.replaceChildren(PL.map(([k, l]) => h('button', { type: 'button', class: st.filter === k ? 'on' : '', onclick: () => { st.filter = k; segs(); rows(); } }, l + (k !== 'all' && k !== 'working' ? (plantPeople.filter(PF[k]).length ? ' ' + plantPeople.filter(PF[k]).length : '') : '')))); }
      q.addEventListener('input', () => { st.q = q.value; rows(); });
      tools.replaceChildren(seg, h('div', { class: 'grow', style: { minWidth: '180px' } }, q), dsel);
      segs();
      function rows() {
        const s = st.q.trim().toLowerCase();
        const list = plantPeople.filter(PF[st.filter] || PF.all).filter((p) => (!st.dept || p.department === st.dept) && (!s || [p.name, p.emp_code, p.code, p.department, p.designation, p.mobile, p.email].some((x) => x && String(x).toLowerCase().indexOf(s) >= 0)));
        holder.replaceChildren(App.grid({
          rows: list, sortKey: 'name', sortDir: 1, onRow: (p) => App.openPerson(p.id),
          emptyTitle: st.filter === 'working' ? 'No employees yet' : 'Nobody here', emptyText: st.filter === 'working' ? 'Use "New joiner" to add the first person - or load demo data from Today.' : '',
          cols: [
            { k: 'name', label: 'Name', sort: (p) => p.name.toLowerCase(), render: (p) => h('div', null, h('span', { class: 'ttl' }, p.name), h('span', { class: 'sub' }, [p.emp_code, p.designation, p.department].filter(Boolean).join(' · '))) },
            { k: 'plant', label: 'Plant', cls: 'nw', sort: true, render: (p) => App.plantText(p.plant) },
            { k: 'kind', label: 'Type', sort: true, render: (p) => lbl(App.vocab().person_kinds, p.kind) },
            { k: 'items', label: 'Items', cls: 'num', sort: (p) => itemCount(p), render: (p) => (itemCount(p) ? h('span', { class: p.status === 'left' ? 'due-over' : '' }, itemCount(p)) : h('span', { class: 'muted' }, '0')) },
            { k: 'ids', label: 'Ids', cls: 'num', sort: (p) => p.n_accounts, render: (p) => (p.n_accounts ? h('span', { class: p.status === 'left' ? 'due-over' : '' }, p.n_accounts) : h('span', { class: 'muted' }, '0')) },
            { k: 'tk', label: 'Open tickets', cls: 'num', sort: (p) => p.n_open_tickets, render: (p) => (p.n_open_tickets ? p.n_open_tickets : h('span', { class: 'muted' }, '0')) },
            { k: 'steps', label: 'Checklist', cls: 'num', sort: (p) => p.n_steps_open, render: (p) => (p.n_steps_open ? p.n_steps_open + ' open' : h('span', { class: 'muted' }, '—')) },
            { k: 'status', label: 'Status', cls: 'nw', sort: (p) => p.status, render: pStatus }
          ]
        }));
      }
      rows();
    }

    function drawAccounts() {
      const seg = h('div', { class: 'seg' });
      const q = h('input', { type: 'search', placeholder: 'Search id, name, system, role…', value: st.aq });
      const ksel = App.sel([['', 'All types']].concat(App.vocab().account_kinds.map((k) => [k.key, k.label])), st.ak, (v) => { st.ak = v; rows(); });
      function segs() { seg.replaceChildren(AL.map(([k, l]) => h('button', { type: 'button', class: st.af === k ? 'on' : '', onclick: () => { st.af = k; segs(); rows(); } }, l + (k === 'orphan' && plantAcc.filter(AF.orphan).length ? ' ' + plantAcc.filter(AF.orphan).length : '')))); }
      q.addEventListener('input', () => { st.aq = q.value; rows(); });
      tools.replaceChildren(seg, h('div', { class: 'grow', style: { minWidth: '180px' } }, q), ksel);
      segs();
      function rows() {
        const s = st.aq.trim().toLowerCase();
        const list = plantAcc.filter(AF[st.af] || AF.all).filter((a) => (!st.ak || a.kind === st.ak) && (!s || [a.identifier, a.person_name, a.owner_name, a.system, a.roles].some((x) => x && String(x).toLowerCase().indexOf(s) >= 0)));
        holder.replaceChildren(App.grid({
          rows: list, sortKey: 'identifier', sortDir: 1, onRow: (a) => accountDialog({ account: a }),
          emptyTitle: 'No ids here', emptyText: 'Mail ids, SAP users and other logins appear here. Add them from a person, or with "Add mail / SAP id".',
          cols: [
            { k: 'identifier', label: 'Id', sort: (a) => a.identifier.toLowerCase(), render: (a) => h('div', null, h('span', { class: 'ttl mono' }, a.identifier), a.system ? h('span', { class: 'sub' }, a.system) : null) },
            { k: 'kind', label: 'Type', sort: true, render: (a) => lbl(App.vocab().account_kinds, a.kind) },
            { k: 'owner', label: 'Belongs to', sort: (a) => (a.person_name || a.owner_name || '').toLowerCase(), render: (a) => (a.person_id ? h('button', { class: 'lnk', type: 'button', onclick: () => App.openPerson(a.person_id) }, a.person_name) : h('span', null, a.owner_name || '—', h('span', { class: 'sub' }, 'shared'))) },
            { k: 'plant', label: 'Plant', cls: 'nw', sort: true, render: (a) => App.plantText(a.plant) },
            { k: 'roles', label: 'Roles', render: (a) => h('span', { class: 'trunc', style: { maxWidth: '220px', display: 'inline-block' }, title: a.roles }, a.roles || '—') },
            { k: 'created_on', label: 'Created', cls: 'nw', sort: true, render: (a) => fmtD(a.created_on) },
            { k: 'valid_to', label: 'Valid until', sort: (a) => a.valid_to || '9999', render: (a) => (a.valid_to ? fmtD(a.valid_to) : '—') },
            { k: 'status', label: 'Status', sort: true, render: (a) => h('span', null, accStatus(a), a.status !== 'deleted' && a.person_status === 'left' ? h('span', { class: 'due-over small', style: { marginLeft: '6px' } }, 'owner has left') : null) }
          ]
        }));
      }
      rows();
    }
    root.replaceChildren(head, tabs, tools, holder);
    draw();
  };

  /* ====================== stock picker (used by joiner + issue) ====================== */
  // Shows what is in stock for one item type: returned (used) items first, then new ones.  value() -> {asset_id, qty, buy, kind}
  function stockPicker(kind, plant, o) {
    o = o || {};
    const el = h('div', { class: 'stack', style: { gap: '6px' } }, App.spin());
    const name = 'sp' + Math.random().toString(36).slice(2, 8);
    const st = { asset: o.asset_id || null, buy: false, qty: 1, d: null, all: false };
    const qty = h('input', { type: 'number', min: 1, value: 1, style: { width: '76px' }, 'aria-label': 'How many' });
    qty.addEventListener('input', () => { st.qty = Math.max(1, parseInt(qty.value, 10) || 1); });
    const bulk = !!(App.vocab().asset_kinds.find((k) => k.key === kind) || {}).bulk;
    function row(checked, onPick, title, sub, chipEl, extra) {
      return h('label', { class: 'stock-row' + (checked ? ' on' : '') }, h('input', { type: 'radio', name: name, checked: checked, onchange: onPick }), h('div', { style: { minWidth: 0 } }, h('b', null, title), sub ? h('span', { class: 'sub', style: { display: 'block' } }, sub) : null, extra || null), chipEl || h('span'));
    }
    function draw() {
      const d = st.d, items = st.all ? d.items : d.items.slice(0, 6);
      const kids = [h('div', { class: 'muted small' }, d.label + ': ' + d.free + ' in stock' + (d.free ? ' (' + d.used + ' returned / used, ' + d.new + ' new' + (plant ? ', ' + d.in_plant + ' in ' + plant : '') + ')' : ''))];
      if (!d.items.length) kids.push(h('div', { class: 'box warn' }, h('b', null, 'None in stock. '), o.allowBuy ? 'A purchase request will be made so it is not forgotten.' : 'Add stock first, or buy it.'));
      items.forEach((a) => {
        const on = !st.buy && st.asset === a.id;
        const sub = [a.tracked ? a.serial : a.qty_free + ' available', a.tag ? 'tag ' + a.tag : '', a.plant ? App.plantText(a.plant) : '', lbl(App.vocab().conditions, a.cond), a.last_return ? 'returned ' + fmtD(a.last_return) : ''].filter(Boolean).join(' · ');
        kids.push(row(on, () => { st.asset = a.id; st.buy = false; draw(); if (o.onChange) o.onChange(); }, a.code + '  ' + (a.name || App.kindLabel(a.kind)), sub,
          App.chip(a.advice, a.cond === 'poor' ? 'var(--c-warning)' : a.is_new ? 'var(--ink-3)' : 'var(--c-ok)'), on && bulk ? h('div', { style: { marginTop: '6px' } }, h('span', { class: 'small muted' }, 'How many? '), qty) : null));
      });
      if (d.items.length > 6 && !st.all) kids.push(h('button', { class: 'lnk small', type: 'button', onclick: () => { st.all = true; draw(); } }, 'Show all ' + d.items.length));
      if (o.allowBuy) kids.push(row(st.buy, () => { st.buy = true; draw(); if (o.onChange) o.onChange(); }, 'Not from stock - buy new', 'A purchase request is created and linked to this person.', null, st.buy && bulk ? h('div', { style: { marginTop: '6px' } }, h('span', { class: 'small muted' }, 'How many? '), qty) : null));
      el.replaceChildren(kids);
    }
    GET('/api/stock/suggest?kind=' + encodeURIComponent(kind) + '&plant=' + encodeURIComponent(plant || '')).then((d) => {
      st.d = d;
      if (!st.asset || !d.items.some((a) => a.id === st.asset)) { st.asset = d.items.length ? d.items[0].id : null; }
      if (!d.items.length && o.allowBuy) st.buy = true;
      if (o.fixedBuy) st.buy = true;
      draw(); if (o.onChange) o.onChange();
    }).catch(() => el.replaceChildren(h('div', { class: 'muted' }, 'Could not read the stock.')));
    el.value = () => ({ kind: kind, asset_id: st.buy ? null : st.asset, qty: bulk ? st.qty : 1, buy: st.buy, bulk: bulk });
    return el;
  }
  App.stockPicker = stockPicker;

  /* ====================== new joiner ====================== */
  const NEED = ['laptop', 'desktop', 'monitor', 'mouse', 'keyboard', 'phone', 'barcode', 'storage'];
  App.newJoiner = function (pre) {
    pre = pre || {};
    const kinds = App.vocab().person_kinds.map((k) => [k.key, k.label]);
    const f = App.makeForm([
      { k: 'name', label: 'Full name', req: true, ph: 'e.g. Mohit Sharma' },
      { k: 'emp_code', label: 'Employee code', ph: 'as in HR / SAP' },
      { k: 'kind', label: 'Type', t: 'select', opts: kinds },
      { k: 'plant', label: 'Plant', t: 'select', opts: [['', '— choose —']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) },
      { k: 'department', label: 'Department', list: 'dl-dept', ph: 'Accounts, Stores, Production…' },
      { k: 'designation', label: 'Designation', ph: 'Operator, Executive…' },
      { k: 'mobile', label: 'Mobile' },
      { k: 'joined_on', label: 'Joining date', t: 'date' },
      { k: 'reports_to', label: 'Reports to' },
      { k: 'location', label: 'Works at', ph: 'e.g. Calendering line 2, Store, Office' }], Object.assign({ kind: 'employee', plant: App.plantFilter() || '', joined_on: App.todayIso() }, pre));
    const dl = h('datalist', { id: 'dl-dept' }, (App.S.meta.departments || []).map((d) => h('option', { value: d })));
    const picks = {}, picksBox = h('div', { class: 'stack', style: { gap: '12px', marginTop: '10px' } });
    const chips = h('div', { class: 'chipbtns' });
    const kindHint = h('div', { class: 'hint-box hide' }, 'Operators and contractors often need no laptop. Tick only what is really given - the handover slip will list exactly that.');
    function drawChips() {
      chips.replaceChildren(NEED.map((k) => h('button', { type: 'button', class: 'chipbtn' + (picks[k] ? ' on' : ''), onclick: () => { if (picks[k]) { picks[k].remove(); delete picks[k]; } else addPick(k); drawChips(); } }, App.kindLabel(k))));
    }
    function addPick(k) {
      const box = h('div', { class: 'box' }, h('h3', null, App.kindLabel(k)), stockPicker(k, f.ctl.plant.value, { allowBuy: true }));
      box._sp = box.lastChild; box.value = () => box._sp.value();
      picks[k] = box; picksBox.append(box);
    }
    f.ctl.plant.addEventListener('change', () => { Object.keys(picks).forEach((k) => { picks[k].remove(); delete picks[k]; addPick(k); }); });
    f.ctl.kind.addEventListener('change', () => kindHint.classList.toggle('hide', f.ctl.kind.value === 'employee'));
    if (App.plantFilter() === '' && App.plants().length === 1) f.ctl.plant.value = App.plants()[0].code;
    drawChips();

    const accRows = [['email', 'Mail id', 'e.g. mohit.sharma@company.com', 'Mail system'], ['sap', 'SAP user', 'e.g. MSHARMA', 'Client / system, e.g. PRD 100'], ['domain', 'Windows login', 'e.g. mohit.sharma', '']].map(([kind, label, ph, sys]) => {
      const id = h('input', { type: 'text', placeholder: ph, autocomplete: 'off', 'aria-label': label }), extra = h('input', { type: 'text', placeholder: kind === 'sap' ? 'Roles given (as approved)' : sys || 'Note', autocomplete: 'off', 'aria-label': label + ' detail' });
      const sysI = kind === 'sap' ? h('input', { type: 'text', placeholder: 'Client / system, e.g. PRD 100', autocomplete: 'off', 'aria-label': 'SAP system' }) : null;
      return { kind, label, id, extra, sysI, el: h('div', { class: kind === 'sap' ? 'grid3' : 'grid2', style: { marginBottom: '8px' } }, h('div', { class: 'fld' }, h('label', null, label), id), sysI ? h('div', { class: 'fld' }, h('label', null, 'SAP system'), sysI) : null, h('div', { class: 'fld' }, h('label', null, kind === 'sap' ? 'Roles' : 'Detail'), extra)) };
    });
    const m = modal({ title: 'New joiner', cls: 'wide', body: [
      f.el, dl, kindHint,
      h('h3', { style: { margin: '18px 0 4px' } }, 'What is the new joiner getting?'), h('div', { class: 'muted small', style: { marginBottom: '8px' } }, 'Tap the items. Returned items from old employees are offered first; if the stock is empty, a purchase request is made.'), chips, picksBox,
      h('h3', { style: { margin: '18px 0 4px' } }, 'Ids created now (optional)'), h('div', { class: 'muted small', style: { marginBottom: '8px' } }, 'Fill only what you create today - you can add the rest later. Never write passwords here.'), accRows.map((r) => r.el)],
    actions: [{ label: 'Cancel' }, { label: 'Add joiner', cls: 'primary', close: false, onClick: async () => {
      const v = f.get();
      if (!v.name.trim()) { toast('Write the name first', 'err'); f.ctl.name.focus(); return false; }
      if (!v.plant) { toast('Choose the plant - it decides which stock is offered', 'err'); f.ctl.plant.focus(); return false; }
      const issue = [], buy = [];
      Object.keys(picks).forEach((k) => { const x = picks[k].value(); if (x.buy) buy.push({ kind: k, qty: x.qty }); else if (x.asset_id) issue.push({ asset_id: x.asset_id, qty: x.qty }); });
      const accounts = accRows.filter((r) => r.id.value.trim()).map((r) => ({ kind: r.kind, identifier: r.id.value.trim(), system: r.sysI ? r.sysI.value.trim() : (r.kind === 'email' ? r.extra.value.trim() : ''), roles: r.kind === 'sap' ? r.extra.value.trim() : '', note: r.kind === 'sap' ? '' : (r.kind === 'email' ? '' : r.extra.value.trim()) }));
      try {
        const p = await POST('/api/people', Object.assign({}, v, { who: me(), issue: issue, buy: buy, accounts: accounts }));
        m.close();
        toast(p.name + ' added' + (issue.length ? ' · ' + issue.length + ' item(s) issued' : '') + (buy.length ? ' · ' + buy.length + ' purchase request(s)' : '') + (accounts.length ? ' · ' + accounts.length + ' id(s)' : ''));
        App.refresh(); App.openPerson(p.id);
      } catch (e) { /* the reason is shown */ }
      return false;
    } }] });
    setTimeout(() => f.ctl.name.focus(), 60);
  };

  /* ====================== issue an item ====================== */
  App.issueDialog = async function (pre) {
    pre = pre || {};
    let fixed = null;
    if (pre.asset_id) { try { fixed = await GET('/api/assets/' + pre.asset_id); } catch (e) { return; } }
    const kindSel = App.sel(App.vocab().asset_kinds.map((k) => [k.key, k.label]), (fixed && fixed.kind) || pre.kind || 'laptop');
    const personP = App.pick('person', pre.person_id || null, null, {});
    const place = h('input', { type: 'text', placeholder: 'or a place, e.g. Calendering line 2 (for a machine PC / camera)', autocomplete: 'off' });
    const note = h('textarea', { placeholder: 'Note (optional): reason, accessories given, condition…', style: { minHeight: '56px' } });
    const area = h('div');
    let sp = null;
    const plantOf = async () => { const id = personP.get(); if (!id) return App.plantFilter(); const p = (await load('people')).find((x) => x.id === id); return (p && p.plant) || App.plantFilter(); };
    async function drawPicker() { if (fixed) return; area.replaceChildren(App.spin()); sp = stockPicker(kindSel.value, await plantOf(), { asset_id: pre.pick_asset }); area.replaceChildren(sp); }
    kindSel.addEventListener('change', drawPicker); personP.addEventListener('pick', drawPicker);
    const body = [App.fld('Who gets it', personP), h('div', { class: 'fld', style: { marginTop: '8px' } }, place),
      fixed ? h('div', { class: 'box', style: { marginTop: '12px' } }, h('b', null, fixed.code + ' ' + fixed.label), h('div', { class: 'muted small' }, [fixed.serial, fixed.tag, lbl(App.vocab().asset_status, fixed.status)].filter(Boolean).join(' · ')))
        : h('div', { style: { marginTop: '12px' } }, App.fld('What', kindSel), area), h('div', { class: 'fld', style: { marginTop: '10px' } }, h('label', null, 'Note'), note)];
    const m = modal({ title: 'Issue an item', cls: 'wide', body: body, actions: [{ label: 'Cancel' }, { label: 'Issue', cls: 'primary', close: false, onClick: async () => {
      const pid = personP.get(), loc = place.value.trim();
      if (!pid && !loc) { toast('Choose who gets it, or write the place', 'err'); return false; }
      let aid, qty = 1;
      if (fixed) aid = fixed.id; else { const x = sp && sp.value && sp.value(); if (!x || !x.asset_id) { toast('Nothing in stock to issue - use "Buy & renew" to order it', 'err'); return false; } aid = x.asset_id; qty = x.qty; }
      try {
        await POST('/api/assets/' + aid + '/op', { op: 'issue', person_id: pid, location: loc, qty: qty, note: note.value, who: me(), ticket_id: pre.ticket_id || null });
        m.close(); toast('Issued'); App.refresh(); if (pre.after) pre.after();
      } catch (e) { /* shown */ }
      return false;
    } }] });
    drawPicker();
  };

  /* ====================== account (mail id / SAP user) ====================== */
  function accountDialog(o) {
    o = o || {};
    const a = o.account;
    const f = App.makeForm([
      { k: 'person_id', label: 'Employee', t: 'person', includeLeft: !!a },
      { k: 'owner_name', label: 'Or a shared id owner', ph: 'e.g. Plant mail - Stores', hint: 'Only when no employee: plant mail, shared login.' },
      { k: 'kind', label: 'Type', t: 'select', opts: App.vocab().account_kinds.map((k) => [k.key, k.label]) },
      { k: 'identifier', label: 'Mail id / user id', req: true },
      { k: 'system', label: 'System', ph: 'e.g. PRD 100, Office 365', list: 'dl-sys' },
      { k: 'status', label: 'Status', t: 'select', opts: [['active', 'Active'], ['locked', 'Locked'], ['deleted', 'Deleted / disabled']] },
      { k: 'valid_to', label: 'Valid until', t: 'date' },
      { k: 'created_on', label: 'Created on', t: 'date' },
      { k: 'roles', label: 'Roles / access given', t: 'area', wide: true, ph: 'SAP roles, mail groups…' },
      { k: 'note', label: 'Note (never write passwords)', t: 'area', wide: true }], Object.assign({ kind: 'email', status: 'active', created_on: App.todayIso() }, a || {}, !a && o.person_id ? { person_id: o.person_id } : {}));
    const systems = Array.from(new Set((App.S.accSystems || []).concat(['PRD 100', 'QAS 100', 'DEV 100', 'Office 365', 'Domain']))).sort();
    const dl = h('datalist', { id: 'dl-sys' }, systems.map((s) => h('option', { value: s })));
    const m = modal({ title: a ? 'Edit ' + a.identifier : 'New mail / SAP / login id', cls: 'wide', body: [f.el, dl],
      actions: (a ? [{ label: 'Remove record', cls: 'ghost danger', close: false, onClick: async () => { if (await confirmBox('Remove this record completely? Use this only for an id entered by mistake. To end a real id set it to Deleted instead.')) { await DEL('/api/accounts/' + a.id); m.close(); toast('Removed'); App.refresh(); if (o.after) o.after(); } return false; } }] : [])
        .concat([{ label: 'Cancel' }, { label: a ? 'Save' : 'Create id', cls: 'primary', close: false, onClick: async () => {
          const v = f.get();
          if (!v.identifier.trim()) { toast('Write the id first', 'err'); return false; }
          if (!v.person_id && !v.owner_name.trim()) { toast('Choose the employee, or write the shared id owner', 'err'); return false; }
          try {
            if (a) await PUT('/api/accounts/' + a.id, v); else await POST('/api/accounts', Object.assign(v, { who: me() }));
            m.close(); toast(a ? 'Saved' : 'Id recorded'); App.refresh(); if (o.after) o.after();
          } catch (e) { /* shown */ }
          return false;
        } }]) });
    setTimeout(() => f.ctl.identifier.focus(), 60);
  }
  App.accountDialog = accountDialog;

  /* ====================== leaver ====================== */
  function leaveDialog(p, after) {
    const d = h('input', { type: 'date', value: App.todayIso() });
    const held = p.holdings.length, accs = p.accounts.filter((a) => a.status !== 'deleted').length;
    const m = modal({ title: 'Mark ' + p.name + ' as left', body: [
      h('p', null, 'The leaving checklist is created. Nothing is deleted: the items and ids still with the person stay on the list ("pending") until you collect them and close the ids.'),
      (held || accs) ? h('div', { class: 'box warn', style: { margin: '10px 0' } }, h('b', null, 'Still with the person now: '), [held ? held + ' item(s)' : '', accs ? accs + ' id(s)' : ''].filter(Boolean).join(' and ')) : null,
      App.fld('Last working day', d)],
    actions: [{ label: 'Cancel' }, { label: 'Mark as left', cls: 'danger', close: false, onClick: async () => { try { await POST('/api/people/' + p.id + '/leave', { left_on: d.value }); m.close(); toast(p.name + ' marked as left'); await after(); } catch (e) { /* shown */ } return false; } }] });
  }

  /* ====================== handover slip ====================== */
  function slipNode(p) {
    const left = p.status === 'left';
    const accs = p.accounts.filter((a) => a.status !== 'deleted');
    const co = App.settings().company || '';
    return h('div', { class: 'slip' },
      h('h1', null, left ? 'IT clearance slip' : 'IT handover slip'), h('div', null, (co ? co + ' · ' : '') + 'Printed ' + new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' })),
      h('table', null, h('tbody', null,
        h('tr', null, h('th', null, 'Name'), h('td', null, p.name), h('th', null, 'Employee code'), h('td', null, p.emp_code || '—')),
        h('tr', null, h('th', null, 'Department'), h('td', null, p.department || '—'), h('th', null, 'Designation'), h('td', null, p.designation || '—')),
        h('tr', null, h('th', null, 'Plant'), h('td', null, App.plantText(p.plant)), h('th', null, left ? 'Left on' : 'Joined on'), h('td', null, fmtD(left ? p.left_on : p.joined_on, true))))),
      h('b', null, left ? 'Still with the employee (to be returned)' : 'Items issued'),
      p.holdings.length ? h('table', null, h('thead', null, h('tr', null, ['Code', 'Item', 'Make / model', 'Serial / tag', 'Qty', 'Since'].map((x) => h('th', null, x)))),
        h('tbody', null, p.holdings.map((x) => h('tr', null, h('td', null, x.code), h('td', null, App.kindLabel(x.kind)), h('td', null, x.name || ''), h('td', null, [x.serial, x.tag].filter(Boolean).join(' / ')), h('td', null, x.qty), h('td', null, fmtD(x.since)))))) : h('p', null, left ? 'Nothing pending.' : 'No items issued.'),
      h('b', null, left ? 'Ids to be closed' : 'Ids given'),
      accs.length ? h('table', null, h('thead', null, h('tr', null, ['Type', 'Id', 'System', 'Roles'].map((x) => h('th', null, x)))),
        h('tbody', null, accs.map((a) => h('tr', null, h('td', null, lbl(App.vocab().account_kinds, a.kind)), h('td', null, a.identifier), h('td', null, a.system || ''), h('td', null, a.roles || ''))))) : h('p', null, 'None.'),
      h('p', { style: { marginTop: '12px' } }, left ? 'The employee has returned the items listed as collected and confirms that no company data is kept on personal devices.' : 'I have received the items above in working condition. I will use them and the ids only for company work, will not share my password, and will return everything when I leave or when asked.'),
      h('div', { class: 'sign' }, h('div', null, 'Employee (' + p.name + ')'), h('div', null, 'IT - ' + (App.settings().manager || '')), h('div', null, 'HOD' + (App.settings().hod ? ' - ' + App.settings().hod : ''))));
  }

  /* ====================== employee drawer ====================== */
  App.openPerson = async function (id) {
    const dr = App.drawer({ aria: 'Employee' });
    dr.body.replaceChildren(App.spin());
    async function render() {
      let p;
      try { p = await GET('/api/people/' + id); } catch (e) { return dr.close(); }
      const done = async () => { await render(); App.refresh(); };
      const left = p.status === 'left';
      dr.setHead([h('div', { class: 'row wrap', style: { marginBottom: '4px', paddingRight: '34px' } }, App.mono(p.code), pStatus(p), App.tag(lbl(App.vocab().person_kinds, p.kind)), p.plant ? App.tag(App.plantText(p.plant)) : null),
        h('div', { style: { fontSize: '20px', fontWeight: '700', lineHeight: '1.25' } }, p.name),
        h('div', { class: 'muted small' }, [p.emp_code, p.designation, p.department].filter(Boolean).join(' · ') + (p.emp_code || p.designation || p.department ? ' · ' : '') + 'joined ' + fmtD(p.joined_on, true) + (left ? ' · left ' + fmtD(p.left_on, true) : ''))]);

      const pending = p.leaver_pending ? h('div', { class: 'box bad', style: { marginBottom: '14px' } }, h('b', null, 'Left the company, but still pending:'),
        h('div', { style: { margin: '4px 0' } }, [p.holdings.map((x) => x.code + ' ' + App.kindLabel(x.kind) + (x.qty > 1 ? ' x' + x.qty : '')).join(', '), p.accounts.filter((a) => a.status !== 'deleted').map((a) => a.identifier).join(', ')].filter(Boolean).join('  ·  ')),
        h('div', { class: 'muted small' }, 'Collect the items and close the ids below - the leaving checklist ticks itself as you do it.')) : null;

      const acts = h('div', { class: 'acts', style: { marginBottom: '16px' } },
        !left ? App.btn('Issue an item', () => App.issueDialog({ person_id: id, after: done }), 'primary', 'laptop') : null,
        !left ? App.btn('Add mail / SAP id', () => accountDialog({ person_id: id, after: done }), '', 'key') : null,
        !left ? App.btn('New ticket', () => App.newTicket({ person_id: id, after: done }), '', 'ticket') : null,
        App.btn(left ? 'Print clearance slip' : 'Print handover slip', () => App.printNode(slipNode(p)), '', 'print'),
        !left ? App.btn('Mark as left', () => leaveDialog(p, done), 'ghost danger') : App.btn('Back at work', async () => { if (await confirmBox('Make ' + p.name + ' an active employee again?', 'Yes, active', false)) { await PUT('/api/people/' + id, { status: 'active' }); toast('Active again'); done(); } }, 'ghost'));

      /* items now */
      const holdBox = h('section', null, h('div', { class: 'sec-h' }, h('h3', null, left ? 'Items still with the person' : 'Items now with the person'), h('span', { class: 'cnt' }, p.holdings.length || '')),
        p.holdings.length ? h('div', { class: 'gridwrap' }, h('table', { class: 'grid' }, h('thead', null, h('tr', null, ['Item', 'Serial / tag', 'Since', ''].map((x) => h('th', null, x)))),
          h('tbody', null, p.holdings.map((x) => h('tr', null,
            h('td', null, h('button', { class: 'lnk', type: 'button', onclick: () => App.openAsset(x.asset_id) }, x.code + '  ' + App.kindLabel(x.kind) + (x.name ? ' · ' + x.name : '') + (x.qty > 1 ? '  x' + x.qty : '')), x.status !== 'issued' ? h('span', { class: 'sub' }, lbl(App.vocab().asset_status, x.status)) : null),
            h('td', { class: 'mono' }, [x.serial, x.tag].filter(Boolean).join(' / ') || '—'), h('td', { style: { whiteSpace: 'nowrap' } }, fmtD(x.since)),
            h('td', { style: { textAlign: 'right', whiteSpace: 'nowrap' } }, App.btn('Take back', () => App.returnDialog({ id: x.asset_id, code: x.code, kind: x.kind, name: x.name, tracked: x.tracked, qty: x.qty, status: x.status }, { person_id: id, after: done }), 'sm'),
              x.tracked && x.status === 'issued' && !left ? App.btn('Replace', () => App.swapDialog({ id: x.asset_id, code: x.code, kind: x.kind, name: x.name }, { plant: p.plant, after: done }), 'sm ghost') : null)))))) : h('div', { class: 'muted' }, left ? 'Nothing pending - all items are back.' : 'Nothing issued yet.'));

      /* ids */
      const accBox = h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'Mail ids, SAP user and logins'), h('span', { class: 'cnt' }, p.accounts.length || ''), h('div', { class: 'acts' }, !left ? App.btn('Add id', () => accountDialog({ person_id: id, after: done }), 'sm', 'plus') : null)),
        p.accounts.length ? h('div', { class: 'stack', style: { gap: '6px' } }, p.accounts.map((a) => h('div', { class: 'box', style: { padding: '8px 12px' } },
          h('div', { class: 'row wrap' }, App.tag(lbl(App.vocab().account_kinds, a.kind)), h('b', { class: 'mono', style: { overflowWrap: 'anywhere' } }, a.identifier),
            h('button', { class: 'iconbtn sm', type: 'button', title: 'Copy', onclick: () => App.copyText(a.identifier, 'Id copied') }, ico('copy')), h('span', { class: 'grow' }),
            App.sel([['active', 'Active'], ['locked', 'Locked'], ['deleted', 'Deleted']], a.status, async (v) => { await PUT('/api/accounts/' + a.id, { status: v }); toast('Id ' + ({ active: 'activated', locked: 'locked', deleted: 'closed' })[v]); done(); }, { class: 'sel-inline', 'aria-label': 'Status of ' + a.identifier }),
            h('button', { class: 'iconbtn sm', type: 'button', title: 'Edit', onclick: () => accountDialog({ account: a, after: done }) }, ico('edit'))),
          (a.system || a.roles || a.valid_to) ? h('div', { class: 'muted small', style: { marginTop: '2px' } }, [a.system, a.roles ? 'Roles: ' + a.roles : '', a.valid_to ? 'valid until ' + fmtD(a.valid_to) : ''].filter(Boolean).join(' · ')) : null,
          h('div', { class: 'muted small' }, 'Created ' + fmtD(a.created_on) + (a.created_by ? ' by ' + a.created_by : '') + (a.ended_on ? ' · closed ' + fmtD(a.ended_on) : ''))))) : h('div', { class: 'muted' }, 'No mail id / SAP user recorded.'));

      /* checklists */
      const flows = [['join', 'Joining checklist'], ['leave', 'Leaving checklist']];
      const stepBox = (flow, title) => {
        const list = p.steps.filter((s) => s.flow === flow);
        if (!list.length && !(flow === 'leave' ? left : !left)) return null;
        const nd = list.filter((s) => s.done).length;
        const inp = h('input', { type: 'text', placeholder: 'Add a step…', 'aria-label': 'New step' });
        const add = async () => { if (!inp.value.trim()) return; await POST('/api/people/' + id + '/steps', { text: inp.value, flow: flow }); done(); };
        inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
        return h('section', null, h('div', { class: 'sec-h' }, h('h3', null, title), h('span', { class: 'cnt' }, list.length ? nd + ' of ' + list.length + ' done' : '')),
          h('div', { class: 'steps-l' }, list.map((s) => h('label', { class: 'stp' + (s.done ? ' done' : '') },
            h('input', { type: 'checkbox', checked: !!s.done, onchange: async (e) => { await PUT('/api/steps/' + s.id, { done: e.target.checked, done_by: me() }); done(); } }),
            h('span', { class: 'grow' }, h('span', { class: 't' }, s.text), s.done && s.done_at ? h('span', { class: 'muted small', style: { display: 'block' } }, 'done ' + fmtTs(s.done_at) + (s.done_by ? ' · ' + s.done_by : '')) : null),
            h('button', { class: 'iconbtn sm', type: 'button', title: 'Remove this step', onclick: async (e) => { e.preventDefault(); await DEL('/api/steps/' + s.id); done(); } }, ico('x'))))),
          h('div', { class: 'row', style: { marginTop: '6px' } }, inp, App.btn('Add', add, 'sm')));
      };

      /* right column */
      const kv = (k, v) => (v ? [h('dt', null, k), h('dd', null, v)] : null);
      const side = h('div', { class: 'stack' },
        h('div', { class: 'box' }, h('div', { class: 'sec-h' }, h('h3', null, 'Details'), h('div', { class: 'acts' }, App.btn('Edit', () => editDialog(p, done), 'sm', 'edit'))),
          h('dl', { class: 'kv' }, kv('Mobile', p.mobile), kv('Reports to', p.reports_to), kv('Works at', p.location), kv('Type', lbl(App.vocab().person_kinds, p.kind)), kv('Employee code', p.emp_code), kv('Note', p.note))),
        h('div', { class: 'box' }, h('h3', null, 'Tickets of ' + p.name.split(' ')[0]), p.tickets.length ? p.tickets.slice(0, 10).map((t) => h('div', { class: 'row', style: { padding: '3px 0' } }, h('button', { class: 'lnk trunc', type: 'button', onclick: () => App.openTicket(t.id) }, t.code + '  ' + t.title), h('span', { class: 'grow' }), App.ticketStatus(t.status))) : h('div', { class: 'muted small' }, 'No tickets.')));
      const main = h('div', { class: 'stack', style: { gap: '22px' } }, holdBox, accBox, flows.map(([f, t]) => stepBox(f, t)));
      dr.body.replaceChildren(pending, acts, h('div', { class: 'cols2' }, main, side),
        h('section', { style: { marginTop: '26px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'Handover forms and documents'), h('span', { class: 'cnt' }, p.files.length || ''), h('div', { class: 'acts' }, App.btn('Open folder', () => POST('/api/open-folder', { kind: 'person', id: id }), 'sm ghost', 'folder'))),
          h('div', { class: 'muted small', style: { marginBottom: '6px' } }, 'Keep the signed handover slip, ID proof copy, laptop photos here.'), App.filesSection('person', id, p.files, done, { cat: 'handover' })),
        h('section', { style: { marginTop: '26px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'Full history')), App.noteBox(async (text, who) => { await POST('/api/people/' + id + '/note', { text: text, who: who || me() }); done(); }, { ph: 'Write a note about this person…', noKnown: true }), App.timeline(p.history)),
        h('section', { style: { marginTop: '28px', borderTop: '1px solid var(--line)', paddingTop: '14px' } }, App.btn('Delete this person', async () => { if (await confirmBox('Delete ' + p.name + '? Only possible when nothing was ever issued or recorded for this person. Otherwise mark as left.')) { await DEL('/api/people/' + id); dr.close(); toast('Deleted'); App.refresh(); } }, 'sm ghost danger')));
    }
    await render();
  };

  function editDialog(p, after) {
    const kinds = App.vocab().person_kinds.map((k) => [k.key, k.label]);
    const fields = [
      { k: 'name', label: 'Full name', req: true }, { k: 'emp_code', label: 'Employee code' },
      { k: 'kind', label: 'Type', t: 'select', opts: kinds }, { k: 'plant', label: 'Plant', t: 'select', opts: [['', '—']].concat(App.plants().map((x) => [x.code, x.code + ' ' + x.name])) },
      { k: 'department', label: 'Department', list: 'dl-dept' }, { k: 'designation', label: 'Designation' }, { k: 'mobile', label: 'Mobile' }, { k: 'email', label: 'Contact mail' },
      { k: 'reports_to', label: 'Reports to' }, { k: 'location', label: 'Works at' }, { k: 'joined_on', label: 'Joining date', t: 'date' }]
      .concat(p.status === 'left' ? [{ k: 'left_on', label: 'Left on', t: 'date' }] : [{ k: 'status', label: 'Status', t: 'select', opts: [['joining', 'Joining (not yet started)'], ['active', 'Working']] }])
      .concat([{ k: 'note', label: 'Note', t: 'area', wide: true }]);
    const dl = h('datalist', { id: 'dl-dept' }, (App.S.meta.departments || []).map((d) => h('option', { value: d })));
    App.formDialog({ title: 'Edit ' + p.name, cls: 'wide', fields: fields, values: p, extra: dl, onSave: async (v) => {
      if (!v.name.trim()) { toast('Name cannot be empty', 'err'); return false; }
      await PUT('/api/people/' + p.id, v); toast('Saved'); await after();
    } });
  }
})();
