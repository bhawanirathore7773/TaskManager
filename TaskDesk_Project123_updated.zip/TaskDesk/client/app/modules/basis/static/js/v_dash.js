/* Today: what needs the manager's attention, team workload, plants, recent activity. */
(function () {
  'use strict';
  const { h, ico, GET, POST, DEL, toast, fmtTs } = App;

  App.V.dashboard = async function (root) {
    const plant = App.plantFilter();
    const d = await GET('/api/dashboard?plant=' + encodeURIComponent(plant));
    const k = d.kpi;
    const today = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });
    const kp = (n, label, cls, go) => h('button', { class: 'kpi ' + (cls || ''), type: 'button', onclick: () => App.go('tickets', go || {}) }, h('b', null, n), h('span', null, label));
    const page = [h('div', { class: 'page-h' }, h('div', null, h('h1', null, 'Today'), h('div', { class: 'sub' }, today + ' · ' + (plant ? App.plantText(plant) : 'all plants'))), h('span', { class: 'grow' }),
      App.btn('New ticket', () => App.newTicket(), 'primary', 'plus'), App.btn('New joiner', () => App.newJoiner(), '', 'people'))];

    if (d.empty) page.push(onboarding(d));
    else {
      page.push(h('div', { class: 'kpis' },
        kp(k.open, 'Open tickets', '', { filter: 'open' }), kp(k.overdue, 'Overdue', k.overdue ? 'hot' : '', { filter: 'overdue' }), kp(k.unassigned, 'Not assigned', k.unassigned ? 'warm' : '', { filter: 'unassigned' }),
        kp(k.to_check, 'Done - check & close', k.to_check ? 'warm' : '', { filter: 'tocheck' }), kp(k.waiting, 'Waiting', '', { filter: 'waiting' }), kp(k.critical, 'Critical open', k.critical ? 'hot' : '', { filter: 'critical' }),
        h('div', { class: 'kpi', style: { cursor: 'default' } }, h('b', null, k.closed_7), h('span', null, 'Closed in 7 days')),
        h('div', { class: 'kpi', style: { cursor: 'default' }, title: 'Average time from received to closed, tickets closed in the last 30 days' }, h('b', null, k.avg_tat_h == null ? '—' : App.ageText(k.avg_tat_h)), h('span', null, 'Average time to close')),
        h('div', { class: 'kpi', style: { cursor: 'default' }, title: 'Closed within the due time, last 30 days' }, h('b', null, k.sla_pct == null ? '—' : k.sla_pct + '%'), h('span', null, 'Closed on time'))));
      const left = d.attention.length ? d.attention.map(group) : [h('div', { class: 'box good' }, h('b', null, 'All clear.'), h('div', null, 'Nothing is overdue, nothing is waiting for your check, no leaver is holding items.'))];
      const rail = h('div', { class: 'rail' },
        h('section', null, h('div', { class: 'sect-t' }, h('h2', null, 'Team workload'), h('span', null, 'open tickets')), h('div', { class: 'panel' }, h('div', { class: 'panel-b', style: { paddingTop: '6px', paddingBottom: '6px' } }, d.team_empty ? h('div', { class: 'muted' }, 'No team members yet. ', h('button', { class: 'lnk', type: 'button', onclick: () => App.go('team') }, 'Add your team')) : load(d)))),
        h('section', null, h('div', { class: 'sect-t' }, h('h2', null, 'Plants')), h('div', { class: 'panel' }, h('div', { class: 'panel-b', style: { paddingTop: '6px', paddingBottom: '6px' } }, d.by_plant.map((p) => h('div', { class: 'load-row', style: { gridTemplateColumns: 'minmax(110px,1fr) auto auto' } },
          h('button', { class: 'lnk', type: 'button', onclick: () => { App.S.plant = p.code; App.LS.set('plant', p.code); App.drawPlants(); App.render(); } }, p.code + ' ' + p.name.replace(/ Plant$/, '')),
          h('span', null, p.open + ' open'), p.overdue ? h('span', { class: 'due-over' }, p.overdue + ' overdue') : h('span', { class: 'muted' }, '')))))),
        h('section', null, h('div', { class: 'sect-t' }, h('h2', null, 'Recent activity')), h('div', { class: 'panel' }, h('div', { class: 'panel-b' }, App.timeline(d.recent)))));
      page.push(h('div', { class: 'dash' }, h('div', null, h('div', { class: 'sect-t' }, h('h2', null, 'Needs your attention'), h('span', null, d.attention.length ? d.attention.length + ' topics' : '')), left), rail));
    }
    root.replaceChildren(page);
  };

  function group(g) {
    return h('div', { class: 'attn ' + g.sev },
      h('div', { class: 'attn-h' }, h('h3', null, g.title), h('span', { class: 'badge' }, g.count), h('span', { class: 'grow' }), g.go ? h('button', { class: 'lnk small', type: 'button', onclick: () => App.follow(g.go.id ? { view: g.go.view } : g.go) }, 'See all') : null),
      g.items.map((i) => h('div', { class: 'attn-i', role: 'button', tabindex: 0, onclick: () => App.follow(i.go), onkeydown: (e) => { if (e.key === 'Enter') App.follow(i.go); } },
        h('div', { style: { minWidth: 0 } }, h('span', { class: 'ttl trunc' }, i.label), h('span', { class: 'sub trunc' }, i.sub)), App.ico('chevron'))),
      g.count > g.items.length ? h('div', { class: 'attn-i', style: { cursor: 'default' } }, h('span', { class: 'muted small' }, '+ ' + (g.count - g.items.length) + ' more')) : null);
  }

  function load(d) {
    const max = Math.max(1, ...d.load.map((x) => x.open));
    return d.load.map((m) => h('div', { class: 'load-row' }, h('button', { class: 'lnk trunc', type: 'button', onclick: () => App.go('tickets', { assignee: String(m.id), filter: 'open' }) }, m.name, h('span', { class: 'sub' }, [m.role, m.plant].filter(Boolean).join(' · '))),
      App.ico ? h('div', { class: 'bar', style: { '--c': m.overdue ? 'var(--c-overdue)' : 'var(--accent)' } }, h('i', { style: { width: Math.round(100 * m.open / max) + '%' } })) : null,
      h('span', { style: { whiteSpace: 'nowrap', fontSize: '12.5px' } }, m.open + ' open' + (m.overdue ? ' · ' : ''), m.overdue ? h('span', { class: 'due-over' }, m.overdue + ' late') : null, m.to_check ? h('span', { class: 'muted' }, ' · ' + m.to_check + ' to check') : null)));
  }

  function onboarding(d) {
    const step = (n, title, text, act) => h('div', { class: 'box', style: { display: 'flex', gap: '14px', alignItems: 'flex-start' } }, h('div', { class: 'badge soft', style: { minWidth: '26px', height: '26px', lineHeight: '26px', borderRadius: '50%', fontSize: '13px' } }, n),
      h('div', { class: 'grow' }, h('b', null, title), h('div', { class: 'muted' }, text)), act);
    return h('div', { class: 'stack', style: { maxWidth: '760px' } },
      h('div', { class: 'note-box info' }, h('b', null, 'Welcome, ' + (App.settings().manager || '') + '. '), 'Everything for the three plants (1100, 1200, 1600) is managed here: IT tickets, stock and laptops, new joiners and leavers, SAP user ids, transports, daily checks. Start with these three steps - they take ten minutes.'),
      step(1, 'Add your team', 'The people who do the work in each plant. You can then give them work and see who has what.', App.btn('Add team members', () => App.go('team'), 'primary')),
      step(2, 'Put your stock in', 'Laptops, PCs, monitors, printers, mouse, keyboards. One form can add many items at once.', App.btn('Add items to stock', () => App.addStock(), 'primary')),
      step(3, 'Add the employees who already use IT items', 'So that every laptop shows who has it. New joiners then take two minutes.', App.btn('Add an employee', () => App.newJoiner(), 'primary')),
      h('div', { class: 'hint-box' }, 'Want to look around first? ', h('button', { class: 'lnk', type: 'button', onclick: async () => { await POST('/api/demo'); toast('Demo data loaded - remove it in Settings > Data'); App.refresh(); } }, 'Load demo data'), ' (it is marked and can be removed with one click).'));
  }
})();
