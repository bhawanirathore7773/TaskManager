/* Core helpers: DOM builder, API, formatting, small UI parts, modal. */
(function () {
  'use strict';
  const App = window.App = { S: { meta: null, view: 'dashboard', plant: '' }, V: {}, D: {}, cache: {} };
  const NS = 'http://www.w3.org/2000/svg';

  /* ---------- DOM ---------- */
  // The native append() / replaceChildren() turn null into the text "null" and arrays into "[object ...]".
  // This app passes lists and optional (null) children everywhere, so make both calls flatten and skip empty values.
  (function () {
    const origAppend = Element.prototype.append, origReplace = Element.prototype.replaceChildren;
    const clean = (kids) => kids.flat(Infinity).filter((k) => k != null && k !== false && k !== true).map((k) => (k.nodeType ? k : document.createTextNode(String(k))));
    Element.prototype.append = function () { return origAppend.apply(this, clean(Array.from(arguments))); };
    Element.prototype.replaceChildren = function () { return origReplace.apply(this, clean(Array.from(arguments))); };
  })();
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  function add(el, kids) {
    for (const k of kids.flat(Infinity)) {
      if (k == null || k === false || k === true) continue;
      el.append(k.nodeType ? k : document.createTextNode(String(k)));
    }
  }
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    let later = null;
    if (attrs) {
      for (const k in attrs) {
        const v = attrs[k];
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'style') {
          if (typeof v === 'object') for (const p in v) { if (p.indexOf('-') >= 0) el.style.setProperty(p, v[p]); else el.style[p] = v[p]; }
          else el.setAttribute('style', v);
        } else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'value') later = v;
        else if (k === 'checked' || k === 'disabled' || k === 'selected' || k === 'multiple' || k === 'readOnly') el[k] = !!v;
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    add(el, kids);
    if (later !== null) el.value = later;
    return el;
  }
  const ICONS = {
    dashboard: 'M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z', ticket: 'M3 9a2 2 0 0 0 0 6v3a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-3a2 2 0 0 1 0-6V6a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1z M13 5v14',
    people: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2 M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M22 21v-2a4 4 0 0 0-3-3.9 M16 3.1a4 4 0 0 1 0 7.8',
    box: 'M21 8l-9-5-9 5v8l9 5 9-5z M3 8l9 5 9-5 M12 13v8', laptop: 'M4 5h16v11H4z M2 19h20', transport: 'M5 12h14 M13 6l6 6-6 6 M3 6v12',
    team: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M4 21a8 8 0 0 1 16 0', checks: 'M9 11l3 3 8-8 M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h9',
    cart: 'M6 6h15l-1.5 9h-12z M6 6L5 3H2 M9 20h.01 M18 20h.01', report: 'M5 3h14v18H5z M9 8h6 M9 12h6 M9 16h4', settings: 'M4 21v-7 M4 10V3 M12 21v-9 M12 8V3 M20 21v-5 M20 12V3 M1 14h6 M9 8h6 M17 16h6',
    plus: 'M12 5v14 M5 12h14', search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.3-4.3', x: 'M18 6L6 18 M6 6l12 12', check: 'M20 6L9 17l-5-5',
    folder: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z', upload: 'M12 16V4 M7 9l5-5 5 5 M4 20h16', download: 'M12 4v12 M7 11l5 5 5-5 M4 20h16',
    trash: 'M3 6h18 M8 6V4h8v2 M6 6l1 14h10l1-14', copy: 'M9 9h11v11H9z M5 15H4V4h11v1', file: 'M6 2h8l6 6v14H6z M14 2v6h6', eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    moon: 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z', sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M12 2v2 M12 20v2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M2 12h2 M20 12h2 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4',
    edit: 'M12 20h9 M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z', alert: 'M12 9v4 M12 17h.01 M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z',
    print: 'M6 9V2h12v7 M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2 M6 14h12v8H6z', send: 'M22 2L11 13 M22 2l-7 20-4-9-9-4z',
    swap: 'M7 4L3 8l4 4 M3 8h14 M17 20l4-4-4-4 M21 16H7', key: 'M21 2l-2 2 M15.5 7.5l3 3 M7.5 11.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9z M10.7 12.3L19 4',
    chevron: 'M9 6l6 6-6 6', clock: 'M12 7v5l3 2 M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z', phone: 'M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z'
  };
  function ico(name, cls) {
    const s = document.createElementNS(NS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'ico' + (cls ? ' ' + cls : '')); s.setAttribute('aria-hidden', 'true');
    String(ICONS[name] || '').split(' M').forEach((d, i) => { const p = document.createElementNS(NS, 'path'); p.setAttribute('d', (i ? 'M' : '') + d); s.appendChild(p); });
    return s;
  }
  const debounce = (fn, ms) => { let t; return function () { const a = arguments; clearTimeout(t); t = setTimeout(() => fn.apply(null, a), ms || 400); }; };
  const LS = {
    get(k, d) { try { const v = localStorage.getItem('tm_' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('tm_' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };

  /* ---------- API ---------- */
  async function api(method, url, body) {
    const o = { method: method, headers: { 'X-TM': '1' } };
    if (body instanceof Blob) o.body = body;
    else if (body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
    let r;
    try { r = await fetch(url, o); } catch (e) { toast('Cannot reach the local server. Start the app again from the desktop icon.', 'err'); throw e; }
    const txt = await r.text();
    let data = null;
    try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = null; }
    if (!r.ok) { const msg = (data && data.error) || ('Error ' + r.status); toast(msg, 'err'); throw new Error(msg); }
    if (method !== 'GET') App.cache = {};
    return data;
  }
  const GET = (u) => api('GET', u), POST = (u, b) => api('POST', u, b || {}), PUT = (u, b) => api('PUT', u, b || {}), DEL = (u) => api('DELETE', u);
  function uploadFile(kind, id, file, category, note) {
    const q = new URLSearchParams({ kind: kind, id: id, name: file.name || 'file', category: category || 'auto', note: note || '' });
    return api('POST', '/api/files?' + q.toString(), file);
  }
  // cached list loads: App.load('people') -> array.  Any write (POST/PUT/DELETE) clears the cache.
  const LOADERS = { tickets: '/api/tickets', people: '/api/people', assets: '/api/assets', transports: '/api/transports', purchases: '/api/purchases', accounts: '/api/accounts',
    team: '/api/team', routines: '/api/routines', renewals: '/api/renewals' };
  function load(name) {
    if (!App.cache[name]) App.cache[name] = GET(LOADERS[name]).catch((e) => { delete App.cache[name]; throw e; });
    return App.cache[name];
  }

  /* ---------- toast / copy ---------- */
  function toast(msg, kind) {
    const t = h('div', { class: 'toast' + (kind === 'err' ? ' err' : ''), role: 'status' }, msg);
    $('#toasts').append(t);
    setTimeout(() => t.remove(), kind === 'err' ? 6000 : 2600);
  }
  function copyText(text, label) {
    const done = () => toast((label || 'Copied') + ' to clipboard');
    if (navigator.clipboard && window.isSecureContext !== false) navigator.clipboard.writeText(text).then(done, () => fallbackCopy(text, done));
    else fallbackCopy(text, done);
  }
  function fallbackCopy(text, done) {
    const ta = h('textarea', { style: { position: 'fixed', left: '-999px' } }); ta.value = text; document.body.append(ta); ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { toast('Copy failed', 'err'); } ta.remove();
  }

  /* ---------- formatting ---------- */
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const todayIso = () => iso(new Date());
  function pd(s) { if (!s) return null; const p = String(s).slice(0, 10).split('-').map(Number); return new Date(p[0], p[1] - 1, p[2]); }
  const addDays = (d, n) => { const x = new Date(d.getTime()); x.setDate(x.getDate() + n); return x; };
  const daysBetween = (a, b) => Math.round((pd(iso(b)) - pd(iso(a))) / 86400000);
  function fmtD(s, withYear) {
    const d = pd(s); if (!d) return '—';
    const o = { day: '2-digit', month: 'short' };
    if (withYear || d.getFullYear() !== new Date().getFullYear()) o.year = 'numeric';
    return d.toLocaleDateString('en-GB', o);
  }
  function fmtTs(ts) {
    if (!ts) return ''; const d = new Date(String(ts).replace(' ', 'T'));
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + ', ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  const fmtH = (v) => (v == null || v === '' ? '—' : (Math.round(v * 10) / 10) + ' h');
  function fmtSize(n) { if (n < 1024) return n + ' B'; if (n < 1048576) return (n / 1024).toFixed(0) + ' KB'; return (n / 1048576).toFixed(1) + ' MB'; }
  const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : '');

  /* ---------- form parts ---------- */
  const fld = (label, input, hint) => h('div', { class: 'fld' }, h('label', null, label), input, hint ? h('span', { class: 'hint' }, hint) : null);
  function sel(options, value, onChange, attrs) {
    const el = h('select', attrs || null, options.map((o) => { const v = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o; return h('option', { value: v }, l); }));
    el.value = value == null ? '' : value;
    if (onChange) el.addEventListener('change', () => onChange(el.value));
    return el;
  }
  function inp(value, onChange, attrs) {
    const el = h('input', Object.assign({ type: 'text' }, attrs || {}));
    el.value = value == null ? '' : value;
    if (onChange) el.addEventListener('change', () => onChange(el.value));
    return el;
  }
  function area(value, onChange, attrs) {
    const el = h('textarea', attrs || null); el.value = value == null ? '' : value;
    if (onChange) el.addEventListener('change', () => onChange(el.value));
    return el;
  }

  /* ---------- modal ---------- */
  function modal(opts) {
    const body = h('div', { class: 'md-b' }, opts.body);
    const foot = opts.actions && opts.actions.length ? h('div', { class: 'md-f' }, opts.foot || null, h('span', { class: 'grow' }), opts.actions.map((a) =>
      h('button', { class: 'btn ' + (a.cls || ''), type: 'button', onclick: () => { if (a.onClick) { const r = a.onClick(api2); if (r === false) return; } if (a.close !== false) dlg.close(); } }, a.label))) : null;
    const dlg = h('dialog', { class: opts.cls || '' },
      h('div', { class: 'md-h' }, h('h2', null, opts.title || ''), h('span', { class: 'grow' }), h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Close', onclick: () => dlg.close() }, ico('x'))), body, foot);
    const api2 = { el: dlg, body: body, close: () => dlg.close() };
    dlg.addEventListener('close', () => { dlg.remove(); if (opts.onClose) opts.onClose(); });
    dlg.addEventListener('mousedown', (e) => { if (e.target === dlg && opts.dismiss !== false) dlg.dataset.down = '1'; });
    dlg.addEventListener('click', (e) => { if (e.target === dlg && dlg.dataset.down) dlg.close(); delete dlg.dataset.down; });
    document.body.append(dlg);
    dlg.showModal();
    return api2;
  }
  function confirmBox(message, okLabel, danger) {
    return new Promise((resolve) => {
      let ans = false;
      modal({ title: 'Please confirm', body: h('p', null, message), onClose: () => resolve(ans),
        actions: [{ label: 'Cancel', cls: '' }, { label: okLabel || 'Delete', cls: danger === false ? 'primary' : 'danger', onClick: () => { ans = true; } }] });
    });
  }


  Object.assign(App, { $, $$, h, add, ico, debounce, LS, api, GET, POST, PUT, DEL, uploadFile, load, toast, copyText, iso, pd, todayIso, addDays, daysBetween, fmtD, fmtTs, fmtH, fmtSize, cap,
    fld, sel, inp, area, modal, confirmBox });
})();
