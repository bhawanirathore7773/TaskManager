/* Reports for the IT head (HOD): one page, any period, printable, WhatsApp summary, Excel. */
(function () {
  'use strict';
  const { h, ico, GET, toast, fmtD, load } = App;
  const iso = App.iso;

  function periods() {
    const t = new Date(), d = (n) => App.addDays(t, n);
    const monday = d(-((t.getDay() + 6) % 7));
    const m1 = new Date(t.getFullYear(), t.getMonth(), 1), pm1 = new Date(t.getFullYear(), t.getMonth() - 1, 1), pm2 = new Date(t.getFullYear(), t.getMonth(), 0);
    return [['week', 'This week', iso(monday), iso(t)], ['7', 'Last 7 days', iso(d(-6)), iso(t)], ['month', 'This month', iso(m1), iso(t)], ['pmonth', 'Last month', iso(pm1), iso(pm2)], ['30', 'Last 30 days', iso(d(-29)), iso(t)]];
  }

  App.V.reports = async function (root, params) {
    const st = App.S.rp = App.S.rp || { key: '7', from: '', to: '' };
    if (params.key) st.key = params.key;
    const P = periods();
    if (st.key !== 'custom') { const p = P.find((x) => x[0] === st.key) || P[1]; st.from = p[2]; st.to = p[3]; }
    const plant = App.plantFilter();
    const r = await GET('/api/report?from=' + st.from + '&to=' + st.to + '&plant=' + encodeURIComponent(plant));
    const seg = h('div', { class: 'seg' }, P.map((p) => h('button', { type: 'button', class: st.key === p[0] ? 'on' : '', onclick: () => { st.key = p[0]; App.render(); } }, p[1])), h('button', { type: 'button', class: st.key === 'custom' ? 'on' : '', onclick: () => { st.key = 'custom'; App.render(); } }, 'Choose dates'));
    const from = h('input', { type: 'date', value: st.from, 'aria-label': 'From' }), to = h('input', { type: 'date', value: st.to, 'aria-label': 'To' });
    const go = () => { if (from.value && to.value) { st.key = 'custom'; st.from = from.value; st.to = to.value; App.render(); } };
    from.addEventListener('change', go); to.addEventListener('change', go);
    root.replaceChildren(
      h('div', { class: 'page-h' }, h('div', null, h('h1', null, 'Reports'), h('div', { class: 'sub' }, 'One page for your IT head: what came in, what was closed, how fast, who did it, stock, transports and checks.')), h('span', { class: 'grow' }),
        App.btn('Copy WhatsApp summary', () => App.copyText(summary(r), 'Summary copied'), '', 'copy'), App.btn('Print / save as PDF', () => App.printNode(sheet(r)), '', 'print'), h('a', { class: 'btn', href: '/api/export.xlsx', download: '' }, ico('download'), 'Excel (all data)')),
      h('div', { class: 'tools' }, seg, st.key === 'custom' ? h('span', { class: 'row' }, from, 'to', to) : h('span', { class: 'muted small' }, fmtD(st.from, true) + ' to ' + fmtD(st.to, true) + ' · ' + r.plant_label)),
      sheet(r));
  };

  const T = (head, rows, o) => {
    o = o || {};
    return h('table', null, h('thead', null, h('tr', null, head.map((x, i) => h('th', { class: (o.num || []).indexOf(i) >= 0 ? 'n' : '' }, x)))),
      h('tbody', null, rows.length ? rows.map((row) => h('tr', null, row.map((c, i) => h('td', { class: (o.num || []).indexOf(i) >= 0 ? 'n' : '' }, c == null ? '' : c)))) : h('tr', null, h('td', { colspan: head.length, class: 'muted' }, o.empty || 'Nothing in this period.'))));
  };
  const kp = (n, l) => h('div', null, h('b', null, n == null ? '—' : n), h('span', { class: 'muted' }, l));
  const hrs = (v) => (v == null ? '—' : App.ageText(v));

  function sheet(r) {
    const t = r.tickets, S = App.settings();
    return h('div', { class: 'report-sheet' },
      h('h1', null, 'IT & SAP BASIS report'), h('div', { class: 'muted' }, [r.company, r.plant_label, fmtD(r.from, true) + ' to ' + fmtD(r.to, true)].filter(Boolean).join(' · ')),
      h('div', { class: 'muted' }, 'Prepared by ' + (r.manager || '—') + (r.hod ? ' for ' + r.hod : '')),
      h('div', { class: 'kp' }, kp(t.opened, 'tickets received'), kp(t.closed, 'closed'), kp(t.open_now, 'open now'), kp(t.overdue_now, 'overdue now'), kp(t.to_check, 'done, to check'), kp(hrs(t.avg_tat_h), 'average time to close'), kp(t.sla_pct == null ? null : t.sla_pct + '%', 'closed on time')),
      h('h2', null, 'Tickets by type'), T(['Type', 'Received'], t.by_category.map((c) => [c.label, c.n]), { num: [1] }),
      h('h2', null, 'Plants'), T(['Plant', 'Received', 'Closed', 'Open now', 'Overdue now'], r.by_plant.map((p) => [p.code + ' ' + p.name, p.opened, p.closed, p.open_now, p.overdue_now]), { num: [1, 2, 3, 4] }),
      h('h2', null, 'Team'), T(['Name', 'Given', 'Closed', 'Open now', 'Average time to close'], r.by_member.map((m) => [m.name, m.assigned, m.closed, m.open_now, hrs(m.avg_tat_h)]), { num: [1, 2, 3, 4], empty: 'No tickets were given to anyone in this period.' }),
      h('h2', null, 'New joiners and leavers'),
      T(['New joiners', 'Plant', 'Department', 'Joined', 'Setup open'], r.people.joined.map((p) => [p.name, p.plant, p.department, fmtD(p.on), p.steps_open ? p.steps_open + ' step(s) open' : 'complete']), { empty: 'No new joiner.' }),
      T(['Leavers', 'Plant', 'Left on', 'Items / ids returned'], r.people.left.map((p) => [p.name, p.plant, fmtD(p.on), p.pending ? 'PENDING' : 'all returned']), { empty: 'No leaver.' }),
      h('h2', null, 'Stock'), h('div', null, 'In this period: ' + r.stock.moves.issued + ' item(s) issued, ' + r.stock.moves.returned + ' taken back, ' + r.stock.moves.scrapped + ' scrapped.'),
      T(['Type', 'In stock', 'Issued', 'In repair', 'Minimum', 'On order'], r.stock.summary.map((k) => [k.label, k.in_stock, k.issued + (k.deployed || 0), k.repair, k.min || '', k.on_order || '']), { num: [1, 2, 3, 4, 5], empty: 'No stock recorded.' }),
      h('h2', null, 'Transports and purchases'), T(['', 'Count'], [['Moved to production in this period', r.transports.moved_prd], ['Requested in this period', r.transports.requested], ['Waiting (asked, QAS, approval, hold)', r.transports.pending], ['Failed', r.transports.failed],
        ['Purchases requested in this period', r.purchases.requested], ['Purchases received in this period', r.purchases.received], ['Purchases still open', r.purchases.open]], { num: [1] }),
      h('h2', null, 'Daily checks'), h('div', null, r.checks.expected ? r.checks.done + ' of ' + r.checks.expected + ' checks done (' + r.checks.pct + '%), ' + r.checks.problems + ' with a problem.' : 'No daily checks set up.'),
      r.renewals.length ? [h('h2', null, 'Renewals due'), T(['What', 'Expires', 'Left'], r.renewals.map((x) => [x.title, fmtD(x.expires_on, true), x.days_left < 0 ? 'expired' : x.days_left + ' days']))] : null,
      r.overdue_list.length ? [h('h2', null, 'Overdue tickets'), T(['Ticket', 'Problem', 'Given to', 'Due'], r.overdue_list.map((x) => [x.code, x.title, x.assignee || 'nobody', x.due_at]))] : null);
  }

  function summary(r) {
    const t = r.tickets, L = [];
    L.push('*IT / BASIS report* - ' + r.plant_label);
    L.push(fmtD(r.from, true) + ' to ' + fmtD(r.to, true));
    L.push('');
    L.push('Tickets: ' + t.opened + ' received, ' + t.closed + ' closed, ' + t.open_now + ' open (' + t.overdue_now + ' overdue, ' + t.to_check + ' to check)');
    if (t.avg_tat_h != null) L.push('Average time to close: ' + App.ageText(t.avg_tat_h) + (t.sla_pct != null ? ', ' + t.sla_pct + '% on time' : ''));
    if (r.by_member.length) L.push('Team: ' + r.by_member.map((m) => m.name + ' ' + m.closed + ' closed').join(', '));
    if (r.people.joined.length || r.people.left.length) L.push('Joiners: ' + r.people.joined.length + ', leavers: ' + r.people.left.length + (r.people.left.some((p) => p.pending) ? ' (items pending)' : ''));
    L.push('Stock: ' + r.stock.moves.issued + ' issued, ' + r.stock.moves.returned + ' returned');
    const low = r.stock.summary.filter((k) => k.low);
    if (low.length) L.push('Low stock: ' + low.map((k) => k.label + ' ' + k.in_stock).join(', '));
    L.push('Transports: ' + r.transports.moved_prd + ' moved to PRD, ' + r.transports.pending + ' waiting' + (r.transports.failed ? ', ' + r.transports.failed + ' failed' : ''));
    if (r.checks.expected) L.push('Daily checks: ' + r.checks.pct + '% done, ' + r.checks.problems + ' problem(s)');
    if (r.renewals.length) L.push('Renew soon: ' + r.renewals.map((x) => x.title + (x.days_left < 0 ? ' (expired)' : ' (' + x.days_left + ' d)')).join(', '));
    L.push('');
    L.push('- ' + (r.manager || ''));
    return L.join('\n');
  }
})();
