/* Settings: names, plants, time limits, minimum stock, rules, checklists, data (backup, Excel, demo). */
(function () {
  'use strict';
  const { h, ico, GET, POST, PUT, toast, confirmBox, fmtSize } = App;
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  App.V.settings = async function (root) {
    const S = await GET('/api/settings');
    const inp = (v, ph, attrs) => h('input', Object.assign({ type: 'text', value: v == null ? '' : v, placeholder: ph || '', autocomplete: 'off' }, attrs || {}));
    const num = (v, min, max) => h('input', { type: 'number', min: min || 0, max: max || null, value: v == null ? '' : v, style: { maxWidth: '120px' } });
    const manager = inp(S.manager, 'Your name'), hod = inp(S.hod, 'Name of the IT head'), company = inp(S.company, 'Company name');
    const plantRows = h('div', { class: 'stack', style: { gap: '6px' } });
    let plants = S.plants.map((p) => ({ code: p.code, name: p.name }));
    function drawPlants() {
      plantRows.replaceChildren(plants.map((p, i) => h('div', { class: 'row' },
        h('input', { type: 'text', value: p.code, style: { maxWidth: '110px' }, placeholder: 'Code', 'aria-label': 'Plant code', oninput: (e) => { p.code = e.target.value; } }),
        h('input', { type: 'text', value: p.name, placeholder: 'Plant name', 'aria-label': 'Plant name', class: 'grow', oninput: (e) => { p.name = e.target.value; } }),
        h('button', { class: 'iconbtn', type: 'button', title: 'Remove', 'aria-label': 'Remove plant', onclick: () => { if (plants.length > 1) { plants.splice(i, 1); drawPlants(); } else toast('Keep at least one plant', 'err'); } }, ico('x')))),
      App.btn('Add a plant', () => { plants.push({ code: '', name: '' }); drawPlants(); }, 'sm', 'plus'));
    }
    drawPlants();
    const sla = {}; ['critical', 'high', 'medium', 'low'].forEach((k) => { sla[k] = num(S['sla_' + k], 1, 2000); });
    const mins = {};
    const minBox = h('div', { class: 'grid3' }, App.vocab().asset_kinds.map((k) => { mins[k.key] = num((S.min_stock || {})[k.key] || '', 0, 9999); return App.fld(k.label, mins[k.key]); }));
    const approval = h('input', { type: 'checkbox', checked: S.tr_need_approval === '1' });
    const renew = num(S.renew_days, 1, 365), wa = inp(S.wa_prefix, '91', { style: 'max-width:100px' });
    const wd = (S.work_days || '0,1,2,3,4,5').split(',');
    const wdBoxes = days.map((d, i) => h('input', { type: 'checkbox', checked: wd.indexOf(String(i)) >= 0 }));
    const tj = h('textarea', { style: { minHeight: '170px' } }, S.tpl_join || ''), tl = h('textarea', { style: { minHeight: '150px' } }, S.tpl_leave || '');
    const sec = (title, sub, body) => h('section', { class: 'box', style: { marginBottom: '14px' } }, h('h3', null, title), sub ? h('div', { class: 'muted small', style: { marginBottom: '10px' } }, sub) : null, body);

    async function save() {
      const body = {
        manager: manager.value, hod: hod.value, company: company.value, plants: plants.filter((p) => p.code.trim()),
        sla_critical: sla.critical.value, sla_high: sla.high.value, sla_medium: sla.medium.value, sla_low: sla.low.value,
        min_stock: Object.fromEntries(Object.keys(mins).filter((k) => +mins[k].value > 0).map((k) => [k, +mins[k].value])),
        tr_need_approval: approval.checked ? '1' : '0', renew_days: renew.value || '30', wa_prefix: wa.value,
        work_days: days.map((d, i) => (wdBoxes[i].checked ? i : null)).filter((x) => x !== null).join(','), tpl_join: tj.value, tpl_leave: tl.value
      };
      if (!body.work_days) { toast('Choose at least one working day', 'err'); return; }
      await PUT('/api/settings', body);
      await App.loadMeta();
      if (!App.plants().some((p) => p.code === App.S.plant)) App.S.plant = '';
      App.drawPlants(); toast('Settings saved'); App.render();
    }

    const dataBox = h('div', { class: 'stack' });
    async function drawData() {
      const backups = await GET('/api/backups');
      dataBox.replaceChildren(
        h('div', { class: 'muted small' }, 'All data is kept on this computer in: ', h('span', { class: 'mono' }, App.S.meta.data_dir)),
        h('div', { class: 'acts' }, App.btn('Open data folder', () => POST('/api/open-data-folder'), '', 'folder'), App.btn('Back up now', async () => { const r = await POST('/api/backup'); toast('Backup saved: ' + r.file); drawData(); }, '', 'download'),
          h('a', { class: 'btn', href: '/api/export.xlsx', download: '' }, ico('download'), 'Excel with all data')),
        h('div', { class: 'muted small' }, backups.length ? 'Last backups: ' + backups.slice(0, 5).map((b) => b.name.replace('taskmanager_', '').replace('.db', '') + ' (' + fmtSize(b.size) + ')').join(' · ') : 'A backup is made automatically once every day.'),
        h('div', { class: 'acts', style: { marginTop: '6px' } }, App.btn('Load demo data', async () => { const r = await POST('/api/demo'); toast(r.added ? 'Demo data loaded' : 'Demo data is already there'); App.refresh(); }, 'ghost'),
          App.btn('Remove demo data', async () => { if (await confirmBox('Remove all demo tickets, people, items and checks? Your own records stay.', 'Remove demo data')) { await App.DEL('/api/demo'); toast('Demo data removed'); App.refresh(); } }, 'ghost danger')));
    }
    root.replaceChildren(
      h('div', { class: 'page-h' }, h('div', null, h('h1', null, 'Settings'), h('div', { class: 'sub' }, 'Names, plants, time limits and rules. Change anything here - old records are not touched.')), h('span', { class: 'grow' }), App.btn('Save settings', save, 'primary', 'check')),
      h('div', { style: { maxWidth: '820px' } },
        sec('Names', 'Printed on messages, handover slips and reports.', h('div', { class: 'grid3' }, App.fld('Basis lead (you)', manager), App.fld('IT head (HOD)', hod), App.fld('Company', company))),
        sec('Plants', 'Every ticket, person and item belongs to a plant. The plant switch at the top uses this list.', plantRows),
        sec('Time to finish', 'Hours given to the team for a ticket, by priority. A new ticket gets its "finish by" time from this; late ones turn red.', h('div', { class: 'grid4' }, App.fld('Critical (hours)', sla.critical), App.fld('High', sla.high), App.fld('Medium', sla.medium), App.fld('Low', sla.low))),
        sec('Minimum stock', 'You are warned on Today when the stock of a type falls below the number. Leave empty for no warning.', minBox),
        sec('Rules', null, h('div', { class: 'stack' }, h('label', { class: 'row' }, approval, 'A transport needs an approval before it can be moved to production'),
          h('div', { class: 'grid3' }, App.fld('Remind before renewals (days)', renew), App.fld('WhatsApp country code', wa, 'Used when a mobile number has no country code.')),
          h('div', null, h('div', { class: 'lbl' }, 'Working days (daily checks are due only on these)'), h('div', { class: 'row wrap', style: { marginTop: '4px' } }, days.map((d, i) => h('label', { class: 'row' }, wdBoxes[i], d.slice(0, 3))))))),
        sec('Joining checklist', 'One step per line. Every new joiner gets these steps; they tick themselves when the item or id is given.', tj),
        sec('Leaving checklist', 'One step per line. Created when you mark someone as left.', tl),
        sec('Data and backup', null, dataBox),
        h('div', { class: 'acts' }, App.btn('Save settings', save, 'primary', 'check'))));
    drawData();
  };
})();
