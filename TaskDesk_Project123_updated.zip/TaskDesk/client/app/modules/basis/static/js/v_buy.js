/* Buy & renew: purchase requests (approve, order, receive into stock), AMC / licence renewals, warranty ending soon. */
(function () {
  'use strict';
  const { h, ico, GET, POST, PUT, DEL, toast, modal, confirmBox, fmtD, load } = App;
  const me = () => App.settings().manager || '';
  const lbl = (list, key) => App.label(list, key);
  const rupee = (n) => (n == null || n === '' ? '' : '₹ ' + Number(n).toLocaleString('en-IN'));
  const buyChip = (b) => App.chip(lbl(App.vocab().buy_status, b.status) + (b.late ? ' - late' : ''), { requested: 'var(--c-warning)', approved: 'var(--accent)', ordered: b.late ? 'var(--c-overdue)' : 'var(--accent)', received: 'var(--c-ok)', cancelled: 'var(--ink-3)' }[b.status]);

  App.V.buy = async function (root, params) {
    const st = App.S.by = App.S.by || { tab: 'buy', filter: 'open', q: '' };
    if (params.tab) st.tab = params.tab;
    if (params.filter) st.filter = params.filter;
    const [buys, ren] = await Promise.all([load('purchases'), load('renewals')]);
    const plant = App.plantFilter();
    const pb = buys.filter((b) => !plant || !b.plant || b.plant === plant);
    const pr = ren.renewals.filter((r) => !plant || !r.plant || r.plant === plant);
    const pw = ren.warranties.filter((w) => !plant || !w.plant || w.plant === plant);
    const tabs = h('div', { class: 'tabs' }), head = h('div', { class: 'page-h' }), tools = h('div', { class: 'tools' }), holder = h('div');
    const dueN = pr.filter((r) => r.state === 'expired' || r.state === 'due').length;
    function draw() {
      tabs.replaceChildren(h('button', { type: 'button', class: st.tab === 'buy' ? 'on' : '', onclick: () => { st.tab = 'buy'; draw(); } }, 'Purchases', h('span', { class: 'muted small' }, pb.filter((b) => b.open).length || '')),
        h('button', { type: 'button', class: st.tab === 'renew' ? 'on' : '', onclick: () => { st.tab = 'renew'; draw(); } }, 'Renewals & warranty', dueN ? h('span', { class: 'due-over small' }, dueN) : null));
      head.replaceChildren(h('div', null, h('h1', null, 'Buy & renew'), h('div', { class: 'sub' }, 'What has to be bought for new joiners and repairs, and what expires soon: AMC, licences, domain, SSL, internet, warranty.')), h('span', { class: 'grow' }),
        st.tab === 'buy' ? App.btn('New purchase request', () => App.newPurchase(), 'primary', 'plus') : App.btn('Add renewal', () => renewalDialog(null), 'primary', 'plus'));
      tools.replaceChildren(); holder.replaceChildren();
      if (st.tab === 'buy') drawBuy(); else drawRenew();
    }
    function drawBuy() {
      const F = { open: (b) => b.open, requested: (b) => b.status === 'requested', approved: (b) => b.status === 'approved', ordered: (b) => b.status === 'ordered', received: (b) => b.status === 'received', cancelled: (b) => b.status === 'cancelled', all: () => true };
      const L = [['open', 'Open'], ['requested', 'To approve'], ['approved', 'To order'], ['ordered', 'Ordered'], ['received', 'Received'], ['cancelled', 'Cancelled'], ['all', 'All']];
      const seg = h('div', { class: 'seg' }), q = h('input', { type: 'search', placeholder: 'Search item, vendor, PO number, person…', value: st.q });
      const segs = () => seg.replaceChildren(L.map(([k, l]) => h('button', { type: 'button', class: st.filter === k ? 'on' : '', onclick: () => { st.filter = k; segs(); rows(); } }, l + (['requested', 'approved'].indexOf(k) >= 0 && pb.filter(F[k]).length ? ' ' + pb.filter(F[k]).length : ''))));
      q.addEventListener('input', () => { st.q = q.value; rows(); });
      tools.replaceChildren(seg, h('div', { class: 'grow', style: { minWidth: '180px' } }, q)); segs();
      function rows() {
        const s = st.q.trim().toLowerCase();
        const list = pb.filter(F[st.filter] || F.all).filter((b) => !s || [b.code, b.item, b.vendor, b.po_no, b.person_name, b.reason].some((x) => x && String(x).toLowerCase().indexOf(s) >= 0));
        holder.replaceChildren(App.grid({
          rows: list, sortKey: 'id', sortDir: -1, onRow: (b) => App.openPurchase(b.id), emptyTitle: 'No purchase requests here', emptyText: 'When something is not in stock, or has to be bought for a joiner, a request is kept here until it arrives.',
          cols: [
            { k: 'id', label: 'Request', sort: (b) => b.id, render: (b) => h('div', null, h('span', { class: 'ttl' }, h('span', { class: 'mono muted' }, b.code + '  '), b.qty + ' × ' + b.item), h('span', { class: 'sub' }, [App.kindLabel(b.kind), b.person_name ? 'for ' + b.person_name : '', b.reason].filter(Boolean).join(' · ').slice(0, 90))) },
            { k: 'plant', label: 'Plant', cls: 'nw', sort: true, render: (b) => App.plantText(b.plant) },
            { k: 'status', label: 'Status', sort: true, render: buyChip },
            { k: 'vendor', label: 'Vendor / PO', sort: true, render: (b) => h('div', null, b.vendor || '—', b.po_no ? h('span', { class: 'sub' }, 'PO ' + b.po_no) : null) },
            { k: 'expected_on', label: 'Expected', sort: (b) => b.expected_on || '9999', render: (b) => (b.expected_on ? h('span', { class: b.late ? 'due-over' : '' }, fmtD(b.expected_on)) : '—') },
            { k: 'cost', label: 'Cost', cls: 'num', sort: (b) => b.cost || 0, render: (b) => rupee(b.cost) || '—' },
            { k: 'requested_on', label: 'Asked', sort: true, render: (b) => fmtD(b.requested_on) }
          ]
        }));
      }
      rows();
    }
    function drawRenew() {
      const stc = { expired: ['Expired', 'var(--c-overdue)'], due: ['Renew soon', 'var(--c-warning)'], ok: ['OK', 'var(--c-ok)'], closed: ['Closed', 'var(--ink-3)'] };
      const act = pr.filter((r) => r.state !== 'closed'), cls = pr.filter((r) => r.state === 'closed');
      holder.replaceChildren(
        App.grid({
          rows: act, sortKey: 'expires_on', sortDir: 1, onRow: (r) => App.openRenewal(r.id), emptyTitle: 'No renewals yet', emptyText: 'Add every contract or licence that expires: CCTV AMC, SAP licence, antivirus, domain, SSL, internet line. You are reminded before the date.',
          cols: [
            { k: 'title', label: 'What', sort: (r) => r.title.toLowerCase(), render: (r) => h('div', null, h('span', { class: 'ttl' }, r.title), h('span', { class: 'sub' }, [lbl(App.vocab().renew_kinds, r.kind), r.vendor].filter(Boolean).join(' · '))) },
            { k: 'plant', label: 'Plant', cls: 'nw', sort: true, render: (r) => (r.plant ? App.plantText(r.plant) : 'Company') },
            { k: 'expires_on', label: 'Expires', cls: 'nw', sort: true, render: (r) => fmtD(r.expires_on, true) },
            { k: 'days_left', label: 'Left', cls: 'num', sort: (r) => (r.days_left == null ? 9999 : r.days_left), render: (r) => (r.days_left == null ? '—' : r.days_left < 0 ? h('span', { class: 'due-over' }, Math.abs(r.days_left) + ' d over') : h('span', { class: r.days_left <= r.remind ? 'due-soon' : '' }, r.days_left + ' d')) },
            { k: 'state', label: 'State', sort: true, render: (r) => App.chip(stc[r.state][0], stc[r.state][1]) },
            { k: 'owner', label: 'Looked after by', sort: true, render: (r) => r.owner || '—' },
            { k: 'cost', label: 'Cost', cls: 'num', sort: (r) => r.cost || 0, render: (r) => rupee(r.cost) || '—' },
            { k: 'act', label: '', render: (r) => App.btn('Renewed', () => renewDialog(r), 'sm') }
          ]
        }),
        pw.length ? h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sect-t' }, h('h2', null, 'Warranty ending in 90 days'), h('span', null, pw.length + ' items')),
          h('div', { class: 'panel' }, h('div', { class: 'panel-b', style: { paddingTop: '6px', paddingBottom: '6px' } }, pw.map((w) => h('div', { class: 'row', style: { padding: '5px 0', borderBottom: '1px solid var(--line-2)' } },
            h('button', { class: 'lnk', type: 'button', onclick: () => App.openAsset(w.id) }, w.code + '  ' + App.kindLabel(w.kind) + (w.name ? ' · ' + w.name : '')), h('span', { class: 'muted small' }, [w.serial, w.plant ? App.plantText(w.plant) : ''].filter(Boolean).join(' · ')), h('span', { class: 'grow' }),
            w.days_left < 0 ? h('span', { class: 'due-over' }, 'over since ' + fmtD(w.warranty_until)) : h('span', { class: w.days_left <= 30 ? 'due-soon' : '' }, w.days_left + ' days left')))))) : null,
        cls.length ? h('div', { class: 'muted small', style: { marginTop: '14px' } }, cls.length + ' closed renewal(s) are kept in the record.') : null);
    }
    root.replaceChildren(head, tabs, tools, holder);
    draw();
  };

  /* ====================== purchases ====================== */
  const buyFields = () => [
    { k: 'item', label: 'What to buy', req: true, wide: true, ph: 'e.g. Dell Latitude 3420 laptop, i5 8GB' }, { k: 'kind', label: 'Type', t: 'select', opts: App.vocab().asset_kinds.map((x) => [x.key, x.label]) },
    { k: 'qty', label: 'How many', t: 'number', min: 1 }, { k: 'plant', label: 'For plant', t: 'select', opts: [['', '—']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) },
    { k: 'person_id', label: 'For employee (if any)', t: 'person' }, { k: 'reason', label: 'Why', t: 'area', wide: true, ph: 'New joiner, stock finished, laptop beyond repair…' }];
  App.newPurchase = function (pre) {
    pre = pre || {};
    App.formDialog({ title: 'New purchase request', cls: 'wide', fields: buyFields(), values: Object.assign({ kind: 'laptop', qty: 1, plant: App.plantFilter() || '' }, pre), ok: 'Create request', onSave: async (v) => {
      if (!v.item.trim()) { toast('Write what has to be bought', 'err'); return false; }
      const b = await POST('/api/purchases', Object.assign({}, v, pre.ticket_id ? { ticket_id: pre.ticket_id } : {}));
      toast(b.code + ' created'); App.refresh(); App.openPurchase(b.id); if (pre.after) pre.after(b);
    } });
  };

  function buyAction(b, act, done) {
    const kindBulk = !!(App.vocab().asset_kinds.find((k) => k.key === b.kind) || {}).bulk;
    if (act === 'approve') return App.formDialog({ title: 'Approve the purchase', fields: [{ k: 'approved_by', label: 'Approved by', req: true, ph: 'HOD / manager' }, { k: 'on', label: 'Date', t: 'date' }], values: { approved_by: b.approved_by || App.settings().hod || '', on: App.todayIso() }, ok: 'Approve',
      onSave: async (v) => { if (!v.approved_by.trim()) { toast('Write who approved it', 'err'); return false; } await POST('/api/purchases/' + b.id + '/do', { do: 'approve', approved_by: v.approved_by, on: v.on }); toast('Approved'); await done(); } });
    if (act === 'order') return App.formDialog({ title: 'Order placed', fields: [{ k: 'vendor', label: 'Vendor' }, { k: 'po_no', label: 'PO number' }, { k: 'expected_on', label: 'Expected on', t: 'date' }, { k: 'cost', label: 'Total cost', t: 'number', step: 'any' }], values: b, ok: 'Save',
      onSave: async (v) => { await POST('/api/purchases/' + b.id + '/do', Object.assign({ do: 'order' }, v)); toast('Marked as ordered'); await done(); } });
    if (act === 'receive') {
      const add = h('input', { type: 'checkbox', checked: true });
      const serials = h('textarea', { style: { minHeight: '90px' }, placeholder: 'One serial number per line (optional - you can add them later)' });
      const sbox = h('div', { class: 'fld', style: { marginTop: '8px' } }, h('label', null, 'Serial numbers (' + b.qty + ' items)'), serials);
      if (kindBulk || b.qty < 1) sbox.classList.add('hide');
      const f = App.makeForm([{ k: 'on', label: 'Received on', t: 'date' }, { k: 'cond', label: 'Condition', t: 'select', opts: App.vocab().conditions.map((c) => [c.key, c.label]) }, { k: 'warranty_until', label: 'Warranty until', t: 'date' }], { on: App.todayIso(), cond: 'new' });
      const m = modal({ title: 'Items received: ' + b.qty + ' × ' + b.item, cls: 'wide', body: [f.el, h('label', { class: 'row', style: { margin: '12px 0 4px' } }, add, 'Add them to stock now'), sbox,
        h('div', { class: 'hint-box' }, 'Adding to stock creates the item records (' + (kindBulk ? 'one counted record' : b.qty + ' separate records') + ') so they can be issued straight away.')],
      actions: [{ label: 'Cancel' }, { label: 'Received', cls: 'primary', close: false, onClick: async () => {
        const v = f.get();
        try { const r = await POST('/api/purchases/' + b.id + '/do', { do: 'receive', on: v.on, cond: v.cond, warranty_until: v.warranty_until || null, add_to_stock: add.checked, serials: serials.value }); m.close(); toast('Received' + (r.created_assets && r.created_assets.length ? ' - added to stock' : '')); await done(); } catch (e) { /* shown */ }
        return false;
      } }] });
      add.addEventListener('change', () => sbox.classList.toggle('hide', !add.checked || kindBulk));
      return null;
    }
    return null;
  }

  App.openPurchase = async function (id) {
    const dr = App.drawer({ aria: 'Purchase request' });
    dr.body.replaceChildren(App.spin());
    async function render() {
      let b;
      try { b = await GET('/api/purchases/' + id); } catch (e) { return dr.close(); }
      b.late = b.status === 'ordered' && b.expected_on && b.expected_on < App.todayIso();
      const done = async () => { await render(); App.refresh(); };
      dr.setHead([h('div', { class: 'row wrap', style: { marginBottom: '4px', paddingRight: '34px' } }, App.mono(b.code), buyChip(b), App.tag(App.kindLabel(b.kind)), b.plant ? App.tag(App.plantText(b.plant)) : null),
        h('div', { style: { fontSize: '20px', fontWeight: '700', lineHeight: '1.25' } }, b.qty + ' × ' + b.item),
        h('div', { class: 'muted small' }, 'asked ' + fmtD(b.requested_on, true) + (b.person_name ? ' · for ' + b.person_name : ''))]);
      const steps = [['Requested', b.requested_on, '', true], ['Approved', b.approved_on, b.approved_by, !!b.approved_on], ['Ordered', b.status === 'ordered' || b.status === 'received' ? (b.expected_on ? 'by ' + fmtD(b.expected_on) : 'yes') : '', b.vendor, b.status === 'ordered' || b.status === 'received'], ['Received', b.received_on, '', b.status === 'received']];
      const now = steps.findIndex((s) => !s[3]);
      const cancelled = b.status === 'cancelled';
      const stepper = h('div', { class: 'stepper' }, steps.map(([l, on, by, ok], i) => h('div', { class: 'st' + (ok ? ' done' : '') + (!cancelled && i === now ? ' now' : '') }, h('i', null, ok ? '✓' : String(i + 1)), h('b', null, l), on ? h('span', null, /^\d{4}-/.test(on) ? fmtD(on) : on) : null, by ? h('span', { class: 'small' }, by) : null)));
      const acts = [];
      if (b.status === 'requested') acts.push(App.btn('Approve', () => buyAction(b, 'approve', done), 'primary'));
      if (b.status === 'requested' || b.status === 'approved') acts.push(App.btn('Order placed', () => buyAction(b, 'order', done), b.status === 'approved' ? 'primary' : ''));
      if (b.status === 'ordered') acts.push(App.btn('Items received', () => buyAction(b, 'receive', done), 'primary'));
      if (b.status === 'requested' || b.status === 'approved') acts.push(App.btn('Received without order', () => buyAction(b, 'receive', done), 'ghost'));
      if (b.status === 'requested' || b.status === 'approved' || b.status === 'ordered') acts.push(App.btn('Cancel request', async () => { const n = prompt('Why is it cancelled?'); if (n === null) return; await POST('/api/purchases/' + id + '/do', { do: 'cancel', note: n }); toast('Cancelled'); done(); }, 'ghost danger'));
      if (b.status === 'cancelled') acts.push(App.btn('Re-open', async () => { await POST('/api/purchases/' + id + '/do', { do: 'reopen' }); done(); }, ''));
      const kv = (k, v) => (v ? [h('dt', null, k), h('dd', null, v)] : null);
      dr.body.replaceChildren(stepper, b.late ? h('div', { class: 'box bad', style: { marginBottom: '12px' } }, 'Expected on ' + fmtD(b.expected_on) + ' - not received yet. Call the vendor.') : null,
        h('div', { class: 'acts', style: { marginBottom: '16px' } }, acts),
        h('div', { class: 'box' }, h('div', { class: 'sec-h' }, h('h3', null, 'Details'), h('div', { class: 'acts' }, App.btn('Edit', () => App.formDialog({ title: 'Edit ' + b.code, cls: 'wide', fields: buyFields().concat([{ k: 'vendor', label: 'Vendor' }, { k: 'po_no', label: 'PO number' }, { k: 'expected_on', label: 'Expected on', t: 'date' }, { k: 'cost', label: 'Cost', t: 'number', step: 'any' }, { k: 'note', label: 'Note', t: 'area', wide: true }]), values: b, onSave: async (v) => { await PUT('/api/purchases/' + id, v); toast('Saved'); await done(); } }), 'sm', 'edit'))),
          h('dl', { class: 'kv' }, kv('Why', b.reason), kv('For', b.person_name ? h('button', { class: 'lnk', type: 'button', onclick: () => App.openPerson(b.person_id) }, b.person_name) : ''), kv('Vendor', b.vendor), kv('PO number', b.po_no), kv('Cost', rupee(b.cost)), kv('Approved by', b.approved_by), kv('Note', b.note),
            b.ticket_id ? kv('Ticket', h('button', { class: 'lnk', type: 'button', onclick: () => App.openTicket(b.ticket_id) }, 'open the ticket')) : null)),
        h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'Quotation, PO, invoice'), h('span', { class: 'cnt' }, b.files.length || ''), h('div', { class: 'acts' }, App.btn('Open folder', () => POST('/api/open-folder', { kind: 'purchase', id: id }), 'sm ghost', 'folder'))), App.filesSection('purchase', id, b.files, done, { cat: 'invoice' })),
        h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'History')), App.noteBox(async (text) => { await POST('/api/purchases/' + id + '/do', { do: 'note', note: text }); done(); }, { noKnown: true }), App.timeline(b.history)),
        h('section', { style: { marginTop: '28px', borderTop: '1px solid var(--line)', paddingTop: '14px' } }, App.btn('Delete this request', async () => { if (await confirmBox('Delete ' + b.code + '? Use "Cancel request" if it should stay in the record.')) { await DEL('/api/purchases/' + id); dr.close(); toast('Deleted'); App.refresh(); } }, 'sm ghost danger')));
    }
    await render();
  };

  /* ====================== renewals ====================== */
  const renewFields = () => [{ k: 'title', label: 'What expires', req: true, wide: true, ph: 'e.g. CCTV AMC - Jaitpura, SAP licence, antivirus, domain' }, { k: 'kind', label: 'Type', t: 'select', opts: App.vocab().renew_kinds.map((x) => [x.key, x.label]) },
    { k: 'vendor', label: 'Vendor / provider' }, { k: 'plant', label: 'For plant', t: 'select', opts: [['', 'Whole company']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) }, { k: 'owner_id', label: 'Looked after by', t: 'who', noneLabel: '— nobody —' },
    { k: 'starts_on', label: 'Started on', t: 'date' }, { k: 'expires_on', label: 'Expires on', t: 'date', req: true }, { k: 'remind_days', label: 'Remind me before (days)', t: 'number', min: 1, hint: 'Empty = the default in Settings' },
    { k: 'cost', label: 'Cost per period', t: 'number', step: 'any' }, { k: 'note', label: 'Note', t: 'area', wide: true }];
  function renewalDialog(r) {
    App.formDialog({ title: r ? 'Edit ' + r.title : 'New renewal', cls: 'wide', fields: renewFields(), values: Object.assign({ kind: 'amc', plant: App.plantFilter() || '', owner_id: 0 }, r || {}), ok: r ? 'Save' : 'Add', onSave: async (v) => {
      if (!v.title.trim()) { toast('Write what expires', 'err'); return false; }
      if (!v.expires_on) { toast('Choose the expiry date', 'err'); return false; }
      if (r) await PUT('/api/renewals/' + r.id, v); else await POST('/api/renewals', v);
      toast('Saved'); App.refresh();
    } });
  }
  function renewDialog(r, done) {
    const d = r.expires_on ? App.iso(App.addDays(App.pd(r.expires_on), 365)) : '';
    App.formDialog({ title: 'Renewed: ' + r.title, fields: [{ k: 'expires_on', label: 'New expiry date', t: 'date', req: true, hint: 'Currently ' + fmtD(r.expires_on, true) }, { k: 'cost', label: 'Cost of this renewal', t: 'number', step: 'any' }, { k: 'note', label: 'Note (invoice no., vendor…)', t: 'area', wide: true }],
      values: { expires_on: d, cost: r.cost }, ok: 'Save renewal', onSave: async (v) => { if (!v.expires_on) { toast('Choose the new expiry date', 'err'); return false; } await POST('/api/renewals/' + r.id + '/renew', v); toast('Renewed till ' + fmtD(v.expires_on, true)); App.refresh(); if (done) done(); } });
  }
  App.openRenewal = async function (id) {
    const dr = App.drawer({ aria: 'Renewal' });
    dr.body.replaceChildren(App.spin());
    async function render() {
      let r;
      try { r = await GET('/api/renewals/' + id); } catch (e) { return dr.close(); }
      const left = r.expires_on ? App.daysBetween(new Date(), App.pd(r.expires_on)) : null;
      const done = async () => { await render(); App.refresh(); };
      dr.setHead([h('div', { class: 'row wrap', style: { marginBottom: '4px', paddingRight: '34px' } }, App.mono(r.code), App.tag(lbl(App.vocab().renew_kinds, r.kind)), r.status === 'closed' ? App.chip('Closed', 'var(--ink-3)') : left == null ? null : left < 0 ? App.chip('Expired', 'var(--c-overdue)') : App.chip(left + ' days left', left <= (r.remind_days || +App.settings().renew_days || 30) ? 'var(--c-warning)' : 'var(--c-ok)')),
        h('div', { style: { fontSize: '20px', fontWeight: '700', lineHeight: '1.25' } }, r.title), h('div', { class: 'muted small' }, [r.vendor, r.plant ? App.plantText(r.plant) : 'whole company', 'expires ' + fmtD(r.expires_on, true)].filter(Boolean).join(' · '))]);
      const kv = (k, v) => (v ? [h('dt', null, k), h('dd', null, v)] : null);
      dr.body.replaceChildren(h('div', { class: 'acts', style: { marginBottom: '16px' } }, r.status !== 'closed' ? App.btn('Renewed', () => renewDialog(r, done), 'primary') : null, App.btn('Edit', () => App.formDialog({ title: 'Edit ' + r.title, cls: 'wide', fields: renewFields(), values: r, onSave: async (v) => { await PUT('/api/renewals/' + id, v); toast('Saved'); await done(); } }), '', 'edit'),
        App.btn(r.status === 'closed' ? 'Start again' : 'Close (no renewal needed)', async () => { await PUT('/api/renewals/' + id, { status: r.status === 'closed' ? 'active' : 'closed' }); done(); }, 'ghost')),
      h('div', { class: 'box' }, h('dl', { class: 'kv' }, kv('Provider', r.vendor), kv('Started', r.starts_on ? fmtD(r.starts_on, true) : ''), kv('Expires', fmtD(r.expires_on, true)), kv('Remind before', (r.remind_days || App.settings().renew_days || 30) + ' days'), kv('Cost', rupee(r.cost)), kv('Looked after by', App.memberName(r.owner_id)), kv('Note', r.note))),
      h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'Contract, invoice, certificate'), h('span', { class: 'cnt' }, r.files.length || ''), h('div', { class: 'acts' }, App.btn('Open folder', () => POST('/api/open-folder', { kind: 'renewal', id: id }), 'sm ghost', 'folder'))), App.filesSection('renewal', id, r.files, done, { cat: 'doc' })),
      h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'History')), App.timeline(r.history)),
      h('section', { style: { marginTop: '28px', borderTop: '1px solid var(--line)', paddingTop: '14px' } }, App.btn('Delete', async () => { if (await confirmBox('Delete ' + r.title + ' with its history? Use "Close" to keep it in the record.')) { await DEL('/api/renewals/' + id); dr.close(); toast('Deleted'); App.refresh(); } }, 'sm ghost danger')));
    }
    await render();
  };
})();
