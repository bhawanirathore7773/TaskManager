/* Shared UI parts for the BASIS module: drawer, pickers, forms, tables, timeline, files, menus, messages, printing. */
(function () {
  'use strict';
  const { h, ico, $, GET, POST, PUT, DEL, toast, modal, confirmBox, fmtTs, fmtD, cap, load } = App;
  const M = () => App.S.meta;
  const vocab = () => M().vocab;
  const label = (list, key) => { const x = (list || []).find((i) => i.key === key); return x ? x.label : (key || ''); };
  const settings = () => M().settings;
  const plants = () => settings().plants;
  const plantName = (code) => { const p = plants().find((x) => x.code === code); return p ? p.name : ''; };
  const plantText = (code) => (code ? code + (plantName(code) ? ' · ' + plantName(code).replace(/ Plant$/, '') : '') : '—');
  const plantFilter = () => App.S.plant || '';
  const inPlant = (row, key) => !plantFilter() || (row[key || 'plant'] || '') === plantFilter();
  const team = () => M().team || [];
  const memberName = (id) => {
    if (id == null || id === '') return '';
    if (+id === 0) return settings().manager || 'Me';
    const m = team().find((x) => x.id === +id); return m ? m.name : '(removed)';
  };
  const kindLabel = (k) => label(vocab().asset_kinds, k);

  /* ---------- small display parts ---------- */
  const chip = (text, color, cls) => h('span', { class: 'chip ' + (cls || ''), style: { '--c': color || 'var(--ink-3)' } }, text);
  const ticketStatus = (k) => chip(label(vocab().statuses, k), 'var(--s-' + k + ')');
  const assetStatus = (k) => chip(label(vocab().asset_status, k), 'var(--a-' + k + ')');
  const trStatus = (k) => chip(label(vocab().tr_status, k), 'var(--t-' + k + ')');
  const prio = (p) => h('span', { class: 'prio ' + p }, h('i', null, h('b'), h('b'), h('b'), h('b')), cap(p));
  const tag = (t, title) => h('span', { class: 'tag', title: title || null }, t);
  const mono = (t) => h('span', { class: 'mono' }, t);
  const empty = (title, text, action) => h('div', { class: 'empty' }, h('b', null, title), text ? h('div', null, text) : null, action ? h('div', { style: { marginTop: '10px' } }, action) : null);
  const spin = () => h('div', { class: 'spin' }, 'Loading…');
  const btn = (text, onclick, cls, icon, title) => h('button', { class: 'btn ' + (cls || ''), type: 'button', onclick: onclick, title: title || null }, icon ? ico(icon) : null, text);
  function dueText(t) {
    if (!t.is_open) return t.status === 'done' ? h('span', { class: 'muted' }, 'done ' + fmtTs(t.done_at)) : h('span', { class: 'muted' }, t.closed_at ? 'closed ' + fmtTs(t.closed_at) : '');
    if (!t.due_at) return '—';
    const hl = t.hours_left;
    if (t.overdue) return h('span', { class: 'due-over', title: 'Due ' + t.due_at }, 'Overdue ' + (Math.abs(hl) >= 48 ? Math.round(-hl / 24) + ' d' : Math.round(-hl) + ' h'));
    return h('span', { class: hl < 8 ? 'due-soon' : '', title: 'Due ' + t.due_at }, hl < 24 ? 'in ' + Math.max(1, Math.round(hl)) + ' h' : fmtTs(t.due_at));
  }
  const ageText = (hours) => (hours == null ? '' : hours < 48 ? Math.round(hours) + ' h' : Math.round(hours / 24) + ' d');
  const dtLocal = (s) => (s ? String(s).replace(' ', 'T').slice(0, 16) : '');

  /* ---------- who (team member) select: nobody / me / members ---------- */
  function whoSelect(value, onChange, o) {
    o = o || {};
    const opts = [];
    if (o.none !== false) opts.push(['', o.noneLabel || '— nobody —']);
    opts.push(['0', (settings().manager || 'Me') + ' (me)']);
    team().filter((m) => m.active || (value != null && +value === m.id)).forEach((m) => opts.push([String(m.id), m.name + (m.plant ? ' · ' + m.plant : '') + (m.active ? '' : ' (not active)')]));
    return App.sel(opts, value == null ? '' : String(value), onChange, o.attrs);
  }

  /* ---------- picker (search + choose a person / asset / ticket) ---------- */
  function pick(kind, value, onChange, o) {
    o = o || {};
    let cur = value || null;
    const input = h('input', { type: 'text', placeholder: o.ph || (kind === 'person' ? 'Type a name or employee code…' : 'Type to search…'), autocomplete: 'off' });
    const list = h('div', { class: 'pick-list hide' });
    const x = h('button', { class: 'iconbtn sm pk-x hide', type: 'button', title: 'Clear', onclick: () => { cur = null; input.value = ''; x.classList.add('hide'); fire(); } }, ico('x'));
    const root = h('div', { class: 'pick' }, input, x, list);
    let all = [];
    async function items() {
      if (kind === 'person') {
        return (await load('people')).filter((p) => o.includeLeft || p.status !== 'left' || p.id === cur)
          .map((p) => ({ id: p.id, label: p.name, sub: [p.emp_code, p.department, p.plant].filter(Boolean).join(' · ') + (p.status === 'left' ? ' · LEFT' : ''), raw: p }));
      }
      if (kind === 'asset') {
        return (await load('assets')).filter(o.filter || (() => true)).map((a) => ({ id: a.id, label: a.code + '  ' + a.label, sub: [a.serial, a.tag, label(vocab().asset_status, a.status)].filter(Boolean).join(' · '), raw: a }));
      }
      return [];
    }
    function fire() { if (o.onText) o.onText(input.value); if (onChange) onChange(cur, all.find((i) => i.id === cur)); root.dispatchEvent(new CustomEvent('pick', { detail: cur })); }
    function show() {
      const q = input.value.trim().toLowerCase();
      const hits = all.filter((i) => !q || (i.label + ' ' + i.sub).toLowerCase().indexOf(q) >= 0).slice(0, 40);
      list.replaceChildren(hits.length ? hits.map((i) => h('button', { type: 'button', onmousedown: (e) => { e.preventDefault(); choose(i); } }, h('span', { class: 'grow' }, h('b', null, i.label), h('span', { class: 'sub' }, i.sub)))) : h('div', { class: 'none' }, q ? 'Nothing found' + (o.free ? ' - the text will be used as typed' : '') : 'Nothing to choose from'));
      list.classList.remove('hide');
    }
    function choose(i) { cur = i.id; input.value = i.label; x.classList.remove('hide'); list.classList.add('hide'); fire(); }
    input.addEventListener('focus', () => items().then((a) => { all = a; show(); }));
    input.addEventListener('input', () => { if (cur) { cur = null; x.classList.add('hide'); } show(); if (o.onText) o.onText(input.value); });
    input.addEventListener('blur', () => setTimeout(() => list.classList.add('hide'), 120));
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); const b = list.querySelector('button'); if (b && !cur) b.dispatchEvent(new MouseEvent('mousedown')); }
      if (e.key === 'Escape') list.classList.add('hide');
    });
    root.get = () => cur;
    root.text = () => input.value.trim();
    root.set = (id) => { cur = id || null; if (!id) { input.value = ''; x.classList.add('hide'); return fire(); } items().then((a) => { all = a; const i = a.find((z) => z.id === id); if (i) { input.value = i.label; x.classList.remove('hide'); } fire(); }); };
    if (value) items().then((a) => { all = a; const i = a.find((z) => z.id === value); if (i) { input.value = i.label; x.classList.remove('hide'); } });
    return root;
  }

  /* ---------- forms ---------- */
  // fields: [{k, label, t: text|area|select|date|datetime|number|check|person|asset|who|list, opts, req, ph, hint, wide, list}]
  function makeForm(fields, values) {
    values = values || {};
    const ctl = {};
    const rows = fields.map((f) => {
      let el;
      const v = values[f.k];
      if (f.t === 'area') el = h('textarea', { placeholder: f.ph || '' }, v || '');
      else if (f.t === 'select') { el = App.sel(f.opts, v == null ? '' : String(v)); }
      else if (f.t === 'date') el = h('input', { type: 'date', value: v || '' });
      else if (f.t === 'datetime') el = h('input', { type: 'datetime-local', value: dtLocal(v) });
      else if (f.t === 'number') el = h('input', { type: 'number', min: f.min != null ? f.min : 0, step: f.step || 1, value: v == null ? '' : v });
      else if (f.t === 'check') el = h('input', { type: 'checkbox', checked: !!+v });
      else if (f.t === 'person') el = pick('person', v, null, { free: f.free, includeLeft: f.includeLeft });
      else if (f.t === 'asset') el = pick('asset', v, null, { filter: f.filter });
      else if (f.t === 'who') el = whoSelect(v, null, f);
      else el = h('input', { type: 'text', value: v == null ? '' : v, placeholder: f.ph || '', list: f.list || null, autocomplete: 'off' });
      ctl[f.k] = el;
      if (f.t === 'check') return h('div', { class: 'fld' + (f.wide ? ' wide' : ''), style: f.wide ? { gridColumn: '1 / -1' } : null }, h('label', { class: 'row' }, el, f.label), f.hint ? h('span', { class: 'hint' }, f.hint) : null);
      return h('div', { class: 'fld', style: f.wide ? { gridColumn: '1 / -1' } : null }, h('label', null, f.label + (f.req ? ' *' : '')), el, f.hint ? h('span', { class: 'hint' }, f.hint) : null);
    });
    const el = h('div', { class: 'grid2' }, rows);
    function get() {
      const out = {};
      fields.forEach((f) => {
        const c = ctl[f.k];
        if (f.t === 'check') out[f.k] = c.checked ? 1 : 0;
        else if (f.t === 'person' || f.t === 'asset') out[f.k] = c.get();
        else if (f.t === 'who') out[f.k] = c.value === '' ? null : +c.value;
        else if (f.t === 'number') out[f.k] = c.value === '' ? null : +c.value;
        else out[f.k] = c.value;
      });
      return out;
    }
    return { el, ctl, get };
  }
  // opens a dialog with a form; onSave(values) may return a promise; the dialog closes when it resolves (false = stay open)
  function formDialog(o) {
    const f = makeForm(o.fields, o.values);
    let busy = false;
    const m = modal({ title: o.title, cls: o.cls || '', body: [o.intro ? h('p', { class: 'muted', style: { marginBottom: '10px' } }, o.intro) : null, f.el, o.extra || null],
      actions: [{ label: 'Cancel' }, { label: o.ok || 'Save', cls: 'primary', close: false, onClick: async () => {
        if (busy) return false; busy = true;
        try { const r = await o.onSave(f.get(), f); if (r !== false) m.close(); } catch (e) { /* the api helper already showed the reason */ } finally { busy = false; }
        return false;
      } }] });
    return Object.assign(m, { form: f });
  }

  /* ---------- drawer ---------- */
  let cur = null;
  function closeDrawer() { if (cur) { cur.close(); } }
  function drawer(o) {
    closeDrawer();
    const root = $('#drawer-root');
    const body = h('div', { class: 'dr-b' });
    const head = h('div', { class: 'dr-h', style: { paddingBottom: '12px' } });
    const scrim = h('div', { class: 'scrim', onclick: () => api.close() });
    const el = h('aside', { class: 'drawer', role: 'dialog', 'aria-label': o.aria || 'Details' }, head, body);
    const onKey = (e) => { if (e.key === 'Escape' && !document.querySelector('dialog[open]')) api.close(); };
    const api = { el, body, head, close() { document.removeEventListener('keydown', onKey); scrim.remove(); el.remove(); if (cur === api) cur = null; if (o.onClose) o.onClose(); }, setHead(kids) { head.replaceChildren(kids, h('button', { class: 'iconbtn', style: { position: 'absolute', top: '12px', right: '14px' }, type: 'button', 'aria-label': 'Close', onclick: () => api.close() }, ico('x'))); } };
    head.style.position = 'relative';
    root.append(scrim, el);
    document.addEventListener('keydown', onKey);
    cur = api;
    return api;
  }

  /* ---------- table with sortable columns ---------- */
  function grid(o) {
    let sk = o.sortKey || null, sd = o.sortDir || 1, limit = o.limit || 250;
    const wrap = h('div', { class: 'gridwrap', style: o.maxH ? { maxHeight: o.maxH } : null });
    function draw() {
      let rows = o.rows.slice();
      if (sk) {
        const c = o.cols.find((z) => z.k === sk), f = c && (typeof c.sort === 'function' ? c.sort : (r) => r[c.k]);
        if (f) rows.sort((a, b) => { let x = f(a), y = f(b); if (x == null) x = ''; if (y == null) y = ''; return (x < y ? -1 : x > y ? 1 : 0) * sd; });
      }
      const shown = rows.slice(0, limit);
      const tbl = h('table', { class: 'grid' }, h('thead', null, h('tr', null, o.cols.map((c) => h('th', { class: (c.sort ? 'sort ' : '') + (c.cls || ''), onclick: c.sort ? () => { if (sk === c.k) sd = -sd; else { sk = c.k; sd = 1; } draw(); } : null },
        c.label, sk === c.k ? h('span', { class: 'arr' }, sd > 0 ? '▲' : '▼') : null)))),
      h('tbody', null, shown.map((r) => h('tr', { class: o.onRow ? 'click' : '', onclick: o.onRow ? (e) => { if (e.target.closest('button,select,input,a')) return; o.onRow(r); } : null }, o.cols.map((c) => h('td', { class: c.cls || '' }, c.render ? c.render(r) : r[c.k]))))));
      wrap.replaceChildren(rows.length ? tbl : empty(o.emptyTitle || 'Nothing here', o.emptyText || ''), rows.length > limit ? h('div', { style: { padding: '10px', textAlign: 'center' } }, btn('Show more (' + (rows.length - limit) + ' left)', () => { limit += 250; draw(); }, 'sm')) : null);
    }
    draw();
    return wrap;
  }

  /* ---------- menu (popup list of actions) ---------- */
  function menu(anchor, items) {
    const m = h('div', { class: 'menu' }, items.filter(Boolean).map((i) => h('button', { type: 'button', onclick: () => { close(); i.run(); } }, i.icon ? ico(i.icon) : null, i.label, i.sub ? h('span', { class: 'sub muted small' }, i.sub) : null)));
    const close = () => { m.remove(); document.removeEventListener('mousedown', away, true); };
    const away = (e) => { if (!m.contains(e.target) && !anchor.contains(e.target)) close(); };
    anchor.parentNode.classList.add('rel'); anchor.parentNode.append(m);
    setTimeout(() => document.addEventListener('mousedown', away, true), 0);
    return close;
  }

  /* ---------- timeline + notes + files ---------- */
  function timeline(items) {
    if (!items || !items.length) return h('div', { class: 'muted small' }, 'Nothing recorded yet.');
    return h('div', { class: 'tline' }, items.map((e) => h('div', { class: 'ev2 ' + e.kind }, h('time', null, fmtTs(e.ts) + (e.who ? ' · ' : ''), e.who ? h('span', { class: 'who' }, e.who) : null), e.text)));
  }
  function noteBox(onAdd, o) {
    o = o || {};
    const ta = h('textarea', { placeholder: o.ph || 'Write a note… (for example what the team said)', style: { minHeight: '52px' } });
    const who = o.noKnown ? null : whoSelect('', null, { noneLabel: '— written by me —', attrs: { 'aria-label': 'Who said it' } });
    return h('div', { class: 'stack', style: { gap: '6px', marginBottom: '10px' } }, ta, h('div', { class: 'row' }, who ? h('span', { class: 'muted small' }, 'From') : null, who, h('span', { class: 'grow' }),
      btn('Add note', async () => { const t = ta.value.trim(); if (!t) return toast('Write the note first', 'err'); await onAdd(t, who && who.value !== '' ? memberName(who.value) : ''); ta.value = ''; }, 'sm primary')));
  }
  function filesSection(kind, id, files, onChange, o) {
    o = o || {};
    const cats = vocab().file_cats;
    const catSel = App.sel(cats.map((c) => [c.key, c.label]), o.cat || 'photo');
    const input = h('input', { type: 'file', multiple: true, class: 'hide' });
    async function up(list) {
      for (const f of Array.from(list)) { try { await App.uploadFile(kind, id, f, catSel.value); } catch (e) { /* shown */ } }
      toast('Uploaded'); onChange();
    }
    input.addEventListener('change', () => { if (input.files.length) up(input.files); });
    const drop = h('div', { class: 'drop', style: { padding: '12px' } }, h('div', { class: 'row', style: { justifyContent: 'center', flexWrap: 'wrap' } }, 'Add a', catSel, btn('Choose files', () => input.click(), 'sm', 'upload'), h('span', { class: 'muted small' }, 'or drop files here')), input);
    ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => { if (e.dataTransfer && e.dataTransfer.files.length) up(e.dataTransfer.files); });
    const isImg = (f) => /\.(png|jpe?g|gif|webp|bmp)$/i.test(f.filename);
    const grid2 = h('div', { class: 'files', style: { marginTop: '10px' } }, (files || []).map((f) => h('div', { class: 'file' },
      h('div', { class: 'thumb', onclick: () => (isImg(f) ? lightbox('/files/' + f.id) : window.open('/files/' + f.id, '_blank')) }, isImg(f) ? h('img', { src: '/files/' + f.id, alt: f.filename, loading: 'lazy' }) : h('span', { class: 'ext' }, (f.filename.split('.').pop() || 'file').toUpperCase().slice(0, 4))),
      h('div', { class: 'meta' }, h('b', null, f.filename), h('span', { class: 'muted' }, (vocab().file_cats.find((c) => c.key === f.category) || {}).label + ' · ' + App.fmtSize(f.size || 0) + ' · ' + fmtTs(f.uploaded_at))),
      h('div', { class: 'fa' }, h('a', { class: 'iconbtn', href: '/files/' + f.id + '?dl=1', title: 'Download' }, ico('download')),
        h('button', { class: 'iconbtn', type: 'button', title: 'Remove', onclick: async () => { if (await confirmBox('Remove ' + f.filename + '?', 'Remove')) { await DEL('/api/files/' + f.id); onChange(); } } }, ico('trash'))))));
    return h('div', null, drop, grid2);
  }
  function lightbox(src) {
    const lb = h('div', { class: 'lightbox', onclick: () => lb.remove() }, h('img', { src: src, alt: '' }), h('button', { class: 'iconbtn x', type: 'button', style: { color: '#fff' } }, ico('x')));
    document.body.append(lb);
  }

  /* ---------- messages to the team ---------- */
  function ticketMessage(t, name) {
    const lines = [];
    const m = team().find((x) => x.id === t.assigned_to);
    lines.push((name || (m && m.name) || 'Hello') + (m ? ' ji' : '') + ',');
    lines.push(t.code + ' - ' + t.title);
    const who = [t.requester, t.department].filter(Boolean).join(', ') + (t.contact ? ' (' + t.contact + ')' : '');
    if (who) lines.push('Who: ' + who);
    if (t.plant) lines.push('Plant: ' + plantText(t.plant));
    if (t.asset_code) lines.push('Device: ' + t.asset_code + ' ' + (t.asset_name || '') + (t.asset_tag ? ' (' + t.asset_tag + ')' : ''));
    if (t.details) lines.push(t.details.length > 220 ? t.details.slice(0, 220) + '…' : t.details);
    lines.push('Priority: ' + cap(t.priority) + (t.due_at ? '. Please finish by ' + fmtTs(t.due_at) + '.' : '.'));
    lines.push('When it is done, reply here with what you did.');
    lines.push('- ' + (settings().manager || ''));
    return lines.join('\n');
  }
  function listMessage(m, tickets) {
    const mine = tickets.filter((t) => t.assigned_to === m.id && ['assigned', 'progress', 'waiting', 'done'].indexOf(t.status) >= 0);
    const lines = [m.name + ' ji, your open work (' + new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + '):'];
    if (!mine.length) lines.push('Nothing pending. Thank you!');
    mine.forEach((t, i) => lines.push((i + 1) + '. ' + t.code + ' ' + t.title + (t.requester ? ' (' + t.requester + ')' : '') + ' - ' + (t.overdue ? 'OVERDUE' : t.status === 'done' ? 'done, waiting for my check' : t.due_at ? 'by ' + fmtTs(t.due_at) : '')));
    if (mine.length) lines.push('Please send me a status on each one.');
    lines.push('- ' + (settings().manager || ''));
    return lines.join('\n');
  }
  function sendDialog(title, text, mobile) {
    const ta = h('textarea', { style: { minHeight: '190px' } }, text);
    const waNum = (mobile || '').replace(/\D/g, '');
    const full = waNum ? (waNum.length <= 10 ? (settings().wa_prefix || '91') + waNum.slice(-10) : waNum) : '';
    modal({ title: title, body: [h('p', { class: 'muted small', style: { marginBottom: '8px' } }, 'Check the text, then copy it or open WhatsApp. Nothing is sent from here by itself.'), ta],
      actions: [{ label: 'Close' }, { label: 'Copy text', close: false, onClick: () => { App.copyText(ta.value, 'Message copied'); return false; } },
        { label: full ? 'Open WhatsApp' : 'Open WhatsApp (no mobile number)', cls: 'primary', close: false, onClick: () => { window.open('https://wa.me/' + full + '?text=' + encodeURIComponent(ta.value), '_blank', 'noopener'); return false; } }] });
  }

  /* ---------- printing ---------- */
  function printNode(node) {
    let root = $('#print-root');
    if (!root) { root = h('div', { id: 'print-root' }); document.body.append(root); }
    root.replaceChildren(node);
    document.body.classList.add('printing');
    const done = () => { document.body.classList.remove('printing'); root.replaceChildren(); window.removeEventListener('afterprint', done); };
    window.addEventListener('afterprint', done);
    setTimeout(() => window.print(), 50);
    setTimeout(done, 60000);
  }

  Object.assign(App, { label, vocab, settings, plants, plantName, plantText, plantFilter, inPlant, team, memberName, kindLabel, chip, ticketStatus, assetStatus, trStatus, prio, tag, mono, empty, spin, btn,
    dueText, ageText, dtLocal, whoSelect, pick, makeForm, formDialog, drawer, closeDrawer, grid, menu, timeline, noteBox, filesSection, lightbox, ticketMessage, listMessage, sendDialog, printNode });
})();
