/* Tickets: list, quick new ticket, ticket drawer (assign, follow up, verify and close). */
(function () {
  'use strict';
  const { h, ico, GET, POST, PUT, DEL, toast, modal, confirmBox, fmtTs, fmtD, cap, load } = App;
  const F = {
    open: (t) => t.is_open, tocheck: (t) => t.status === 'done', overdue: (t) => t.overdue, unassigned: (t) => t.is_open && t.assigned_to == null, waiting: (t) => t.status === 'waiting',
    critical: (t) => t.is_open && t.priority === 'critical', follow: (t) => t.follow_due, quiet: (t) => t.is_open && t.quiet_days >= 2, closed: (t) => t.status === 'closed' || t.status === 'cancelled', all: () => true
  };
  const FL = [['open', 'Open'], ['tocheck', 'To check'], ['overdue', 'Overdue'], ['unassigned', 'Not assigned'], ['waiting', 'Waiting'], ['closed', 'Closed'], ['all', 'All']];
  const SUBS = { hardware: ['Laptop', 'Desktop PC', 'Mouse', 'Keyboard', 'Monitor', 'UPS', 'Headset'], software: ['Windows', 'MS Office', 'Antivirus', 'Browser', 'Install software'], sap: ['SAP GUI', 'Slow system', 'Authorization', 'Print from SAP', 'Transaction error'],
    sap_user: ['Create user', 'Delete user', 'Lock user', 'Password reset', 'Role change'], email: ['New mail id', 'Mail not working', 'Password reset', 'Mailbox full'], network: ['Internet', 'WiFi', 'VPN', 'LAN point'],
    camera: ['No picture', 'New camera', 'Recording problem'], printer: ['Not printing', 'Toner / cartridge', 'Scanner', 'Barcode printer'], phone: ['Intercom', 'Mobile', 'Extension'] };

  App.V.tickets = async function (root, params) {
    const st = App.S.tk = App.S.tk || { filter: 'open', cat: '', assignee: '', q: '' };
    if (params.filter) st.filter = params.filter === 'critical' ? 'critical' : params.filter;
    if (params.assignee != null) st.assignee = params.assignee;
    if (params.q != null) st.q = params.q;
    const all = (await load('tickets')).filter((t) => App.inPlant(t));
    const cats = App.vocab().categories;
    const counts = {}; FL.forEach(([k]) => { counts[k] = all.filter(F[k]).length; });
    const seg = h('div', { class: 'seg', role: 'group', 'aria-label': 'Filter' });
    const q = h('input', { type: 'search', placeholder: 'Search this list…', value: st.q });
    const catSel = App.sel([['', 'All types']].concat(cats.map((c) => [c.key, c.label.replace(/ \(.*\)/, '')])), st.cat, (v) => { st.cat = v; draw(); });
    const asSel = App.sel([['', 'Everyone'], ['none', 'Not assigned'], ['0', (App.settings().manager || 'Me') + ' (me)']].concat(App.team().map((m) => [String(m.id), m.name])), st.assignee, (v) => { st.assignee = v; draw(); });
    const holder = h('div');
    function drawSeg() { seg.replaceChildren(FL.map(([k, l]) => h('button', { type: 'button', class: st.filter === k ? 'on' : '', onclick: () => { st.filter = k; drawSeg(); draw(); } }, l + (counts[k] && k !== 'all' ? ' ' + counts[k] : '')))); }
    q.addEventListener('input', () => { st.q = q.value; draw(); });
    function rowsNow() {
      const s = st.q.trim().toLowerCase();
      return all.filter(F[st.filter] || F.all).filter((t) => (!st.cat || t.category === st.cat) && (!st.assignee || (st.assignee === 'none' ? t.assigned_to == null : String(t.assigned_to) === st.assignee))
        && (!s || [t.code, t.title, t.requester, t.department, t.assignee, t.details, t.sub, t.asset_code, t.resolution].some((x) => x && String(x).toLowerCase().indexOf(s) >= 0)));
    }
    function draw() {
      const rows = rowsNow();
      holder.replaceChildren(App.grid({
        rows: rows, sortKey: 'due', sortDir: 1, onRow: (t) => App.openTicket(t.id), emptyTitle: st.filter === 'open' ? 'No open tickets' : 'No tickets here', emptyText: 'Use New > Ticket when someone calls with a problem.',
        cols: [
          { k: 'priority', label: '', cls: 'row-bar', render: (t) => h('div', { class: 'sev-bar', style: { '--c': { critical: 'var(--c-overdue)', high: 'var(--c-urgent)', medium: 'var(--c-warning)', low: 'var(--line)' }[t.priority], minHeight: '34px' } }) },
          { k: 'code', label: 'Ticket', sort: (t) => t.id, render: (t) => h('div', null, h('span', { class: 'ttl' }, h('span', { class: 'mono muted' }, t.code + '  '), t.title), h('span', { class: 'sub' }, [t.requester, t.department, App.plantText(t.plant)].filter((x) => x && x !== '—').join(' · '))) },
          { k: 'category', label: 'Type', sort: true, render: (t) => h('div', null, App.label(cats, t.category).replace(/ \(.*\)/, ''), t.sub ? h('span', { class: 'sub' }, t.sub) : null) },
          { k: 'assignee', label: 'Assigned to', sort: (t) => t.assignee || 'zzz', render: (t) => (t.is_open ? App.whoSelect(t.assigned_to, async (v) => { await POST('/api/tickets/' + t.id + '/do', { do: 'assign', to: v === '' ? null : +v }); toast(v === '' ? 'Taken back' : 'Assigned to ' + App.memberName(v)); App.refresh(); }, { attrs: { class: 'sel-inline', 'aria-label': 'Assign ' + t.code } }) : h('span', null, t.assignee || '—')) },
          { k: 'status', label: 'Status', sort: true, render: (t) => h('div', null, App.ticketStatus(t.status), t.status === 'waiting' && t.waiting_for ? h('span', { class: 'sub', title: t.waiting_for }, t.waiting_for.slice(0, 28)) : null) },
          { k: 'due', label: 'Due', cls: 'nw', sort: (t) => (t.is_open ? t.due_at || '9999' : '9999-' + (t.closed_at || '')), render: (t) => App.dueText(t) },
          { k: 'age', label: 'Age', cls: 'num', sort: (t) => t.age_hours, render: (t) => App.ageText(t.age_hours) }
        ]
      }));
    }
    root.replaceChildren(
      h('div', { class: 'page-h' }, h('div', null, h('h1', null, 'Tickets'), h('div', { class: 'sub' }, 'Every problem and request from the three plants - who has it and whether it is really done.')), h('span', { class: 'grow' }), App.btn('New ticket', () => App.newTicket(), 'primary', 'plus')),
      h('div', { class: 'tools' }, seg, h('div', { class: 'grow', style: { minWidth: '180px' } }, q), catSel, asSel), holder);
    drawSeg(); draw();
  };

  /* ---------- new ticket ---------- */
  App.newTicket = function (pre) {
    pre = pre || {};
    const cats = App.vocab().categories;
    const fields = [
      { k: 'title', label: 'What is the problem or request?', req: true, t: 'text', wide: true, ph: 'e.g. Laptop not starting · Create SAP user for new clerk · Mouse not working' },
      { k: 'category', label: 'Type', t: 'select', opts: cats.map((c) => [c.key, c.label]) },
      { k: 'req_type', label: 'What kind of SAP user request', t: 'select', opts: App.vocab().sap_req.map((c) => [c.key, c.label]) },
      { k: 'sub', label: 'Which item (optional)', t: 'text', list: 'dl-sub', ph: 'Laptop, Mouse, Printer…' },
      { k: 'person_id', label: 'Who reported it', t: 'person', free: true },
      { k: 'plant', label: 'Plant', t: 'select', opts: [['', '—']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) },
      { k: 'priority', label: 'Priority', t: 'select', opts: App.vocab().priorities.map((p) => [p, cap(p)]) },
      { k: 'assigned_to', label: 'Give it to', t: 'who', noneLabel: '— decide later —' },
      { k: 'due_at', label: 'Finish by', t: 'datetime', hint: 'Filled from the priority; change it if needed.' },
      { k: 'source', label: 'How did it reach you', t: 'select', opts: App.vocab().sources.map((s) => [s.key, s.label]) },
      { k: 'details', label: 'Details', t: 'area', wide: true, ph: 'Anything the team needs to know: error text, place, phone number…' }
    ];
    const f = App.makeForm(fields, Object.assign({ category: 'hardware', priority: 'medium', plant: App.plantFilter() || '', source: 'phone' }, pre));
    const dl = h('datalist', { id: 'dl-sub' });
    const sub = (k) => dl.replaceChildren((SUBS[k] || []).map((x) => h('option', { value: x })));
    const reqFld = f.ctl.req_type.closest('.fld');
    let dueTouched = false, assetId = pre.asset_id || null;
    function sync() { const c = f.ctl.category.value; sub(c); reqFld.style.display = c === 'sap_user' ? '' : 'none'; }
    function dueFromPrio() { if (dueTouched) return; const hrs = parseFloat(App.settings()['sla_' + f.ctl.priority.value] || 24); const d = new Date(Date.now() + hrs * 3600000); const p = (n) => String(n).padStart(2, '0'); f.ctl.due_at.value = d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes()); }
    f.ctl.category.addEventListener('change', sync); f.ctl.priority.addEventListener('change', dueFromPrio); f.ctl.due_at.addEventListener('change', () => { dueTouched = true; });
    sync(); dueFromPrio();
    // the reporter's own devices as one-click chips
    const devs = h('div', { class: 'fld', style: { gridColumn: '1 / -1' } });
    async function showDevs() {
      const pid = f.ctl.person_id.get(); devs.replaceChildren(); if (!pid) return;
      const p = await GET('/api/people/' + pid);
      if (p.plant && !f.ctl.plant.value) f.ctl.plant.value = p.plant;
      if (!p.holdings.length) return;
      const wrap = h('div', { class: 'chipbtns' }, p.holdings.map((x) => h('button', { type: 'button', class: 'chipbtn' + (assetId === x.asset_id ? ' on' : ''), onclick: (e) => { assetId = assetId === x.asset_id ? null : x.asset_id; wrap.querySelectorAll('button').forEach((b) => b.classList.remove('on')); if (assetId) e.currentTarget.classList.add('on'); } }, x.code + ' ' + App.kindLabel(x.kind) + (x.name ? ' · ' + x.name : ''))));
      devs.replaceChildren(h('label', null, 'Is it about one of their items? (tap to link)'), wrap);
    }
    f.ctl.person_id.addEventListener('pick', showDevs);
    const solved = h('input', { type: 'checkbox' }), res = h('textarea', { placeholder: 'What did you do to solve it?', style: { minHeight: '52px' } });
    const resBox = h('div', { class: 'hide' }, res);
    solved.addEventListener('change', () => resBox.classList.toggle('hide', !solved.checked));
    const m = modal({ title: 'New ticket', cls: 'wide', body: [f.el, devs, h('label', { class: 'row', style: { marginTop: '12px' } }, solved, 'I already solved it - just keep a record'), resBox, dl],
      actions: [{ label: 'Cancel' }, { label: 'Create ticket', cls: 'primary', close: false, onClick: async () => {
        const v = f.get();
        if (!v.title.trim()) { toast('Write the problem first', 'err'); return false; }
        const body = { title: v.title, category: v.category, req_type: v.req_type, sub: v.sub, plant: v.plant, priority: v.priority, due_at: v.due_at || null, source: v.source, details: v.details, person_id: v.person_id, asset_id: assetId };
        if (!v.person_id && f.ctl.person_id.text()) body.requester = f.ctl.person_id.text();
        if (v.assigned_to != null) body.assigned_to = v.assigned_to;
        if (solved.checked) { body.solved = true; body.resolution = res.value; }
        try { const t = await POST('/api/tickets', body); m.close(); toast(t.code + ' created' + (t.assignee ? ' - ' + t.assignee : '')); if (pre.after) pre.after(t); App.refresh(); } catch (e) { /* shown */ }
        return false;
      } }] });
    setTimeout(() => f.ctl.title.focus(), 60);
  };

  /* ---------- ticket drawer ---------- */
  App.openTicket = async function (id) {
    const dr = App.drawer({ aria: 'Ticket' });
    async function render() {
      let t;
      try { t = await GET('/api/tickets/' + id); } catch (e) { return dr.close(); }
      const cats = App.vocab().categories;
      const act = async (body, msg) => { await POST('/api/tickets/' + id + '/do', body); if (msg) toast(msg); await render(); App.refresh(); };
      const title = h('input', { class: 'dr-title', value: t.title, 'aria-label': 'Problem', onchange: async () => { if (!title.value.trim()) { title.value = t.title; return; } await PUT('/api/tickets/' + id, { title: title.value }); render(); App.refresh(); } });
      dr.setHead([h('div', { class: 'row wrap', style: { marginBottom: '4px', paddingRight: '34px' } }, App.mono(t.code), App.ticketStatus(t.status), App.prio(t.priority), t.plant ? App.tag(App.plantText(t.plant)) : null, t.overdue ? App.chip('Overdue', 'var(--c-overdue)') : null, t.sla_met === false ? App.chip('Closed late', 'var(--c-warning)') : null), title,
        h('div', { class: 'muted small' }, 'Reported by ' + (t.requester || '—') + (t.department ? ', ' + t.department : '') + (t.contact ? ' · ' + t.contact : '') + ' · received ' + fmtTs(t.received_at) + ' (' + App.label(App.vocab().sources, t.source) + ')')]);

      /* status + assignment */
      const asSel = App.whoSelect(t.assigned_to, (v) => act({ do: 'assign', to: v === '' ? null : +v }, v === '' ? 'Taken back' : 'Assigned to ' + App.memberName(v)), { attrs: { 'aria-label': 'Assigned to' }, noneLabel: '— nobody yet —' });
      const due = h('input', { type: 'datetime-local', value: App.dtLocal(t.due_at), onchange: async () => { await PUT('/api/tickets/' + id, { due_at: due.value }); toast('Due time saved'); render(); App.refresh(); } });
      const member = App.team().find((m) => m.id === t.assigned_to);
      const buttons = [];
      if (t.status === 'new' || t.status === 'assigned') buttons.push(App.btn('Work has started', () => act({ do: 'status', status: 'progress' }, 'In progress'), 'primary'));
      if (t.status === 'waiting') buttons.push(App.btn('Back to in progress', () => act({ do: 'status', status: 'progress' }), 'primary'));
      if (t.is_open && t.status !== 'waiting') buttons.push(App.btn('Waiting…', () => waitDialog(t, act)));
      if (t.is_open) buttons.push(App.btn('Team says it is done', () => doneDialog(t, act)), App.btn('Close (I checked)', () => closeDialog(t, act), t.status === 'progress' ? '' : 'ghost'));
      if (t.status === 'done') buttons.push(App.btn('Checked - close it', () => closeDialog(t, act), 'primary'), App.btn('Not fixed - send back', () => backDialog(t, act), 'danger'));
      if (t.status === 'closed' || t.status === 'cancelled') buttons.push(App.btn('Re-open', () => backDialog(t, act, 'Why is it re-opened?'), ''));
      const statusBox = h('div', { class: 'box' + (t.status === 'done' ? ' warn' : t.overdue ? ' bad' : '') },
        t.status === 'done' ? h('div', { style: { marginBottom: '8px' } }, h('b', null, 'The team says this is done. '), 'Check with the user, then close it.' + (t.resolution ? '' : '')) : null,
        h('div', { class: 'grid3' }, App.fld('Assigned to', asSel), App.fld('Finish by', due), App.fld('Follow up on', h('input', { type: 'date', value: t.follow_up_on || '', onchange: (e) => act({ do: 'follow', date: e.target.value }, e.target.value ? 'Follow-up set' : 'Follow-up cleared') }))),
        h('div', { class: 'acts', style: { marginTop: '10px' } }, buttons, t.assigned_to != null && t.is_open ? App.btn('Message ' + (member ? member.name : 'me'), () => App.sendDialog('Message for ' + (App.memberName(t.assigned_to)), App.ticketMessage(t), member && member.mobile), 'ghost', 'send') : null),
        t.status === 'waiting' ? h('div', { class: 'hint-box', style: { marginTop: '8px' } }, 'Waiting for: ' + (t.waiting_for || '—') + (t.follow_up_on ? ' · follow up on ' + fmtD(t.follow_up_on) : '')) : null,
        t.status === 'closed' || t.status === 'done' ? h('div', { style: { marginTop: '10px' } }, h('div', { class: 'lbl' }, 'What was done'), h('div', null, t.resolution || '—'), t.verify_note ? h('div', { class: 'muted small' }, 'Checked: ' + t.verify_note) : null, t.closed_at ? h('div', { class: 'muted small' }, 'Closed ' + fmtTs(t.closed_at) + ' · took ' + App.ageText(t.age_hours)) : null) : null);

      /* details form */
      const f = App.makeForm([
        { k: 'category', label: 'Type', t: 'select', opts: cats.map((c) => [c.key, c.label]) },
        { k: 'req_type', label: 'SAP request', t: 'select', opts: [['', '—']].concat(App.vocab().sap_req.map((c) => [c.key, c.label])) },
        { k: 'sub', label: 'Item', t: 'text', list: 'dl-sub2' },
        { k: 'priority', label: 'Priority', t: 'select', opts: App.vocab().priorities.map((p) => [p, cap(p)]) },
        { k: 'plant', label: 'Plant', t: 'select', opts: [['', '—']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) },
        { k: 'source', label: 'Received by', t: 'select', opts: App.vocab().sources.map((s) => [s.key, s.label]) },
        { k: 'person_id', label: 'Employee', t: 'person', includeLeft: true },
        { k: 'requester', label: 'Name (if not in People)', t: 'text' },
        { k: 'department', label: 'Department', t: 'text' }, { k: 'contact', label: 'Contact', t: 'text' },
        { k: 'asset_id', label: 'Device / item', t: 'asset', wide: true },
        { k: 'details', label: 'Details', t: 'area', wide: true }], t);
      const reqF = f.ctl.req_type.closest('.fld'); const syncReq = () => { reqF.style.display = f.ctl.category.value === 'sap_user' ? '' : 'none'; }; f.ctl.category.addEventListener('change', syncReq); syncReq();
      const dl2 = h('datalist', { id: 'dl-sub2' }, (SUBS[t.category] || []).map((x) => h('option', { value: x })));
      const details = h('div', null, h('div', { class: 'sec-h' }, h('h3', null, 'Problem details'), h('div', { class: 'acts' }, App.btn('Save changes', async () => { const v = f.get(); if (!v.person_id && !v.requester && f.ctl.person_id.text()) v.requester = f.ctl.person_id.text(); await PUT('/api/tickets/' + id, v); toast('Saved'); render(); App.refresh(); }, 'sm primary'))), f.el, dl2);
      const side = h('div', { class: 'stack' },
        t.person ? h('div', { class: 'box' }, h('h3', null, t.person.name), h('div', { class: 'muted small' }, [t.person.emp_code, t.person.department, t.person.plant].filter(Boolean).join(' · ')), h('div', { style: { marginTop: '6px' } }, h('button', { class: 'lnk', type: 'button', onclick: () => App.openPerson(t.person.id) }, 'Open the record (items, ids)'))) : null,
        t.asset ? h('div', { class: 'box' }, h('h3', null, t.asset.code + ' ' + App.kindLabel(t.asset.kind)), h('div', { class: 'muted small' }, [t.asset.name, t.asset.serial].filter(Boolean).join(' · ')), h('div', { style: { marginTop: '6px' } }, h('button', { class: 'lnk', type: 'button', onclick: () => App.openAsset(t.asset.id) }, 'Open the item (history, repairs)'))) : null,
        t.related.length ? h('div', { class: 'box' }, h('h3', null, 'Other tickets of the same person / item'), t.related.map((r) => h('div', { class: 'row', style: { padding: '3px 0' } }, h('button', { class: 'lnk trunc', type: 'button', onclick: () => App.openTicket(r.id) }, r.code + ' ' + r.title), h('span', { class: 'grow' }), App.ticketStatus(r.status)))) : null,
        h('div', { class: 'box' }, h('h3', null, 'Make a record'), h('div', { class: 'acts' },
          App.btn('Link a purchase', () => App.newPurchase({ ticket_id: id, plant: t.plant, person_id: t.person_id }), 'sm'), App.btn('Issue / return item', () => App.issueDialog({ person_id: t.person_id, ticket_id: id }), 'sm'))));
      dr.body.replaceChildren(statusBox, h('div', { class: 'cols2', style: { marginTop: '20px' } }, details, side),
        h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'Notes and history')), App.noteBox(async (text, who) => { await act({ do: 'note', text: text, who: who }); }), App.timeline(t.history)),
        h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'Photos and files'), h('span', { class: 'cnt' }, t.files.length || ''), h('div', { class: 'acts' }, App.btn('Open folder', async () => { await POST('/api/open-folder', { kind: 'ticket', id: id }); }, 'sm ghost', 'folder'))), App.filesSection('ticket', id, t.files, async () => { await render(); App.refresh(); })),
        h('section', { style: { marginTop: '28px', borderTop: '1px solid var(--line)', paddingTop: '14px' } }, t.is_open ? App.btn('Cancel this ticket', async () => { const n = prompt('Why is it cancelled? (duplicate, no longer needed…)'); if (n === null) return; await act({ do: 'cancel', note: n }, 'Cancelled'); }, 'sm ghost') : null,
          App.btn('Delete ticket', async () => { if (await confirmBox('Delete ' + t.code + ' and its files? This cannot be undone. (Cancel keeps the record.)')) { await DEL('/api/tickets/' + id); dr.close(); toast('Deleted'); App.refresh(); } }, 'sm ghost danger')));
    }
    dr.body.replaceChildren(App.spin());
    await render();
  };

  function ask(title, label, value, ok, extra, onOk, req) {
    const ta = h('textarea', { style: { minHeight: '84px' }, placeholder: label }, value || '');
    const more = extra ? extra() : null;
    const m = modal({ title: title, body: [h('div', { class: 'fld' }, h('label', null, label), ta), more ? more.el : null],
      actions: [{ label: 'Cancel' }, { label: ok, cls: 'primary', close: false, onClick: async () => { if (req !== false && ta.value.trim().length < 3) { toast('Write a few words first', 'err'); return false; } try { await onOk(ta.value.trim(), more); m.close(); } catch (e) { /* shown */ } return false; } }] });
    setTimeout(() => ta.focus(), 50);
  }
  function waitDialog(t, act) {
    const d = h('input', { type: 'date' });
    ask('Waiting - for what?', 'Waiting for…', t.waiting_for, 'Mark as waiting', () => ({ el: App.fld('Follow up on', d, 'You will see it on Today when the date comes.') }), (txt) => act({ do: 'status', status: 'waiting', waiting_for: txt, follow_up_on: d.value || null }, 'Marked as waiting'));
  }
  function doneDialog(t, act) { ask('The team finished the work', 'What was done?', t.resolution, 'Mark as done', null, (txt) => act({ do: 'status', status: 'done', resolution: txt }, 'Waiting for your check')); }
  function closeDialog(t, act) {
    const v = h('input', { type: 'text', placeholder: 'e.g. called the user, tested printing' });
    ask('Close ' + t.code, 'What was done? (the solution)', t.resolution, 'Close ticket', () => ({ el: App.fld('How did you check it? (optional)', v) }), (txt) => act({ do: 'close', resolution: txt, verify_note: v.value }, 'Closed'));
  }
  function backDialog(t, act, label) { ask(label ? 'Re-open ' + t.code : 'Send back to the team', label || 'What is still wrong?', '', label ? 'Re-open' : 'Send back', null, (txt) => act({ do: 'reopen', note: txt }, 'Re-opened')); }
})();
