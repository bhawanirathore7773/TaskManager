/* Stock and assets: summary by type, item list, add to stock, item drawer, take back / replace / repair / scrap. */
(function () {
  'use strict';
  const { h, ico, GET, POST, PUT, DEL, toast, modal, confirmBox, fmtTs, fmtD, load } = App;
  const me = () => App.settings().manager || '';
  const lbl = (list, key) => App.label(list, key);
  const isBulk = (kind) => !!(App.vocab().asset_kinds.find((k) => k.key === kind) || {}).bulk;
  const condChip = (c) => App.chip(lbl(App.vocab().conditions, c), { new: 'var(--c-ok)', good: 'var(--c-ok)', fair: 'var(--c-warning)', poor: 'var(--c-overdue)' }[c]);
  const warrantyChip = (a) => (a.warranty_left == null ? null : a.warranty_left < 0 ? App.chip('Warranty over ' + fmtD(a.warranty_until), 'var(--ink-3)') : App.chip('Warranty ' + (a.warranty_left <= 90 ? a.warranty_left + ' days left' : 'till ' + fmtD(a.warranty_until)), a.warranty_left <= 60 ? 'var(--c-warning)' : 'var(--c-ok)'));

  /* ====================== list ====================== */
  App.V.stock = async function (root, params) {
    const st = App.S.sk = App.S.sk || { filter: 'active', kind: '', q: '' };
    if (params.kind != null) { st.kind = params.kind; st.filter = 'active'; }
    const [sum, assets] = await Promise.all([GET('/api/stock/summary'), load('assets')]);
    const plant = App.plantFilter();
    const here = assets.filter((a) => !plant || a.plant === plant || (a.person_id && a.holder_plant === plant));
    const AF = {
      active: (a) => a.status !== 'scrap', instock: (a) => (a.tracked ? a.status === 'in_stock' : a.qty_free > 0), issued: (a) => (a.tracked ? a.status === 'issued' || a.status === 'deployed' : a.qty_out > 0),
      repair: (a) => a.status === 'repair' || a.status === 'lost', scrap: (a) => a.status === 'scrap', all: () => true
    };
    const AL = [['active', 'Active'], ['instock', 'In stock'], ['issued', 'Issued'], ['repair', 'Repair / lost'], ['scrap', 'Scrapped'], ['all', 'All']];
    const seg = h('div', { class: 'seg' }), holder = h('div'), cards = h('div', { class: 'sum-grid' });
    const q = h('input', { type: 'search', placeholder: 'Search serial no., tag, make, name, user…', value: st.q });
    const ksel = App.sel([['', 'All types']].concat(App.vocab().asset_kinds.map((k) => [k.key, k.label])), st.kind, (v) => { st.kind = v; drawCards(); rows(); });
    function drawSeg() { seg.replaceChildren(AL.map(([k, l]) => h('button', { type: 'button', class: st.filter === k ? 'on' : '', onclick: () => { st.filter = k; drawSeg(); rows(); } }, l))); }
    function drawCards() {
      cards.replaceChildren(sum.map((k) => {
        const n = plant ? (k.by_plant[plant] || 0) : k.in_stock;
        return h('button', { type: 'button', class: 'sum-card' + (st.kind === k.kind ? ' on' : '') + (k.low && !plant ? ' low' : ''), onclick: () => { st.kind = st.kind === k.kind ? '' : k.kind; ksel.value = st.kind; drawCards(); rows(); } },
          h('b', { class: 'big' }, n), h('div', { class: 'l' }, k.label + ' in stock' + (plant ? ' · ' + plant : '')),
          h('div', { class: 'm' }, k.issued + ' issued' + (k.deployed ? ' · ' + k.deployed + ' fixed at places' : '') + (k.repair ? ' · ' + k.repair + ' in repair' : '')),
          k.low && !plant ? h('div', { class: 'lowtag' }, 'Low - minimum ' + k.min + (k.on_order ? ', ' + k.on_order + ' on order' : ', none on order')) : (k.on_order ? h('div', { class: 'm' }, k.on_order + ' on order') : null));
      }));
    }
    q.addEventListener('input', () => { st.q = q.value; rows(); });
    function rows() {
      const s = st.q.trim().toLowerCase();
      const list = here.filter(AF[st.filter] || AF.all).filter((a) => (!st.kind || a.kind === st.kind) && (!s || [a.code, a.name, a.serial, a.tag, a.holder, a.location, a.vendor, a.specs, App.kindLabel(a.kind)].some((x) => x && String(x).toLowerCase().indexOf(s) >= 0)));
      holder.replaceChildren(App.grid({
        rows: list, sortKey: 'code', sortDir: -1, onRow: (a) => App.openAsset(a.id), emptyTitle: 'No items here', emptyText: 'Use "Add to stock" to register laptops, PCs, mouse, keyboards and other items.',
        cols: [
          { k: 'code', label: 'Item', sort: (a) => a.id, render: (a) => h('div', null, h('span', { class: 'ttl' }, h('span', { class: 'mono muted' }, a.code + '  '), App.kindLabel(a.kind) + (a.name ? ' · ' + a.name : '')), h('span', { class: 'sub' }, a.tracked ? [a.serial ? 'S/N ' + a.serial : '', a.tag ? 'tag ' + a.tag : ''].filter(Boolean).join(' · ') || 'no serial recorded' : 'counted item')) },
          { k: 'status', label: 'Status', sort: (a) => a.status, render: (a) => (a.tracked ? App.assetStatus(a.status) : h('span', null, App.chip(a.qty_free + ' of ' + a.qty + ' free', a.qty_free ? 'var(--c-ok)' : 'var(--c-warning)'))) },
          { k: 'where', label: 'With / at', sort: (a) => (a.holder || a.location || '').toLowerCase(), render: (a) => (a.holder ? h('button', { class: 'lnk', type: 'button', onclick: () => App.openPerson(a.person_id) }, a.holder) : a.location || (a.tracked ? '' : (a.qty_out ? a.qty_out + ' issued' : ''))) },
          { k: 'plant', label: 'Plant', cls: 'nw', sort: true, render: (a) => App.plantText(a.plant) },
          { k: 'cond', label: 'Condition', cls: 'nw', sort: true, render: (a) => condChip(a.cond) },
          { k: 'used', label: 'History', cls: 'nw', sort: (a) => a.times_issued, render: (a) => (a.tracked ? (a.times_issued ? 'issued ' + a.times_issued + '×' : 'new') : '') },
          { k: 'warranty', label: 'Warranty', cls: 'nw', sort: (a) => (a.warranty_until || '9999'), render: (a) => (a.warranty_until ? h('span', { class: a.warranty_left != null && a.warranty_left < 0 ? 'muted' : a.warranty_left <= 60 ? 'due-soon' : '' }, fmtD(a.warranty_until)) : '—') }
        ]
      }));
    }
    root.replaceChildren(
      h('div', { class: 'page-h' }, h('div', null, h('h1', null, 'Stock & assets'), h('div', { class: 'sub' }, 'What is in stock, who has which laptop, what is in repair - with the full history of every item.')), h('span', { class: 'grow' }),
        App.btn('Issue an item', () => App.issueDialog({}), '', 'laptop'), App.btn('Add to stock', () => App.addStock(), 'primary', 'plus')),
      cards, h('div', { class: 'tools' }, seg, h('div', { class: 'grow', style: { minWidth: '180px' } }, q), ksel), holder);
    drawSeg(); drawCards(); rows();
  };

  /* ====================== add to stock ====================== */
  App.addStock = function (pre) {
    pre = pre || {};
    const kinds = App.vocab().asset_kinds;
    const f = App.makeForm([
      { k: 'kind', label: 'Type', t: 'select', opts: kinds.map((k) => [k.key, k.label]) },
      { k: 'name', label: 'Make / model', ph: 'e.g. Dell Latitude 3420, i5 8GB 512GB' },
      { k: 'plant', label: 'Kept at plant', t: 'select', opts: [['', '—']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) },
      { k: 'cond', label: 'Condition', t: 'select', opts: App.vocab().conditions.map((c) => [c.key, c.label]) },
      { k: 'serial', label: 'Serial number', ph: 'from the sticker at the back' },
      { k: 'tag', label: 'Asset tag (company sticker)' },
      { k: 'qty', label: 'How many', t: 'number', min: 1 },
      { k: 'min_qty', label: 'Tell me when stock falls below', t: 'number', min: 0, hint: 'Optional. Mouse, keyboard etc.' },
      { k: 'more_serials', label: 'More serial numbers (same make, one per line)', t: 'area', wide: true, ph: 'Add several identical laptops at once: one serial number per line' },
      { k: 'purchase_date', label: 'Purchase date', t: 'date' }, { k: 'vendor', label: 'Vendor' },
      { k: 'cost', label: 'Cost per item', t: 'number', min: 0, step: 'any' }, { k: 'warranty_until', label: 'Warranty until', t: 'date' },
      { k: 'location', label: 'Place / shelf', ph: 'e.g. IT store, cupboard 2' },
      { k: 'issue_to', label: 'Already with an employee?', t: 'person', hint: 'Use this when you register a laptop that someone already uses.' },
      { k: 'specs', label: 'Specification', t: 'area', wide: true, ph: 'RAM, disk, accessories in the box…' }],
      Object.assign({ kind: 'laptop', cond: 'new', qty: 1, plant: App.plantFilter() || '', location: '' }, pre));
    const fld = (k) => f.ctl[k].closest('.fld');
    function sync() {
      const bulk = isBulk(f.ctl.kind.value);
      ['serial', 'tag', 'more_serials'].forEach((k) => { fld(k).style.display = bulk ? 'none' : ''; });
      ['qty', 'min_qty'].forEach((k) => { fld(k).style.display = bulk ? '' : 'none'; });
      fld('issue_to').style.display = bulk ? 'none' : '';
      f.ctl.name.placeholder = bulk ? 'e.g. Logitech M90 USB mouse' : 'e.g. Dell Latitude 3420, i5 8GB 512GB';
    }
    f.ctl.kind.addEventListener('change', sync); sync();
    const m = modal({ title: 'Add to stock', cls: 'wide', body: [f.el, h('div', { class: 'hint-box', style: { marginTop: '10px' } }, 'Laptops, PCs, monitors, printers: one record per item, with its serial number. Mouse, keyboard, cables, pen drives: one record with a quantity.')],
      actions: [{ label: 'Cancel' }, { label: 'Add to stock', cls: 'primary', close: false, onClick: async () => {
        const v = f.get(), bulk = isBulk(v.kind);
        if (!bulk && !v.name.trim() && !v.serial.trim() && !v.more_serials.trim()) { toast('Write the make / model or the serial number', 'err'); return false; }
        if (bulk && (!v.qty || v.qty < 1)) { toast('How many?', 'err'); return false; }
        const body = Object.assign({}, v, { who: me() });
        if (bulk) { delete body.serial; delete body.tag; delete body.more_serials; delete body.issue_to; }
        if (!body.issue_to) delete body.issue_to;
        if (body.cost === null) delete body.cost;
        try {
          const a = await POST('/api/assets', body);
          m.close(); toast((a.created_ids.length > 1 ? a.created_ids.length + ' items' : a.code) + ' added' + (body.issue_to ? ' and given to the employee' : ''));
          App.refresh(); if (pre.after) pre.after(a);
        } catch (e) { /* shown */ }
        return false;
      } }] });
    setTimeout(() => f.ctl.name.focus(), 60);
  };

  /* ====================== small operation dialogs ====================== */
  function conditionSelect(value) { return App.sel(App.vocab().conditions.map((c) => [c.key, c.label]), value || 'good'); }
  function opDialog(a, o) {
    // o: {op, title, ok, label, cls, noteReq, cond: current cond | true, qty: max, extra, after, ticket_id, text}
    const note = h('textarea', { style: { minHeight: '70px' }, placeholder: o.label || 'Note (optional)' }, o.text || '');
    const cond = o.cond ? conditionSelect(typeof o.cond === 'string' ? o.cond : a.cond) : null;
    const qty = o.qty ? h('input', { type: 'number', min: 1, max: o.qtyMax || null, value: o.qtyDefault || 1, style: { width: '110px' } }) : null;
    const m = modal({ title: o.title, body: [o.intro ? h('p', { style: { marginBottom: '10px' } }, o.intro) : null, qty ? App.fld('How many', qty) : null, cond ? h('div', { style: { margin: '8px 0' } }, App.fld('Condition now', cond)) : null, o.extra ? o.extra.el : null, App.fld(o.label || 'Note', note)],
      actions: [{ label: 'Cancel' }, { label: o.ok || 'Save', cls: o.cls || 'primary', close: false, onClick: async () => {
        if (o.noteReq && note.value.trim().length < 3) { toast('Write a few words first', 'err'); return false; }
        try {
          const body = Object.assign({ op: o.op, note: note.value, who: me(), ticket_id: o.ticket_id || null }, o.body ? o.body(o.extra) : {});
          if (cond) body.cond = cond.value;
          if (qty) body.qty = +qty.value;
          await POST('/api/assets/' + a.id + '/op', body);
          m.close(); toast(o.done || 'Saved'); App.refresh(); if (o.after) o.after();
        } catch (e) { /* shown */ }
        return false;
      } }] });
    setTimeout(() => note.focus(), 60);
  }

  // take an item back from an employee / place
  App.returnDialog = function (a, o) {
    o = o || {};
    const to = App.sel([['stock', 'Back in stock - fine to issue again'], ['repair', 'Needs repair first'], ['scrap', 'Scrap - no longer usable'], ['lost', 'Lost / not returned']], 'stock');
    opDialog(a, { op: 'return', title: 'Take back ' + a.code + ' ' + App.kindLabel(a.kind), ok: 'Take back', done: 'Taken back', label: 'Note (optional)', cond: a.cond || 'good', qty: !a.tracked, qtyMax: a.qty, qtyDefault: a.qty, after: o.after, ticket_id: o.ticket_id,
      intro: 'Check the item and its accessories, then say where it goes.', extra: { el: App.fld('Where does it go now?', to), to: to }, body: (x) => ({ to: x.to.value, person_id: o.person_id || null, location: o.location || '' }) });
  };

  // replace a broken item with another one from stock, in one step
  App.swapDialog = function (a, o) {
    o = o || {};
    const sp = App.stockPicker(a.kind, o.plant || App.plantFilter(), {});
    const to = App.sel([['repair', 'Needs repair'], ['stock', 'Back in stock'], ['scrap', 'Scrap']], 'repair');
    const note = h('textarea', { style: { minHeight: '56px' }, placeholder: 'What was wrong with the old one?' });
    const m = modal({ title: 'Replace ' + a.code + ' ' + App.kindLabel(a.kind), cls: 'wide', body: [h('p', { class: 'muted', style: { marginBottom: '8px' } }, 'The user gets the item you choose below. The old one is taken back and its history stays.'), sp, h('div', { style: { marginTop: '12px' } }, App.fld('The old item goes', to)), h('div', { style: { marginTop: '10px' } }, App.fld('Reason', note))],
      actions: [{ label: 'Cancel' }, { label: 'Replace', cls: 'primary', close: false, onClick: async () => {
        const x = sp.value(); if (!x.asset_id) { toast('Nothing in stock to give. Order one first.', 'err'); return false; }
        try { await POST('/api/assets/' + a.id + '/op', { op: 'swap', new_asset_id: x.asset_id, to: to.value, note: note.value, who: me(), ticket_id: o.ticket_id || null }); m.close(); toast('Replaced'); App.refresh(); if (o.after) o.after(); } catch (e) { /* shown */ }
        return false;
      } }] });
  };

  /* ====================== item drawer ====================== */
  App.openAsset = async function (id) {
    const dr = App.drawer({ aria: 'Item' });
    dr.body.replaceChildren(App.spin());
    async function render() {
      let a;
      try { a = await GET('/api/assets/' + id); } catch (e) { return dr.close(); }
      const done = async () => { await render(); App.refresh(); };
      const k = a.kind;
      dr.setHead([h('div', { class: 'row wrap', style: { marginBottom: '4px', paddingRight: '34px' } }, App.mono(a.code), a.tracked ? App.assetStatus(a.status) : App.chip(a.qty_free + ' of ' + a.qty + ' free', a.qty_free ? 'var(--c-ok)' : 'var(--c-warning)'), App.tag(App.kindLabel(k)), a.plant ? App.tag(App.plantText(a.plant)) : null, condChip(a.cond), warrantyChip(a)),
        h('div', { style: { fontSize: '20px', fontWeight: '700', lineHeight: '1.25' } }, a.name || App.kindLabel(k)),
        h('div', { class: 'muted small' }, a.tracked ? [a.serial ? 'S/N ' + a.serial : 'no serial recorded', a.tag ? 'tag ' + a.tag : ''].filter(Boolean).join(' · ') : 'Counted item - ' + a.qty + ' in total')]);

      const acts = [];
      if (a.tracked) {
        if (a.status === 'in_stock') acts.push(App.btn('Issue', () => App.issueDialog({ asset_id: id, after: done }), 'primary', 'laptop'));
        if (a.status === 'issued' || a.status === 'deployed') acts.push(App.btn('Take back', () => App.returnDialog(a, { after: done }), 'primary'), a.status === 'issued' ? App.btn('Replace', () => App.swapDialog(a, { plant: a.holder_plant || a.plant, after: done }), '', 'swap') : null);
        if (['in_stock', 'issued', 'deployed'].indexOf(a.status) >= 0) acts.push(App.btn('Send for repair', () => opDialog(a, { op: 'repair', title: 'Send ' + a.code + ' for repair', label: 'What is the fault? Who takes it (vendor)?', noteReq: true, ok: 'Send for repair', done: 'Marked in repair', after: done }), ''));
        if (a.status === 'repair') acts.push(App.btn('Back from repair', () => opDialog(a, { op: 'repaired', title: a.code + ' is back from repair', label: 'What was done? Cost?', ok: 'Back from repair', cond: 'good', done: 'Back from repair', after: done }), 'primary'));
        if (a.status === 'lost') acts.push(App.btn('Found again', () => opDialog(a, { op: 'found', title: a.code + ' found', ok: 'Found', done: 'Found', after: done }), 'primary'));
        if (['issued', 'deployed', 'repair'].indexOf(a.status) >= 0) acts.push(App.btn('Mark lost', () => opDialog(a, { op: 'lost', title: 'Mark ' + a.code + ' as lost', label: 'What happened?', noteReq: true, ok: 'Mark lost', cls: 'danger', done: 'Marked lost', after: done }), 'ghost danger'));
        if (['in_stock', 'repair', 'lost'].indexOf(a.status) >= 0) acts.push(App.btn('Scrap', () => opDialog(a, { op: 'scrap', title: 'Scrap ' + a.code, intro: 'The item is no longer usable. It stays in the history; it is not counted in stock.', label: 'Why is it scrapped?', noteReq: true, ok: 'Scrap', cls: 'danger', done: 'Scrapped', after: done }), 'ghost danger'));
      } else {
        acts.push(App.btn('Issue', () => App.issueDialog({ asset_id: id, after: done }), 'primary', 'laptop'), App.btn('Add stock', () => opDialog(a, { op: 'restock', title: 'Add to stock: ' + (a.name || App.kindLabel(k)), qty: true, ok: 'Add', label: 'Note (bill no., vendor…)', done: 'Added to stock', after: done }), '', 'plus'));
      }
      acts.push(App.btn('New ticket', () => App.newTicket({ asset_id: id, plant: a.holder_plant || a.plant, person_id: a.person_id || null, after: done }), 'ghost', 'ticket'));

      /* who has it */
      let holderBox = null;
      if (a.tracked && a.person_id) holderBox = h('div', { class: 'box' }, h('div', { class: 'muted small' }, 'With'), h('div', null, h('button', { class: 'lnk', type: 'button', style: { fontSize: '15px' }, onclick: () => App.openPerson(a.person_id) }, a.holder), a.holder_status === 'left' ? h('span', { class: 'due-over', style: { marginLeft: '8px' } }, 'has left - collect it') : null), h('div', { class: 'muted small' }, 'since ' + fmtD(a.since, true)));
      else if (a.tracked && a.status === 'deployed') holderBox = h('div', { class: 'box' }, h('div', { class: 'muted small' }, 'Fixed at'), h('b', null, a.location || '—'), h('div', { class: 'muted small' }, 'since ' + fmtD(a.since, true)));
      else if (!a.tracked && a.holders.length) holderBox = h('div', { class: 'box' }, h('h3', null, 'Who has them'), h('div', { class: 'stack', style: { gap: '4px' } }, a.holders.map((x) => h('div', { class: 'row' },
        x.person_id ? h('button', { class: 'lnk', type: 'button', onclick: () => App.openPerson(x.person_id) }, x.name) : h('span', null, x.location || '—'), h('span', { class: 'grow' }), h('b', null, x.qty),
        App.btn('Take back', () => App.returnDialog(a, { person_id: x.person_id, location: x.location, after: done }), 'sm')))));
      const kv = (k2, v) => (v || v === 0 ? [h('dt', null, k2), h('dd', null, v)] : null);
      const details = h('div', { class: 'box' }, h('div', { class: 'sec-h' }, h('h3', null, 'Details'), h('div', { class: 'acts' }, App.btn('Edit', () => editDialog(a, done), 'sm', 'edit'))),
        h('dl', { class: 'kv' }, kv('Make / model', a.name), a.tracked ? kv('Serial no.', a.serial) : null, a.tracked ? kv('Asset tag', a.tag) : null, kv('Plant', a.plant ? App.plantText(a.plant) : ''), kv('Place', a.location), kv('Bought', a.purchase_date ? fmtD(a.purchase_date, true) : ''),
          kv('Vendor', a.vendor), kv('Cost', a.cost != null ? '₹ ' + Number(a.cost).toLocaleString('en-IN') : ''), kv('Warranty', a.warranty_until ? fmtD(a.warranty_until, true) : ''), a.tracked ? kv('Issued', a.times_issued ? a.times_issued + ' time(s)' + (a.last_return ? ', last returned ' + fmtD(a.last_return) : '') : 'never - new') : null,
          !a.tracked ? kv('Minimum stock', a.min_qty || '') : null, kv('Specification', a.specs), kv('Note', a.note)));
      const tix = h('div', { class: 'box' }, h('h3', null, 'Tickets about this item'), a.tickets.length ? a.tickets.slice(0, 10).map((t) => h('div', { class: 'row', style: { padding: '3px 0' } }, h('button', { class: 'lnk trunc', type: 'button', onclick: () => App.openTicket(t.id) }, t.code + '  ' + t.title), h('span', { class: 'grow' }), App.ticketStatus(t.status))) : h('div', { class: 'muted small' }, 'No tickets yet.'));
      dr.body.replaceChildren(h('div', { class: 'acts', style: { marginBottom: '16px' } }, acts),
        h('div', { class: 'cols2' }, h('div', { class: 'stack' }, holderBox, details), h('div', { class: 'stack' }, tix)),
        h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'Invoice, warranty card, photos'), h('span', { class: 'cnt' }, a.files.length || ''), h('div', { class: 'acts' }, App.btn('Open folder', () => POST('/api/open-folder', { kind: 'asset', id: id }), 'sm ghost', 'folder'))), App.filesSection('asset', id, a.files, done, { cat: 'invoice' })),
        h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'History of this item')), App.noteBox(async (text, who) => { await POST('/api/assets/' + id + '/op', { op: 'note', note: text, who: who || me() }); done(); }, { ph: 'Write a note (for example: screen scratch, charger missing)…', noKnown: true }), App.timeline(a.history)),
        h('section', { style: { marginTop: '28px', borderTop: '1px solid var(--line)', paddingTop: '14px' } }, App.btn('Delete this record', async () => { if (await confirmBox('Delete ' + a.code + '? Only possible if it was never issued or used in a ticket - otherwise use Scrap.')) { await DEL('/api/assets/' + id); dr.close(); toast('Deleted'); App.refresh(); } }, 'sm ghost danger')));
    }
    await render();
  };

  function editDialog(a, after) {
    const fields = [{ k: 'kind', label: 'Type', t: 'select', opts: App.vocab().asset_kinds.map((x) => [x.key, x.label]), hint: a.times_issued ? 'Cannot be changed - already issued once.' : '' },
      { k: 'name', label: 'Make / model' }, { k: 'plant', label: 'Plant', t: 'select', opts: [['', '—']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) }, { k: 'cond', label: 'Condition', t: 'select', opts: App.vocab().conditions.map((c) => [c.key, c.label]) }]
      .concat(a.tracked ? [{ k: 'serial', label: 'Serial number' }, { k: 'tag', label: 'Asset tag' }] : [{ k: 'min_qty', label: 'Tell me when stock falls below', t: 'number' }])
      .concat([{ k: 'location', label: 'Place' }, { k: 'purchase_date', label: 'Purchase date', t: 'date' }, { k: 'vendor', label: 'Vendor' }, { k: 'cost', label: 'Cost', t: 'number', step: 'any' }, { k: 'warranty_until', label: 'Warranty until', t: 'date' },
        { k: 'specs', label: 'Specification', t: 'area', wide: true }, { k: 'note', label: 'Note', t: 'area', wide: true }]);
    App.formDialog({ title: 'Edit ' + a.code, cls: 'wide', fields: fields, values: a, onSave: async (v) => {
      if (v.cost === null) v.cost = '';
      await PUT('/api/assets/' + a.id, v); toast('Saved'); await after();
    } });
  }
})();
