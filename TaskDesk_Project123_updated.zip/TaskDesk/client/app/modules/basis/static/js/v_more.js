/* Transports (TR to production), Team (who does what), Daily / weekly / monthly checks. */
(function () {
  'use strict';
  const { h, ico, GET, POST, PUT, DEL, toast, modal, confirmBox, fmtTs, fmtD, load } = App;
  const me = () => App.settings().manager || '';
  const lbl = (list, key) => App.label(list, key);
  const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  /* =============================================================== TRANSPORTS */
  const TF = {
    open: (t) => t.open, requested: (t) => t.status === 'requested', qas: (t) => t.status === 'qas', approved: (t) => t.status === 'approved', failed: (t) => t.status === 'failed' || t.status === 'hold',
    prd: (t) => t.status === 'prd', all: () => true
  };
  const TL = [['open', 'Open'], ['requested', 'Asked'], ['qas', 'In QAS'], ['approved', 'Approved - move it'], ['failed', 'Failed / on hold'], ['prd', 'In production'], ['all', 'All']];
  function miniFlow(t) {
    const f = t.status === 'failed';
    return h('span', { class: 'mini-flow', title: 'Requested → QAS → Approved → PRD' }, h('i', { class: 'on' }), h('i', { class: t.qas_on ? 'on' : '' }), h('i', { class: t.approved_on ? 'on' : '' }), h('i', { class: t.status === 'prd' ? 'on' : f ? 'bad' : '' }));
  }

  App.V.transports = async function (root, params) {
    const st = App.S.tr = App.S.tr || { filter: 'open', q: '' };
    if (params.filter) st.filter = params.filter;
    const all = await load('transports');
    const seg = h('div', { class: 'seg' }), holder = h('div');
    const q = h('input', { type: 'search', placeholder: 'Search TR number, description, who…', value: st.q });
    const count = (k) => all.filter(TF[k]).length;
    function segs() { seg.replaceChildren(TL.map(([k, l]) => h('button', { type: 'button', class: st.filter === k ? 'on' : '', onclick: () => { st.filter = k; segs(); rows(); } }, l + (['approved', 'failed'].indexOf(k) >= 0 && count(k) ? ' ' + count(k) : '')))); }
    q.addEventListener('input', () => { st.q = q.value; rows(); });
    function rows() {
      const s = st.q.trim().toLowerCase();
      const list = all.filter(TF[st.filter] || TF.all).filter((t) => !s || [t.tr_number, t.code, t.description, t.owner_name, t.requested_by, t.approver, t.note].some((x) => x && String(x).toLowerCase().indexOf(s) >= 0));
      holder.replaceChildren(App.grid({
        rows: list, sortKey: 'id', sortDir: -1, onRow: (t) => App.openTransport(t.id), emptyTitle: 'No transports here', emptyText: 'Add every TR that has to go to QAS or production, so nothing is moved without approval and nothing is forgotten.',
        cols: [
          { k: 'id', label: 'Transport', sort: (t) => t.id, render: (t) => h('div', null, h('span', { class: 'ttl' }, h('span', { class: 'mono' }, t.tr_number || t.code + '  '), '  ' + t.description), h('span', { class: 'sub' }, [t.owner_name ? 'made by ' + t.owner_name : '', t.requested_by ? 'asked by ' + t.requested_by : '', t.depends_on ? 'after ' + t.depends_on : ''].filter(Boolean).join(' · '))) },
          { k: 'source_sys', label: 'From', sort: true, render: (t) => t.source_sys || '—' },
          { k: 'status', label: 'Status', sort: true, render: (t) => h('div', null, App.trStatus(t.status), t.priority === 'urgent' ? h('span', { style: { marginLeft: '6px' } }, App.chip('Urgent', 'var(--c-urgent)')) : null) },
          { k: 'flow', label: 'Steps', render: miniFlow },
          { k: 'approver', label: 'Approved by', sort: true, render: (t) => (t.approver ? h('span', null, t.approver, t.approved_on ? h('span', { class: 'sub' }, fmtD(t.approved_on)) : null) : h('span', { class: 'muted' }, '—')) },
          { k: 'prd_on', label: 'In PRD', sort: (t) => t.prd_on || '', render: (t) => (t.prd_on ? fmtD(t.prd_on) : '—') },
          { k: 'age', label: 'Asked', cls: 'num', sort: (t) => t.age_days || 0, render: (t) => (t.open && t.age_days != null ? h('span', { class: t.age_days > 7 ? 'due-over' : '' }, t.age_days + ' d ago') : fmtD(t.requested_on)) }
        ]
      }));
    }
    root.replaceChildren(h('div', { class: 'page-h' }, h('div', null, h('h1', null, 'Transports'), h('div', { class: 'sub' }, 'TR requests from DEV to QAS and production - who asked, who approved, when it moved, and the return code.')), h('span', { class: 'grow' }), App.btn('New transport', () => App.newTransport(), 'primary', 'plus')),
      h('div', { class: 'tools' }, seg, h('div', { class: 'grow', style: { minWidth: '180px' } }, q)), holder);
    segs(); rows();
  };

  const trFields = () => [
    { k: 'tr_number', label: 'TR number', ph: 'e.g. DEVK900123' }, { k: 'source_sys', label: 'From system', t: 'select', opts: ['DEV', 'QAS', 'PRD', 'Other'] },
    { k: 'description', label: 'What does it contain?', req: true, wide: true, ph: 'e.g. ZGATE_OUT: partial gate pass fix' },
    { k: 'owner_name', label: 'Made by (developer)' }, { k: 'requested_by', label: 'Asked by' },
    { k: 'priority', label: 'Priority', t: 'select', opts: [['normal', 'Normal'], ['urgent', 'Urgent']] }, { k: 'depends_on', label: 'Move after (TR number)', ph: 'only if another TR must go first' },
    { k: 'approver', label: 'Who will approve', ph: 'HOD / functional owner' }, { k: 'requested_on', label: 'Requested on', t: 'date' },
    { k: 'note', label: 'Note', t: 'area', wide: true }];
  App.newTransport = function (pre) {
    pre = pre || {};
    App.formDialog({ title: 'New transport request', cls: 'wide', fields: trFields(), values: Object.assign({ source_sys: 'DEV', priority: 'normal', requested_on: App.todayIso() }, pre), ok: 'Add transport', onSave: async (v) => {
      if (!v.description.trim()) { toast('Write what the transport contains', 'err'); return false; }
      const t = await POST('/api/transports', v); toast(t.code + ' added'); App.refresh(); App.openTransport(t.id); if (pre.after) pre.after(t);
    } });
  };

  function trAction(t, act, o, done) {
    const fields = [];
    if (act === 'approve') fields.push({ k: 'approver', label: 'Who approved it', req: true, ph: 'name of HOD / owner' });
    if (act !== 'hold' && act !== 'reject' && act !== 'reopen' && act !== 'fail') fields.push({ k: 'on', label: 'Date', t: 'date' });
    if (act === 'qas' || act === 'prd') fields.push({ k: 'by', label: act === 'qas' ? 'Imported by' : 'Moved by' });
    if (act === 'prd' || act === 'fail') fields.push({ k: 'rc', label: 'Return code', hint: '0 or 4 = fine. 8 or more = import failed.' });
    fields.push({ k: 'note', label: act === 'hold' || act === 'reject' || act === 'reopen' || act === 'fail' ? 'Reason' : 'Note (optional)', t: 'area', wide: true });
    App.formDialog({ title: o.title, fields: fields, values: { approver: t.approver || App.settings().hod || '', on: App.todayIso(), by: me(), rc: act === 'prd' ? '0' : t.rc || '' }, ok: o.ok, onSave: async (v) => {
      if (act === 'approve' && !v.approver.trim()) { toast('Write who approved it', 'err'); return false; }
      if ((act === 'hold' || act === 'reject' || act === 'fail') && v.note.trim().length < 3) { toast('Write the reason', 'err'); return false; }
      await POST('/api/transports/' + t.id + '/do', Object.assign({ do: act }, v, act === 'approve' ? { by: me() } : {}));
      toast(o.done); await done();
    } });
  }

  App.openTransport = async function (id) {
    const dr = App.drawer({ aria: 'Transport' });
    dr.body.replaceChildren(App.spin());
    async function render() {
      let t;
      try { t = await GET('/api/transports/' + id); } catch (e) { return dr.close(); }
      const done = async () => { await render(); App.refresh(); };
      const closed = t.status === 'prd' || t.status === 'rejected';
      dr.setHead([h('div', { class: 'row wrap', style: { marginBottom: '4px', paddingRight: '34px' } }, App.mono(t.code), App.trStatus(t.status), t.priority === 'urgent' ? App.chip('Urgent', 'var(--c-urgent)') : null, t.source_sys ? App.tag('from ' + t.source_sys) : null),
        h('div', { style: { fontSize: '20px', fontWeight: '700', lineHeight: '1.25' } }, (t.tr_number ? t.tr_number + ' - ' : '') + t.description),
        h('div', { class: 'muted small' }, [t.owner_name ? 'made by ' + t.owner_name : '', t.requested_by ? 'asked by ' + t.requested_by : '', 'requested ' + fmtD(t.requested_on, true)].filter(Boolean).join(' · '))]);
      const steps = [['Requested', t.requested_on, t.requested_by, true], ['In QAS', t.qas_on, t.qas_by, !!t.qas_on], ['Approved', t.approved_on, t.approver, !!t.approved_on], ['In PRD', t.prd_on, t.prd_by, t.status === 'prd']];
      const now = steps.findIndex((s) => !s[3]);
      const stepper = h('div', { class: 'stepper' }, steps.map(([l, on, by, ok], i) => h('div', { class: 'st' + (ok ? ' done' : '') + (!closed && i === now ? ' now' : '') + (t.status === 'failed' && i === 3 ? ' bad' : '') }, h('i', null, ok ? '✓' : t.status === 'failed' && i === 3 ? '!' : String(i + 1)), h('b', null, l), on ? h('span', null, fmtD(on)) : null, by ? h('span', { class: 'small' }, by) : null)));
      const acts = [];
      if (!closed && t.status !== 'failed') {
        if (!t.qas_on) acts.push(App.btn('Imported to QAS', () => trAction(t, 'qas', { title: 'Imported to QAS', ok: 'Save', done: 'QAS recorded' }, done), t.status === 'requested' ? 'primary' : ''));
        if (!t.approved_on) acts.push(App.btn('Approved', () => trAction(t, 'approve', { title: 'Approval received', ok: 'Save approval', done: 'Approval recorded' }, done), t.qas_on ? 'primary' : ''));
        acts.push(App.btn('Moved to production', () => trAction(t, 'prd', { title: 'Moved to production (PRD)', ok: 'Save', done: 'Production move recorded' }, done), t.approved_on ? 'primary' : ''));
      }
      if (t.status === 'failed') acts.push(App.btn('Moved to production (retry)', () => trAction(t, 'prd', { title: 'Moved to production (PRD)', ok: 'Save', done: 'Recorded' }, done), 'primary'));
      if (!closed && t.status !== 'failed') acts.push(App.btn('Import failed', () => trAction(t, 'fail', { title: 'Import failed', ok: 'Mark failed', done: 'Marked failed' }, done), 'ghost danger'));
      if (!closed && t.status !== 'hold') acts.push(App.btn('Put on hold', () => trAction(t, 'hold', { title: 'Put on hold', ok: 'Hold', done: 'On hold' }, done), 'ghost'));
      if (t.status !== 'prd' && t.status !== 'rejected') acts.push(App.btn('Reject', () => trAction(t, 'reject', { title: 'Reject this transport', ok: 'Reject', done: 'Rejected' }, done), 'ghost danger'));
      if (['failed', 'rejected', 'hold'].indexOf(t.status) >= 0) acts.push(App.btn('Re-open', () => trAction(t, 'reopen', { title: 'Re-open', ok: 'Re-open', done: 'Re-opened' }, done), ''));
      const needApproval = App.settings().tr_need_approval === '1' && !t.approved_on && !closed;
      const kv = (k, v) => (v ? [h('dt', null, k), h('dd', null, v)] : null);
      dr.body.replaceChildren(stepper,
        needApproval ? h('div', { class: 'hint-box', style: { marginBottom: '12px' } }, 'Rule: nothing goes to production without approval. Record the approval first.') : null,
        t.status === 'failed' ? h('div', { class: 'box bad', style: { marginBottom: '12px' } }, h('b', null, 'Import to production failed'), t.rc ? ' - return code ' + t.rc : '', h('div', { class: 'muted small' }, 'Fix the reason, then use "Moved to production (retry)".')) : null,
        h('div', { class: 'acts', style: { marginBottom: '16px' } }, acts),
        h('div', { class: 'box' }, h('div', { class: 'sec-h' }, h('h3', null, 'Details'), h('div', { class: 'acts' }, App.btn('Edit', () => App.formDialog({ title: 'Edit ' + t.code, cls: 'wide', fields: trFields().concat([{ k: 'rc', label: 'Return code' }]), values: t, onSave: async (v) => { await PUT('/api/transports/' + id, v); toast('Saved'); await done(); } }), 'sm', 'edit'))),
          h('dl', { class: 'kv' }, kv('TR number', t.tr_number), kv('Description', t.description), kv('From', t.source_sys), kv('Made by', t.owner_name), kv('Asked by', t.requested_by), kv('Move after', t.depends_on),
            kv('Approved by', t.approver ? t.approver + (t.approved_on ? ' on ' + fmtD(t.approved_on, true) : '') : ''), kv('Return code', t.rc), kv('Note', t.note))),
        h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'Approval mail, test screenshots, documents'), h('span', { class: 'cnt' }, t.files.length || ''), h('div', { class: 'acts' }, App.btn('Open folder', () => POST('/api/open-folder', { kind: 'transport', id: id }), 'sm ghost', 'folder'))), App.filesSection('transport', id, t.files, done, { cat: 'doc' })),
        h('section', { style: { marginTop: '24px' } }, h('div', { class: 'sec-h' }, h('h3', null, 'History')), App.noteBox(async (text, who) => { await POST('/api/transports/' + id + '/do', { do: 'note', note: text, by: who || me() }); done(); }, { noKnown: true }), App.timeline(t.history)),
        h('section', { style: { marginTop: '28px', borderTop: '1px solid var(--line)', paddingTop: '14px' } }, App.btn('Delete this record', async () => { if (await confirmBox('Delete ' + t.code + '? Use "Reject" if it should stay in the record.')) { await DEL('/api/transports/' + id); dr.close(); toast('Deleted'); App.refresh(); } }, 'sm ghost danger')));
    }
    await render();
  };

  /* =============================================================== TEAM */
  App.V.team = async function (root) {
    const [team, tickets] = await Promise.all([load('team'), load('tickets')]);
    const mine = tickets.filter((t) => t.assigned_to === 0 && ['assigned', 'progress', 'waiting'].indexOf(t.status) >= 0);
    const plant = App.plantFilter();
    const list = team.filter((m) => !plant || !m.plant || m.plant === plant);
    const noCover = App.plants().filter((p) => !team.some((m) => m.active && m.plant === p.code));
    const card = (m) => h('div', { class: 'team-card' + (m.active ? '' : ' off') },
      h('div', { class: 'row start' }, h('div', { class: 'grow', style: { minWidth: 0 } }, h('b', { style: { fontSize: '15px' } }, m.name), h('div', { class: 'muted small' }, [m.role, m.plant ? App.plantText(m.plant) : 'all plants'].filter(Boolean).join(' · ')), m.mobile ? h('div', { class: 'muted small' }, m.mobile) : null),
        m.active ? null : App.chip('Not active', 'var(--ink-3)'), h('button', { class: 'iconbtn', type: 'button', title: 'Edit', onclick: () => teamDialog(m) }, ico('edit'))),
      h('div', { class: 'nums' }, h('div', null, h('b', null, m.open), h('span', null, 'open')), h('div', { class: m.overdue ? 'hot' : '' }, h('b', null, m.overdue), h('span', null, 'overdue')), h('div', null, h('b', null, m.to_check), h('span', null, 'to check')), h('div', null, h('b', null, m.closed_30), h('span', null, 'closed (30 d)')), m.routines ? h('div', null, h('b', null, m.routines), h('span', null, 'daily checks')) : null),
      h('div', { class: 'acts' }, App.btn('Open work', () => App.go('tickets', { assignee: String(m.id), filter: 'open' }), 'sm'), App.btn('Send work list', () => App.sendDialog('Work list for ' + m.name, App.listMessage(m, tickets), m.mobile), 'sm', 'send'),
        App.btn('Give new work', () => App.newTicket({ assigned_to: m.id }), 'sm ghost', 'plus')));
    root.replaceChildren(h('div', { class: 'page-h' }, h('div', null, h('h1', null, 'Team'), h('div', { class: 'sub' }, 'The people who do the work in each plant: what each one has right now, and what is waiting for your check.')), h('span', { class: 'grow' }), App.btn('Add team member', () => teamDialog(null), 'primary', 'plus')),
      noCover.length && team.length ? h('div', { class: 'box warn', style: { marginBottom: '14px' } }, 'Nobody is posted at ' + noCover.map((p) => p.code + ' ' + p.name).join(', ') + '. Tickets from there will have to be given to someone from another plant.') : null,
      list.length || team.length ? h('div', { class: 'team-grid' }, list.map(card), h('div', { class: 'team-card' }, h('div', null, h('b', { style: { fontSize: '15px' } }, me() + ' (you)'), h('div', { class: 'muted small' }, 'Work you keep for yourself')),
        h('div', { class: 'nums' }, h('div', null, h('b', null, mine.length), h('span', null, 'open')), h('div', { class: mine.some((t) => t.overdue) ? 'hot' : '' }, h('b', null, mine.filter((t) => t.overdue).length), h('span', null, 'overdue'))),
        h('div', { class: 'acts' }, App.btn('Open my work', () => App.go('tickets', { assignee: '0', filter: 'open' }), 'sm')))) : App.empty('No team members yet', 'Add the people who work for you in each plant. Then you can give them tickets and see who has what.', App.btn('Add team member', () => teamDialog(null), 'primary')));
  };
  function teamDialog(m) {
    App.formDialog({ title: m ? 'Edit ' + m.name : 'New team member', fields: [{ k: 'name', label: 'Name', req: true }, { k: 'plant', label: 'Posted at', t: 'select', opts: [['', 'All plants / office']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) },
      { k: 'role', label: 'Role', ph: 'e.g. Hardware & network, SAP user support' }, { k: 'mobile', label: 'Mobile (for WhatsApp)' }, { k: 'email', label: 'Mail id' },
      { k: 'active', label: 'Working in the team now', t: 'check' }, { k: 'note', label: 'Note', t: 'area', wide: true }], values: Object.assign({ active: 1, plant: App.plantFilter() || '' }, m || {}), ok: m ? 'Save' : 'Add',
    extra: m ? h('div', { style: { marginTop: '10px' } }, App.btn('Remove from the team', async () => { if (await confirmBox('Remove ' + m.name + '? If there is work on record you can only switch to "not active".')) { await DEL('/api/team/' + m.id); toast('Removed'); App.refresh(); document.querySelectorAll('dialog[open]').forEach((d) => d.close()); } }, 'sm ghost danger')) : null,
    onSave: async (v) => {
      if (!v.name.trim()) { toast('Write the name', 'err'); return false; }
      if (m) await PUT('/api/team/' + m.id, v); else await POST('/api/team', v);
      toast(m ? 'Saved' : v.name + ' added to the team'); App.refresh();
    } });
  }

  /* =============================================================== DAILY CHECKS */
  const STATE = { ok: ['Done', 'var(--c-ok)'], issue: ['Problem', 'var(--c-overdue)'], skipped: ['Skipped', 'var(--ink-3)'], pending: ['To do', 'var(--c-warning)'], missed: ['Missed', 'var(--c-overdue)'] };
  const freqText = (r) => (r.frequency === 'weekly' ? 'Every ' + dayNames[r.weekday || 0] : r.frequency === 'monthly' ? 'Monthly, day ' + r.month_day : 'Every working day');
  const TEMPLATES = [['SAP backup finished OK', 'daily', 0], ['SAP production system up and responding', 'daily', 0], ['Mail server and mails working', 'daily', 0], ['Internet / ISP link up', 'daily', 1],
    ['CCTV: all cameras recording', 'daily', 1], ['UPS and server room temperature OK', 'daily', 1], ['Antivirus updated on servers', 'weekly', 0], ['Printers: toner and paper', 'weekly', 1], ['SAP user list reviewed (locked / expired users)', 'monthly', 0], ['Backup restore test', 'monthly', 0]];

  App.V.checks = async function (root) {
    const all = await load('routines');
    const plant = App.plantFilter();
    const list = all.filter((r) => !plant || !r.plant || r.plant === plant);
    const act = list.filter((r) => r.active);
    const cnt = (s) => act.filter((r) => r.state === s).length;
    const groups = [];
    const keys = [''].concat(App.plants().map((p) => p.code));
    keys.forEach((k) => { const rows = list.filter((r) => (r.plant || '') === k); if (rows.length) groups.push([k, rows]); });
    function row(r) {
      const s = r.active ? (r.state || 'next') : 'off';
      const chip = s === 'next' ? App.chip('Starts next time', 'var(--ink-3)') : s === 'off' ? App.chip('Paused', 'var(--ink-3)') : App.chip(STATE[s][0], STATE[s][1]);
      const lg = r.cur_log;
      return h('div', { class: 'check-card' }, h('div', { style: { minWidth: 0 } }, h('div', { class: 'row wrap' }, h('b', null, r.title), chip, r.prev_state === 'missed' && r.active ? h('button', { class: 'lnk small due-over', type: 'button', onclick: () => logDialog(r, r.prev_due, 'ok') }, 'Missed ' + fmtD(r.prev_due) + ' - fill in') : null),
        h('div', { class: 'muted small' }, [freqText(r), r.assignee || 'nobody assigned', lg ? (lg.by_name ? 'by ' + lg.by_name + ' ' : '') + fmtTs(lg.ts) + (lg.note ? ' - ' + lg.note : '') : ''].filter(Boolean).join(' · '))),
      h('div', { class: 'acts', style: { justifyContent: 'flex-end' } }, r.active && s !== 'next' ? [
        App.btn('Done OK', async () => { await POST('/api/routines/' + r.id + '/log', { status: 'ok' }); toast('Marked done'); App.refresh(); }, s === 'ok' ? 'sm' : 'sm primary'),
        App.btn('Problem', () => logDialog(r, r.cur_due, 'issue'), 'sm ghost danger'), App.btn('Skip', () => logDialog(r, r.cur_due, 'skipped'), 'sm ghost')] : null,
      h('button', { class: 'iconbtn', type: 'button', title: 'More', 'aria-label': 'More for ' + r.title, onclick: (e) => App.menu(e.currentTarget, [{ label: 'See the last entries', icon: 'clock', run: () => historyDialog(r) }, { label: 'Edit', icon: 'edit', run: () => routineDialog(r) },
        { label: r.active ? 'Pause this check' : 'Start it again', icon: 'checks', run: async () => { await PUT('/api/routines/' + r.id, { active: r.active ? 0 : 1 }); App.refresh(); } },
        { label: 'Delete', icon: 'trash', run: async () => { if (await confirmBox('Delete "' + r.title + '" with its whole record? Pause it instead if you only want it to stop.')) { await DEL('/api/routines/' + r.id); toast('Deleted'); App.refresh(); } } }]) }, ico('chevron'))));
    }
    const sum = act.length ? h('div', { class: 'kpis', style: { marginBottom: '14px' } },
      h('div', { class: 'kpi', style: { cursor: 'default' } }, h('b', null, cnt('ok')), h('span', null, 'Done')), h('div', { class: 'kpi ' + (cnt('pending') ? 'warm' : ''), style: { cursor: 'default' } }, h('b', null, cnt('pending')), h('span', null, 'Still to do')),
      h('div', { class: 'kpi ' + (cnt('issue') ? 'hot' : ''), style: { cursor: 'default' } }, h('b', null, cnt('issue')), h('span', null, 'Problems')), h('div', { class: 'kpi ' + (cnt('missed') ? 'hot' : ''), style: { cursor: 'default' } }, h('b', null, cnt('missed')), h('span', null, 'Missed'))) : null;
    root.replaceChildren(h('div', { class: 'page-h' }, h('div', null, h('h1', null, 'Daily checks'), h('div', { class: 'sub' }, 'The routine work that must happen without anyone calling: backups, servers, cameras, UPS. Tick each one; a problem becomes a ticket.')), h('span', { class: 'grow' }),
      App.btn('Add typical checks', () => templateDialog(), '', 'plus'), App.btn('New check', () => routineDialog(null), 'primary', 'plus')), sum,
    groups.length ? groups.map(([k, rows]) => h('section', { style: { marginBottom: '18px' } }, h('div', { class: 'sect-t' }, h('h2', null, k ? App.plantText(k) : 'Whole company'), h('span', null, rows.filter((r) => r.active).length + ' checks')), h('div', { class: 'panel' }, rows.map(row))))
      : App.empty('No checks yet', 'Start with the typical ones - SAP backup, servers, cameras, UPS. You can change or remove any of them.', App.btn('Add typical checks', () => templateDialog(), 'primary')));
  };

  function logDialog(r, day, status) {
    const st = App.sel([['ok', 'Done - all fine'], ['issue', 'Problem found'], ['skipped', 'Skipped']], status);
    const note = h('textarea', { style: { minHeight: '64px' }, placeholder: 'What did you find? / why skipped?' });
    const mk = h('input', { type: 'checkbox', checked: status === 'issue' });
    const prio = App.sel(App.vocab().priorities.map((p) => [p, App.cap(p)]), 'high');
    const tk = h('div', { class: 'stack', style: { gap: '6px', marginTop: '8px' } }, h('label', { class: 'row' }, mk, 'Also open a ticket for this problem'), h('div', { class: 'row' }, h('span', { class: 'muted small' }, 'Priority'), prio));
    const sync = () => { tk.classList.toggle('hide', st.value !== 'issue'); };
    st.addEventListener('change', sync); sync();
    const m = modal({ title: r.title + ' - ' + fmtD(day), body: [App.fld('Result', st), h('div', { style: { marginTop: '8px' } }, App.fld('Note', note)), tk], actions: [{ label: 'Cancel' }, { label: 'Save', cls: 'primary', close: false, onClick: async () => {
      if (st.value !== 'ok' && note.value.trim().length < 3) { toast(st.value === 'issue' ? 'Write in one line what the problem is' : 'Write why it was skipped', 'err'); return false; }
      try {
        let tid = null;
        if (st.value === 'issue' && mk.checked) {
          const t = await POST('/api/tickets', { title: 'Check failed: ' + r.title, details: note.value, category: 'other', plant: r.plant || '', priority: prio.value, source: 'self', assigned_to: r.assigned_to });
          tid = t.id; toast(t.code + ' opened');
        }
        await POST('/api/routines/' + r.id + '/log', { status: st.value, note: note.value, on_date: day, ticket_id: tid });
        m.close(); toast('Saved'); App.refresh();
      } catch (e) { /* shown */ }
      return false;
    } }] });
  }
  function historyDialog(r) {
    GET('/api/routines/' + r.id + '/logs').then((rows) => modal({ title: r.title, body: rows.length ? h('table', { class: 'grid' }, h('thead', null, h('tr', null, ['Date', 'Result', 'By', 'Note'].map((x) => h('th', null, x)))), h('tbody', null, rows.map((x) => h('tr', null, h('td', null, fmtD(x.on_date)), h('td', null, App.chip(STATE[x.status][0], STATE[x.status][1])), h('td', null, x.by_name || '—'), h('td', null, x.note || ''))))) : h('div', { class: 'muted' }, 'Nothing recorded yet.'), actions: [{ label: 'Close' }] }));
  }
  function routineDialog(r) {
    const f = App.makeForm([{ k: 'title', label: 'What is checked', req: true, wide: true, ph: 'e.g. SAP backup finished OK' },
      { k: 'plant', label: 'For plant', t: 'select', opts: [['', 'Whole company']].concat(App.plants().map((p) => [p.code, p.code + ' ' + p.name])) }, { k: 'assigned_to', label: 'Who does it', t: 'who', noneLabel: '— nobody —' },
      { k: 'frequency', label: 'How often', t: 'select', opts: App.vocab().freq.map((x) => [x.key, x.label]) }, { k: 'weekday', label: 'On which day', t: 'select', opts: dayNames.map((d, i) => [String(i), d]) },
      { k: 'month_day', label: 'Day of the month (1-28)', t: 'number', min: 1 }, { k: 'note', label: 'How to check / note', t: 'area', wide: true }], Object.assign({ frequency: 'daily', weekday: 0, month_day: 1, plant: App.plantFilter() || '' }, r || {}));
    const sync = () => { f.ctl.weekday.closest('.fld').style.display = f.ctl.frequency.value === 'weekly' ? '' : 'none'; f.ctl.month_day.closest('.fld').style.display = f.ctl.frequency.value === 'monthly' ? '' : 'none'; };
    f.ctl.frequency.addEventListener('change', sync); sync();
    const m = modal({ title: r ? 'Edit check' : 'New check', cls: 'wide', body: [f.el], actions: [{ label: 'Cancel' }, { label: r ? 'Save' : 'Add check', cls: 'primary', close: false, onClick: async () => {
      const v = f.get(); if (!v.title.trim()) { toast('Write what is checked', 'err'); return false; }
      try { if (r) await PUT('/api/routines/' + r.id, v); else await POST('/api/routines', v); m.close(); toast('Saved'); App.refresh(); } catch (e) { /* shown */ }
      return false;
    } }] });
  }
  function templateDialog() {
    const who = App.whoSelect(null, null, { noneLabel: '— decide later —' });
    const boxes = TEMPLATES.map((t) => h('input', { type: 'checkbox', checked: true }));
    const body = [h('p', { class: 'muted', style: { marginBottom: '8px' } }, 'Tick the checks you want. Cameras, UPS and internet are made separately for every plant; the rest once for the whole company.'),
      h('div', { class: 'stack', style: { gap: '4px', marginBottom: '10px' } }, TEMPLATES.map((t, i) => h('label', { class: 'row' }, boxes[i], t[0], h('span', { class: 'muted small' }, '(' + (t[1] === 'daily' ? 'daily' : t[1] === 'weekly' ? 'weekly' : 'monthly') + ')')))), App.fld('Who does them', who)];
    const m = modal({ title: 'Add typical checks', body: body, actions: [{ label: 'Cancel' }, { label: 'Add', cls: 'primary', close: false, onClick: async () => {
      let n = 0;
      try {
        for (let i = 0; i < TEMPLATES.length; i++) {
          if (!boxes[i].checked) continue;
          const [title, freq, perPlant] = TEMPLATES[i];
          const plants = perPlant ? App.plants().map((p) => p.code) : [''];
          for (const p of plants) { await POST('/api/routines', { title: title, frequency: freq, weekday: 0, month_day: 1, plant: p, assigned_to: who.value === '' ? null : +who.value }); n++; }
        }
        m.close(); toast(n + ' checks added'); App.refresh();
      } catch (e) { /* shown */ }
      return false;
    } }] });
  }
})();
