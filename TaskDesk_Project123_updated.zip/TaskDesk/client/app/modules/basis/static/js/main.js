/* App shell: navigation, top bar (search, plant switch, New menu), routing, start-up. */
(function () {
  'use strict';
  const { h, ico, $, GET, LS, debounce } = App;
  const NAV = [
    ['dashboard', 'Today', 'dashboard'], ['tickets', 'Tickets', 'ticket'], ['people', 'People', 'people'], ['stock', 'Stock & assets', 'box'], ['transports', 'Transports', 'transport'],
    ['team', 'Team', 'team'], ['checks', 'Daily checks', 'checks'], ['buy', 'Buy & renew', 'cart'], ['reports', 'Reports', 'report']
  ];
  const TITLES = { dashboard: 'Today', tickets: 'Tickets', people: 'People', stock: 'Stock & assets', transports: 'Transports', team: 'Team', checks: 'Daily checks', buy: 'Buy & renew', reports: 'Reports', settings: 'Settings' };

  App.S.params = {};
  App.go = function (view, params) {
    App.S.params = params || {};
    if (location.hash === '#/' + view) App.render(); else location.hash = '#/' + view;
  };
  const curView = () => (location.hash.replace(/^#\//, '').split(/[/?]/)[0] || 'dashboard');

  App.loadMeta = async function () { App.S.meta = await GET('/api/meta'); return App.S.meta; };
  App.refresh = async function () { await App.loadMeta(); renderNav(); App.render(); };

  function renderNav() {
    const v = curView(), b = App.S.meta ? App.S.meta.badges : {};
    $('#nav').replaceChildren(
      h('div', { class: 'brand' }, h('img', { src: '/icon.svg', alt: '' }), h('div', null, h('b', null, 'BASIS & IT'), h('span', null, 'TaskDesk'))),
      NAV.map(([k, l, i]) => h('a', { href: '#/' + k, class: v === k ? 'on' : '', onclick: () => { App.S.params = {}; } }, ico(i), h('span', null, l), b[k] ? h('span', { class: 'cnt' }, b[k]) : null)),
      h('div', { class: 'sp' }),
      h('a', { href: '#/settings', class: v === 'settings' ? 'on' : '' }, ico('settings'), h('span', null, 'Settings')),
      h('div', { class: 'foot' }, App.S.meta ? (App.S.meta.settings.manager || '') : ''));
  }

  function buildTop() {
    const q = h('input', { type: 'search', placeholder: 'Search tickets, people, serial no., TR number, mail id…', 'aria-label': 'Search', autocomplete: 'off' });
    const res = h('div', { class: 'results hide' });
    const search = h('div', { class: 'search' }, ico('search'), q, h('kbd', null, '/'), res);
    const run = debounce(async () => {
      const t = q.value.trim();
      if (t.length < 2) return res.classList.add('hide');
      const r = await GET('/api/search?q=' + encodeURIComponent(t));
      res.replaceChildren(r.length ? r.map((x) => h('button', { type: 'button', onclick: () => { res.classList.add('hide'); q.value = ''; App.open(x.kind, x.id); } },
        App.tag(({ ticket: 'Ticket', person: 'Person', asset: 'Item', transport: 'TR', account: 'Id' })[x.kind]), h('span', { class: 'grow' }, h('b', null, x.title), h('span', { class: 'sub' }, x.sub)))) : h('div', { style: { padding: '12px', color: 'var(--ink-3)' } }, 'Nothing found'));
      res.classList.remove('hide');
    }, 250);
    q.addEventListener('input', run);
    q.addEventListener('keydown', (e) => { if (e.key === 'Escape') { res.classList.add('hide'); q.blur(); } });
    document.addEventListener('click', (e) => { if (!search.contains(e.target)) res.classList.add('hide'); });
    document.addEventListener('keydown', (e) => { if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && !document.querySelector('dialog[open]')) { e.preventDefault(); q.focus(); } });

    const plantTab = h('div', { class: 'planttab', role: 'group', 'aria-label': 'Plant' });
    function drawPlants() {
      const cur = App.S.plant || '';
      plantTab.replaceChildren(h('button', { type: 'button', class: cur === '' ? 'on' : '', onclick: () => setPlant('') }, 'All plants'),
        App.plants().map((p) => h('button', { type: 'button', class: cur === p.code ? 'on' : '', title: p.name, onclick: () => setPlant(p.code) }, p.code + ' ' + p.name.replace(/ Plant$/, ''))));
    }
    function setPlant(c) { App.S.plant = c; LS.set('plant', c); drawPlants(); App.render(); }
    App.drawPlants = drawPlants;
    drawPlants();

    const newBtn = h('button', { class: 'btn primary', type: 'button' }, ico('plus'), 'New');
    newBtn.addEventListener('click', () => App.menu(newBtn, [
      { label: 'Ticket (problem / request)', icon: 'ticket', run: () => App.newTicket() },
      { label: 'New joiner', icon: 'people', run: () => App.newJoiner() },
      { label: 'Issue an item to someone', icon: 'laptop', run: () => App.issueDialog() },
      { label: 'Add items to stock', icon: 'box', run: () => App.addStock() },
      { label: 'Transport request (TR)', icon: 'transport', run: () => App.newTransport() },
      { label: 'Purchase request', icon: 'cart', run: () => App.newPurchase() }]));
    const themeBtn = h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Switch light / dark theme', title: 'Light / dark', onclick: () => {
      const n = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'; document.documentElement.setAttribute('data-theme', n); LS.set('theme', n);
      themeBtn.replaceChildren(ico(n === 'dark' ? 'sun' : 'moon')); } }, ico(document.documentElement.getAttribute('data-theme') === 'dark' ? 'sun' : 'moon'));
    $('#top').replaceChildren(search, plantTab, h('span', { class: 'grow' }), h('div', { class: 'rel' }, newBtn), themeBtn);
  }

  App.render = async function () {
    const v = curView();
    const fn = App.V[v] || App.V.dashboard;
    const root = $('#view');
    document.title = (TITLES[v] || 'Today') + ' · BASIS & IT Task Manager';
    renderNav();
    const keep = root.scrollTop;
    const params = App.S.params || {}; App.S.params = {};   // a view reads its filter once; later refreshes keep what the user chose
    try { await fn(root, params); } catch (e) { if (!root.firstChild) root.replaceChildren(App.empty('Could not load this page', String(e.message || e))); }
    root.scrollTop = keep;
  };

  // open any record (used by search, dashboard and links)
  App.open = function (kind, id) {
    ({ ticket: App.openTicket, person: App.openPerson, asset: App.openAsset, transport: App.openTransport, purchase: App.openPurchase, renewal: App.openRenewal, account: () => App.go('people', { tab: 'accounts' }) })[kind](id);
  };
  App.follow = function (go) {
    if (!go) return;
    if (go.id) {
      const k = { tickets: 'ticket', people: 'person', stock: 'asset', transports: 'transport' }[go.view] || (go.view === 'buy' ? (go.tab === 'renew' ? 'renewal' : 'purchase') : null);
      if (k) { App.go(go.view, go.tab ? { tab: go.tab } : {}); return setTimeout(() => App.open(k, go.id), 80); }
    }
    App.go(go.view, go);
  };

  async function init() {
    App.S.plant = LS.get('plant', '') || '';
    try { await App.loadMeta(); } catch (e) { $('#view').replaceChildren(App.empty('Cannot reach the local server', 'Start the app again from its desktop icon.')); return; }
    if (App.S.plant && !App.plants().some((p) => p.code === App.S.plant)) App.S.plant = '';
    buildTop(); renderNav();
    window.addEventListener('hashchange', () => { App.closeDrawer(); App.render(); });
    App.render();
    // keep the badges and "overdue" marks fresh while the window stays open
    setInterval(() => { if (!document.hidden && !document.querySelector('dialog[open]') && !$('#drawer-root').firstChild) App.refresh(); }, 120000);
  }
  init();
})();
