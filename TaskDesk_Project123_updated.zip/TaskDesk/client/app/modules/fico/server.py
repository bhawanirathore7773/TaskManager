# -*- coding: utf-8 -*-
"""
FICO Task Manager - local server (SAP FI / CO functional consultant edition).

Pure Python standard library (no pip install needed). Python 3.9+.
Everything is stored locally in the "data" folder next to this file:
  data/taskmanager.db   -> SQLite database
  data/files/<task>/..  -> images, Excel, before-change snapshots, documents of every task
  data/backups/         -> automatic daily copies of the database
"""
import contextlib
import datetime as dt
import io
import json
import mimetypes
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import traceback
import zipfile
import xml.etree.ElementTree as ET
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urlparse

APP_ID = 'fico-task-manager'
APP_NAME = 'FICO Task Manager'
APP_VERSION = '1.0'
APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(APP_DIR, 'static')
DATA_DIR = os.environ.get('FICO_TM_DATA') or os.path.join(APP_DIR, 'data')
FILES_DIR = os.path.join(DATA_DIR, 'files')
BACKUP_DIR = os.path.join(DATA_DIR, 'backups')
TRASH_DIR = os.path.join(DATA_DIR, 'trash')
DB_PATH = os.path.join(DATA_DIR, 'taskmanager.db')
DEFAULT_PORT = 8780            # launcher tries 8780-8790
MAX_UPLOAD = 500 * 1024 * 1024

STATUSES = [
    {'key': 'new', 'label': 'Not Started', 'floor': 0, 'active': True},
    {'key': 'analysis', 'label': 'Analysis / GAP', 'floor': 10, 'active': True},
    {'key': 'dev', 'label': 'In Progress', 'floor': 25, 'active': True},
    {'key': 'unit_test', 'label': 'Unit Testing', 'floor': 60, 'active': True},
    {'key': 'quality', 'label': 'UAT / Quality', 'floor': 75, 'active': True},
    {'key': 'prod', 'label': 'In Production', 'floor': 95, 'active': False},
    {'key': 'closed', 'label': 'Closed', 'floor': 100, 'active': False},
    {'key': 'hold', 'label': 'On Hold', 'floor': 0, 'active': False},
    {'key': 'cancelled', 'label': 'Cancelled', 'floor': 0, 'active': False},
]
STATUS_MAP = {s['key']: s for s in STATUSES}
PRIORITIES = ['critical', 'high', 'medium', 'low']
PRIO_WEIGHT = {'critical': 40, 'high': 28, 'medium': 16, 'low': 6}
URG_WEIGHT = {'overdue': 60, 'crunch': 52, 'urgent': 46, 'warning': 26, 'ok': 8, 'none': 0}

TYPE_LABELS = {
    'issue': 'Support Issue / Ticket', 'config': 'Configuration / Change Request', 'master': 'Master Data / Mass Upload',
    'report': 'Report / MIS / Analysis', 'fs': 'Functional Spec (to ABAP)', 'periodend': 'Period-end / Year-end Activity',
    'statutory': 'Tax / Statutory / Audit', 'auth': 'Authorisation / Role', 'other': 'Other (training, document, project)',
}
CATS = {
    'image': '1_Reference_Images', 'excel': '2_Excel_Requirement', 'backup': '3_Before_Change_Snapshot',
    'doc': '4_Documents_FS_UserGuide', 'evidence': '5_Test_UAT_Signoff', 'other': '6_Other',
}
CAT_LABELS = {
    'image': 'Reference image / screenshot', 'excel': 'Excel / requirement sheet', 'backup': 'Before-change snapshot / backup',
    'doc': 'Document (FS, user guide, mail)', 'evidence': 'Test evidence / UAT sign-off', 'other': 'Other',
}
DEFAULT_SETTINGS = {
    'hours_per_day': '6', 'work_days': '0,1,2,3,4,5', 'warn_days': '3', 'urgent_days': '1',
}
REPEATS = {'': 0, 'weekly': 7, 'monthly': 1, 'quarterly': 3, 'halfyearly': 6, 'yearly': 12}
REPEAT_LABELS = {'': 'Does not repeat', 'weekly': 'Every week', 'monthly': 'Every month', 'quarterly': 'Every quarter',
                 'halfyearly': 'Every 6 months', 'yearly': 'Every year'}
SERVER = {'last_seen': time.time(), 'httpd': None}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS tasks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT UNIQUE, folder TEXT,
  title TEXT NOT NULL,
  task_type TEXT DEFAULT 'issue', nature TEXT DEFAULT 'new', module TEXT DEFAULT '',
  requested_by TEXT DEFAULT '', committed_to TEXT DEFAULT '', department TEXT DEFAULT '',
  priority TEXT DEFAULT 'medium', complexity TEXT DEFAULT 'medium', status TEXT DEFAULT 'new',
  received_date TEXT, start_date TEXT, due_date TEXT, completed_at TEXT,
  est_hours REAL, progress_mode TEXT DEFAULT 'auto', progress_manual INTEGER DEFAULT 0,
  summary TEXT DEFAULT '', req TEXT DEFAULT '{}', dev TEXT DEFAULT '{}',
  waiting_on TEXT DEFAULT '', waiting_since TEXT, repeat TEXT DEFAULT '', spawned INTEGER DEFAULT 0,
  is_demo INTEGER DEFAULT 0, created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS checklist(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  text TEXT NOT NULL, done INTEGER DEFAULT 0, sort INTEGER DEFAULT 0, done_at TEXT
);
CREATE TABLE IF NOT EXISTS timelog(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  log_date TEXT, hours REAL, note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS files(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  category TEXT, filename TEXT, rel_path TEXT, size INTEGER,
  note TEXT DEFAULT '', version TEXT DEFAULT '', uploaded_at TEXT
);
CREATE TABLE IF NOT EXISTS history(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  ts TEXT, kind TEXT, text TEXT
);
CREATE TABLE IF NOT EXISTS issues(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  kind TEXT, title TEXT, details TEXT DEFAULT '', severity TEXT DEFAULT 'medium',
  status TEXT DEFAULT 'open', raised_on TEXT, raised_by TEXT DEFAULT '',
  fixed_on TEXT, fix_note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS moves(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  env TEXT, tr_number TEXT DEFAULT '', moved_on TEXT, result TEXT DEFAULT 'ok', note TEXT DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_cl_task ON checklist(task_id);
CREATE INDEX IF NOT EXISTS ix_tl_task ON timelog(task_id);
CREATE INDEX IF NOT EXISTS ix_f_task ON files(task_id);
CREATE INDEX IF NOT EXISTS ix_h_task ON history(task_id);
CREATE INDEX IF NOT EXISTS ix_i_task ON issues(task_id);
CREATE INDEX IF NOT EXISTS ix_m_task ON moves(task_id);
"""

LIST_SQL = """
SELECT t.*,
 (SELECT COUNT(*) FROM checklist c WHERE c.task_id=t.id) AS cl_total,
 (SELECT COUNT(*) FROM checklist c WHERE c.task_id=t.id AND c.done=1) AS cl_done,
 (SELECT COALESCE(SUM(hours),0) FROM timelog l WHERE l.task_id=t.id) AS logged,
 (SELECT COUNT(*) FROM files f WHERE f.task_id=t.id) AS n_files,
 (SELECT COUNT(*) FROM issues i WHERE i.task_id=t.id AND i.kind='quality' AND i.status='open') AS q_open,
 (SELECT COUNT(*) FROM issues i WHERE i.task_id=t.id AND i.kind='quality') AS q_total,
 (SELECT COUNT(*) FROM issues i WHERE i.task_id=t.id AND i.kind='prod' AND i.status='open') AS p_open,
 (SELECT COUNT(*) FROM issues i WHERE i.task_id=t.id AND i.kind='prod') AS p_total,
 (SELECT MAX(moved_on) FROM moves m WHERE m.task_id=t.id AND m.env='PRD') AS prd_date,
 (SELECT COUNT(*) FROM moves m WHERE m.task_id=t.id AND m.env='PRD' AND m.result='issue') AS prd_issue_moves
FROM tasks t
"""


# ----------------------------------------------------------------------------- helpers
def now_ts():
    return dt.datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def today_date():
    return dt.date.today()


def today_iso():
    return today_date().isoformat()


def jloads(s, default=None):
    try:
        v = json.loads(s) if s else None
    except Exception:
        v = None
    if v is None:
        return {} if default is None else default
    return v


def parse_d(s):
    try:
        return dt.date.fromisoformat(s[:10]) if s else None
    except Exception:
        return None


def clean_date(v):
    d = parse_d(v) if isinstance(v, str) else None
    return d.isoformat() if d else None


def safe_name(name, default='file'):
    name = os.path.basename((name or '').replace('\\', '/'))
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name).strip(' .')
    return name[:150] or default


def unique_path(folder, name):
    base, ext = os.path.splitext(name)
    p = os.path.join(folder, name)
    n = 2
    while os.path.exists(p):
        p = os.path.join(folder, '%s_%d%s' % (base, n, ext))
        n += 1
    return p


def guess_category(name):
    ext = os.path.splitext(name)[1].lower()
    if ext in ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.svg'):
        return 'image'
    if ext in ('.xls', '.xlsx', '.xlsm', '.xlsb', '.csv'):
        return 'excel'
    if ext in ('.pdf', '.doc', '.docx', '.ppt', '.pptx', '.rtf', '.md'):
        return 'doc'
    return 'other'


def count_workdays(d1, d2, wd):
    n = 0
    d = d1
    guard = 0
    while d <= d2 and guard < 1500:
        if d.weekday() in wd:
            n += 1
        d += dt.timedelta(days=1)
        guard += 1
    return n


@contextlib.contextmanager
def dbc():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys=ON')
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def get_settings(conn):
    s = dict(DEFAULT_SETTINGS)
    for r in conn.execute('SELECT key,value FROM settings'):
        s[r['key']] = r['value']
    return s


def work_days_of(st):
    out = set()
    for x in str(st.get('work_days', '')).split(','):
        x = x.strip()
        if x.isdigit() and 0 <= int(x) <= 6:
            out.add(int(x))
    return out or {0, 1, 2, 3, 4}


def log(conn, tid, kind, text):
    conn.execute('INSERT INTO history(task_id,ts,kind,text) VALUES(?,?,?,?)', (tid, now_ts(), kind, text))


def touch(conn, tid):
    conn.execute('UPDATE tasks SET updated_at=? WHERE id=?', (now_ts(), tid))


def row_dicts(rows):
    return [dict(r) for r in rows]


# ----------------------------------------------------------------------------- enrichment
def enrich(row, st, today, with_req=False):
    t = dict(row)
    t['dev'] = jloads(t.get('dev'))
    req = jloads(t.pop('req', None))
    if with_req:
        t['req'] = req
    status = t['status']
    info = STATUS_MAP.get(status)
    cl_total, cl_done = t['cl_total'], t['cl_done']
    if t['progress_mode'] == 'manual':
        prog = int(t['progress_manual'] or 0)
    else:
        cl = round(100.0 * cl_done / cl_total) if cl_total else 0
        floor = info['floor'] if info else 0
        if status in ('hold', 'cancelled'):
            prog = cl
        else:
            prog = min(95, max(floor, cl))
    # a finished task is finished, whatever the progress mode says
    if status == 'closed':
        prog = 100
    elif status == 'prod':
        prog = max(95, prog)
    t['progress'] = max(0, min(100, prog))
    est = t['est_hours']
    rem = max(0.0, est * (100 - t['progress']) / 100.0) if est else None
    t['remaining_hours'] = round(rem, 1) if rem is not None else None
    t['logged'] = round(t['logged'] or 0, 2)
    hpd = float(st.get('hours_per_day') or 6)
    warn_days = int(st.get('warn_days') or 3)
    urgent_days = int(st.get('urgent_days') or 1)
    due = parse_d(t['due_date'])
    days_left = (due - today).days if due else None
    avail = None
    if due is not None and days_left >= 0:
        avail = count_workdays(today, due, work_days_of(st)) * hpd
    active = bool(info and info['active'])
    if not active:
        state = status if status in ('hold', 'cancelled') else 'done'
    elif due is None:
        state = 'none'
    elif days_left < 0:
        state = 'overdue'
    elif rem is not None and avail is not None and rem > avail + 0.01:
        state = 'crunch'
    elif days_left <= urgent_days:
        state = 'urgent'
    elif days_left <= warn_days:
        state = 'warning'
    else:
        state = 'ok'
    t['days_left'] = days_left
    t['avail_hours'] = avail
    t['urgency'] = state
    # waiting on somebody else (user, ABAP developer, basis ...): only meaningful while the task is open
    ws = parse_d(t.get('waiting_since'))
    t['waiting_days'] = max(0, (today - ws).days) if (active and t.get('waiting_on') and ws) else None
    if not active:
        t['waiting_on'] = t.get('waiting_on') if status in ('hold',) else ''
    score = 0.0
    if active:
        score = PRIO_WEIGHT.get(t['priority'], 16) + URG_WEIGHT.get(state, 0)
        if due is not None and days_left >= 0:
            score += max(0, 14 - days_left)
        rd = parse_d(t['received_date'])
        if rd:
            score += min(max((today - rd).days, 0), 30) * 0.25
        if t['q_open']:
            score += 8
        if status in ('unit_test', 'quality'):
            score += 4
    t['score'] = round(score, 1)
    return t


def list_tasks(conn, where='', params=()):
    st = get_settings(conn)
    today = today_date()
    rows = conn.execute(LIST_SQL + where, params).fetchall()
    return [enrich(r, st, today) for r in rows]


def get_task_detail(conn, tid):
    st = get_settings(conn)
    r = conn.execute(LIST_SQL + ' WHERE t.id=?', (tid,)).fetchone()
    if not r:
        return None
    t = enrich(r, st, today_date(), with_req=True)
    return {
        'task': t,
        'checklist': row_dicts(conn.execute('SELECT * FROM checklist WHERE task_id=? ORDER BY sort,id', (tid,))),
        'time': row_dicts(conn.execute('SELECT * FROM timelog WHERE task_id=? ORDER BY log_date DESC,id DESC', (tid,))),
        'files': row_dicts(conn.execute('SELECT * FROM files WHERE task_id=? ORDER BY uploaded_at DESC,id DESC', (tid,))),
        'history': row_dicts(conn.execute('SELECT * FROM history WHERE task_id=? ORDER BY id DESC LIMIT 300', (tid,))),
        'issues': row_dicts(conn.execute('SELECT * FROM issues WHERE task_id=? ORDER BY id DESC', (tid,))),
        'moves': row_dicts(conn.execute('SELECT * FROM moves WHERE task_id=? ORDER BY moved_on DESC,id DESC', (tid,))),
    }


# ----------------------------------------------------------------------------- task creation / update
TASK_FIELDS = ['title', 'task_type', 'nature', 'module', 'requested_by', 'committed_to', 'department',
               'priority', 'complexity', 'status', 'received_date', 'start_date', 'due_date', 'est_hours',
               'progress_mode', 'progress_manual', 'summary', 'req', 'dev', 'waiting_on', 'repeat']
TRACKED = {'title': 'Title', 'priority': 'Priority', 'due_date': 'Due date', 'est_hours': 'Estimate (h)',
           'module': 'Module', 'requested_by': 'Requested by', 'complexity': 'Complexity'}


def add_months(d, n):
    m = d.month - 1 + n
    y = d.year + m // 12
    m = m % 12 + 1
    last = [31, 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1]
    return dt.date(y, m, min(d.day, last))


def shift_date(iso, repeat):
    d = parse_d(iso)
    if not d:
        return None
    step = REPEATS.get(repeat, 0)
    if repeat == 'weekly':
        return (d + dt.timedelta(days=7)).isoformat()
    return add_months(d, step).isoformat() if step else None


MONTHS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
ABBREVS = {'jan', 'feb', 'mar', 'apr', 'jun', 'jul', 'aug', 'sep', 'sept', 'oct', 'nov', 'dec'}
MONTHS_FULL = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']


def bump_title(title, repeat):
    """'GST return - Oct 2026' -> 'GST return - Nov 2026' for a monthly repeat (also 10/2026, quarters shift by 3, yearly by a year)."""
    step = REPEATS.get(repeat, 0)
    if not step:
        return title
    pat = re.compile(r"\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\b\.?"
                     r"(?:([ \-/']*)(\d{4})|([\-/']+)(\d{2}))\b", re.I)

    def by_name(m):
        word = m.group(1)
        sep = m.group(2) if m.group(3) else m.group(4)
        ytxt = m.group(3) or m.group(5)
        idx = MONTHS.index(word.lower()[:3])
        nd = add_months(dt.date(int(ytxt) + (2000 if len(ytxt) == 2 else 0), idx + 1, 1), step)
        name = MONTHS_FULL[nd.month - 1][:3] if word.lower() in ABBREVS else MONTHS_FULL[nd.month - 1]
        if word.isupper():
            name = name.upper()
        yr = str(nd.year) if len(ytxt) == 4 else '%02d' % (nd.year % 100)
        return name + (sep or '') + yr
    new, n = pat.subn(by_name, title, count=1)
    if n:
        return new
    mm = re.search(r'\b(0?[1-9]|1[0-2])([/-])(20\d\d)\b', title)
    if mm:
        nd = add_months(dt.date(int(mm.group(3)), int(mm.group(1)), 1), step)
        return title[:mm.start()] + ('%02d' % nd.month if len(mm.group(1)) == 2 else str(nd.month)) + mm.group(2) + str(nd.year) + title[mm.end():]
    if step >= 12:
        fy = re.search(r'\b(20\d\d)-(\d\d)\b', title)
        if fy:
            y = int(fy.group(1)) + step // 12
            return title[:fy.start()] + '%d-%02d' % (y, (y + 1) % 100) + title[fy.end():]
        yr = re.search(r'\b(20\d\d)\b', title)
        if yr:
            return title[:yr.start()] + str(int(yr.group(1)) + step // 12) + title[yr.end():]
    return title


def spawn_next(conn, tid):
    """A repeating task was finished: create the next occurrence (same steps, dates moved on). Returns the new id or None."""
    r = conn.execute('SELECT * FROM tasks WHERE id=?', (tid,)).fetchone()
    if not r or not r['repeat'] or r['repeat'] not in REPEATS or r['spawned']:
        return None
    rep = r['repeat']
    nd = {'title': bump_title(r['title'], rep), 'task_type': r['task_type'], 'nature': r['nature'], 'module': r['module'],
          'requested_by': r['requested_by'], 'committed_to': r['committed_to'], 'department': r['department'],
          'priority': r['priority'], 'complexity': r['complexity'], 'status': 'new', 'received_date': today_iso(),
          'start_date': shift_date(r['start_date'], rep), 'due_date': shift_date(r['due_date'], rep), 'est_hours': r['est_hours'],
          'summary': r['summary'], 'req': r['req'], 'repeat': rep}
    nd['checklist'] = [c['text'] for c in conn.execute('SELECT text FROM checklist WHERE task_id=? ORDER BY sort,id', (tid,))]
    nid = create_task(conn, nd)
    conn.execute('UPDATE tasks SET spawned=1 WHERE id=?', (tid,))
    ncode = conn.execute('SELECT code FROM tasks WHERE id=?', (nid,)).fetchone()['code']
    log(conn, tid, 'created', 'Next occurrence created automatically: %s (%s)' % (ncode, REPEAT_LABELS.get(rep, rep).lower()))
    log(conn, nid, 'created', 'Created automatically from %s (%s)' % (r['code'], REPEAT_LABELS.get(rep, rep).lower()))
    return nid


def norm_value(field, v):
    if field in ('req', 'dev'):
        return json.dumps(v if isinstance(v, (dict, list)) else jloads(v), ensure_ascii=False)
    if field == 'repeat':
        v = str(v or '').strip().lower()
        return v if v in REPEATS else ''
    if field == 'waiting_on':
        return str(v or '').strip()[:80]
    if field in ('received_date', 'start_date', 'due_date'):
        return clean_date(v)
    if field == 'est_hours':
        try:
            f = float(v)
            return f if f > 0 else None
        except (TypeError, ValueError):
            return None
    if field == 'progress_manual':
        try:
            return max(0, min(100, int(float(v))))
        except (TypeError, ValueError):
            return 0
    if field == 'priority':
        return v if v in PRIORITIES else 'medium'
    if field == 'status':
        return v if v in STATUS_MAP else 'new'
    if field == 'progress_mode':
        return 'manual' if v == 'manual' else 'auto'
    if field == 'title':
        return (str(v or '').strip() or 'Untitled task')[:300]
    return str(v if v is not None else '').strip()


def make_dirs(folder):
    base = os.path.join(FILES_DIR, folder)
    for sub in CATS.values():
        os.makedirs(os.path.join(base, sub), exist_ok=True)


def create_task(conn, d, demo=False):
    ts = now_ts()
    vals = {}
    for f in TASK_FIELDS:
        if f in d:
            vals[f] = norm_value(f, d[f])
    vals.setdefault('title', 'Untitled task')
    vals.setdefault('received_date', today_iso())
    vals.setdefault('req', '{}')
    vals.setdefault('dev', '{}')
    if vals.get('status') in ('prod', 'closed'):
        vals['completed_at'] = today_iso()
    if vals.get('waiting_on'):
        vals['waiting_since'] = clean_date(d.get('waiting_since')) or today_iso()
    cols = list(vals.keys()) + ['is_demo', 'created_at', 'updated_at']
    params = list(vals.values()) + [1 if demo else 0, ts, ts]
    cur = conn.execute('INSERT INTO tasks(%s) VALUES(%s)' % (','.join(cols), ','.join('?' * len(cols))), params)
    tid = cur.lastrowid
    code = 'T-%04d' % tid
    slug = re.sub(r'[^A-Za-z0-9]+', '_', vals['title']).strip('_')[:40] or 'task'
    folder = '%s_%s' % (code, slug)
    conn.execute('UPDATE tasks SET code=?, folder=? WHERE id=?', (code, folder, tid))
    make_dirs(folder)
    for i, text in enumerate(d.get('checklist') or []):
        text = text if isinstance(text, str) else str(text.get('text', ''))
        if text.strip():
            conn.execute('INSERT INTO checklist(task_id,text,done,sort) VALUES(?,?,0,?)', (tid, text.strip(), i))
    log(conn, tid, 'created', 'Task created (%s)' % code)
    return tid


def update_task(conn, tid, d):
    """Update a task. Returns False when it does not exist, otherwise the id of an automatically created next occurrence (or True)."""
    old = conn.execute('SELECT * FROM tasks WHERE id=?', (tid,)).fetchone()
    if not old:
        return False
    sets, params = [], []
    finished_now = False
    for f in TASK_FIELDS:
        if f not in d:
            continue
        nv = norm_value(f, d[f])
        sets.append('%s=?' % f)
        params.append(nv)
        if f == 'status' and nv != old['status']:
            log(conn, tid, 'status', 'Status: %s → %s' % (STATUS_MAP[old['status']]['label'], STATUS_MAP[nv]['label']))
            if nv in ('prod', 'closed'):
                finished_now = True
                if not old['completed_at']:
                    sets.append('completed_at=?')
                    params.append(today_iso())
            else:
                sets.append('completed_at=?')
                params.append(None)
            if nv == 'dev' and not old['start_date'] and 'start_date' not in d:
                sets.append('start_date=?')
                params.append(today_iso())
        elif f == 'waiting_on':
            if nv != (old['waiting_on'] or ''):
                sets.append('waiting_since=?')
                params.append(today_iso() if nv else None)
                log(conn, tid, 'field', ('Waiting for: %s' % nv) if nv else 'No longer waiting (%s)' % (old['waiting_on'] or ''))
        elif f == 'repeat':
            if nv != (old['repeat'] or ''):
                log(conn, tid, 'field', 'Repeat: %s' % REPEAT_LABELS.get(nv, nv))
                if nv:
                    sets.append('spawned=?')
                    params.append(0)
        elif f in TRACKED and str(nv or '') != str(old[f] or ''):
            log(conn, tid, 'field', '%s: %s → %s' % (TRACKED[f], old[f] or '—', nv or '—'))
        elif f == 'dev':
            od = jloads(old['dev'])
            nd = jloads(nv)
            for key, label in (('tcode', 'T-code'), ('obj_name', 'Object'), ('version', 'Version'), ('signoff_by', 'UAT sign-off')):
                if (od.get(key) or '') != (nd.get(key) or ''):
                    log(conn, tid, 'dev', 'Solution info – %s: %s' % (label, nd.get(key) or '—'))
    if sets:
        sets.append('updated_at=?')
        params.append(now_ts())
        conn.execute('UPDATE tasks SET %s WHERE id=?' % ','.join(sets), params + [tid])
    if finished_now:
        nid = spawn_next(conn, tid)
        if nid:
            return nid
    return True


def trash_folder(folder):
    src = os.path.join(FILES_DIR, folder or '')
    if folder and os.path.isdir(src):
        os.makedirs(TRASH_DIR, exist_ok=True)
        dst = os.path.join(TRASH_DIR, '%s__deleted_%s' % (folder, dt.datetime.now().strftime('%Y%m%d_%H%M%S')))
        try:
            shutil.move(src, dst)
        except Exception:
            pass


# ----------------------------------------------------------------------------- demo data
def seed_demo(conn):
    d = lambda n: (today_date() + dt.timedelta(days=n)).isoformat()
    chk_close = ['Posting periods opened for the closing activities (OB52)', 'Parked / held documents cleared (FBV0, FB03 check)', 'GR/IR reviewed and cleared (MB5S, MR11)',
                 'Depreciation run done (AFAB)', 'Foreign currency valuation done (F.05 / FAGL_FCV)', 'Accruals and provisions posted (FBS1 / F.81 reversal)',
                 'Bank reconciliation completed', 'Intercompany / cross-company balances matched', 'CO allocations, WIP and variances settled', 'Trial balance reviewed with Finance',
                 'Previous period closed (OB52)']
    chk_config = ['Requirement and current setting understood (screenshot taken)', 'Change made in DEV client', 'Unit tested with test postings', 'Transport released to QAS',
                  'UAT done and sign-off mail saved', 'Transport moved to Production', 'Post-move check with a real document', 'Solution info filled in']
    chk_issue = ['Issue reproduced / example documents received', 'Root cause found', 'Fix or workaround agreed with user', 'Corrected in DEV / data corrected', 'Tested with the failing example',
                 'Moved to Production (if configuration)', 'User confirmed', 'Root cause and fix noted']
    chk_fs = ['Business requirement understood', 'Standard SAP option checked first', 'Functional spec written and shared with the ABAP developer', 'Technical design reviewed',
              'Developed and unit tested by the ABAP developer', 'Functional testing in QAS', 'UAT sign-off', 'Moved to Production', 'Documented']
    tasks = [
        dict(title='Month-end closing FI / CO - Nov 2026', task_type='periodend', module='FI-GL',
             requested_by='Accounts Head', committed_to='Accounts Head', department='Finance',
             priority='high', complexity='medium', status='dev', received_date=d(-4), start_date=d(-2), due_date=d(4), est_hours=18, repeat='monthly',
             summary='Standard monthly close: periods, GR/IR, depreciation, FX valuation, accruals, CO settlement, trial balance review.',
             req={'need': 'Close November books by the 5th working day so the MIS can go to management.', 'expected': 'All periods closed, trial balance agreed, MIS data available.',
                  'logic': ['Cut-off: last day for MM goods receipts is the 30th', 'Accruals reversed on day 1 of the next period'],
                  'tests': ['Trial balance agrees with the sub-ledger reconciliation accounts', 'No open parked documents in the period'],
                  'qa': [{'q': 'Any special accrual this month (audit fee, bonus)?', 'a': 'Bonus provision - confirm with HR'}]},
             checklist=chk_close, done=4, logs=[(d(-2), 3.0, 'GR/IR review'), (d(-1), 2.5, 'Depreciation run and checks')]),
        dict(title='Vendor payment run F110 - 14 invoices not picked', task_type='issue', module='FI-AP',
             requested_by='AP Team Lead', committed_to='AP Team Lead', department='Accounts Payable',
             priority='critical', complexity='simple', status='analysis', received_date=d(-2), start_date=d(-2), due_date=d(1), est_hours=3,
             waiting_on='User input', waiting_since=d(-1),
             summary='Payment proposal shows 14 open vendor invoices as exceptions. Vendors are waiting for payment.',
             req={'need': 'Payment run for Friday must include all due invoices.', 'expected': 'Proposal picks all due items; exceptions list is empty.',
                  'sel': [{'n': 'F110', 'd': 'Run date / identification used', 'm': True}, {'n': 'Vendors', 'd': '14 invoices of 6 vendors (list awaited from AP)', 'm': False}],
                  'logic': ['Check payment block and payment method in the vendor master (FK03)', 'Check payment method in company code (FBZP) and bank determination'],
                  'tests': ['Run a proposal again for the 14 items', 'Check the exception log in F110'],
                  'qa': [{'q': 'Which F110 run date and identification?', 'a': ''}, {'q': 'Was the vendor master changed recently?', 'a': 'Not sure, AP checking'}]},
             checklist=chk_issue, done=1, logs=[(d(-1), 1.0, 'Checked payment run log')]),
        dict(title='New TDS withholding code for transporter vendors', task_type='config', module='TAX',
             requested_by='Tax Manager', committed_to='Tax Manager', department='Taxation',
             priority='medium', complexity='medium', status='quality', received_date=d(-12), start_date=d(-10), due_date=d(3), est_hours=10,
             summary='Create a withholding tax code for transporters (with declaration) and assign to the vendor group.',
             req={'need': 'Tax wants a separate TDS code for transport vendors so the deduction is correct and the return is easy.',
                  'sel': [{'n': 'Company code', 'd': 'All plants of the company', 'm': True}, {'n': 'Vendor group', 'd': 'Transport vendors', 'm': False}],
                  'out': [{'n': 'WHT type / code', 'd': 'New code with rate and section from the Tax team'}, {'n': 'Vendor master', 'd': 'Assigned in the company code data'}],
                  'entries': [{'n': 'Vendor invoice', 'd': 'Dr expense, Cr vendor (net), Cr TDS payable'}, {'n': 'TDS payment', 'd': 'Dr TDS payable, Cr bank'}],
                  'tests': ['Vendor invoice with and without declaration', 'Payment and TDS certificate data', 'Credit memo'],
                  'existing': {'name': 'Existing WHT code for contractors', 'tcode': 'SPRO (Extended withholding tax)', 'desc': 'Current setting used for all contractors'},
                  'changes': [{'t': 'Create new WHT code and link to the WHT type', 'done': True}, {'t': 'Assign to the transporter vendors', 'done': True}]},
             dev={'tcode': 'SPRO / FK02', 'obj_name': 'WHT code for transporters', 'package': 'SPRO > Financial Accounting > AR/AP > Withholding Tax > Extended Withholding Tax', 'scope': 'Company code 1000', 'version': 'CR-114'},
             checklist=chk_config, done=4,
             moves=[('DEV', 'DEVK900512', d(-6), 'ok', ''), ('QAS', 'DEVK900512', d(-4), 'ok', 'Sent to Tax Manager for UAT')],
             issues=[('quality', 'Show TDS code text in the vendor line item report', 'Tax team needs the code visible in FBL1N layout', 'low', 'open'), ('quality', 'Add the new code to the TDS return working', '', 'medium', 'open')],
             logs=[(d(-6), 3.0, 'Configuration'), (d(-4), 2.5, 'Testing')]),
        dict(title='Asset class and depreciation key for solar panel assets', task_type='config', module='FI-AA',
             requested_by='Fixed Assets Accountant', committed_to='Accounts Head', department='Finance',
             priority='high', complexity='medium', status='prod', received_date=d(-25), start_date=d(-23), due_date=d(-9), est_hours=12,
             summary='New asset class with account determination and depreciation terms for the rooftop solar plant.',
             dev={'tcode': 'AOAA / AFAMA / AO90', 'obj_name': 'Asset class 3200 - Solar plant', 'package': 'SPRO > Financial Accounting > Asset Accounting > Asset Classes / Depreciation', 'scope': 'Company code 1000, all depreciation areas',
                  'version': 'CR-097', 'developed_on': d(-12), 'what_done': 'New asset class, account determination (cost and depreciation accounts), depreciation key and useful life for books and tax areas.',
                  'how_to_use': 'Create assets with AS01 in class 3200. Depreciation is picked up by the normal AFAB run.', 'signoff_by': 'Accounts Head', 'signoff_on': d(-10)},
             checklist=chk_config, done=8,
             moves=[('DEV', 'DEVK900431', d(-14), 'ok', ''), ('QAS', 'DEVK900431', d(-11), 'ok', ''), ('PRD', 'DEVK900431', d(-9), 'ok', 'Moved after UAT sign-off')],
             logs=[(d(-14), 4.0, 'Configuration'), (d(-12), 3.0, 'Testing with sample asset')]),
        dict(title='Plant-wise Profit Centre P&L report (spec for ABAP)', task_type='fs', module='FI-GL',
             requested_by='CFO Office', committed_to='CFO Office', department='Finance',
             priority='high', complexity='complex', status='dev', received_date=d(-8), start_date=d(-6), due_date=d(9), est_hours=26,
             waiting_on='ABAP developer', waiting_since=d(-3),
             summary='Profit centre wise P&L in management format with plant totals, month vs budget. Needs a custom ALV report.',
             req={'need': 'CFO needs a one-page plant-wise P&L every month without Excel work.', 'expected': 'ALV with plants in columns, P&L lines in rows, month, YTD and budget.',
                  'sel': [{'n': 'Company code', 'd': 'Mandatory', 'm': True}, {'n': 'Fiscal year / period', 'd': 'From and to period', 'm': True}, {'n': 'Profit centre group', 'd': 'Plant-wise groups', 'm': False}],
                  'out': [{'n': 'P&L line', 'd': 'Financial statement version (management format)'}, {'n': 'Month actual', 'd': ''}, {'n': 'YTD actual', 'd': ''}, {'n': 'Budget', 'd': 'From plan version 0'}],
                  'logic': ['Read profit centre balances and map accounts through the FS version', 'Show variance in value and percent'],
                  'tables': ['FAGLFLEXT / GLPCT - profit centre totals (check which is active)', 'FS version in OB58 / FSE2'],
                  'qa': [{'q': 'Which FS version is the management format?', 'a': 'To be shared by CFO office'}]},
             checklist=chk_fs, done=3, logs=[(d(-6), 2.0, 'Requirement meeting'), (d(-5), 3.0, 'Functional spec draft'), (d(-3), 1.0, 'Spec review with ABAP developer')]),
        dict(title='GL account creation - 38 new accounts with Schedule III mapping', task_type='master', module='FI-GL',
             requested_by='Accounts Head', committed_to='Accounts Head', department='Finance',
             priority='low', complexity='medium', status='new', received_date=d(-1), due_date=d(11), est_hours=8,
             summary='Create new expense and provision accounts from the approved Excel and map them to the balance sheet / P&L version.',
             req={'need': 'New accounts for the new plant cost heads.', 'sel': [{'n': 'Chart of accounts', 'd': 'Company chart', 'm': True}, {'n': 'Company code', 'd': '1000', 'm': True}]},
             checklist=['Excel template received and checked', 'Account groups and field status confirmed', 'Test upload with 3 accounts', 'Full upload', 'Mapped in financial statement version', 'Authorisation roles updated'], done=0),
        dict(title='Cost centre wise power and fuel expense - month vs budget', task_type='report', module='CO-OM',
             requested_by='Plant Controller', committed_to='Plant Controller', department='Costing',
             priority='medium', complexity='simple', status='closed', received_date=d(-40), start_date=d(-38), due_date=d(-26), est_hours=6,
             summary='Standard cost centre report variant with plan version and layout saved for the plant controller.',
             dev={'tcode': 'S_ALR_87013611', 'obj_name': 'Report variant PWRFUEL - cost centre actual / plan', 'package': 'Standard report, saved variant and layout', 'scope': 'Controlling area 1000', 'version': 'v1',
                  'developed_on': d(-28), 'what_done': 'Variant with cost element group (power, fuel) and cost centre group (plants), layout with variance column.',
                  'how_to_use': 'Run S_ALR_87013611, load variant PWRFUEL, enter period.', 'signoff_by': 'Plant Controller', 'signoff_on': d(-27)},
             checklist=['Standard report checked', 'Cost element and cost centre groups created', 'Variant and layout saved', 'Shown to the user', 'User guide shared'], done=5,
             logs=[(d(-30), 3.0, 'Groups and variant'), (d(-29), 1.5, 'Walkthrough with user')]),
    ]
    for t in tasks:
        extra_logs = t.pop('logs', [])
        moves = t.pop('moves', [])
        issues = t.pop('issues', [])
        done = t.pop('done', 0)
        t.setdefault('nature', 'new')
        tid = create_task(conn, t, demo=True)
        ids = [r['id'] for r in conn.execute('SELECT id FROM checklist WHERE task_id=? ORDER BY sort,id', (tid,))]
        for cid in ids[:done]:
            conn.execute('UPDATE checklist SET done=1, done_at=? WHERE id=?', (now_ts(), cid))
        for ld, hrs, note in extra_logs:
            conn.execute('INSERT INTO timelog(task_id,log_date,hours,note) VALUES(?,?,?,?)', (tid, ld, hrs, note))
        for env, tr, mon, res, note in moves:
            conn.execute('INSERT INTO moves(task_id,env,tr_number,moved_on,result,note) VALUES(?,?,?,?,?,?)', (tid, env, tr, mon, res, note))
            log(conn, tid, 'move', 'Moved to %s (%s)%s' % (env, tr, ' - issue reported' if res == 'issue' else ''))
        for kind, title, det, sev, stt in issues:
            conn.execute('INSERT INTO issues(task_id,kind,title,details,severity,status,raised_on) VALUES(?,?,?,?,?,?,?)',
                         (tid, kind, title, det, sev, stt, today_iso()))
    return len(tasks)


# ----------------------------------------------------------------------------- init / backup
def init_all():
    for p in (DATA_DIR, FILES_DIR, BACKUP_DIR):
        os.makedirs(p, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute('PRAGMA journal_mode=WAL')
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()
    try:
        daily_backup()
    except Exception:
        pass


def backup_db(label='manual'):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    dst = os.path.join(BACKUP_DIR, 'taskmanager_%s_%s.db' % (dt.datetime.now().strftime('%Y%m%d_%H%M%S'), label))
    src = sqlite3.connect(DB_PATH)
    out = sqlite3.connect(dst)
    src.backup(out)
    out.close()
    src.close()
    files = sorted(f for f in os.listdir(BACKUP_DIR) if f.endswith('.db'))
    for old in files[:-30]:
        try:
            os.remove(os.path.join(BACKUP_DIR, old))
        except Exception:
            pass
    return dst


def daily_backup():
    tag = dt.datetime.now().strftime('%Y%m%d')
    if not any(f.startswith('taskmanager_' + tag) for f in os.listdir(BACKUP_DIR)):
        backup_db('auto')


def open_path(path):
    path = os.path.abspath(path)
    if sys.platform.startswith('win'):
        os.startfile(path)  # noqa
    elif sys.platform == 'darwin':
        subprocess.Popen(['open', path])
    else:
        subprocess.Popen(['xdg-open', path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ----------------------------------------------------------------------------- xlsx writer / reader (stdlib only)
ILLEGAL_XML = re.compile('[\x00-\x08\x0b\x0c\x0e-\x1f]')


def xl_col(i):
    s = ''
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def xl_idx(letters):
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def xesc(v):
    v = ILLEGAL_XML.sub('', str(v))
    return v.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def sheet_xml(headers, rows):
    all_rows = [headers] + rows
    n = len(headers)
    widths = []
    for i in range(n):
        longest = 0
        for r in all_rows[:300]:
            v = r[i] if i < len(r) else None
            if v is None:
                continue
            longest = max(longest, max(len(x) for x in str(v).split('\n')))
        widths.append(min(60, max(8, longest + 2)))
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>',
           '<sheetFormatPr defaultRowHeight="15"/>',
           '<cols>%s</cols>' % ''.join('<col min="%d" max="%d" width="%d" customWidth="1"/>' % (i + 1, i + 1, w) for i, w in enumerate(widths)),
           '<sheetData>']
    for ri, row in enumerate(all_rows, 1):
        out.append('<row r="%d">' % ri)
        for ci in range(n):
            v = row[ci] if ci < len(row) else None
            ref = '%s%d' % (xl_col(ci), ri)
            if ri == 1:
                out.append('<c r="%s" t="inlineStr" s="1"><is><t xml:space="preserve">%s</t></is></c>' % (ref, xesc(v)))
            elif v is None or v == '':
                continue
            elif isinstance(v, (int, float)) and not isinstance(v, bool):
                out.append('<c r="%s"><v>%s</v></c>' % (ref, repr(v)))
            else:
                out.append('<c r="%s" t="inlineStr" s="2"><is><t xml:space="preserve">%s</t></is></c>' % (ref, xesc(v)))
        out.append('</row>')
    out.append('</sheetData>')
    out.append('<autoFilter ref="A1:%s%d"/>' % (xl_col(n - 1), len(all_rows)))
    out.append('</worksheet>')
    return ''.join(out)


STYLES_XML = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
              '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>'
              '<font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font></fonts>'
              '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>'
              '<fill><patternFill patternType="solid"><fgColor rgb="FF1F3A5F"/><bgColor indexed="64"/></patternFill></fill></fills>'
              '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
              '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf>'
              '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs>'
              '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')


def build_xlsx(sheets):
    """sheets = [(name, headers, rows)]"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as z:
        ct = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
              '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
              '<Default Extension="xml" ContentType="application/xml"/>',
              '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
              '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>']
        wb = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
              '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>']
        rels = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
                '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">']
        for i, (name, headers, rows) in enumerate(sheets, 1):
            nm = re.sub(r'[\[\]:*?/\\]', ' ', name)[:31]
            ct.append('<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % i)
            wb.append('<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (xesc(nm), i, i))
            rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>' % (i, i))
            z.writestr('xl/worksheets/sheet%d.xml' % i, sheet_xml(headers, rows))
        n = len(sheets)
        rels.append('<Relationship Id="rId%d" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>' % (n + 1))
        ct.append('</Types>')
        wb.append('</sheets></workbook>')
        z.writestr('[Content_Types].xml', ''.join(ct))
        z.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml', ''.join(wb))
        z.writestr('xl/_rels/workbook.xml.rels', ''.join(rels))
        z.writestr('xl/styles.xml', STYLES_XML)
    return buf.getvalue()


def read_xlsx(path, sheet_idx=0, max_rows=300, max_cols=40):
    ns = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
          'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    M = '{%s}' % ns['m']
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        sheets = [(s.get('name'), s.get('{%s}id' % ns['r'])) for s in wb.find('m:sheets', ns)]
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        rmap = {r.get('Id'): r.get('Target') for r in rels}
        sheet_idx = max(0, min(sheet_idx, len(sheets) - 1))
        target = rmap[sheets[sheet_idx][1]]
        spath = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        shared = []
        if 'xl/sharedStrings.xml' in names:
            sst = ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in sst.findall('m:si', ns):
                shared.append(''.join(t.text or '' for t in si.iter(M + 't')))
        ws = ET.fromstring(z.read(spath))
        rows = []
        for row in ws.find('m:sheetData', ns).findall('m:row', ns)[:max_rows]:
            cells = {}
            for c in row.findall('m:c', ns):
                ref = c.get('r') or ''
                m = re.match(r'[A-Z]+', ref)
                if not m:
                    continue
                ci = xl_idx(m.group())
                t = c.get('t')
                v = c.find('m:v', ns)
                if t == 's' and v is not None and v.text is not None:
                    val = shared[int(v.text)] if int(v.text) < len(shared) else ''
                elif t == 'inlineStr':
                    val = ''.join(x.text or '' for x in c.iter(M + 't'))
                elif v is not None and v.text is not None:
                    val = v.text
                    if re.fullmatch(r'-?\d+\.0+', val):
                        val = val.split('.')[0]
                else:
                    val = ''
                cells[ci] = val
            width = (max(cells) + 1) if cells else 0
            rows.append([cells.get(i, '') for i in range(min(width, max_cols))])
        return {'type': 'sheet', 'sheets': [s[0] for s in sheets], 'sheet': sheet_idx, 'rows': rows}


# ----------------------------------------------------------------------------- routing
ROUTES = []


def route(method, pattern):
    def deco(fn):
        ROUTES.append((method, re.compile('^' + pattern + '$'), fn))
        return fn
    return deco


class ApiError(Exception):
    def __init__(self, status, msg):
        Exception.__init__(self, msg)
        self.status = status
        self.msg = msg


def need(row, what='Record'):
    if not row:
        raise ApiError(404, '%s not found' % what)
    return row


@route('GET', r'/api/ping')
def api_ping(h):
    return {'app': APP_ID, 'version': APP_VERSION}


@route('GET', r'/api/meta')
def api_meta(h):
    with dbc() as c:
        st = get_settings(c)
        names = []
        for col in ('requested_by', 'committed_to'):
            for r in c.execute("SELECT DISTINCT %s AS v FROM tasks WHERE %s<>'' AND is_demo=0" % (col, col)):
                if r['v'] not in names:
                    names.append(r['v'])
        n_tasks = c.execute('SELECT COUNT(*) FROM tasks').fetchone()[0]
        n_demo = c.execute('SELECT COUNT(*) FROM tasks WHERE is_demo=1').fetchone()[0]
    return {'app': APP_ID, 'version': APP_VERSION, 'statuses': STATUSES, 'priorities': PRIORITIES,
            'type_labels': TYPE_LABELS, 'repeat_labels': REPEAT_LABELS, 'cats': CAT_LABELS, 'data_dir': os.path.abspath(DATA_DIR),
            'settings': st, 'names': names, 'today': today_iso(), 'n_tasks': n_tasks, 'n_demo': n_demo,
            'platform': sys.platform}


@route('GET', r'/api/tasks')
def api_tasks(h):
    with dbc() as c:
        return list_tasks(c)


@route('POST', r'/api/tasks')
def api_task_create(h):
    d = h.json_body()
    if not str(d.get('title', '')).strip():
        raise ApiError(400, 'Title is required')
    with dbc() as c:
        tid = create_task(c, d)
        return get_task_detail(c, tid)


@route('GET', r'/api/tasks/(\d+)')
def api_task_get(h, tid):
    with dbc() as c:
        return need(get_task_detail(c, int(tid)), 'Task')


@route('PUT', r'/api/tasks/(\d+)')
def api_task_put(h, tid):
    d = h.json_body()
    with dbc() as c:
        res = update_task(c, int(tid), d)
        if not res:
            raise ApiError(404, 'Task not found')
        detail = get_task_detail(c, int(tid))
        if res is not True:                 # a repeating task was finished: tell the page about the next one
            n = c.execute('SELECT id, code, title, due_date FROM tasks WHERE id=?', (res,)).fetchone()
            detail['spawned'] = {'id': n['id'], 'code': n['code'], 'title': n['title'], 'due_date': n['due_date']}
        return detail


@route('DELETE', r'/api/tasks/(\d+)')
def api_task_delete(h, tid):
    with dbc() as c:
        t = need(c.execute('SELECT folder FROM tasks WHERE id=?', (int(tid),)).fetchone(), 'Task')
        c.execute('DELETE FROM tasks WHERE id=?', (int(tid),))
    trash_folder(t['folder'])
    return {'ok': True}


@route('POST', r'/api/tasks/(\d+)/checklist')
def api_cl_add(h, tid):
    d = h.json_body()
    tid = int(tid)
    items = d.get('items') or ([d['text']] if d.get('text') else [])
    with dbc() as c:
        need(c.execute('SELECT 1 FROM tasks WHERE id=?', (tid,)).fetchone(), 'Task')
        mx = c.execute('SELECT COALESCE(MAX(sort),0) FROM checklist WHERE task_id=?', (tid,)).fetchone()[0]
        for i, text in enumerate(items):
            if str(text).strip():
                c.execute('INSERT INTO checklist(task_id,text,done,sort) VALUES(?,?,0,?)', (tid, str(text).strip(), mx + 1 + i))
        touch(c, tid)
        return get_task_detail(c, tid)


@route('PUT', r'/api/checklist/(\d+)')
def api_cl_put(h, cid):
    d = h.json_body()
    with dbc() as c:
        r = need(c.execute('SELECT * FROM checklist WHERE id=?', (int(cid),)).fetchone(), 'Item')
        if 'text' in d:
            c.execute('UPDATE checklist SET text=? WHERE id=?', (str(d['text']).strip() or r['text'], r['id']))
        if 'done' in d:
            done = 1 if d['done'] else 0
            c.execute('UPDATE checklist SET done=?, done_at=? WHERE id=?', (done, now_ts() if done else None, r['id']))
            if done != r['done']:
                log(c, r['task_id'], 'check', ('Done: ' if done else 'Re-opened: ') + r['text'])
        touch(c, r['task_id'])
        return get_task_detail(c, r['task_id'])


@route('DELETE', r'/api/checklist/(\d+)')
def api_cl_del(h, cid):
    with dbc() as c:
        r = need(c.execute('SELECT task_id FROM checklist WHERE id=?', (int(cid),)).fetchone(), 'Item')
        c.execute('DELETE FROM checklist WHERE id=?', (int(cid),))
        return get_task_detail(c, r['task_id'])


@route('POST', r'/api/tasks/(\d+)/time')
def api_time_add(h, tid):
    d = h.json_body()
    tid = int(tid)
    try:
        hrs = float(d.get('hours'))
    except (TypeError, ValueError):
        raise ApiError(400, 'Hours required')
    if hrs <= 0 or hrs > 24:
        raise ApiError(400, 'Hours must be between 0 and 24')
    with dbc() as c:
        need(c.execute('SELECT 1 FROM tasks WHERE id=?', (tid,)).fetchone(), 'Task')
        c.execute('INSERT INTO timelog(task_id,log_date,hours,note) VALUES(?,?,?,?)',
                  (tid, clean_date(d.get('log_date')) or today_iso(), hrs, str(d.get('note') or '').strip()))
        log(c, tid, 'time', 'Logged %s h%s' % (('%g' % hrs), (' - ' + d['note']) if d.get('note') else ''))
        touch(c, tid)
        return get_task_detail(c, tid)


@route('DELETE', r'/api/time/(\d+)')
def api_time_del(h, lid):
    with dbc() as c:
        r = need(c.execute('SELECT task_id FROM timelog WHERE id=?', (int(lid),)).fetchone(), 'Entry')
        c.execute('DELETE FROM timelog WHERE id=?', (int(lid),))
        return get_task_detail(c, r['task_id'])


@route('POST', r'/api/tasks/(\d+)/notes')
def api_note_add(h, tid):
    d = h.json_body()
    text = str(d.get('text') or '').strip()
    if not text:
        raise ApiError(400, 'Note is empty')
    with dbc() as c:
        need(c.execute('SELECT 1 FROM tasks WHERE id=?', (int(tid),)).fetchone(), 'Task')
        log(c, int(tid), 'note', text)
        touch(c, int(tid))
        return get_task_detail(c, int(tid))


@route('POST', r'/api/tasks/(\d+)/files')
def api_upload(h, tid):
    tid = int(tid)
    q = h.query
    name = safe_name(q.get('name'), 'file')
    length = int(h.headers.get('Content-Length') or 0)
    if length <= 0:
        raise ApiError(400, 'Empty upload')
    if length > MAX_UPLOAD:
        raise ApiError(413, 'File too large (max 500 MB)')
    with dbc() as c:
        t = need(c.execute('SELECT * FROM tasks WHERE id=?', (tid,)).fetchone(), 'Task')
        cat = q.get('category', 'auto')
        if cat not in CATS:
            cat = guess_category(name)
        folder = os.path.join(FILES_DIR, t['folder'], CATS[cat])
        os.makedirs(folder, exist_ok=True)
        path = unique_path(folder, name)
        remaining = length
        with open(path, 'wb') as f:
            while remaining > 0:
                chunk = h.rfile.read(min(1 << 20, remaining))
                if not chunk:
                    break
                f.write(chunk)
                remaining -= len(chunk)
        h.body_consumed = True
        if remaining > 0:
            os.remove(path)
            raise ApiError(400, 'Upload interrupted')
        rel = os.path.relpath(path, FILES_DIR).replace('\\', '/')
        cur = c.execute('INSERT INTO files(task_id,category,filename,rel_path,size,note,version,uploaded_at) VALUES(?,?,?,?,?,?,?,?)',
                        (tid, cat, os.path.basename(path), rel, os.path.getsize(path), q.get('note', ''), q.get('version', ''), now_ts()))
        log(c, tid, 'file', 'Uploaded %s (%s)' % (os.path.basename(path), CAT_LABELS[cat]))
        touch(c, tid)
        return dict(c.execute('SELECT * FROM files WHERE id=?', (cur.lastrowid,)).fetchone())


def file_row(conn, fid):
    return need(conn.execute('SELECT * FROM files WHERE id=?', (int(fid),)).fetchone(), 'File')


def file_abs(row):
    p = os.path.abspath(os.path.join(FILES_DIR, row['rel_path']))
    if not p.startswith(os.path.abspath(FILES_DIR)) or not os.path.isfile(p):
        raise ApiError(404, 'File missing on disk')
    return p


@route('PUT', r'/api/files/(\d+)')
def api_file_put(h, fid):
    d = h.json_body()
    with dbc() as c:
        r = file_row(c, fid)
        note = str(d.get('note', r['note']))
        version = str(d.get('version', r['version']))
        cat = d.get('category', r['category'])
        rel = r['rel_path']
        if cat in CATS and cat != r['category']:
            src = file_abs(r)
            t = c.execute('SELECT folder FROM tasks WHERE id=?', (r['task_id'],)).fetchone()
            dst_dir = os.path.join(FILES_DIR, t['folder'], CATS[cat])
            os.makedirs(dst_dir, exist_ok=True)
            dst = unique_path(dst_dir, r['filename'])
            shutil.move(src, dst)
            rel = os.path.relpath(dst, FILES_DIR).replace('\\', '/')
        else:
            cat = r['category']
        c.execute('UPDATE files SET note=?, version=?, category=?, rel_path=?, filename=? WHERE id=?',
                  (note, version, cat, rel, os.path.basename(rel), r['id']))
        return dict(c.execute('SELECT * FROM files WHERE id=?', (r['id'],)).fetchone())


@route('DELETE', r'/api/files/(\d+)')
def api_file_del(h, fid):
    with dbc() as c:
        r = file_row(c, fid)
        try:
            p = file_abs(r)
            os.makedirs(TRASH_DIR, exist_ok=True)
            shutil.move(p, unique_path(TRASH_DIR, '%s__%s' % (dt.datetime.now().strftime('%Y%m%d_%H%M%S'), r['filename'])))
        except ApiError:
            pass
        c.execute('DELETE FROM files WHERE id=?', (r['id'],))
        log(c, r['task_id'], 'file', 'Removed file %s' % r['filename'])
        return {'ok': True}


@route('GET', r'/files/(\d+)')
def file_get(h, fid):
    with dbc() as c:
        r = file_row(c, fid)
    p = file_abs(r)
    ctype = mimetypes.guess_type(r['filename'])[0] or 'application/octet-stream'
    inline = ctype.startswith('image/') or ctype in ('application/pdf', 'text/plain')
    if ctype == 'image/svg+xml':
        inline = False
    if h.query.get('dl'):
        inline = False
    h.send_file(p, ctype, r['filename'], inline)
    return None


@route('GET', r'/api/files/(\d+)/preview')
def file_preview(h, fid):
    with dbc() as c:
        r = file_row(c, fid)
    p = file_abs(r)
    ext = os.path.splitext(r['filename'])[1].lower()
    size = os.path.getsize(p)
    try:
        if ext in ('.xlsx', '.xlsm'):
            if size > 25 * 1024 * 1024:
                return {'type': 'none', 'reason': 'File too large for preview - open it in Excel.'}
            out = read_xlsx(p, int(h.query.get('sheet', 0)))
            out['name'] = r['filename']
            return out
        if ext in ('.csv', '.txt', '.xml', '.json', '.log', '.abap', '.md', '.html', '.htm', '.ini', '.cfg', '.sql', '.py', '.js'):
            with open(p, 'rb') as f:
                raw = f.read(400 * 1024)
            if b'\x00' in raw[:2000]:
                return {'type': 'none', 'reason': 'Binary file - cannot preview.'}
            for enc in ('utf-8-sig', 'cp1252', 'latin-1'):
                try:
                    text = raw.decode(enc)
                    break
                except Exception:
                    continue
            if ext == '.csv':
                import csv
                rows = list(csv.reader(io.StringIO(text)))[:300]
                return {'type': 'sheet', 'sheets': [r['filename']], 'sheet': 0, 'rows': [x[:40] for x in rows], 'name': r['filename']}
            return {'type': 'text', 'text': text, 'truncated': size > 400 * 1024, 'name': r['filename']}
    except Exception as e:
        return {'type': 'none', 'reason': 'Preview failed (%s). Use Download.' % e}
    return {'type': 'none', 'reason': 'No preview for this file type - use Open / Download.'}


@route('POST', r'/api/tasks/(\d+)/open-folder')
def api_open_folder(h, tid):
    with dbc() as c:
        t = need(c.execute('SELECT folder FROM tasks WHERE id=?', (int(tid),)).fetchone(), 'Task')
    make_dirs(t['folder'])
    p = os.path.join(FILES_DIR, t['folder'])
    try:
        open_path(p)
    except Exception as e:
        raise ApiError(500, 'Could not open folder: %s' % e)
    return {'ok': True, 'path': os.path.abspath(p)}


@route('POST', r'/api/open-data-folder')
def api_open_data(h):
    open_path(DATA_DIR)
    return {'ok': True, 'path': os.path.abspath(DATA_DIR)}


ISSUE_FIELDS = ['title', 'details', 'severity', 'status', 'raised_on', 'raised_by', 'fixed_on', 'fix_note']


@route('POST', r'/api/tasks/(\d+)/issues')
def api_issue_add(h, tid):
    d = h.json_body()
    tid = int(tid)
    kind = 'prod' if d.get('kind') == 'prod' else 'quality'
    title = str(d.get('title') or '').strip()
    if not title:
        raise ApiError(400, 'Title is required')
    with dbc() as c:
        need(c.execute('SELECT 1 FROM tasks WHERE id=?', (tid,)).fetchone(), 'Task')
        c.execute('INSERT INTO issues(task_id,kind,title,details,severity,status,raised_on,raised_by,fixed_on,fix_note) VALUES(?,?,?,?,?,?,?,?,?,?)',
                  (tid, kind, title, str(d.get('details') or ''), d.get('severity') or 'medium',
                   'fixed' if d.get('status') == 'fixed' else 'open', clean_date(d.get('raised_on')) or today_iso(),
                   str(d.get('raised_by') or ''), clean_date(d.get('fixed_on')), str(d.get('fix_note') or '')))
        log(c, tid, 'issue', ('Post-production issue: ' if kind == 'prod' else 'Quality point: ') + title)
        touch(c, tid)
        return get_task_detail(c, tid)


@route('PUT', r'/api/issues/(\d+)')
def api_issue_put(h, iid):
    d = h.json_body()
    with dbc() as c:
        r = need(c.execute('SELECT * FROM issues WHERE id=?', (int(iid),)).fetchone(), 'Issue')
        sets, params = [], []
        for f in ISSUE_FIELDS:
            if f in d:
                v = d[f]
                if f in ('raised_on', 'fixed_on'):
                    v = clean_date(v)
                sets.append('%s=?' % f)
                params.append(v)
        if d.get('status') == 'fixed' and r['status'] != 'fixed':
            if 'fixed_on' not in d:
                sets.append('fixed_on=?')
                params.append(today_iso())
            log(c, r['task_id'], 'issue', 'Resolved: ' + r['title'])
        if d.get('status') == 'open' and r['status'] != 'open':
            sets.append('fixed_on=?')
            params.append(None)
            log(c, r['task_id'], 'issue', 'Re-opened: ' + r['title'])
        if sets:
            c.execute('UPDATE issues SET %s WHERE id=?' % ','.join(sets), params + [r['id']])
        touch(c, r['task_id'])
        return get_task_detail(c, r['task_id'])


@route('DELETE', r'/api/issues/(\d+)')
def api_issue_del(h, iid):
    with dbc() as c:
        r = need(c.execute('SELECT task_id FROM issues WHERE id=?', (int(iid),)).fetchone(), 'Issue')
        c.execute('DELETE FROM issues WHERE id=?', (int(iid),))
        return get_task_detail(c, r['task_id'])


@route('GET', r'/api/issues')
def api_issues(h):
    with dbc() as c:
        return row_dicts(c.execute(
            'SELECT i.*, t.code, t.title AS task_title, t.module, t.status AS task_status FROM issues i JOIN tasks t ON t.id=i.task_id ORDER BY i.status, i.id DESC'))


@route('POST', r'/api/tasks/(\d+)/moves')
def api_move_add(h, tid):
    d = h.json_body()
    tid = int(tid)
    env = str(d.get('env') or 'DEV').upper()
    if env not in ('DEV', 'QAS', 'PRD'):
        raise ApiError(400, 'Environment must be DEV, QAS or PRD')
    with dbc() as c:
        need(c.execute('SELECT 1 FROM tasks WHERE id=?', (tid,)).fetchone(), 'Task')
        res = 'issue' if d.get('result') == 'issue' else 'ok'
        c.execute('INSERT INTO moves(task_id,env,tr_number,moved_on,result,note) VALUES(?,?,?,?,?,?)',
                  (tid, env, str(d.get('tr_number') or '').strip(), clean_date(d.get('moved_on')) or today_iso(), res, str(d.get('note') or '')))
        log(c, tid, 'move', 'Moved to %s%s%s' % (env, (' (%s)' % d['tr_number']) if d.get('tr_number') else '', ' - issue reported' if res == 'issue' else ''))
        touch(c, tid)
        return get_task_detail(c, tid)


@route('PUT', r'/api/moves/(\d+)')
def api_move_put(h, mid):
    d = h.json_body()
    with dbc() as c:
        r = need(c.execute('SELECT * FROM moves WHERE id=?', (int(mid),)).fetchone(), 'Move')
        c.execute('UPDATE moves SET env=?, tr_number=?, moved_on=?, result=?, note=? WHERE id=?',
                  (str(d.get('env', r['env'])).upper(), str(d.get('tr_number', r['tr_number'])), clean_date(d.get('moved_on', r['moved_on'])) or r['moved_on'],
                   'issue' if d.get('result', r['result']) == 'issue' else 'ok', str(d.get('note', r['note'])), r['id']))
        touch(c, r['task_id'])
        return get_task_detail(c, r['task_id'])


@route('DELETE', r'/api/moves/(\d+)')
def api_move_del(h, mid):
    with dbc() as c:
        r = need(c.execute('SELECT task_id FROM moves WHERE id=?', (int(mid),)).fetchone(), 'Move')
        c.execute('DELETE FROM moves WHERE id=?', (int(mid),))
        return get_task_detail(c, r['task_id'])


@route('GET', r'/api/moves')
def api_moves(h):
    with dbc() as c:
        return row_dicts(c.execute(
            'SELECT m.*, t.code, t.title AS task_title, t.module FROM moves m JOIN tasks t ON t.id=m.task_id ORDER BY m.moved_on DESC, m.id DESC'))


@route('GET', r'/api/history')
def api_history(h):
    lim = max(1, min(200, int(h.query.get('limit', 40))))
    with dbc() as c:
        return row_dicts(c.execute(
            'SELECT h.*, t.code, t.title AS task_title FROM history h JOIN tasks t ON t.id=h.task_id ORDER BY h.id DESC LIMIT ?', (lim,)))


@route('GET', r'/api/settings')
def api_settings_get(h):
    with dbc() as c:
        return get_settings(c)


@route('PUT', r'/api/settings')
def api_settings_put(h):
    d = h.json_body()
    with dbc() as c:
        for k in DEFAULT_SETTINGS:
            if k in d:
                v = str(d[k]).strip()
                if k == 'hours_per_day':
                    try:
                        v = str(max(1.0, min(16.0, float(v)))).rstrip('0').rstrip('.')
                    except ValueError:
                        v = '6'
                elif k in ('warn_days', 'urgent_days'):
                    v = str(max(0, min(60, int(float(v or 0)))))
                elif k == 'work_days':
                    v = ','.join(str(x) for x in sorted(work_days_of({'work_days': v})))
                c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value', (k, v))
        return get_settings(c)


@route('POST', r'/api/backup')
def api_backup(h):
    p = backup_db('manual')
    return {'ok': True, 'file': os.path.basename(p), 'path': p}


@route('GET', r'/api/backups')
def api_backups(h):
    out = []
    if os.path.isdir(BACKUP_DIR):
        for f in sorted(os.listdir(BACKUP_DIR), reverse=True):
            if f.endswith('.db'):
                p = os.path.join(BACKUP_DIR, f)
                out.append({'name': f, 'size': os.path.getsize(p)})
    return out[:15]


@route('POST', r'/api/demo')
def api_demo_load(h):
    with dbc() as c:
        n = seed_demo(c)
    return {'ok': True, 'added': n}


@route('DELETE', r'/api/demo')
def api_demo_del(h):
    with dbc() as c:
        rows = c.execute('SELECT id, folder FROM tasks WHERE is_demo=1').fetchall()
        for r in rows:
            c.execute('DELETE FROM tasks WHERE id=?', (r['id'],))
    for r in rows:
        shutil.rmtree(os.path.join(FILES_DIR, r['folder'] or '#none#'), ignore_errors=True)
    return {'ok': True, 'removed': len(rows)}


@route('POST', r'/api/shutdown')
def api_shutdown(h):
    httpd = SERVER.get('httpd')
    if httpd:
        threading.Thread(target=httpd.shutdown, daemon=True).start()
    return {'ok': True}


def lines(v):
    return [x for x in (v or [])]


@route('GET', r'/api/export\.xlsx')
def api_export(h):
    with dbc() as c:
        tasks = list_tasks(c, ' ORDER BY t.id')
        moves = row_dicts(c.execute('SELECT m.*, t.code, t.title AS tt FROM moves m JOIN tasks t ON t.id=m.task_id ORDER BY m.moved_on, m.id'))
        issues = row_dicts(c.execute('SELECT i.*, t.code, t.title AS tt FROM issues i JOIN tasks t ON t.id=i.task_id ORDER BY i.id'))
        times = row_dicts(c.execute('SELECT l.*, t.code, t.title AS tt FROM timelog l JOIN tasks t ON t.id=l.task_id ORDER BY l.log_date, l.id'))
        reqs = {r['id']: jloads(r['req']) for r in c.execute('SELECT id, req FROM tasks')}
    st_label = lambda k: STATUS_MAP.get(k, {}).get('label', k)
    s_tasks = [[t['code'], t['title'], TYPE_LABELS.get(t['task_type'], t['task_type']), 'Change in existing' if t['nature'] == 'change' else 'New', t['module'],
                t['requested_by'], t['committed_to'], t['priority'], st_label(t['status']), t['progress'], t['urgency'], t['received_date'],
                t['start_date'], t['due_date'], t['days_left'], t['est_hours'], t['logged'], t['remaining_hours'],
                '%d/%d' % (t['cl_done'], t['cl_total']), t['q_open'], t['p_open'], t['dev'].get('tcode', ''), t['dev'].get('obj_name', ''), t.get('waiting_on', ''), REPEAT_LABELS.get(t.get('repeat') or '', ''), t['summary']]
               for t in tasks]
    h1 = ['Code', 'Title', 'Type', 'Nature', 'Module', 'Requested by', 'Committed to', 'Priority', 'Status', 'Progress %', 'Urgency', 'Received',
          'Start', 'Due', 'Days left', 'Est. hours', 'Logged hours', 'Remaining hours', 'Checklist', 'Open UAT points', 'Open prod issues', 'T-code', 'Object configured / name', 'Waiting for', 'Repeats', 'Summary']
    s_reg = []
    for t in tasks:
        dv = t['dev']
        if dv.get('obj_name') or dv.get('tcode') or t['status'] in ('prod', 'closed'):
            s_reg.append([t['code'], dv.get('obj_name', ''), dv.get('tcode', ''), TYPE_LABELS.get(t['task_type'], ''), t['module'], t['title'], t['requested_by'],
                          dv.get('developed_on', ''), dv.get('version', ''), dv.get('package', ''), dv.get('scope', ''), t['prd_date'] or '',
                          '%d open / %d total' % (t['p_open'], t['p_total']), st_label(t['status']), dv.get('tables', ''), dv.get('what_done', ''), dv.get('how_to_use', ''),
                          dv.get('signoff_by', ''), dv.get('signoff_on', '')])
    h2 = ['Code', 'Object / config name', 'T-code / SPRO node', 'Type', 'Module', 'Title', 'Requested by', 'Done on', 'Version / CR no.', 'SPRO / IMG path', 'Scope (company code, plant)', 'Moved to PRD', 'Post-prod issues',
          'Status', 'Tables used', 'What was done', 'How to use', 'UAT sign-off by', 'Sign-off date']
    s_moves = [[m['code'], m['tt'], m['env'], m['tr_number'], m['moved_on'], 'Issue after move' if m['result'] == 'issue' else 'OK', m['note']] for m in moves]
    h3 = ['Code', 'Title', 'Environment', 'Transport', 'Date', 'Result', 'Note']
    s_issues = [[i['code'], i['tt'], 'Post-production' if i['kind'] == 'prod' else 'UAT / Quality', i['title'], i['details'], i['severity'], i['status'], i['raised_on'], i['fixed_on'] or '', i['fix_note']] for i in issues]
    h4 = ['Code', 'Title', 'Kind', 'Issue / point', 'Details', 'Severity', 'Status', 'Raised', 'Fixed', 'Fix note']
    s_time = [[x['code'], x['tt'], x['log_date'], x['hours'], x['note']] for x in times]
    h5 = ['Code', 'Title', 'Date', 'Hours', 'Note']
    sections = [('sel', 'Scope / input'), ('out', 'Settings / output'), ('entries', 'Accounting entry'), ('logic', 'Business rule / logic'), ('valid', 'Check / validation'),
                ('auth', 'Authorisation'), ('tables', 'T-code / path / table'), ('tests', 'Test scenario'), ('qa', 'Question'), ('changes', 'Change point')]
    s_req = []
    for t in tasks:
        rq = reqs.get(t['id'], {})
        for key, label in sections:
            for it in rq.get(key) or []:
                if isinstance(it, dict):
                    if key in ('sel', 'out', 'entries'):
                        s_req.append([t['code'], t['title'], label, it.get('n', ''), it.get('d', '') + (' (mandatory)' if it.get('m') else '')])
                    elif key == 'qa':
                        s_req.append([t['code'], t['title'], label, it.get('q', ''), it.get('a', '')])
                    elif key == 'changes':
                        s_req.append([t['code'], t['title'], label, it.get('t', ''), 'done' if it.get('done') else 'pending'])
                else:
                    s_req.append([t['code'], t['title'], label, str(it), ''])
    h6 = ['Code', 'Title', 'Section', 'Item', 'Description / answer']
    data = build_xlsx([('Tasks', h1, s_tasks), ('Register', h2, s_reg), ('Transports', h3, s_moves), ('Issues & quality points', h4, s_issues),
                       ('Time log', h5, s_time), ('Requirement points', h6, s_req)])
    h.send_bytes(data, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                 'FICO_TaskManager_Export_%s.xlsx' % dt.datetime.now().strftime('%Y%m%d_%H%M'), inline=False)
    return None


# ----------------------------------------------------------------------------- HTTP handler
class Handler(BaseHTTPRequestHandler):
    server_version = 'FICOTaskManager/' + APP_VERSION
    protocol_version = 'HTTP/1.1'

    def log_message(self, *a):
        pass

    # -- helpers
    def json_body(self):
        length = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(length) if length else b''
        self.body_consumed = True
        if not raw:
            return {}
        try:
            return json.loads(raw.decode('utf-8'))
        except Exception:
            raise ApiError(400, 'Invalid JSON')

    def send_json(self, obj, status=200):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

    def send_bytes(self, data, ctype, filename=None, inline=True):
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        if filename:
            self.send_header('Content-Disposition', "%s; filename*=UTF-8''%s" % ('inline' if inline else 'attachment', quote(filename)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)
        self.responded = True

    def send_file(self, path, ctype, filename=None, inline=True):
        size = os.path.getsize(path)
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(size))
        self.send_header('X-Content-Type-Options', 'nosniff')
        if filename:
            # uploaded user files: never let them run as part of the app page
            self.send_header('Content-Security-Policy', 'sandbox')
        if filename:
            self.send_header('Content-Disposition', "%s; filename*=UTF-8''%s" % ('inline' if inline else 'attachment', quote(filename)))
        self.send_header('Cache-Control', 'no-cache')
        self.end_headers()
        with open(path, 'rb') as f:
            while True:
                chunk = f.read(1 << 20)
                if not chunk:
                    break
                self.wfile.write(chunk)
        self.responded = True

    def host_ok(self):
        host = (self.headers.get('Host') or '').split(':')[0].lower()
        return host in ('127.0.0.1', 'localhost', '[::1]', '')

    def handle_any(self, method):
        SERVER['last_seen'] = time.time()
        self.body_consumed = False
        self.responded = False
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        self.query = {k: v[0] for k, v in parse_qs(parsed.query, keep_blank_values=True).items()}
        try:
            if not self.host_ok():
                raise ApiError(403, 'Forbidden host')
            if path.startswith('/api/') or path.startswith('/files/'):
                if method != 'GET' and self.headers.get('X-TM') != '1':
                    raise ApiError(403, 'Missing X-TM header')
                for m, rx, fn in ROUTES:
                    if m != method:
                        continue
                    mt = rx.match(path)
                    if mt:
                        res = fn(self, *mt.groups())
                        if res is not None and not self.responded:
                            self.send_json(res)
                        return
                raise ApiError(404, 'Unknown endpoint')
            if method == 'GET':
                return self.serve_static(path)
            raise ApiError(405, 'Method not allowed')
        except ApiError as e:
            self.fail(e.status, e.msg)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
        except Exception as e:
            traceback.print_exc()
            self.fail(500, 'Server error: %s' % e)
        finally:
            if method in ('POST', 'PUT', 'DELETE') and not self.body_consumed:
                self.close_connection = True

    def fail(self, status, msg):
        if self.responded:
            return
        try:
            self.send_json({'error': msg}, status)
        except Exception:
            self.close_connection = True

    def serve_static(self, path):
        if path in ('', '/'):
            path = '/index.html'
        full = os.path.abspath(os.path.join(STATIC_DIR, path.lstrip('/')))
        if not full.startswith(os.path.abspath(STATIC_DIR)) or not os.path.isfile(full):
            raise ApiError(404, 'Not found')
        # fixed types: the Windows registry sometimes maps .js to text/plain, which browsers refuse to run
        ext = os.path.splitext(full)[1].lower()
        ctype = STATIC_TYPES.get(ext) or mimetypes.guess_type(full)[0] or 'application/octet-stream'
        if ctype.startswith('text/') or ctype in ('application/javascript', 'application/json'):
            ctype += '; charset=utf-8'
        self.send_file(full, ctype)

    def do_GET(self):
        self.handle_any('GET')

    def do_POST(self):
        self.handle_any('POST')

    def do_PUT(self):
        self.handle_any('PUT')

    def do_DELETE(self):
        self.handle_any('DELETE')


mimetypes.add_type('application/javascript', '.js')
mimetypes.add_type('image/x-icon', '.ico')
STATIC_TYPES = {'.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
                '.png': 'image/png', '.json': 'application/json'}


# ----------------------------------------------------------------------------- run
def idle_watch(httpd, seconds):
    """Stop the server when the browser window has been closed for `seconds`."""
    poll = min(15, max(1, seconds // 3))
    prev = time.time()
    while True:
        time.sleep(poll)
        now = time.time()
        if now - prev > poll + 45:
            # the PC was asleep / suspended: give the open window time to reconnect before judging idleness
            SERVER['last_seen'] = now
        prev = now
        if now - SERVER['last_seen'] > seconds:
            httpd.shutdown()
            return


class LocalServer(ThreadingHTTPServer):
    # On Windows SO_REUSEADDR lets a second copy bind the same port, so use exclusive binding there.
    allow_reuse_address = not sys.platform.startswith('win')

    def server_bind(self):
        if sys.platform.startswith('win') and hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        ThreadingHTTPServer.server_bind(self)


def serve(port=DEFAULT_PORT, idle_exit=0):
    init_all()
    httpd = LocalServer(('127.0.0.1', port), Handler)
    httpd.daemon_threads = True
    SERVER['httpd'] = httpd
    SERVER['last_seen'] = time.time()
    if idle_exit:
        threading.Thread(target=idle_watch, args=(httpd, idle_exit), daemon=True).start()
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description='FICO Task Manager server')
    ap.add_argument('--port', type=int, default=DEFAULT_PORT)
    ap.add_argument('--idle-exit', type=int, default=0, help='stop automatically after N idle seconds (0 = never)')
    a = ap.parse_args()
    try:
        print('FICO Task Manager running on http://127.0.0.1:%d  (Ctrl+C to stop)' % a.port)
        print('Data folder: %s' % os.path.abspath(DATA_DIR), flush=True)
    except Exception:
        pass    # no console (pythonw) or a console that cannot show the path characters
    try:
        serve(a.port, a.idle_exit)
    except KeyboardInterrupt:
        pass
