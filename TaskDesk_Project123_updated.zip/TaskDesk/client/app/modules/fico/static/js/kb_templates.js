/* Ready templates for the "New task" screen (type, module, summary, scope, settings, logic, hours).
   Item format:  'Name:Description'  or  'Name:Description:1'  (the last 1 means mandatory).
   Do not use a colon inside a name or a description. hours = estimate for your own time.
   repeat: 'monthly' makes the task create the next one when you finish it. */
(function () {
  const tpl = (module, type, title, summary, extra) => Object.assign({ module: module, type: type, title: title, summary: summary, complexity: 'medium' }, extra || {});
  const L = window.KB.templates;
  const add = (...x) => x.forEach((t) => L.push(t));

  /* ---------- FI-GL ---------- */
  add(
    tpl('FI-GL', 'issue', 'Posting period not open - document cannot be posted', 'User gets a message that the posting period is closed for the account type or account range.', {
      complexity: 'simple', hours: 2,
      sel: ['T-code:Transaction where the message comes:1', 'Company code:Company code:1', 'Posting date:Date the user entered:1', 'Account type:Vendor / customer / GL / asset'],
      out: ['Expected:Posting is allowed', 'Actual:Message that the period is closed'],
      tables: ['OB52', 'T001B', 'OBY6'],
      logic: ['Check the posting period variant of the company code (OBY6)', 'In OB52 check the interval for the account type and the account range, and the special periods', 'Check the authorisation group of the period (F_BKPF_BUP) for the user', 'If MM is involved also check MMPV / MMRV']
    }),
    tpl('FI-GL', 'config', 'Document type and number range', 'New accounting document type with its own number range for a company code.', {
      complexity: 'simple', hours: 3,
      sel: ['Company code:Company code:1', 'Fiscal year:Number range interval is per year'],
      out: ['Document type:Two character key and text', 'Number range:Interval, internal or external', 'Reversal type:Type used when the document is reversed', 'Account types allowed:Vendor, customer, asset, GL', 'Required during entry:Reference number, document header text'],
      tables: ['OBA7', 'FBN1', 'T003', 'T003O'],
      logic: ['Check if an existing type can be used', 'External numbering only if an upload needs it', 'Maintain the number range interval for the current and the next fiscal year (FBN1)']
    }),
    tpl('FI-GL', 'config', 'Field status group change (make a field mandatory or hidden)', 'Make a field such as text, assignment or cost centre mandatory, optional or hidden for a group of GL accounts.', {
      complexity: 'simple', hours: 3,
      sel: ['Company code:Company code:1', 'Accounts:GL accounts or account group concerned:1', 'Field status group:Group now assigned to the accounts'],
      out: ['Field:The field to change, for example Text or Cost centre', 'Status:Required, optional, display or hidden'],
      tables: ['OBC4', 'FS00', 'OB41'],
      logic: ['The screen of a posting is a result of the account field status group and the posting key field status', 'Copy the group instead of changing one that many accounts share', 'Test with the posting key used for the case']
    }),
    tpl('FI-GL', 'config', 'Tolerance group for a user (posting limits)', 'Posting limit and payment difference limits for a new or changed user group.', {
      complexity: 'simple', hours: 2,
      sel: ['Company code:Company code:1', 'Tolerance group:Group name', 'Users:Users to assign'],
      out: ['Amount per document:Upper limit', 'Amount per line item:Upper limit', 'Payment difference:Limits for gain and loss'],
      tables: ['OBA4', 'OB57']
    }),
    tpl('FI-GL', 'config', 'Validation or substitution rule', 'A rule that blocks a wrong posting or fills a field automatically.', {
      hours: 6,
      sel: ['Callup point:Header, line item or complete document:1', 'Company code:Where the rule is active:1', 'Condition:When the rule applies:1'],
      out: ['Message:Text and type, error or warning', 'Substituted field:Value to fill'],
      tables: ['GGB0', 'GGB1', 'OB28', 'OBBH'],
      logic: ['Activate the rule per company code (OB28 for validations, OBBH for substitutions)', 'Callup point 1 is the header, 2 the line item, 3 the complete document', 'Test with FB60, FB50 and with a posting that comes from MM or SD'],
      valid: ['Rule does not block uploads and system postings by mistake', 'Message text is clear to the user']
    }),
    tpl('FI-GL', 'master', 'GL account creation with Schedule III mapping', 'Create new GL accounts from the approved Excel and map them to the balance sheet and P&L version.', {
      hours: 8,
      sel: ['Chart of accounts:Operating chart:1', 'Company code:Company code:1', 'Number of accounts:Volume of the Excel'],
      out: ['GL account:Number', 'Short text:Up to 20 characters', 'Long text:Description', 'Account group:Controls the fields', 'Account type:P&L or balance sheet', 'Reconciliation account type:Only for sub-ledger accounts', 'Field status group:Mandatory fields at posting', 'FS version node:Where the account appears'],
      tables: ['FS00', 'FSP0', 'FSS0', 'OB58', 'SKA1', 'SKB1'],
      logic: ['Create at chart level and extend to the company code', 'Check that the account is assigned in the financial statement version, else it appears as unassigned in F.01', 'Check tax category and open item management flags']
    }),
    tpl('FI-GL', 'report', 'Trial balance - opening, movement, closing', 'Trial balance by company code and period with opening balance, debit, credit and closing balance.', {
      complexity: 'simple', hours: 4,
      sel: ['Company code:Company code:1', 'Fiscal year and period:From and to:1', 'Account range:GL accounts or group', 'Currency type:Company code or group currency'],
      out: ['GL account:Number and text', 'Opening balance:Brought forward', 'Debit:Period movement', 'Credit:Period movement', 'Closing balance:After the period'],
      tables: ['S_ALR_87012277', 'FAGLB03', 'FS10N', 'F.08'],
      logic: ['Use the standard report with a saved variant and layout first', 'Spec to ABAP only if the grouping by plant or by management format is needed']
    }),
    tpl('FI-GL', 'report', 'Balance sheet and P&L in Schedule III format', 'Financial statement version with the Schedule III heads, current and previous year, with unassigned accounts check.', {
      complexity: 'complex', hours: 14,
      sel: ['Company code:Company code:1', 'Fiscal year:Current year:1', 'Comparison year:Previous year', 'Financial statement version:Version name:1'],
      out: ['FS item:Head and sub-head as in the format', 'Current year:Amount', 'Previous year:Amount', 'Note reference:Schedule note number'],
      tables: ['OB58', 'FSE2', 'F.01', 'S_ALR_87012284', 'OB53'],
      logic: ['Build the nodes of the format and assign the accounts', 'Run F.01 and check the list of unassigned accounts', 'Set the retained earnings account (OB53) so the P&L result moves to the balance sheet', 'Tie totals to the trial balance']
    }),
    tpl('FI-GL', 'periodend', 'Month-end closing - FI and CO', 'Standard monthly closing from periods to trial balance. Set to repeat every month.', {
      complexity: 'medium', hours: 16, repeat: 'monthly',
      sel: ['Company code:Company codes closed:1', 'Fiscal year and period:Period being closed:1', 'Cut-off date:Last date for other departments'],
      out: ['Closed periods:FI, MM, CO', 'Trial balance:Signed off', 'Reconciliations:AP, AR, assets, stock, bank', 'Open points:Carried to next month']
    }),
    tpl('FI-GL', 'periodend', 'Foreign currency valuation of open items and balances', 'Month-end valuation of foreign currency open items and bank balances with reversal in the next period.', {
      hours: 6, repeat: 'monthly',
      sel: ['Company code:Company code:1', 'Key date:Month end date:1', 'Valuation method:Method defined in OB59'],
      out: ['Valuation difference:Unrealised gain or loss', 'Reversal posting:Next period first day'],
      entries: ['Unrealised loss:Dr exchange loss, Cr revaluation or reconciliation account', 'Unrealised gain:Dr revaluation account, Cr exchange gain', 'Reversal:Opposite entry on the first day of the next period'],
      tables: ['F.05', 'FAGL_FCV', 'OB08', 'OB59'],
      logic: ['Load the month-end exchange rates first (OB08)', 'Run in test mode and review the list before the update run', 'Check the reversal posting date']
    }),
    tpl('FI-GL', 'periodend', 'Accruals and provisions with automatic reversal', 'Month-end accrual of expenses (audit fee, bonus, freight, utilities) reversed in the next period.', {
      complexity: 'simple', hours: 4, repeat: 'monthly',
      sel: ['Company code:Company code:1', 'Period:Period of the accrual:1', 'Accrual list:Items and amounts from the departments:1'],
      out: ['Accrual documents:One document per item or one batch', 'Reversal date:First day of the next period'],
      entries: ['Accrual:Dr expense with cost centre, Cr provision or accrued liability', 'Reversal:Dr provision, Cr expense in the next period'],
      tables: ['FBS1', 'F.81', 'FBD1', 'F.14'],
      logic: ['Use the accrual posting with the reversal date so the reversal is automatic', 'Run F.81 on the first day of the next period', 'Keep the approval of each amount']
    }),
    tpl('FI-GL', 'periodend', 'Year-end closing and balance carry forward', 'Closing of the fiscal year: audit adjustments, assets, balance carry forward, opening the new year.', {
      complexity: 'complex', hours: 20,
      sel: ['Company code:Company codes:1', 'Fiscal year:Year being closed:1', 'Controlling area:For CO year change'],
      out: ['New fiscal year open:FI, MM, CO, assets', 'Balances carried forward:GL, vendor, customer', 'Asset year-end closing:Done', 'Audit adjustments:Posted in special periods'],
      tables: ['F.16', 'FAGLGVTR', 'AJAB', 'AJRW', 'OB52', 'MMPV', 'MMRV'],
      logic: ['Finish the audit adjustments in the special periods 13 to 16', 'Asset year-end closing (AJAB) only after depreciation for all periods; then the fiscal year change (AJRW)', 'Run the balance carry forward and repeat it after late adjustments', 'MM: close the last period and open the new year', 'Keep the previous year posting periods closed after sign-off']
    })
  );

  /* ---------- FI-AP ---------- */
  add(
    tpl('FI-AP', 'issue', 'Vendor payment run - items not picked or in exception list', 'Open vendor invoices are not selected in the F110 proposal or appear in the exception list.', {
      complexity: 'simple', hours: 3,
      sel: ['Run date and identification:F110 parameters:1', 'Vendor and invoices:Examples of the items not picked:1', 'Company code:Paying company code'],
      out: ['Expected:Invoices due are in the proposal', 'Actual:Items missing or in the exception list'],
      tables: ['F110', 'FBZP', 'REGUH', 'REGUP', 'T008'],
      logic: ['Open the log of the proposal and read the reason for each item', 'Check payment block on the vendor and on the item', 'Check the payment method in the vendor master and in FBZP for the company code and country', 'Check due date against the next payment run date', 'Check bank determination: ranking and available amounts'],
      qa: ['Which F110 run date and identification?', 'Which invoices and vendors?', 'Was the vendor or the configuration changed recently?']
    }),
    tpl('FI-AP', 'config', 'Payment terms and payment method', 'New payment term (days net, discount) or a new payment method for a company code and bank.', {
      complexity: 'simple', hours: 4,
      sel: ['Company code:Company code:1', 'Country:For the payment method', 'House bank:Bank for the method'],
      out: ['Payment term key:Four character key', 'Days net and discount:Terms text', 'Baseline date rule:Posting date or document date', 'Payment method:Cheque, transfer, other', 'Bank determination:Ranking and amounts'],
      tables: ['OBB8', 'FBZP', 'T052', 'FI12'],
      logic: ['Check if an existing term gives the same result', 'In FBZP the payment method must be allowed in the country, in the paying company code and in the bank determination', 'Test with a proposal in F110']
    }),
    tpl('FI-AP', 'report', 'Vendor ageing and due-date wise payable report', 'Open vendor items grouped by ageing buckets as on a key date with due date from payment terms.', {
      complexity: 'simple', hours: 6,
      sel: ['Company code:Company code:1', 'Key date:As-on date:1', 'Vendor or account group:Vendors in the report', 'Ageing buckets:For example 0-30, 31-60, 61-90, 90+'],
      out: ['Vendor:Number and name', 'Invoice and date:Document number, reference, date', 'Due date:Baseline date plus terms', 'Days overdue:Key date minus due date', 'Amount:In local currency'],
      tables: ['FBL1N', 'BSIK', 'LFA1', 'T052'],
      logic: ['Standard FBL1N with a layout and an ageing list is usually enough', 'Reconcile the total to the vendor reconciliation account']
    }),
    tpl('FI-AP', 'fs', 'MSME vendor payment ageing report (spec for ABAP)', 'List of MSME vendor invoices with the due date as per the allowed days, payment date and overdue days. Needed for the tax and statutory disclosure.', {
      complexity: 'medium', hours: 12,
      sel: ['Company code:Company code:1', 'Key date:As-on date:1', 'Allowed days:Parameter, confirm the current rule with Finance:1', 'MSME indicator:Vendors flagged as MSME'],
      out: ['Vendor and MSME category:From the vendor master', 'Invoice date and acceptance date:Document and goods receipt date', 'Due date as per the rule:Parameter days from the start date', 'Payment date:From the clearing document', 'Days overdue:Payment or key date minus due date', 'Amount:Local currency'],
      tables: ['LFA1', 'BSIK', 'BSAK', 'MKPF', 'EKBE'],
      logic: ['Keep the number of days as a parameter and not in the code', 'Confirm which date is the start date, invoice date or acceptance date', 'Include invoices cleared in the period for the paid-late list', 'Reconcile the total to the vendor balances']
    }),
    tpl('FI-AP', 'master', 'Vendor company code data extension', 'Extend vendors to a new company code with reconciliation account, payment terms, payment method and withholding tax.', {
      hours: 8,
      sel: ['Company code:Target company code:1', 'Vendors:List from the user:1'],
      out: ['Vendor number:Existing vendor', 'Reconciliation account:Payable account', 'Payment terms:Key', 'Payment method:Allowed methods', 'Withholding tax:Type and code', 'Bank details:Verified by the user'],
      tables: ['FK01', 'FK02', 'LFB1', 'LFBW', 'LFBK'],
      logic: ['Use the standard tool and a test with 3 vendors', 'Bank details are verified by a second person before the payment run'],
      auth: ['F_LFA1_BUK for the company code', 'Segregation: the person who creates is not the person who pays']
    }),
    tpl('FI-AP', 'periodend', 'Vendor reconciliation and balance confirmation', 'Vendor wise balance list, confirmation letters and difference follow-up at month, quarter or year end.', {
      hours: 6,
      sel: ['Company code:Company code:1', 'Key date:Period end:1', 'Vendors:All or selected vendors'],
      out: ['Vendor balance list:From SAP', 'Confirmation letters:Sent to the vendors', 'Difference list:Vendor balance against SAP'],
      tables: ['FBL1N', 'FK10N', 'S_ALR_87012082']
    })
  );

  /* ---------- FI-AR ---------- */
  add(
    tpl('FI-AR', 'report', 'Customer ageing and outstanding with credit days', 'Open customer items by ageing bucket, credit days and overdue amount as on a key date.', {
      complexity: 'simple', hours: 6,
      sel: ['Company code:Company code:1', 'Key date:As-on date:1', 'Customer or group:Customers in the report', 'Sales area or region:For management'],
      out: ['Customer:Number and name', 'Invoice and date:Document, reference, date', 'Due date:Baseline date plus terms', 'Ageing bucket:0-30, 31-60, 61-90, 90+', 'Credit limit:From the credit master', 'Overdue amount:Total beyond due date'],
      tables: ['FBL5N', 'BSID', 'KNA1', 'KNKK', 'FD32'],
      logic: ['FBL5N with an ageing layout is often enough', 'Add the credit limit only if the standard layout cannot show it (spec to ABAP)']
    }),
    tpl('FI-AR', 'config', 'Credit control area and credit limit setup', 'Credit control for a company code: control area, limits, risk categories and automatic checks.', {
      complexity: 'complex', hours: 8,
      sel: ['Company code:Company code:1', 'Credit control area:Area key', 'Customers:Customers to set up'],
      out: ['Credit control area:Define and assign to the company code', 'Risk category:Categories used', 'Credit limit:Per customer or group', 'Automatic credit check:SD credit check settings'],
      tables: ['OB01', 'OB45', 'FD32', 'OVA8'],
      logic: ['Credit exposure includes open orders, deliveries and open items', 'Coordinate the SD check (OVA8) with the SD consultant']
    }),
    tpl('FI-AR', 'periodend', 'Dunning run', 'Dunning proposal, review and printing with the right dunning level for overdue customers.', {
      complexity: 'simple', hours: 4, repeat: 'monthly',
      sel: ['Company code:Company code:1', 'Run date and identification:F150 parameters:1', 'Customers:Range or all'],
      out: ['Dunning proposal:Reviewed by the collection team', 'Dunning notices:Printed or mailed', 'Dunning log:Saved'],
      tables: ['F150', 'FBMP', 'MAHNV', 'MHND']
    }),
    tpl('FI-AR', 'issue', 'Customer payment clearing - short payment or residual items', 'Incoming payment does not clear the invoice completely or leaves a residual item.', {
      complexity: 'simple', hours: 3,
      sel: ['Customer and invoice:Examples:1', 'Payment document:Bank or incoming payment document:1', 'Difference:Amount and reason'],
      out: ['Expected:Invoice cleared', 'Actual:Open difference'],
      entries: ['Residual item:Invoice stays open for the difference', 'Write-off or TDS:Dr expense or TDS receivable, Cr customer'],
      tables: ['F-28', 'F-32', 'FBL5N'],
      logic: ['Decide with Finance: residual item, partial payment, or write-off with a reason code', 'For TDS deduction by the customer use the agreed TDS receivable treatment']
    })
  );

  /* ---------- FI-AA ---------- */
  add(
    tpl('FI-AA', 'config', 'New asset class with account determination and depreciation key', 'Asset class with GL accounts and depreciation terms for books and tax areas.', {
      hours: 12,
      sel: ['Company code:Company code:1', 'Chart of depreciation:Chart used', 'Depreciation areas:Book and tax areas:1'],
      out: ['Asset class:Number and text', 'Account determination:Cost, accumulated depreciation, depreciation expense, retirement accounts', 'Depreciation key:Method, useful life', 'Number range:Asset numbers', 'Screen layout:Fields required in the master'],
      tables: ['AO90', 'AFAMA', 'AS01', 'AFAB'],
      logic: ['Copy a similar asset class and change the accounts and key', 'Check the useful life for every depreciation area', 'Test with a sample asset, acquisition and a test depreciation run'],
      entries: ['Acquisition:Dr asset cost account, Cr vendor or clearing', 'Depreciation:Dr depreciation expense, Cr accumulated depreciation']
    }),
    tpl('FI-AA', 'master', 'Asset master upload - opening or legacy assets', 'Load assets with cost and accumulated depreciation at a cut-over date from the approved Excel.', {
      complexity: 'complex', hours: 14,
      sel: ['Company code:Company code:1', 'Cut-over date:Transfer date:1', 'Number of assets:Volume'],
      out: ['Asset class:From the Excel', 'Description:Text', 'Capitalisation date:Start of depreciation:1', 'Cost:Acquisition value', 'Accumulated depreciation:Up to the cut-over date', 'Cost centre and location:Master data', 'Useful life:Remaining life'],
      tables: ['AS91', 'ANLA', 'ANLC', 'BAPI_FIXEDASSET_CREATE1'],
      logic: ['Load a test file of 5 assets and check the values in AW01N', 'After the load reconcile cost and accumulated depreciation with the GL', 'Check the capitalisation dates before the first depreciation run']
    }),
    tpl('FI-AA', 'periodend', 'Depreciation run and asset to GL reconciliation', 'Monthly depreciation run with test run, log check and reconciliation of the asset register with the GL.', {
      hours: 5, repeat: 'monthly',
      sel: ['Company code:Company code:1', 'Fiscal year and period:Period:1', 'Depreciation area:Areas to run'],
      out: ['Depreciation run log:Without errors', 'Reconciliation:Asset register to GL accounts'],
      entries: ['Depreciation:Dr depreciation expense by cost centre, Cr accumulated depreciation'],
      tables: ['AFAB', 'AFBP', 'S_ALR_87011963'],
      logic: ['Run in test mode first and fix the assets with errors', 'Check the new assets of the month for the capitalisation date', 'Compare the asset history sheet totals with the GL accounts']
    }),
    tpl('FI-AA', 'report', 'Fixed asset schedule - additions, deletions and depreciation', 'Yearly asset schedule: opening gross block, additions, deletions, depreciation and closing written down value.', {
      hours: 10,
      sel: ['Company code:Company code:1', 'Fiscal year:Year:1', 'Depreciation area:Book area or tax area:1', 'Asset class:Range'],
      out: ['Asset class:Group', 'Opening gross block:Start of the year', 'Additions:During the year', 'Deletions:During the year', 'Depreciation:For the year and accumulated', 'Closing written down value:End of the year'],
      tables: ['S_ALR_87011963', 'AW01N', 'ANLC', 'ANLA'],
      logic: ['Standard asset history sheet with a layout usually fits the Companies Act format', 'For the tax block use the tax depreciation area']
    }),
    tpl('FI-AA', 'config', 'Capital work in progress - settlement of order to asset', 'Settle a capital internal order to an Asset under Construction and then to the final asset.', {
      hours: 6,
      sel: ['Company code:Company code:1', 'Internal order:Order type for capital projects:1', 'Final asset:Asset to receive the cost'],
      out: ['Settlement profile:Allowed receivers', 'Settlement rule:Order to AuC to final asset', 'Investment profile:For the order type'],
      tables: ['KO02', 'OKO7', 'AIAB', 'AIBU', 'KO88'],
      entries: ['Settlement of the order:Dr Asset under construction, Cr order (cost credited)', 'Capitalisation:Dr final asset, Cr Asset under construction']
    })
  );

  /* ---------- FI-BL ---------- */
  add(
    tpl('FI-BL', 'config', 'Electronic bank statement - MT940 or multicash posting rules', 'Automatic posting of the bank statement file with posting rules for the bank codes.', {
      complexity: 'complex', hours: 16,
      sel: ['House bank and account:Account of the statement:1', 'File format:MT940, multicash or other:1', 'Bank codes:External transaction codes from the bank'],
      out: ['External transaction code mapping:To posting rule', 'Posting rule:Account symbol and accounts', 'Account symbols:Bank, charges, clearing', 'Search string rules:To find the open item'],
      entries: ['Receipt:Dr bank, Cr bank clearing or customer', 'Charges:Dr bank charges, Cr bank'],
      tables: ['FF.5', 'FEBA_BANK_STATEMENT', 'FEBKO', 'FEBEP'],
      logic: ['Get a sample file from the bank for each type', 'Map every external code, a missing code goes to the post-processing list', 'A bank specific file format needs an ABAP conversion (functional spec)']
    }),
    tpl('FI-BL', 'periodend', 'Bank reconciliation and clearing account review', 'Month-end bank reconciliation with the open items of the bank clearing account.', {
      complexity: 'simple', hours: 4, repeat: 'monthly',
      sel: ['Company code:Company code:1', 'House bank account:Accounts:1', 'Key date:Month end:1'],
      out: ['Reconciliation statement:Bank balance and book balance', 'Open items list:Clearing account items'],
      tables: ['FBL3N', 'FF67', 'FF.5']
    }),
    tpl('FI-BL', 'config', 'New house bank, bank account and payment method', 'Set up a new bank account and make it usable in the payment run.', {
      hours: 5,
      sel: ['Company code:Company code:1', 'Bank and branch:Bank key and IFSC:1', 'Account number:Bank account:1'],
      out: ['House bank and account ID:FI12', 'GL accounts:Bank and bank clearing', 'Bank determination:Ranking and amounts in FBZP', 'Payment medium format:Format agreed with the bank'],
      tables: ['FI12', 'FBZP', 'T012', 'T012K'],
      logic: ['Create the GL accounts first and link them to the account ID', 'Test a payment run proposal and a test file with the bank']
    })
  );

  /* ---------- CO-OM ---------- */
  add(
    tpl('CO-OM', 'master', 'Cost centre, profit centre and internal order master upload', 'Create or change cost centres, profit centres or orders in bulk from the approved Excel.', {
      hours: 8,
      sel: ['Controlling area:Area:1', 'Object:Cost centre, profit centre or order:1', 'Number of records:Volume'],
      out: ['Key:Number', 'Name and description:Short and long text', 'Responsible person:Name', 'Hierarchy node:Group or standard hierarchy', 'Company code and profit centre:Assignment', 'Valid from and to:Dates'],
      tables: ['KS01', 'KSH1', 'KE51', 'KO01', 'BAPI_COSTCENTER_CREATEMULTIPLE'],
      logic: ['Check that the hierarchy node exists', 'Check the validity dates and the profit centre of the cost centre']
    }),
    tpl('CO-OM', 'report', 'Cost centre wise expense - actual against budget', 'Cost centre report by cost element group with plan, actual, variance and percent.', {
      complexity: 'simple', hours: 6,
      sel: ['Controlling area:Area:1', 'Fiscal year and period:From and to:1', 'Cost centre group:Plant or department group:1', 'Cost element group:Expense group', 'Version:Plan version, normally 0'],
      out: ['Cost centre:Number and name', 'Cost element:Group or element', 'Actual:Period and cumulative', 'Plan:Period and cumulative', 'Variance:Value and percent'],
      tables: ['S_ALR_87013611', 'KSB1', 'KP06'],
      logic: ['Create the cost centre and cost element groups first', 'Save a variant and a layout with the variance columns']
    }),
    tpl('CO-OM', 'config', 'Assessment or distribution cycle', 'Allocate a service cost (power, canteen, maintenance) from the sender cost centre to the receivers.', {
      hours: 8,
      sel: ['Controlling area:Area:1', 'Sender:Cost centre or group:1', 'Receiver:Cost centres and the basis:1', 'Valid from:Start period'],
      out: ['Cycle:Name and segments', 'Secondary cost element:For assessment', 'Allocation basis:Fixed percent, statistical key figure or posted value', 'Sender and receiver rules:Tracing factors'],
      entries: ['Assessment:Dr receiver cost centre with the assessment cost element, Cr sender cost centre'],
      tables: ['KSU1', 'KSU5', 'KSV1', 'KSV5', 'KB31N'],
      logic: ['Assessment hides the original cost elements, distribution keeps them', 'Test with a copy of the cycle for one period and check the sender is cleared']
    }),
    tpl('CO-OM', 'periodend', 'Internal order settlement and period lock', 'Settle internal orders to their receivers at period end and lock the CO period.', {
      complexity: 'simple', hours: 5, repeat: 'monthly',
      sel: ['Controlling area:Area:1', 'Period:Period:1', 'Order selection:Order type or group'],
      out: ['Settlement run:Log without errors', 'Open orders list:Orders with no receiver'],
      tables: ['KO8G', 'KO88', 'OKP1'],
      logic: ['Run settlement in test mode and fix the orders with no rule', 'Lock the period after the review']
    })
  );

  /* ---------- CO-PC ---------- */
  add(
    tpl('CO-PC', 'periodend', 'Production order WIP, variance and settlement', 'Month-end WIP calculation, variance calculation and settlement of production orders.', {
      complexity: 'complex', hours: 10, repeat: 'monthly',
      sel: ['Plant:Plants:1', 'Period:Period:1', 'Order selection:Order type and status'],
      out: ['WIP posting:By order', 'Variance by category:Price, quantity, resource usage, scrap', 'Settlement:To stock accounts and price difference accounts'],
      entries: ['WIP:Dr WIP (balance sheet), Cr change in WIP (P&L)', 'Variance:Dr or Cr price difference accounts', 'Settlement:Order credited, receiver is the material or the cost centre'],
      tables: ['KKAO', 'KKS2', 'CO88', 'COOIS'],
      logic: ['Order of the steps: WIP, variance, settlement', 'Check orders with errors in the log, mostly a missing cost estimate or a missing activity price', 'Compare the results with the previous month']
    }),
    tpl('CO-PC', 'periodend', 'Standard cost estimate and price release', 'Costing run for the new standard cost and release of the prices at the agreed date.', {
      complexity: 'complex', hours: 12,
      sel: ['Plant:Plants:1', 'Costing variant:Variant used:1', 'Costing date and period:Date for BOM, routing and prices:1', 'Material selection:Finished and semi-finished materials'],
      out: ['Costing run:Selection, structure explosion, costing, marking', 'Release:Standard price updated', 'Price change analysis:Old and new price with the reason'],
      tables: ['CK40N', 'CK11N', 'CK24', 'KEKO', 'KP26'],
      logic: ['Check the activity prices (KP26) and the overhead before the run', 'Review the error list: missing BOM, routing or price', 'Release only at the agreed date and tell MM and SD', 'Take a snapshot of the old prices (MBEW download) before release']
    }),
    tpl('CO-PC', 'periodend', 'Material ledger actual costing run', 'Period closing of the material ledger with the actual costing run and the closing entries.', {
      complexity: 'complex', hours: 8, repeat: 'monthly',
      sel: ['Plant:Plants:1', 'Period:Period:1'],
      out: ['Actual price per material:Periodic unit price', 'Closing entries:Revaluation of stock and consumption', 'Error list:Materials with problems'],
      tables: ['CKMLCP', 'CKM3N', 'CKMLCR'],
      logic: ['Steps in the cockpit: selection, sequence, single level, multi level, closing entries, post closing', 'All goods movements and invoices of the period must be posted before the run']
    }),
    tpl('CO-PC', 'report', 'Product wise cost of goods manufactured and margin', 'Cost per product with material, labour, overhead and variance, and margin against the selling price.', {
      complexity: 'complex', hours: 12,
      sel: ['Plant:Plant:1', 'Period:Period:1', 'Material or group:Products', 'Version:Actual or standard'],
      out: ['Material:Number and text', 'Quantity:Produced', 'Material cost:Per unit and total', 'Conversion cost:Labour and overhead', 'Variance:By category', 'Selling price and margin:From SD or CO-PA'],
      tables: ['CKM3N', 'KE30', 'COOIS', 'CK13N'],
      logic: ['Check if CO-PA reports or CKM3N already show it', 'If not, write a spec to ABAP with the sample output']
    }),
    tpl('CO-PC', 'issue', 'Production order settlement error or variance in the wrong account', 'Settlement of a production order fails or variance posts to an unexpected account.', {
      complexity: 'medium', hours: 4,
      sel: ['Order number:Production order:1', 'Plant:Plant:1', 'Period:Period of the settlement'],
      out: ['Expected:Settled to the material or price difference account', 'Actual:Error message or wrong account'],
      entries: ['Posted entry:Accounts that were posted', 'Correct entry:What should have posted'],
      tables: ['CO88', 'KKS1', 'OBYC', 'COBRB'],
      logic: ['Check the order status, the settlement rule and the settlement profile', 'Check the variance key and the account determination for the price difference (PRD)', 'Check the cost estimate of the finished material']
    })
  );

  /* ---------- CO-PA ---------- */
  add(
    tpl('CO-PA', 'fs', 'Profit centre wise P&L in management format (spec for ABAP)', 'Plant or profit centre wise P&L with month, year to date and budget in one page for the management.', {
      complexity: 'complex', hours: 26,
      sel: ['Company code:Company code:1', 'Fiscal year and period:From and to:1', 'Profit centre group:Plant wise groups', 'Plan version:For the budget column'],
      out: ['P&L line:From the management FS version', 'Month actual:Period', 'Year to date actual:Cumulative', 'Budget:From the plan version', 'Variance:Value and percent'],
      tables: ['FAGLFLEXT', 'GLPCT', 'OB58', 'FSE2'],
      logic: ['Check if F.01 with a profit centre selection and a management FS version already works', 'If not, write the spec with the layout and one numeric example', 'Reconcile the total with the company code P&L']
    }),
    tpl('CO-PA', 'config', 'CO-PA derivation - new characteristic (product group, customer group, region)', 'Add a characteristic to the operating concern and fill it at billing.', {
      complexity: 'complex', hours: 14,
      sel: ['Operating concern:Concern:1', 'Characteristic:Name and source field:1', 'Valid from:Start period'],
      out: ['Characteristic:Add to the operating concern', 'Derivation rule:From material, customer or plant', 'Report change:Add to the profitability reports'],
      tables: ['KEA0', 'KE30', 'KE24'],
      logic: ['Changing the operating concern may need the structure to be regenerated: plan it outside working hours with Basis', 'Test the derivation with a billing document and check the line item (KE24)', 'Old data does not get the new characteristic unless it is re-derived']
    })
  );

  /* ---------- TAX ---------- */
  add(
    tpl('TAX', 'config', 'TDS - new withholding tax code and vendor assignment', 'Create a withholding tax code with the rate and section given by the Tax team and assign it to the vendors.', {
      hours: 10,
      sel: ['Company code:Company code:1', 'Vendor group:Vendors concerned:1', 'Section and rate:Given by the Tax team, with the valid from date:1'],
      out: ['WHT type and code:New code', 'Rate and threshold:From the Tax team', 'Accounts:TDS payable account', 'Vendor master:Type and code assigned', 'Certificate data:Setting for certificates'],
      entries: ['Invoice posting:Dr expense, Cr vendor for the net amount, Cr TDS payable', 'TDS payment:Dr TDS payable, Cr bank for the challan'],
      tables: ['LFBW', 'T059Z', 'WITH_ITEM', 'FK02'],
      logic: ['Do not copy a rate from memory: take the section, rate and threshold in writing from the Tax team', 'Test an invoice with and without the declaration, a credit memo and a payment', 'Check the data for the return and the certificate']
    }),
    tpl('TAX', 'statutory', 'GST ITC reconciliation - portal purchase data against purchase register', 'Monthly reconciliation of the credit available in the portal data with the SAP purchase register.', {
      hours: 8, repeat: 'monthly',
      sel: ['Company code and GSTIN:Registration:1', 'Period:Return month:1', 'Portal file:Downloaded purchase statement:1', 'Due date:Return due date'],
      out: ['Reconciliation statement:Matched, missing in SAP, missing in portal, amount differences', 'Action list:Vendors to follow up', 'ITC to claim or reverse:For the return'],
      entries: ['ITC reversal:Dr expense or ITC reversal account, Cr input tax account'],
      tables: ['BSET', 'FBL3N', 'J_1IG_HSN_SAC'],
      logic: ['Match by GSTIN, invoice number, date and tax amount', 'List differences by reason: timing, wrong GSTIN, wrong tax code, not filed by the vendor', 'Tie the final credit to the input tax accounts in the trial balance']
    }),
    tpl('TAX', 'statutory', 'GST return working from SAP data', 'Output tax and input credit working for the monthly return, tied to the tax accounts.', {
      hours: 8, repeat: 'monthly',
      sel: ['Company code and GSTIN:Registration:1', 'Period:Return month:1', 'Due date:Return due date:1'],
      out: ['Sales register summary:By tax head and rate', 'Purchase and credit summary:By tax head', 'Tax payable:Output less input', 'Reconciliation:Tax accounts against the return'],
      tables: ['BSET', 'FBL3N', 'RFUMSV00'],
      logic: ['Check documents with no tax code or no HSN before the working', 'Check cancelled and credit note documents', 'Get the approval of the Tax manager before filing']
    }),
    tpl('TAX', 'statutory', 'TDS quarterly return working and certificate data check', 'Quarterly TDS return data with vendor wise deduction, challan and certificate check.', {
      hours: 8, repeat: 'quarterly',
      sel: ['Company code and TAN:Registration:1', 'Quarter:Quarter:1', 'Due date:Return due date:1'],
      out: ['Deduction list:By vendor, section, amount and TDS', 'Challan list:Payments and dates', 'Differences:Deduction against payment', 'Certificate data:For vendors'],
      tables: ['WITH_ITEM', 'LFBW', 'FBL1N'],
      logic: ['Check vendors without a PAN and deductions at a different rate', 'Match the challans with the TDS payable account', 'Confirm the sections and rates with the Tax team']
    }),
    tpl('TAX', 'config', 'New GST tax code and HSN / SAC setup', 'Tax code for a new rate or a new type of supply, with accounts and HSN / SAC on the material or service.', {
      hours: 8,
      sel: ['Company code:Company code:1', 'Type of supply:Goods, service, reverse charge, import:1', 'Rate and date:From the Tax team:1'],
      out: ['Tax code:New code and text', 'Accounts:Input, output, reverse charge', 'Condition records:Tax procedure', 'HSN or SAC:On the master data'],
      tables: ['FTXP', 'OB40', 'J_1IG_HSN_SAC', 'T007A'],
      logic: ['Copy the nearest tax code and change the rate', 'Test purchase, sales, credit note and reverse charge', 'Keep the valid from date so old documents are not affected']
    }),
    tpl('TAX', 'statutory', 'Statutory audit query - schedule and reconciliation support', 'Reply to the auditor with the SAP reports, reconciliations and explanations.', {
      complexity: 'simple', hours: 6,
      sel: ['Audit item:Query reference and text:1', 'Period:Year or quarter:1', 'Reply date:Date the auditor asked:1'],
      out: ['Report or schedule:Download from SAP', 'Reconciliation:To the trial balance', 'Explanation:Plain reply with the evidence'],
      tables: ['FBL3N', 'FAGLL03', 'FS10N', 'CDHDR'],
      logic: ['Answer with a report and a reconciliation, not with a statement', 'Keep every reply and its working in the task folder']
    }),
    tpl('TAX', 'issue', 'E-invoice failure - IRN not generated', 'Billing document is not accepted by the e-invoice portal or the IRN is missing on the invoice.', {
      complexity: 'simple', hours: 3,
      sel: ['Billing document:Example invoices:1', 'Company code and GSTIN:Registration', 'Error text:Message from the portal or the log:1'],
      out: ['Expected:IRN and QR code on the invoice', 'Actual:Rejected or pending'],
      logic: ['Read the error from the portal log: common causes are wrong GSTIN, HSN, pin code, tax rate or duplicate invoice number', 'Correct the master data or the document and resend', 'If the problem is the connection, pass it to Basis with the log']
    })
  );

  /* ---------- INT ---------- */
  add(
    tpl('INT', 'issue', 'Account not found in goods movement or invoice posting', 'Goods receipt, goods issue or MIRO stops because the account determination has no entry.', {
      complexity: 'simple', hours: 3,
      sel: ['Plant and material:Where the message comes:1', 'Movement type:Movement type used:1', 'Valuation class:Class of the material', 'Message:Transaction key and account modifier in the message:1'],
      out: ['Expected:Posting goes through', 'Actual:Message that no account is found'],
      entries: ['Expected entry:Accounts that the posting should hit'],
      tables: ['OBYC', 'OMSK', 'T030', 'MBEW'],
      logic: ['Read the transaction key and the modifier in the message', 'Open OBYC for that key and the chart of accounts and find the missing combination', 'Check the valuation class on the material and the valuation modifier of the plant']
    }),
    tpl('INT', 'config', 'New valuation class and account determination for a new material type', 'Valuation class and OBYC entries for a new type of material so that stock and consumption post correctly.', {
      hours: 8,
      sel: ['Chart of accounts:Chart:1', 'Plant or valuation grouping:Valuation area', 'Material type:New or existing type:1', 'Valuation class:New class'],
      out: ['BSX:Stock account', 'WRX:GR/IR account', 'GBB:Offsetting accounts, such as consumption, scrap, issue to cost centre', 'PRD:Price differences', 'UMB:Revaluation'],
      entries: ['Goods receipt:Dr stock (BSX), Cr GR/IR (WRX)', 'Goods issue to cost centre:Dr consumption (GBB), Cr stock (BSX)'],
      tables: ['OMSK', 'OMS2', 'OBYC', 'T030'],
      logic: ['Copy the entries of a similar valuation class', 'Test goods receipt, goods issue, invoice, price change and scrap with a test material', 'Tell MM and the stores team about the new class']
    }),
    tpl('INT', 'issue', 'Stock value does not match GL balance', 'The total of stock values (MB5L) differs from the GL balance of the stock accounts.', {
      complexity: 'medium', hours: 6,
      sel: ['Company code and plant:Scope:1', 'Key date:Date of the difference:1', 'Difference amount:Value:1'],
      out: ['Expected:MB5L total equals the GL balance', 'Actual:Difference'],
      tables: ['MB5L', 'MB5B', 'FBL3N', 'CKM3N', 'OBYC'],
      logic: ['Find the first period where the difference appears', 'Check manual postings to the stock accounts in that period', 'Check materials with price control V and a negative stock', 'Check account determination changes in the same period']
    }),
    tpl('INT', 'config', 'SD revenue account determination for a new product or customer group', 'Revenue, discount and freight accounts for a new material group or customer group.', {
      complexity: 'simple', hours: 5,
      sel: ['Sales organisation:Org:1', 'Customer account assignment group:Group:1', 'Material account assignment group:Group:1'],
      out: ['Account key:Revenue, discount, freight', 'GL account:Per combination'],
      tables: ['VKOA', 'KOMV'],
      logic: ['Add the combination in VKOA by copying a similar line', 'Test with a billing document and check the FI document']
    })
  );

  /* ---------- GEN ---------- */
  add(
    tpl('GEN', 'auth', 'New role for an AP or AR accountant', 'Access to the posting and display T-codes of the job with company code limits and no segregation conflict.', {
      complexity: 'simple', hours: 3,
      sel: ['User ID:Users:1', 'Job role:For example AP accountant:1', 'Company codes:Org levels:1', 'Approved by:Manager:1'],
      out: ['T-codes:FB60, FBL1N, F-53, FK03 or as required', 'Activity:Create, display, reverse', 'Org levels:Company codes and account groups'],
      logic: ['Copy an existing role for the same job', 'Check the segregation of duties: vendor creation and payment must not be with one user', 'Send exact T-codes and values to Basis']
    }),
    tpl('GEN', 'auth', 'Temporary posting access or special period-end authorisation', 'Short term access (for example period opening or reversal) with an end date.', {
      complexity: 'simple', hours: 1,
      sel: ['User ID:User:1', 'Access needed:T-code and activity:1', 'Valid from and to:Dates:1', 'Approved by:Name:1'],
      out: ['Role or authorisation:Added', 'Removal date:Access removed on this date'],
      logic: ['Set the end date at the start and note it as a follow-up', 'Keep the approval mail in the task']
    }),
    tpl('GEN', 'other', 'User manual or training for a new process', 'Short guide with screenshots and a training session for the users of a changed or new process.', {
      complexity: 'simple', hours: 6,
      out: ['User guide:Steps with screenshots', 'Training session:Date and attendees', 'Feedback:Questions and corrections'],
      logic: ['Write the steps exactly as the user will do them', 'Use the QAS screens and test data', 'Save the guide in the task folder and link it in Solution info']
    }),
    tpl('GEN', 'report', 'Change history - who changed vendor bank details or a GL master', 'Audit trail report from the change documents for a master record in a period.', {
      complexity: 'simple', hours: 3,
      sel: ['Object:Vendor, customer, GL account:1', 'Period:From and to:1', 'Fields:Bank details, payment terms, status'],
      out: ['Object and field:What changed', 'Old and new value:From the change document', 'User and date:Who changed it and when'],
      tables: ['CDHDR', 'CDPOS', 'SE16N'],
      logic: ['Use the change document display of the object first', 'For a bulk list read CDHDR and CDPOS by object class and date']
    })
  );
})();
