/* FI / CO / Tax modules: what a consultant looks up all day.
   Each module: name, hint, tcodes, spro, reports, tables, tools, auth, notes.
   ECC and S/4HANA differences are written in the notes. Confirm on your system. */
(function () {
  const T = window.KB.T;
  const M = window.KB.modules;

  M['FI-GL'] = {
    name: 'General Ledger', hint: 'Chart of accounts, posting, periods, closing, financial statements',
    tcodes: [T('FB50', 'Enter GL account document'), T('FB01 / F-02', 'Post document / general posting'), T('FB03', 'Display document'), T('FB02 / FB09', 'Change document / change line items'), T('FB08', 'Reverse document'), T('F.80', 'Mass reversal of documents'),
      T('FV50 / FBV0', 'Park GL document / post parked documents'), T('FBS1', 'Accrual / deferral posting'), T('F.81', 'Reverse GL account posting (for accruals)'), T('FBD1 / F.14', 'Enter recurring entry / run recurring entries'), T('F-03', 'Clear GL account'), T('F.13', 'Automatic clearing'),
      T('FBRA', 'Reset cleared items'), T('FBL3N / FAGLL03', 'GL account line items'), T('FS10N / FAGLB03', 'GL account balances'), T('FS00', 'GL account master (chart and company code)'), T('FSP0 / FSS0', 'GL master at chart level / company code level'),
      T('KE51 / KE52 / KE53', 'Create / change / display profit centre'), T('F.05 / FAGL_FCV', 'Foreign currency valuation'), T('F.16 / FAGLGVTR', 'Balance carry forward (classic GL / new GL)')],
    spro: [T('OB52', 'Open and close posting periods'), T('OBY6', 'Company code global parameters'), T('OB29', 'Fiscal year variant'), T('OB22', 'Additional local currencies (parallel currencies)'), T('OB08 / OB07', 'Exchange rates / exchange rate types'), T('OBA7', 'Document types'), T('FBN1', 'Document number ranges'),
      T('OBC4', 'Field status variants and groups'), T('OB41', 'Posting keys'), T('OB13 / OB62', 'Chart of accounts / assign company code to chart'), T('OB58', 'Financial statement versions (also FSE2 to maintain)'), T('OB53', 'Retained earnings account'), T('OB59', 'Valuation methods (FX valuation)'),
      T('OBA4 / OB57', 'Tolerance groups for employees / assign user'), T('OB28 / GGB0', 'Validations (activate / maintain)'), T('OBBH / GGB1', 'Substitutions (activate / maintain)')],
    reports: [T('F.01', 'Financial statements (balance sheet / P&L) with the FS version'), T('S_ALR_87012277', 'Trial balance (G/L account balances)'), T('S_ALR_87012284', 'Balance sheet / P&L statement'), T('FAGLB03 / FS10N', 'Balances with drill-down to line items'), T('F.08', 'GL account balances')],
    tables: [T('SKA1 / SKAT / SKB1', 'GL account: chart / text / company code data'), T('T001 / T001B', 'Company codes / posting periods'), T('BKPF / BSEG', 'Accounting document header / item'), T('BSIS / BSAS', 'GL open items / cleared items'), T('GLT0', 'GL totals (classic)'),
      T('FAGLFLEXA / FAGLFLEXT', 'New GL line items / totals (ECC)'), T('ACDOCA', 'Universal journal (S/4HANA)'), T('T003', 'Document types'), T('TCURR', 'Exchange rates'), T('T004', 'Charts of accounts'), T('CEPC', 'Profit centre master')],
    tools: [T('BAPI_ACC_DOCUMENT_POST', 'Post an accounting document'), T('BAPI_ACC_DOCUMENT_CHECK', 'Check before posting'), T('BAPI_ACC_DOCUMENT_REV_POST', 'Reverse a document'), T('LSMW / SHDB recording', 'GL master upload (FS00) when no BAPI fits'), T('Migration cockpit (S/4HANA)', 'Standard mass load of GL accounts')],
    auth: ['F_BKPF_BUK (company code)', 'F_BKPF_BLA (document type)', 'F_BKPF_KOA (account type)', 'F_BKPF_BUP (posting period)', 'F_BKPF_GSB (business area)', 'F_SKA1_BUK (GL master, company code)'],
    notes: ['Document type controls the number range, the reversal type and which account types may be posted; field status groups control which fields are required or hidden for an account.',
      'Posting in a closed period: check OB52 for BOTH the account type and the account range, and the special periods. A reversal can use a different posting date in an open period (FB08).',
      'Reconciliation accounts (vendor, customer, asset) cannot be posted directly: post through the sub-ledger.',
      'Document splitting (new GL) can stop a posting with a message about an item that cannot be assigned: check the splitting configuration and the profit centre / segment on the accounts.',
      'GL account in a new company code: create at chart level (FSP0) and extend to the company code (FSS0) or copy with FS00.',
      'S/4HANA: GL, CO and assets post into the universal journal (ACDOCA); old totals tables are replaced by views; cost elements are GL accounts. Check with SE11 before using a table name.']
  };

  M['FI-AP'] = {
    name: 'Accounts Payable', hint: 'Vendor invoices, payments, down payments, TDS, payment run',
    tcodes: [T('FB60 / FB65', 'Vendor invoice / credit memo (FI)'), T('MIRO', 'Invoice with reference to PO (MM)'), T('MR8M', 'Cancel MIRO invoice'), T('MRBR', 'Release blocked invoices'), T('F-53', 'Post outgoing payment'), T('F-44', 'Clear vendor account'), T('F110', 'Automatic payment run'),
      T('F-47 / F-48', 'Down payment request / down payment to vendor'), T('F-54', 'Clear vendor down payment'), T('FBL1N', 'Vendor line items'), T('FK10N', 'Vendor balances'), T('FK01 / FK02 / FK03', 'Vendor master (company code data); in S/4HANA use BP'), T('FCH5 / FCHN', 'Cheque number entry / cheque register'), T('FCH8', 'Reverse cheque payment')],
    spro: [T('FBZP', 'Payment program configuration (company codes, paying company codes, payment methods, bank determination, forms)'), T('OBB8', 'Payment terms'), T('OB27', 'Payment block reasons'), T('FBKP', 'Automatic account determination for FI (for example exchange rate differences)'),
      T('SPRO: Extended withholding tax', 'Financial Accounting > Accounts Receivable and Accounts Payable > Business Transactions > Withholding Tax > Extended Withholding Tax'), T('OBYC', 'Automatic postings for MM invoices (GR/IR, price differences)')],
    reports: [T('FBL1N', 'Vendor open items with ageing layout'), T('FK10N', 'Balances by period'), T('S_ALR_87012082', 'Vendor balances in local currency'), T('MB5S', 'GR/IR balances (for vendors with goods received not invoiced)')],
    tables: [T('LFA1 / LFB1 / LFBK', 'Vendor general / company code / bank data'), T('LFBW', 'Vendor withholding tax types'), T('BSIK / BSAK', 'Vendor open / cleared items'), T('REGUH / REGUP', 'Payment run header / items'), T('PAYR', 'Cheque register'), T('T052', 'Payment terms'), T('T008', 'Payment block reasons'),
      T('WITH_ITEM', 'Withholding tax per document item'), T('RBKP / RSEG', 'MM invoice header / item'), T('BUT000', 'Business partner (S/4HANA)')],
    tools: [T('BAPI_ACC_DOCUMENT_POST', 'Vendor items through ACCOUNTPAYABLE'), T('BAPI_INCOMINGINVOICE_CREATE', 'MM invoice'), T('BAPI_AP_ACC_GETOPENITEMS', 'Read open items'), T('BAPI_VENDOR_GETDETAIL', 'Read vendor data'), T('LSMW / recording FK01, FK02', 'Vendor master load in ECC')],
    auth: ['F_LFA1_BUK (vendor, company code)', 'F_LFA1_GRP (vendor account group)', 'F_LFA1_APP (vendor application)', 'F_BKPF_BUK', 'F_BKPF_KOA', 'F_REGU_BUK (payment program, company code)'],
    notes: ['F110 does not pick an item: check due date against the next run date, payment block on the vendor or on the item, payment method in the vendor master and in FBZP for the company code and country, currency allowed, bank determination (ranking and amounts), and the exception list in the proposal log.',
      'Payment run order: parameters (run date, identification, posting date), proposal, edit proposal, payment run, payment medium (file or cheque print). Do not change the vendor after the proposal without a new proposal.',
      'Down payments use special GL indicator A (down payment) and F (request); clear them when the invoice is posted (F-54).',
      'Payment terms give the baseline date, net days and discounts; the due date used in ageing comes from them.',
      'MSME vendors need an MSME indicator in the vendor master (check how your system keeps it) so a report can show the invoices that must be paid within the allowed days.',
      'TDS: the vendor needs the withholding tax type and code (LFBW) and a PAN; the invoice posting calculates the tax. Rates and sections belong to the Tax team: keep them in the WHT codes with validity dates.',
      'S/4HANA: vendor master is maintained as Business Partner (BP); FK01 / FK02 are redirected.']
  };

  M['FI-AR'] = {
    name: 'Accounts Receivable', hint: 'Customer invoices, incoming payments, clearing, dunning, credit',
    tcodes: [T('FB70 / FB75', 'Customer invoice / credit memo (FI)'), T('VF01', 'Billing (SD), posts to FI automatically'), T('F-28', 'Post incoming payment'), T('F-32', 'Clear customer account'), T('F-29 / F-39', 'Customer down payment / clear down payment'), T('FBL5N', 'Customer line items'), T('FD10N', 'Customer balances'),
      T('FD32 / FD33', 'Change / display customer credit data'), T('FD01 / FD02 / FD03', 'Customer master (company code data); in S/4HANA use BP'), T('F150', 'Dunning run'), T('FBRA', 'Reset cleared items')],
    spro: [T('OB01 / OB45', 'Credit control area / assign company code'), T('OVA8', 'Automatic credit control (SD)'), T('FBMP', 'Dunning procedure'), T('OBB8', 'Payment terms'), T('VKOA', 'Revenue account determination (SD-FI)'), T('FBKP', 'Automatic account determination for FI')],
    reports: [T('FBL5N', 'Customer open items with ageing layout'), T('FD10N', 'Balances by period'), T('S_ALR_87012172', 'Customer balances in local currency'), T('F150', 'Dunning proposal and log')],
    tables: [T('KNA1 / KNB1 / KNVV', 'Customer general / company code / sales data'), T('KNKK', 'Credit control area data (ECC)'), T('BSID / BSAD', 'Customer open / cleared items'), T('VBRK / VBRP', 'Billing header / item'), T('MAHNV / MHND', 'Dunning header / dunned items'), T('T052', 'Payment terms')],
    tools: [T('BAPI_ACC_DOCUMENT_POST', 'Customer items through ACCOUNTRECEIVABLE'), T('BAPI_AR_ACC_GETOPENITEMS', 'Read open items'), T('BAPI_AR_ACC_GETKEYDATEBALANCE', 'Balance on a key date'), T('BAPI_CUSTOMER_GETDETAIL2', 'Read customer data'), T('LSMW / recording FD01, FD02', 'Customer master load in ECC')],
    auth: ['F_KNA1_BUK (customer, company code)', 'F_KNA1_GRP (customer account group)', 'F_BKPF_BUK', 'F_BKPF_KOA'],
    notes: ['Customer invoices come from SD billing and post to FI by itself (account determination VKOA). Do not post manually unless asked; if the revenue account is wrong, check the account assignment groups on the customer and on the material.',
      'Incoming payment: F-28 with selection by document number or reference; for short payment decide residual item (invoice stays open for the difference) or partial payment (payment stays unassigned).',
      'Customer deducts TDS on payment: post the difference with the agreed treatment (TDS receivable account) so the invoice clears; coordinate with the Tax team.',
      'Credit exposure = open orders + deliveries + open items. In ECC credit data is in FD32; in S/4HANA credit management is a part of the Business Partner.',
      'Dunning: parameters and run date, proposal, edit, print. The dunning level is stored in the customer master and in the items.']
  };

  M['FI-AA'] = {
    name: 'Asset Accounting', hint: 'Asset classes, acquisition, depreciation, retirement, AuC, year-end',
    tcodes: [T('AS01 / AS02 / AS03', 'Create / change / display asset'), T('AS91', 'Create asset (legacy data transfer)'), T('F-90', 'Acquisition from vendor'), T('ABZON', 'Acquisition with automatic offsetting entry'), T('F-92', 'Retirement with sale to customer'), T('ABAVN', 'Retirement by scrapping'),
      T('ABUMN', 'Transfer within a company code'), T('ABAA / ABMA', 'Unplanned depreciation / manual depreciation'), T('AFAB', 'Depreciation run (use test run first)'), T('AFBP', 'Depreciation run log'), T('ASKB', 'Post planned depreciation to GL (if the area needs it)'), T('AW01N', 'Asset explorer'),
      T('AIAB / AIBU', 'Distribution rule / settle Asset under Construction'), T('AJAB', 'Year-end closing'), T('AJRW', 'Fiscal year change')],
    spro: [T('AO90', 'Account determination (assign GL accounts to asset class)'), T('AFAMA', 'Depreciation keys'), T('SPRO: Asset classes', 'Asset Accounting > Asset Classes > Define Asset Classes and Specify Account Determination'), T('SPRO: Depreciation areas', 'Asset Accounting > Depreciation > Valuation Methods'),
      T('SPRO: Screen layout rules', 'Asset Accounting > Master Data > Screen Layout')],
    reports: [T('S_ALR_87011963', 'Asset history sheet (opening gross block, additions, retirements, depreciation, closing)'), T('AW01N', 'Values of one asset by depreciation area'), T('AFBP', 'Log of the depreciation run'), T('SAP menu: Fixed Assets > Information System', 'Asset register reports')],
    tables: [T('ANLA', 'Asset master (general data, capitalisation date)'), T('ANLB', 'Depreciation terms'), T('ANLC', 'Asset values by year and area (ECC)'), T('ANLZ', 'Time dependent data (cost centre, location)'), T('ANLH', 'Asset main numbers'), T('ANEP / ANEK', 'Asset line items / document header'),
      T('ANLP', 'Periodic values'), T('ANKA', 'Asset class'), T('T095', 'Account determination'), T('FAAT_DOC_IT / FAAT_YDDA', 'Asset line items / depreciation (S/4HANA)')],
    tools: [T('BAPI_FIXEDASSET_CREATE1', 'Create asset'), T('BAPI_FIXEDASSET_CHANGE', 'Change asset'), T('BAPI_ASSET_ACQUISITION_POST', 'Post acquisition'), T('BAPI_ASSET_RETIREMENT_POST', 'Post retirement'), T('BAPI_FIXEDASSET_GETLIST', 'List assets')],
    auth: ['A_B_ANLKL (asset class)', 'F_BKPF_BUK', 'F_BKPF_BLA'],
    notes: ['The capitalisation date decides the first depreciation period: check it before the first AFAB run for the asset.',
      'Depreciation areas: area 01 is the book depreciation; tax and other areas have their own terms. Change useful life only in the time dependent depreciation terms (AS02).',
      'Always run AFAB as a test run first and read the log (AFBP). Fix errors (assets with missing data) before the real run.',
      'Year-end: all periods of the year must have depreciation posted before AJAB (year-end closing); AJRW opens the new fiscal year. Do them in order.',
      'Capital work in progress: collect on an internal order or an Asset under Construction, settle with the settlement rule (KO88 / AIAB, AIBU) when the asset is ready.',
      'Sale of an asset (F-92) posts the revenue and the gain or loss on retirement: check the accounts in AO90.',
      'S/4HANA: new Asset Accounting posts all areas into the universal journal; ANLC values are not used; the AFAB run stays.']
  };

  M['FI-BL'] = {
    name: 'Bank and Cash', hint: 'House banks, bank statements, cheques, cash journal, cash position',
    tcodes: [T('FF67', 'Manual bank statement'), T('FF.5', 'Import electronic bank statement (MT940, multicash, BAI2)'), T('FEBA_BANK_STATEMENT', 'Post-process bank statement'), T('FBCJ', 'Cash journal (petty cash)'), T('FCH5 / FCHN', 'Cheque number entry / cheque register'), T('FCH8', 'Reverse cheque payment'),
      T('FF7A / FF7B', 'Cash position / liquidity forecast'), T('F-02 / FB50', 'Bank charges and manual bank entries')],
    spro: [T('FI12', 'House banks and bank accounts'), T('FBZP', 'Bank determination for the payment run'), T('SPRO: Electronic bank statement', 'Financial Accounting > Bank Accounting > Business Transactions > Payment Transactions > Electronic Bank Statement (posting rules, account symbols, external transaction codes)'),
      T('SPRO: Check management', 'Bank Accounting > Business Transactions > Payment Transactions > Check Management (check lots)')],
    reports: [T('FF7A', 'Cash position by bank account'), T('FBL3N on bank accounts', 'Bank GL line items'), T('FBL3N on bank clearing', 'Open items on the clearing account = items to reconcile')],
    tables: [T('T012 / T012K', 'House banks / bank accounts'), T('BNKA', 'Bank master'), T('FEBKO / FEBEP', 'Bank statement header / items'), T('PAYR', 'Cheque register'), T('REGUH', 'Payment run header')],
    tools: [T('BAPI_ACC_DOCUMENT_POST', 'Posting of bank entries'), T('Standard formats', 'MT940, multicash, BAI2. A bank specific format needs an ABAP conversion (functional spec)')],
    auth: ['F_BKPF_BUK', 'F_BKPF_KOA'],
    notes: ['Reconciliation method: payments post to a bank clearing account; the bank statement clears it. The open items left on the clearing account are your reconciliation difference list.',
      'Electronic bank statement: the external transaction code from the bank is mapped to a posting rule and an account symbol; a new bank code with no mapping goes to the post-processing list.',
      'Cheque numbers come from check lots; the payment run takes the next number from the lot of the house bank account.',
      'Petty cash: one cash journal per ID; the book balance must agree with the cash counted.']
  };

  M['CO-OM'] = {
    name: 'Cost Centres and Internal Orders', hint: 'Cost centres, cost elements, allocations, internal orders, settlement',
    tcodes: [T('KS01 / KS02 / KS03', 'Cost centre'), T('KSH1 / KSH2 / KSH3', 'Cost centre group'), T('KA01 / KA06', 'Primary / secondary cost element (ECC; in S/4HANA use FS00)'), T('KO01 / KO02 / KO03', 'Internal order'), T('KOH1', 'Order group'), T('KSB1 / KOB1', 'Cost centre / order actual line items'),
      T('KB11N / KB21N / KB31N', 'Manual cost reposting / activity allocation / statistical key figures'), T('KP06 / KP26', 'Plan costs / plan activity types and prices'), T('KSU5 / KSV5', 'Actual assessment / actual distribution'), T('KSU1 / KSV1', 'Create assessment / distribution cycle'), T('KSII / KSPI', 'Actual / plan price calculation'),
      T('KO88 / KO8G', 'Settle order / collective settlement')],
    spro: [T('OKKP', 'Controlling area'), T('OKEON', 'Standard hierarchy'), T('OKEQ', 'Versions'), T('KOT2', 'Order types'), T('OKO7', 'Settlement profile'), T('OKB9', 'Default account assignment (cost centre for an expense account)'), T('OKP1', 'Period lock for CO')],
    reports: [T('S_ALR_87013611', 'Cost centres: actual / plan / variance'), T('KSB1 / KOB1', 'Line items'), T('KKBC_ORD', 'Analyze orders'), T('Report Painter / Query', 'Custom layouts without ABAP')],
    tables: [T('CSKS / CSKT', 'Cost centre / text'), T('CSKA / CSKB', 'Cost element / company code'), T('COBK / COEP', 'CO document header / items'), T('COSP / COSS', 'Totals: primary / secondary'), T('AUFK', 'Order master'), T('SETHEADER / SETNODE / SETLEAF', 'Groups'),
      T('TKA01', 'Controlling area'), T('COBRB', 'Settlement rules'), T('ACDOCA', 'CO line items (S/4HANA)')],
    tools: [T('BAPI_COSTCENTER_CREATEMULTIPLE', 'Create cost centres'), T('BAPI_COSTCENTER_GETDETAIL', 'Read a cost centre'), T('BAPI_INTERNALORDER_CREATE', 'Create internal order'), T('BAPI_ACC_ACT_POSTINGS_POST', 'Activity allocation')],
    auth: ['K_CCA (cost centre actual postings)', 'K_CSKS (cost centre master)', 'K_ORDER (orders)', 'F_BKPF_BUK'],
    notes: ['Primary cost elements are GL accounts with a cost element category; secondary ones are used only by CO allocations. In S/4HANA both are GL accounts of type cost element.',
      'A P&L account that needs a cost centre / order stops the posting if none is given: fix with the field status group or with a default account assignment (OKB9).',
      'Assessment posts with a secondary cost element and hides the original cost elements at the receiver; distribution keeps the original primary cost elements.',
      'Settlement of orders needs a settlement rule and a settlement profile. "No settlement rule" and "no receiver" are the common errors.',
      'Version 0 is the main plan / actual version. Lock periods in OKP1 after closing.']
  };

  M['CO-PC'] = {
    name: 'Product Costing, Material Ledger and Variances', hint: 'Standard cost, WIP, variances, settlement, actual costing',
    tcodes: [T('CK11N / CK13N', 'Create / display cost estimate with quantity structure'), T('CK40N', 'Costing run'), T('CK24', 'Mark and release standard cost (price update)'), T('CKM3N', 'Material price analysis'), T('CKMLCP', 'Actual costing run (material ledger)'),
      T('KKAO', 'WIP calculation for production orders (collective)'), T('KKS1 / KKS2', 'Variance calculation (single / collective)'), T('CO88', 'Settle production orders (collective)'), T('COOIS', 'Order information system'), T('MR21 / MR22', 'Price change / debit-credit material'), T('KP26', 'Activity type prices')],
    spro: [T('SPRO: Costing variants', 'Controlling > Product Cost Controlling > Product Cost Planning > Material Cost Estimates with Quantity Structure > Costing Variants'), T('SPRO: Variances and WIP', 'Controlling > Product Cost Controlling > Cost Object Controlling > Product Cost by Order > Period-End Closing'),
      T('SPRO: Material ledger', 'Controlling > Product Cost Controlling > Actual Costing / Material Ledger (activate valuation areas, currency types)'), T('SPRO: Costing sheet', 'Controlling > Product Cost Controlling > Product Cost Planning > Basic Settings for Material Costing > Overhead')],
    reports: [T('CKM3N', 'Price and quantity flow of one material by period'), T('MB5L', 'Stock values by account (balance sheet valuation)'), T('COOIS', 'Orders with actual / target cost'), T('KKBC_ORD', 'Analyze order costs'), T('CK13N', 'Display costing result')],
    tables: [T('KEKO / KEPH / CKIS', 'Costing header / cost components / items'), T('MBEW', 'Material valuation'), T('CKMLHD / CKMLCR / CKMLPP', 'Material ledger header / currency values / period totals'), T('AFKO / AFPO / AUFK', 'Order header / item / master'), T('COSP / COSS', 'CO totals'), T('MATDOC', 'Material documents (S/4HANA)')],
    tools: [T('BAPI_MATERIAL_SAVEDATA', 'Valuation class, price control, standard price'), T('CKMLCP', 'Actual costing steps: selection, sequence, single level, multi level, closing entries, post closing')],
    auth: ['K_ORDER', 'M_MATE_WRK (plant)', 'F_BKPF_BUK'],
    notes: ['Standard cost steps: create (CK11N or CK40N), mark, release (CK24). Release only at the agreed date (start of period or year); wrong timing creates large price differences.',
      'Price control S (standard) posts price differences to the PRD account; V (moving average) changes the stock value.',
      'Production order flow: goods issue debits the order, confirmation charges activity and overhead, goods receipt credits the order at standard cost, then WIP (KKAO), variances (KKS2) and settlement (CO88), in this order.',
      'Variance categories: input price, quantity, resource usage, scrap, lot size, remaining variance.',
      'Common errors: no standard cost estimate for a finished product, missing routing or BOM, missing activity price (KP26), no overhead assignment, order not released or already settled.',
      'S/4HANA: material ledger is always active; actual costing runs in CKMLCP; MATDOC replaces the old material document tables.']
  };

  M['CO-PA'] = {
    name: 'Profit Centres and Profitability Analysis', hint: 'Profit centre accounting, CO-PA reports, derivation',
    tcodes: [T('KE51 / KE52 / KE53', 'Profit centre create / change / display'), T('KE5Z', 'Profit centre list'), T('KEA0', 'Operating concern'), T('KE21N', 'Enter CO-PA line item'), T('KE24', 'Display CO-PA line items'), T('KE30', 'Execute profitability report'), T('KE31', 'Create profitability report'), T('FAGLB03', 'Balances by profit centre')],
    spro: [T('KEA0 / KEKK', 'Operating concern and assignment to controlling area'), T('SPRO: Structures', 'Controlling > Profitability Analysis > Structures > Define Operating Concern (characteristics and value fields)'),
      T('SPRO: Derivation', 'Controlling > Profitability Analysis > Master Data > Characteristic Derivation'), T('SPRO: Profit centre', 'Controlling > Profit Center Accounting / General Ledger Accounting > Master data (dummy profit centre)')],
    reports: [T('KE30', 'Profitability reports (by product, customer, region, plant)'), T('KE24', 'Line items'), T('FAGLB03', 'Profit centre balances'), T('F.01 with FS version', 'P&L by profit centre (use the profit centre as selection)')],
    tables: [T('CEPC / CEPCT', 'Profit centre master / text'), T('CE1xxxx', 'CO-PA line items (xxxx = operating concern)'), T('CE2xxxx / CE3xxxx / CE4xxxx', 'Plan / totals / segments'), T('GLPCA / GLPCT', 'Classic profit centre line items / totals'), T('FAGLFLEXT', 'New GL totals with profit centre'), T('ACDOCA', 'Account based CO-PA and profit centre (S/4HANA)')],
    tools: [T('KE21N', 'Manual CO-PA postings'), T('Derivation rules', 'Fill characteristics (region, product group) from SD or master data')],
    auth: ['F_BKPF_BUK', 'F_BKPF_GSB'],
    notes: ['Costing based CO-PA uses value fields and valuation (for example standard cost); account based CO-PA reconciles with the GL by itself. S/4HANA has account based CO-PA in the universal journal.',
      'Characteristics such as customer, product, region are derived at billing: a blank "#" in a report usually means the derivation found nothing.',
      'Reconcile CO-PA revenue and cost of sales with the FI P&L every month (KE30 against FBL3N).',
      'The profit centre comes from the material master (plant data) and from the cost centre or order. Missing or wrong profit centre ends up on the dummy profit centre.']
  };

  M['TAX'] = {
    name: 'Tax: GST, TDS, TCS (India)', hint: 'Tax codes, GST accounts, withholding tax, returns, reconciliation',
    tcodes: [T('FTXP', 'Maintain tax codes'), T('OB40', 'Assign accounts to tax codes'), T('FBL3N on tax accounts', 'Input, output, reverse charge accounts'), T('FBL1N', 'Vendor items with TDS'), T('RFUMSV00 (SA38)', 'Tax on sales / purchases report'), T('SE16N on J_1IG_HSN_SAC', 'HSN / SAC master'),
      T('SAP menu: Withholding Tax', 'India reports for TDS challan, certificate and return data (menu path depends on the release)')],
    spro: [T('SPRO: Tax codes', 'Financial Accounting Global Settings > Tax on Sales/Purchases > Calculation > Define Tax Codes for Sales and Purchases'), T('SPRO: Tax accounts', 'Financial Accounting Global Settings > Tax on Sales/Purchases > Posting > Define Tax Accounts (OB40)'),
      T('SPRO: Extended WHT', 'Financial Accounting > Accounts Receivable and Accounts Payable > Business Transactions > Withholding Tax > Extended Withholding Tax (WHT type, WHT code, recipient type, certificate)'),
      T('SPRO: GST (India)', 'Logistics - General > Tax on Goods Movements > India > Basic Settings (tax procedure and condition types for the GST heads)')],
    reports: [T('FBL3N', 'Tax accounts month wise for the return working'), T('RFUMSV00', 'Advance return for tax on sales / purchases'), T('Purchase and sales register', 'Custom or standard register used for the GST reconciliation (spec to ABAP if missing)')],
    tables: [T('BSET', 'Tax data per document'), T('T007A / T007S', 'Tax keys / tax code texts'), T('T030K', 'Tax accounts'), T('J_1IG_HSN_SAC', 'HSN / SAC master (India)'), T('J_1BBRANCH', 'Business places and GSTIN (India)'), T('LFBW', 'Vendor withholding tax types'), T('WITH_ITEM', 'Withholding tax per item'),
      T('T059Z', 'Withholding tax codes'), T('J_1IMOVEND', 'India vendor data (PAN)')],
    tools: [T('CALCULATE_TAX_FROM_NET_AMOUNT', 'Function module for tax from net'), T('CALCULATE_TAX_FROM_GROSSAMOUNT', 'Function module for tax from gross'), T('BAPI_ACC_DOCUMENT_POST', 'Tax lines through ACCOUNTTAX')],
    auth: ['F_BKPF_BUK', 'F_BKPF_KOA'],
    notes: ['GST has output tax (IGST, CGST, SGST / UTGST) and input credit in the same heads, plus reverse charge and blocked credit. Keep separate accounts for ITC reversal, blocked credit and reverse charge.',
      'The tax code decides the rate, the accounts and the tax procedure. The business place of the plant decides the GSTIN. HSN is on the material master, SAC on the service master.',
      'Rates, sections, thresholds and due dates change often. Keep them in tax codes and WHT codes with validity dates and confirm with the Tax team. Never hard code them in a program or a task.',
      'TDS needs a withholding tax type and code in the vendor master and a PAN. A vendor without a PAN or with a different status can need a different rate: ask the Tax team for the rule.',
      'E-invoice and e-way bill need a GSP / API connection or an add-on, usually done with Basis and ABAP. Your part is the data mapping and the error analysis of rejected documents.',
      'GST reconciliation: purchase register against the portal purchase statement, sales register against the portal sales data; tie the totals to the tax accounts in the trial balance.']
  };

  M['INT'] = {
    name: 'Integration: MM-FI, SD-FI, PP-CO', hint: 'Automatic account determination, GR/IR, stock reconciliation',
    tcodes: [T('OBYC', 'Automatic postings for MM (transaction keys BSX, WRX, GBB, PRD, UMB)'), T('OMSK', 'Valuation classes'), T('VKOA', 'Revenue account determination (SD)'), T('MIGO / MIRO', 'Goods movement / invoice'), T('MR11 / MR11SHOW', 'Clear GR/IR account / show proposal'),
      T('MR21 / MR22', 'Price change / debit-credit material'), T('MMPV / MMRV', 'Close MM period / allow posting to previous period'), T('MB5S / MB5L', 'GR/IR balances / list of stock values')],
    spro: [T('OBYC', 'Account determination per chart of accounts, transaction key, valuation modifier and valuation class'), T('OMSK', 'Valuation classes and account category reference'), T('OMS2', 'Material types (valuation class, quantity / value update)'), T('VKOA', 'Account key, sales organisation, customer group, material group'),
      T('SPRO: Valuation areas', 'Materials Management > Valuation and Account Assignment (valuation level, grouping codes)')],
    reports: [T('MB5S', 'GR/IR balances by PO'), T('MB5L', 'Stock value against GL balance'), T('MB5B', 'Stock on a posting date'), T('FBL3N on BSX / GBB accounts', 'Postings of inventory and consumption accounts'), T('CKM3N', 'Material price analysis')],
    tables: [T('T030', 'Automatic account determination (OBYC data)'), T('T025 / T025T', 'Valuation classes'), T('T134', 'Material types'), T('T001K', 'Valuation area to company code'), T('T156', 'Movement types'), T('MBEW', 'Material valuation'), T('EKBE', 'PO history (GR/IR)'), T('MKPF / MSEG', 'Material documents (ECC)')],
    tools: [T('BAPI_GOODSMVT_CREATE', 'Goods movement'), T('BAPI_ACC_DOCUMENT_POST', 'FI posting'), T('BAPI_MATERIAL_SAVEDATA', 'Valuation data')],
    auth: ['M_MSEG_BWA (movement type)', 'M_MATE_WRK (plant)', 'F_BKPF_BUK', 'F_BKPF_BLA'],
    notes: ['MM-FI: movement type, valuation class and transaction key (with the modifier) decide the GL account. When the message says no account is found, find the missing combination in OBYC for that chart of accounts and transaction key.',
      'GR/IR (WRX): goods receipt debits stock and credits GR/IR; invoice debits GR/IR and credits the vendor. A price difference goes to PRD with standard price, to the stock with moving average price.',
      'SD-FI (VKOA): account key plus sales organisation plus customer account assignment group plus material account assignment group give the revenue account. A wrong revenue account means one of the two groups is wrong.',
      'PP-CO: goods issue debits the order; goods receipt credits the order at standard price; variance and WIP at period end; activity is charged through confirmation and the activity price.',
      'Stock against GL: the total of MB5L must equal the GL balance of the stock accounts. A difference points to manual postings or an account determination error.',
      'Inventory and GR/IR accounts are normally blocked for manual posting; correct them with MR11, MR21 or a proper goods movement.']
  };

  M['GEN'] = {
    name: 'Cross-module and Basis helpers', hint: 'Tables, transports, users, jobs, uploads',
    tcodes: [T('SE16N', 'Table display (edit mode only in DEV and never in production)'), T('SM30', 'Maintain table views (customizing tables)'), T('SE09 / SE10', 'Transport organiser'), T('STMS', 'Transport management (import queue, done by Basis)'), T('SCC4', 'Client settings (is customizing allowed in this client?)'),
      T('SU01 / PFCG / SU53', 'User / role / last authorisation check'), T('SU21 / ST01 / SUIM', 'Authorisation objects / trace / user information'), T('ST22', 'Short dumps'), T('SM37 / SM36', 'Job overview / schedule a job'), T('SA38 / SE38', 'Run a program'),
      T('LSMW / SHDB / SM35', 'Upload tool / recording / batch input monitor'), T('SCMP / SCU0', 'Compare customizing between systems / customizing cross-system viewer'), T('SLG1', 'Application log'), T('SO10', 'Standard text')],
    spro: [T('SPRO > IMG search', 'Use Ctrl+F in the IMG to find a node by words'), T('SPRO_ADMIN', 'Project and IMG administration')],
    reports: [T('CDHDR / CDPOS via SE16N', 'Change documents: who changed what and when (vendor bank, GL master, customer)'), T('SUIM', 'Who has which authorisation')],
    tables: [T('CDHDR / CDPOS', 'Change document header / items'), T('E070 / E071', 'Transport requests / objects'), T('USR02 / AGR_USERS / AGR_1251', 'Users / role assignment / role authorisation values'), T('TSTC / TSTCT', 'T-codes'), T('DD03L', 'Table fields'), T('NRIV', 'Number range intervals'),
      T('TVARVC', 'Selection variables'), T('T000', 'Clients'), T('TBTCO', 'Job header')],
    tools: [T('LSMW', 'Recording, mapping and upload without code'), T('SHDB', 'Recording of a transaction for batch input'), T('eCATT / SECATT', 'Test scripts'), T('SE16N edit', 'Only in DEV for test data; never in production')],
    auth: ['S_TCODE (T-code)', 'S_TABU_DIS (table display group)', 'S_TABU_NAM (table name)', 'S_GUI (file upload / download)'],
    notes: ['A customizing request is client specific. Check the client role (SCC4) so you configure only in the client that allows it, then release the request and ask Basis to import it into QAS and PRD in that order.',
      'Never change data in production with the debugger or SE16N edit. Correct through standard postings or a controlled upload with an approval.',
      'After an authorisation error ask the user to run SU53 immediately and send a screenshot.',
      'Use the change documents (CDHDR / CDPOS) to find who changed a master record and when.',
      'Keep the transport request number in the task: it is the first thing audit and Basis ask for.']
  };
})();
