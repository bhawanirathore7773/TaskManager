/* =====================================================================
   SAP FI / CO consultant knowledge base for the Task Manager (core part).
   Everything here is plain data: edit / extend it freely.
     kb.js            task types, estimate model, checklists, people  (this file)
     kb_modules.js    FI / CO / Tax modules: T-codes, SPRO nodes, tables, notes
     kb_templates.js  ready templates for the "New task" screen
   T-codes, paths and table names differ a little between ECC and S/4HANA:
   always confirm on your own system (SE16N, SPRO search) before you rely on them.
   Tax rates, sections and due dates change: keep them in configuration and
   confirm with the Tax team, never write them into a task as facts.
   ===================================================================== */
(function () {
  const P = (n, d, m) => ({ n: n, d: d, m: !!m });          // scope / setting / field row
  const T = (n, d) => ({ n: n, d: d });                      // T-code / table / path row

  /* ------------------------------------------------------------------
     1. TASK TYPES - what to capture for each kind of work
        labels.entries is optional: only types with it show the
        "Accounting entries (Dr / Cr)" section.
     ------------------------------------------------------------------ */
  const types = {
    issue: {
      label: 'Support Issue / Ticket', icon: '\u{1F3AB}',
      intro: 'Something is wrong in a posting, report, payment run or tax result. Find the cause, fix it, confirm with the user.',
      ph: { n: 'Item', d: 'Detail' },
      labels: { sel: 'Where it happens (T-code / document / process)', out: 'Expected vs actual result', entries: 'Accounting entries (posted vs correct)', logic: 'Analysis / root cause', valid: 'Solution / correction applied', auth: 'Impact (periods, company codes, other modules)', tables: 'Config / master data / tables checked', tests: 'Retest scenarios', qa: 'Questions to the user' },
      sel: [P('T-code / process', 'Where the user got the problem (FB60, MIRO, F110, VF01...)', 1), P('Document number(s)', 'Example accounting / MM / SD documents'), P('Company code / plant', 'Where it happens'), P('Posting date / period', 'Period of the document'),
        P('User and time', 'Who got it and when'), P('Error message', 'Message class, number and exact text'), P('Since when', 'First seen; any recent transport or configuration change')],
      out: [P('Expected result', 'What the user expects'), P('Actual result', 'What SAP does now'), P('Screenshot', 'Screen with the message or the wrong output (upload in Files)'), P('Amount / impact', 'Value and number of documents affected')],
      entries: [P('Posted entry', 'Dr / Cr accounts and amounts that were posted'), P('Correct entry', 'What should have posted'), P('Correction entry', 'Reversal or reclass needed to fix the books')],
      logic: ['Reproduce in QAS / DEV with the same example', 'Display the document (FB03) and compare with what was expected; check the document change log', 'Check the account determination used: OBYC (MM-FI), VKOA (SD-FI), AO90 (assets), default account assignment (OKB9)',
        'Check what changed before the problem started: recent transports (STMS, table E070), master data changes (change documents)', 'Check master data: GL account (FS00), vendor / customer reconciliation account, payment terms, tax code', 'Check authorisation with SU53 if the message is about authorisation',
        'Decide first: data problem or configuration problem?', 'Keep the workaround and the permanent fix as two separate points'],
      valid: ['Fix tested with the same example document', 'Correction entry approved by Finance before posting', 'Other documents with the same problem listed', 'Closed period / year-end effect confirmed'],
      auth: ['Which periods and company codes are affected', 'Impact on tax returns already filed (GST / TDS)', 'Impact on other modules (MM, SD, PP)', 'Who approved the correction (audit trail)'],
      tests: ['Original failing scenario now works', 'Normal scenario still works', 'Another company code / plant', 'Reversal or cancellation of the document', 'Posting in a closed period gives the correct message'],
      qa: ['Exact steps and example document numbers?', 'Screenshot or message text?', 'Since when, and for all users or one?', 'Is a payment, tax return or closing blocked (how urgent)?', 'Any workaround used so far?', 'Did anything change recently (master data, configuration, transport)?'],
      checklistNew: ['Issue reproduced / example documents received', 'Root cause found', 'Solution or workaround agreed with the user', 'Fix done in DEV (configuration) or data corrected', 'Tested with the failing example', 'Transport to QAS and tested (if configuration)', 'Moved to Production (if configuration)', 'User confirmed it works', 'Root cause and fix noted in Solution info'],
      checklistChange: ['Current setting captured (screenshot / table download)', 'Change made in DEV', 'Retested', 'Moved to Production', 'User confirmed'],
      devExtra: [{ k: 'root_cause', l: 'Root cause' }, { k: 'fix', l: 'Fix applied' }]
    },
    config: {
      label: 'Configuration / Change Request', icon: '\u{2699}\u{FE0F}',
      intro: 'A change in SPRO customizing: account determination, document type, payment terms, tax code, asset class, controlling setting.',
      ph: { n: 'Setting / field', d: 'Value / rule' },
      labels: { sel: 'Scope (company code, chart of accounts, plant, controlling area)', out: 'Settings to maintain (field = value)', entries: 'Accounting entries expected', logic: 'Business rules / design', valid: 'Dependencies and checks', auth: 'Authorisation / roles impact', tables: 'T-codes / SPRO path / tables', tests: 'Test scenarios', qa: 'Questions to the user' },
      sel: [P('Company code(s)', 'Which company codes get this', 1), P('Chart of accounts', 'Operating or country chart of accounts'), P('Controlling area / operating concern', 'For CO settings'), P('Plant / valuation area', 'For MM-FI and PP-CO links'), P('Fiscal year variant / periods', 'If it depends on periods'),
        P('Transport type', 'Customizing request (client specific) or workbench')],
      out: [P('GL account(s)', 'Accounts to create or assign'), P('Document type / number range', 'Type, number range, reversal type'), P('Posting key / field status', 'Field status group changes'), P('Payment terms / methods', 'Terms, discount, payment method'), P('Tax code', 'Rate, account, tax procedure'),
        P('Account determination entry', 'Transaction key, valuation class, combination'), P('Tolerance', 'Tolerance group limits'), P('Asset class / depreciation key', 'Useful life, method')],
      entries: [P('Business transaction', 'The event that posts, e.g. goods issue to a cost centre'), P('Debit', 'Account and posting key'), P('Credit', 'Account and posting key'), P('Condition', 'When this entry applies')],
      logic: ['Check whether standard SAP already does it (existing setting, validation, standard report) before designing anything new', 'Find a similar existing setting and copy its pattern', 'Find the node: SPRO (use the IMG search) or the T-code, for example OBYC, OBA7, OBB8, FTXP, AO90',
        'Decide the scope: one company code or all; client specific or cross-client', 'Plan the order: configuration first, then master data, then testing', 'Think of other modules that use the same account determination (MM, SD, PP)', 'Keep a record of the old and new values (snapshot in Files)'],
      valid: ['GL accounts exist in the chart and in the company code (FS00) and are not blocked', 'Account type is right (P&L or balance sheet, not a reconciliation account)', 'Number range does not overlap (FBN1)', 'Posting period is open in the test company code', 'Existing open items and balances are not affected', 'Effect on tax returns and reports (financial statement version) understood'],
      auth: ['New T-code or account needs a role change (PFCG)', 'Authorisation group on the GL account', 'Segregation of duties still correct', 'Effect on users for old documents'],
      tests: ['Post a test document that uses the new setting', 'Post one that must NOT use it (old behaviour unchanged)', 'Reverse / cancel the document', 'Check the entry in FB03 and the line item reports', 'Run the related reports (trial balance, financial statement)', 'Test with a user role that the end user really has', 'Check the transport in QAS before moving to production'],
      qa: ['Which company codes and plants?', 'Is there a similar existing setting to copy?', 'Effective from which date or period?', 'Approval from Finance / auditor for the accounts?', 'Effect on existing open items?', 'Who will do UAT and with which test cases?'],
      checklistNew: ['Requirement and scope confirmed (company codes, accounts)', 'Standard SAP option checked', 'Current setting captured (screenshot) where relevant', 'Configuration done in DEV', 'Unit tested in DEV with test postings', 'Transport released to QAS', 'UAT done and user sign-off saved', 'Transport moved to Production', 'First live document checked after the move', 'Solution info filled (T-code, SPRO path, transport)'],
      checklistChange: ['Current setting captured (screenshot / table download) as snapshot', 'Effect on existing documents and open items checked', 'Change made in DEV', 'Unit tested and old behaviour re-tested', 'Transport to QAS and UAT', 'Moved to Production', 'First live document checked', 'Solution info updated'],
      devExtra: [{ k: 'tr_list', l: 'Transport request(s)' }, { k: 'client_dep', l: 'Client specific / cross-client' }, { k: 'rollback', l: 'How to roll back' }]
    },
    master: {
      label: 'Master Data / Mass Upload', icon: '\u{1F5C3}\u{FE0F}',
      intro: 'Create or change master data in bulk (GL accounts, cost centres, profit centres, assets, vendor / customer finance data) from an approved Excel.',
      ph: { n: 'Column / field', d: 'Rule / default' },
      labels: { sel: 'Data scope (what is created or changed)', out: 'Upload template columns', logic: 'Mapping and load method', valid: 'Checks before the upload', auth: 'Authorisation', tables: 'Tools / T-codes / BAPIs', tests: 'Test scenarios', qa: 'Questions to the user' },
      sel: [P('Object', 'GL account / cost centre / profit centre / asset / vendor / customer', 1), P('Company code / controlling area', 'Scope'), P('Number of records', 'Rough volume'), P('Create or change', 'Create new, extend to another company code, or mass change'), P('Source file', 'Excel received from the user')],
      out: [P('Key field', 'Account / cost centre / asset number'), P('Description', 'Short and long text'), P('Account group / type', 'Grouping that controls the fields'), P('Company code data', 'Reconciliation account, currency, tax category, field status group'),
        P('Controlling data', 'Cost element category, hierarchy or group'), P('Status / message', 'Result column filled after the load')],
      logic: ['Choose the tool: copy function, mass change, LSMW, recording (SHDB), BAPI, or the migration cockpit in S/4HANA', 'Prefer a standard tool over a recording when one exists', 'Define the mapping: Excel column, SAP field, rule', 'Convert values: leading zeros, dates, decimals, upper case',
        'Load a small file first (3 to 5 rows) in DEV / QAS', 'Capture the message of every row and keep the error list', 'Check number ranges: external or internal, and enough free numbers', 'Keep the loaded file and the result log in the task folder'],
      valid: ['Mandatory columns are not empty', 'No duplicate keys in the file', 'Account group and chart of accounts exist', 'Reconciliation account and currency are valid', 'Cost centre hierarchy node / profit centre exist', 'Text length limits respected (short text is 20 characters)'],
      auth: ['Create authorisation for the object (for GL accounts F_SKA1_BUK)', 'S_GUI for file upload', 'Creator and approver are different people'],
      tests: ['3 to 5 row test file', 'A row with an error in the middle', 'Leading zeros and decimal format', 'Account / object already exists', 'Full file volume', 'Check created objects in FS00 / KS03 / AS03', 'Old documents not affected'],
      qa: ['Final approved Excel, and who approved it?', 'Create new or change existing, and which fields?', 'Company codes and chart of accounts?', 'Numbering: given by the user or by SAP?', 'Field status and account group defaults to use?', 'Who verifies after the load?'],
      checklistNew: ['Approved Excel received', 'Mapping and defaults agreed', 'Test file prepared', 'Loaded in DEV / QAS and checked', 'Authorisation and approvals confirmed', 'Full load in Production', 'Result log checked and errors fixed', 'Loaded data verified with the user', 'Files saved in the task folder'],
      checklistChange: ['Current data downloaded as snapshot (SE16N / report)', 'Change file approved', 'Test load', 'Production load', 'Result log and before / after comparison checked'],
      devExtra: [{ k: 'tool', l: 'Tool used (LSMW / BAPI / mass change)' }, { k: 'template', l: 'Template file name' }, { k: 'records', l: 'Records loaded' }]
    },
    report: {
      label: 'Report / MIS / Analysis', icon: '\u{1F4CA}',
      intro: 'A report, MIS or reconciliation the user needs. First check standard reports, variants and layouts; if nothing fits, raise it as a Functional Spec to ABAP.',
      ph: { n: 'Item', d: 'Rule / note' },
      labels: { sel: 'Selection criteria', out: 'Output columns / layout', logic: 'Calculations / rules', valid: 'Checks', auth: 'Authorisation', tables: 'Standard report / T-code / tables', tests: 'Test scenarios', qa: 'Questions to the user' },
      sel: [P('Company code', 'Mandatory in most reports', 1), P('Fiscal year / period', 'From and to period', 1), P('GL account / account group', 'Account or group'), P('Cost centre / profit centre / order', 'Object or group'), P('Vendor / customer', 'Account'), P('Posting date', 'Range'),
        P('Plant / business area / segment', 'Org unit'), P('Ledger / currency type', 'Leading ledger, company code or group currency'), P('Layout / variant', 'Saved layout'), P('Key date', 'As-on date for ageing and balances')],
      out: [P('Account / object', 'Number and text'), P('Opening balance', 'Balance at the start'), P('Debit / credit', 'Movement in the period'), P('Closing balance', ''), P('Document number / date', 'For line item drill-down'), P('Amount in local currency', 'Company code currency'),
        P('Ageing bucket', '0-30, 31-60, 61-90, 90+ days'), P('Budget / plan', 'Plan version for comparison'), P('Variance', 'Absolute and percent'), P('Reference / text', 'Invoice number, PO, assignment')],
      logic: ['Check the standard reports first (FBL1N, FBL3N, FBL5N, FAGLL03, KSB1, KOB1, S_ALR_* reports) and whether a variant or layout is enough', 'Define the data source: line items, totals or the financial statement version', 'Ageing from baseline date plus payment terms (due date), or from posting date? Confirm with the user',
        'Opening and closing balance logic across fiscal years (balance carry forward)', 'Reconcile the report total with the trial balance before handing it over', 'Saved variant, layout and Excel download for the user', 'If standard cannot do it: write a Functional Spec to ABAP with a sample output'],
      valid: ['Report total equals the trial balance / reconciliation account', 'No double counting of cleared and open items', 'Reversed documents handled', 'Currency conversion rate and date are right', 'User sees only the company codes allowed'],
      auth: ['F_BKPF_BUK - company code', 'F_BKPF_KOA - account type', 'K_CCA - cost centre', 'S_TCODE'],
      tests: ['Compare with the trial balance for the same period', 'Compare 3 accounts with FAGLL03 / FBL3N', 'Period with no data', 'Cleared and open items', 'Foreign currency documents', 'Download to Excel and open it', 'User with limited company code authorisation'],
      qa: ['Who uses it and how often (daily, month-end)?', 'Which company codes, periods and ledgers?', 'Why does a standard report not work, what is missing?', 'Sample output in Excel?', 'Opening balances and ageing: which date logic?', 'Should it be mailed or run as a background job?', 'Who must or must not see the data?'],
      checklistNew: ['Requirement and sample output understood', 'Standard reports and variants checked', 'Solution chosen (variant / layout / query / spec to ABAP)', 'Report built or spec written', 'Tested against the trial balance', 'User walkthrough and feedback', 'Variant, layout and user guide shared', 'Solution info filled (T-code, variant, layout)'],
      checklistChange: ['Current variant / layout saved as snapshot', 'Change made', 'Compared with the old output', 'User confirmed', 'Solution info updated'],
      devExtra: [{ k: 'variant', l: 'Variant name' }, { k: 'layout', l: 'Layout name' }, { k: 'user_guide', l: 'User guide file' }]
    },
    fs: {
      label: 'Functional Spec (to ABAP)', icon: '\u{1F4DD}',
      intro: 'Standard SAP cannot do it: you write the functional specification, the ABAP developer builds it, you test and take UAT.',
      ph: { n: 'Field / item', d: 'Rule / source' },
      labels: { sel: 'Trigger / selection screen', out: 'Output / expected behaviour', entries: 'Accounting entries (if posting is involved)', logic: 'Business logic / calculation rules', valid: 'Validations and messages', auth: 'Authorisation', tables: 'Tables / standard objects involved', tests: 'Functional test scenarios', qa: 'Questions to the user and developer' },
      sel: [P('Object type', 'Report / form / enhancement / interface / validation', 1), P('Where it acts', 'T-code and event, e.g. on save of FB60, at billing, at goods issue'), P('Selection screen fields', 'Fields with F4 help and mandatory flags'), P('Plant / company code condition', 'When the logic applies'), P('Users / roles', 'Who is affected')],
      out: [P('Output fields', 'Column list with the source field'), P('Behaviour', 'Block / warn / default a value / create a document'), P('Layout / print format', 'Sample output or form layout'), P('Download / mail', 'Excel, PDF, e-mail'), P('Messages', 'Text of errors and warnings')],
      entries: [P('Posting triggered', 'Dr / Cr accounts, posting keys, amount logic'), P('Reversal logic', 'What happens on cancellation'), P('Document type / reference', 'Header text and reference fields')],
      logic: ['First confirm that standard SAP (configuration, validation, substitution, standard report) cannot do it', 'Give the exact rule with example numbers (input, expected output)', 'Name the standard tables and fields used as the source', 'Say what must happen in edge cases: zero, negative, reversed, foreign currency, closed period',
        'For an enhancement: name the transaction and the exact step; the developer finds the exit or BAdI', 'Give the expected volume of documents (performance)', 'Say what must be configurable (switch by company code) instead of hard coded'],
      valid: ['Mandatory fields and exact message texts', 'Should it also apply to uploads / interfaces / background postings?', 'Authority checks needed', 'Behaviour in QAS with copies of real data'],
      auth: ['Authorisation object and roles for the new T-code', 'Company code level check', 'Who can run it in production'],
      tests: ['Each business rule: one positive and one negative case', 'Foreign currency and tax code combinations', 'Reversal / cancellation', 'Large volume', 'User without authorisation', 'Order: developer unit test, your functional test, then user UAT'],
      qa: ['Exact rule with 2 or 3 numeric examples?', 'Who is the ABAP developer and by when is the technical design?', 'Sample output / paper format / Excel?', 'Which company codes and plants?', 'Should it also apply to uploads and interfaces?', 'Is a standard / configuration alternative possible (cost versus benefit)?', 'Who signs off the spec?'],
      checklistNew: ['Requirement understood and standard option checked', 'Functional spec written with examples', 'Spec shared and discussed with the ABAP developer', 'Technical design reviewed', 'Development done and unit tested by the developer', 'Functional test in QAS', 'UAT and user sign-off', 'Transport moved to Production', 'First live use checked', 'Solution info filled (program, T-code, spec file)'],
      checklistChange: ['Existing object and its spec / code reference found', 'Change spec written', 'Spec shared with the ABAP developer', 'Regression scenarios listed', 'Tested in QAS', 'UAT sign-off', 'Moved to Production', 'Solution info updated'],
      devExtra: [{ k: 'abap_dev', l: 'ABAP developer' }, { k: 'abap_ref', l: 'ABAP ticket / program / enhancement name' }, { k: 'fs_file', l: 'Spec file name' }]
    },
    periodend: {
      label: 'Period-end / Year-end Activity', icon: '\u{1F4C5}',
      intro: 'Month-end, quarter-end and year-end work: depreciation, GR/IR, FX valuation, accruals, CO allocation, settlement, variances, closing periods. Set it to repeat and the next one is created for you.',
      ph: { n: 'Item', d: 'Note' },
      labels: { sel: 'Scope (company code, period, controlling area)', out: 'Deliverables / outputs', entries: 'Standard period-end entries', logic: 'Sequence and cut-off rules', valid: 'Reconciliation checks', auth: 'Authorisation / period control', tables: 'T-codes / reports used', tests: 'Check results', qa: 'Questions to Finance' },
      sel: [P('Company code(s)', 'Scope', 1), P('Fiscal year / period', 'Period being closed', 1), P('Controlling area', 'For CO activities'), P('Cut-off date', 'Last date for postings from MM, SD, HR'), P('Ledgers / currencies', 'Leading ledger, parallel currencies')],
      out: [P('Closed periods', 'FI, MM and CO periods closed'), P('Trial balance', 'Signed-off trial balance'), P('Reconciliation file', 'Sub-ledger to GL reconciliations'), P('MIS / reports', 'Reports released to management'), P('Open points list', 'What is carried to the next month')],
      entries: [P('Accruals / provisions', 'Dr expense, Cr provision (FBS1) with automatic reversal'), P('FX valuation', 'Unrealised gain or loss (F.05 / FAGL_FCV)'), P('Depreciation', 'Dr depreciation, Cr accumulated depreciation (AFAB)'), P('GR/IR clearing', 'Dr GR/IR, Cr expense or stock (MR11)'),
        P('Settlement', 'Order, WIP and variance settlement (CO88, KO88, KKAO)'), P('Reclassification', 'Intercompany or regrouping of balances')],
      logic: ['Sequence: MM period (MMPV), parked documents, accruals, GR/IR, depreciation, FX valuation, CO allocation and settlement, reconciliations, trial balance, close periods (OB52)', 'Cut-off: agree the last date for goods receipts, invoices and payroll with the other departments',
        'Reverse last month accruals on day 1 of the new period', 'Run each activity in test mode first where SAP offers it, then check the log', 'Special periods 13 to 16 for audit adjustments at year end', 'Write down every manual entry with its reason'],
      valid: ['Sub-ledger totals equal reconciliation account balances (AP, AR, assets)', 'Stock value (MB5L) equals inventory GL accounts', 'GR/IR balance is explained', 'No open parked or held documents', 'Intercompany balances agree', 'Depreciation run has no errors in the log', 'No open WIP or variance on orders that should be settled'],
      auth: ['Who can open and close periods (OB52 is restricted)', 'Special periods for audit adjustments', 'Authorisation group for posting periods (F_BKPF_BUP)'],
      tests: ['Trial balance before and after', 'Balance sheet balances (assets equal liabilities)', 'Posting in the closed period is blocked (test it)', 'Compare P&L with last month for large variances'],
      qa: ['Cut-off date and time for the other departments?', 'Special accruals or provisions this month (audit fee, bonus, freight)?', 'Is the previous period closed already?', 'Who signs off the trial balance?', 'Any change in scope (new plant, new asset class)?'],
      checklistNew: ['Posting periods opened for the closing activities (OB52)', 'Parked / held documents cleared (FBV0)', 'GR/IR reviewed and cleared (MB5S, MR11)', 'Depreciation run done (AFAB)', 'Foreign currency valuation done (F.05 / FAGL_FCV)', 'Accruals and provisions posted (FBS1), last month reversed',
        'Bank reconciliation completed', 'Intercompany / cross-company balances matched', 'CO allocations, WIP, variances and settlement done', 'Trial balance reviewed with Finance', 'Period closed (OB52, MMPV)'],
      checklistChange: ['Change in the closing process agreed with Finance', 'Updated checklist shared with the team', 'Tested in QAS or on a copy period', 'Applied this period', 'Result compared with the previous month'],
      devExtra: [{ k: 'closed_on', l: 'Period closed on' }, { k: 'tb_signoff', l: 'Trial balance signed off by' }]
    },
    statutory: {
      label: 'Tax / Statutory / Audit', icon: '\u{1F9FE}',
      intro: 'GST, TDS / TCS, e-invoice, return reconciliation, audit queries, certificates. Dates are fixed by law: set the due date from the return calendar.',
      ph: { n: 'Item', d: 'Note / reference' },
      labels: { sel: 'Scope (company code, GSTIN / TAN, period)', out: 'Deliverable (return, report, certificate, reply)', entries: 'Adjustment / correction entries', logic: 'Rules and reconciliation logic', valid: 'Checks before filing / replying', auth: 'Access / authorisation', tables: 'Reports / T-codes / tables', tests: 'Verification', qa: 'Questions to Tax / auditor' },
      sel: [P('Company code / GSTIN / TAN', 'Registration the work is for', 1), P('Return / report / audit item', 'e.g. GST return, TDS return, tax audit, statutory audit query', 1), P('Period', 'Month, quarter or financial year', 1), P('Due date (statutory)', 'Last date to file or reply'), P('Authority / auditor', 'Who asked')],
      out: [P('Reconciliation statement', 'SAP versus portal / return'), P('Return working', 'Data used for filing'), P('Reply / explanation', 'Audit query reply with evidence'), P('Certificate / challan data', 'TDS certificate, challan'), P('Adjustment entry', 'Entries needed to correct')],
      entries: [P('ITC reversal / reclass', 'Input tax credit entries'), P('TDS / TCS adjustment', 'Deduction short or excess'), P('Tax payment', 'Challan posting'), P('Audit adjustment', 'Entry suggested by the auditor')],
      logic: ['Match SAP data with the portal data (for GST: purchase register against the portal purchase statement; sales register against the e-invoice / return data)', 'Reconcile the tax accounts (input, output, reverse charge, TDS payable) with the returns', 'Check tax code, HSN / SAC and place of supply on the documents',
        'List the differences by reason: timing, missing invoice, wrong tax code, blocked credit', 'TDS: check vendor PAN, section, rate, threshold and certificate data', 'Keep the working and the evidence for audit', 'Confirm current rates and rules with the Tax team (they change); never hard code a rate'],
      valid: ['Tax payable per SAP accounts agrees with the return', 'No documents without tax code / HSN', 'Reversed and cancelled invoices handled', 'Totals tie to the trial balance', 'Corrections approved by the Tax manager before posting'],
      auth: ['Restricted access to tax accounts and returns', 'Read-only access for the auditor', 'Who may post tax adjustment entries'],
      tests: ['Tax account balances match the return totals', 'Sample of 10 invoices end to end', 'Credit notes and reverse charge', 'Import / foreign vendor', 'Cancelled e-invoice', 'Invoice dated in the previous month (period boundary)'],
      qa: ['Which return and period, and what is the due date?', 'Where does the portal data come from (download file)?', 'Known differences from the last period?', 'Who approves adjustments and filing?', 'Which rates or rules changed since the last filing?', 'Does the auditor need screenshots or reports from SAP?'],
      checklistNew: ['Scope and due date confirmed', 'SAP data extracted for the period', 'Portal / external data received', 'Reconciliation done and differences listed', 'Corrections agreed with Tax / Finance', 'Correction entries posted', 'Final check against the trial balance', 'Working saved for audit', 'Filing / reply confirmed by the Tax team'],
      checklistChange: ['Change in rule or rate understood and documented', 'Configuration or tax code changed in DEV', 'Tested with sample documents', 'UAT with the Tax team', 'Moved to Production', 'First period after the change checked'],
      devExtra: [{ k: 'period', l: 'Period / return' }, { k: 'filed_on', l: 'Filed / replied on' }, { k: 'ack', l: 'Acknowledgement / reference no.' }]
    },
    auth: {
      label: 'Authorisation / Role', icon: '\u{1F511}',
      intro: 'New or changed access for FI / CO users: T-codes, company code and cost centre authorisation, segregation of duties.',
      ph: { n: 'Item', d: 'Value' },
      labels: { sel: 'Who needs access (user / role / department)', out: 'Access required', logic: 'Design and segregation of duties', valid: 'Approvals', auth: 'Authorisation objects', tables: 'T-codes / roles', tests: 'Tests', qa: 'Questions' },
      sel: [P('User ID(s)', 'Users who need the access', 1), P('Role / position', 'Job role, e.g. AP accountant'), P('Company codes / plants', 'Org levels to open'), P('Reason / approval', 'Who approved (manager, process owner)'), P('Valid from - to', 'For temporary access')],
      out: [P('T-codes', 'Transactions needed'), P('Activity', 'Display / create / change / reverse'), P('Org levels', 'Company code, cost centre group'), P('Posting limits', 'Tolerance group, document type authorisation')],
      logic: ['Check if an existing role already fits (copy it, do not invent a new one)', 'Check segregation of duties: creating a vendor and paying a vendor must not sit with one user', 'Use SU53 (last failed check) and the authorisation trace (ST01) to find the missing value',
        'The role change is done by Basis / security: give them the exact T-codes and values', 'Temporary access needs an end date and must be removed', 'Keep the approval mail'],
      valid: ['Approval from manager / process owner', 'Segregation of duties check passed', 'Tested in QAS first if it is a new role', 'End date set for temporary access'],
      auth: ['F_BKPF_BUK (company code)', 'F_BKPF_KOA (account type)', 'F_BKPF_BLA (document type)', 'F_LFA1_BUK / F_KNA1_BUK (vendor / customer company code)', 'F_SKA1_BUK (GL master)', 'K_CCA (cost centre)', 'A_B_ANLKL (asset class)'],
      tests: ['User can do the intended task', 'User cannot do what is not allowed', 'SU53 shows no missing authorisation after the change', 'Reports show only the allowed company codes'],
      qa: ['Exact T-codes and what the user does in each?', 'Which company codes, plants, cost centres?', 'Who approved, and is it temporary?', 'Is there an existing user to copy the access from?', 'Does it create a segregation of duties conflict?'],
      checklistNew: ['Request and approval received', 'Existing role checked', 'Exact T-codes and org values listed', 'Request sent to Basis / security', 'Tested by the user (SU53 clean)', 'Segregation of duties checked', 'End date noted for temporary access', 'Approval mail saved'],
      checklistChange: ['Current roles captured (SU01 screenshot)', 'Change requested with exact values', 'Tested by the user', 'Approval mail saved'],
      devExtra: [{ k: 'role', l: 'Role name' }, { k: 'ticket', l: 'Basis / security ticket no.' }]
    },
    other: {
      label: 'Other (training, document, project)', icon: '\u{1F4CC}',
      intro: 'Anything else: user training, process document, knowledge transfer, project work, meetings with auditors or users.',
      ph: { n: 'Item', d: 'Detail' },
      labels: { sel: 'Inputs', out: 'Deliverables', logic: 'Approach', valid: 'Checks', auth: 'Authorisation', tables: 'Objects', tests: 'Verification', qa: 'Questions' },
      sel: [], out: [P('Deliverable', 'What is to be handed over')], logic: ['Approach / steps'], valid: [], auth: [],
      tests: ['Verified with the requester'], qa: ['What exactly is expected and by when?', 'Who will check the result?'],
      checklistNew: ['Requirement understood', 'Work done', 'Verified with the requester', 'Documented'],
      checklistChange: ['Snapshot taken', 'Work done', 'Verified', 'Documented'], devExtra: []
    }
  };

  /* ------------------------------------------------------------------
     2. ESTIMATION - base hours by type and complexity (one consultant)
     ------------------------------------------------------------------ */
  const estimate = {
    base: {
      issue: { simple: 1, medium: 3, complex: 8 }, config: { simple: 2, medium: 6, complex: 16 }, master: { simple: 3, medium: 8, complex: 18 }, report: { simple: 3, medium: 8, complex: 20 },
      fs: { simple: 6, medium: 14, complex: 30 }, periodend: { simple: 3, medium: 8, complex: 20 }, statutory: { simple: 3, medium: 8, complex: 20 }, auth: { simple: 0.5, medium: 1.5, complex: 4 }, other: { simple: 2, medium: 5, complex: 12 }
    },
    changeFactor: 0.7,      // change to something that exists = 70 % of a fresh setup (snapshot and regression test included)
    factors: [
      { k: 'multi_cc', l: 'Multiple company codes / plants', h: 2, types: null },
      { k: 'nosample', l: 'Requirement unclear / no sample or example', h: 3, types: null },
      { k: 'othermod', l: 'Touches other modules (MM / SD / PP account determination)', h: 2, types: ['config', 'issue', 'fs'] },
      { k: 'abap', l: 'ABAP developer dependency (design review, follow-ups)', h: 3, types: ['fs', 'report'] },
      { k: 'recon', l: 'Reconciliation with trial balance / sub-ledger', h: 2, types: ['report', 'statutory', 'periodend', 'issue'] },
      { k: 'excel', l: 'Excel template and mapping', h: 1.5, types: ['master', 'report', 'statutory'] },
      { k: 'upload', l: 'Test and production upload with error correction rounds', h: 2, types: ['master'] },
      { k: 'uat', l: 'UAT sessions / user training', h: 2, types: ['config', 'fs', 'report', 'master'] },
      { k: 'taxreview', l: 'Tax team or auditor review', h: 2, types: ['statutory', 'config'] },
      { k: 'foreign', l: 'Foreign currency / intercompany scenarios', h: 2, types: ['config', 'report', 'periodend'] },
      { k: 'transport', l: 'Transport coordination with Basis (QAS and PRD)', h: 1, types: ['config', 'fs', 'auth'] },
      { k: 'doc', l: 'User guide / documentation', h: 1.5, types: null }
    ],
    uatBuffer: 0.15,       // +15 % for UAT fixes, transport and follow-ups
    hint: 'Estimate = base hours x complexity (x 0.7 for a change) + selected extras + 15 % buffer for UAT, transports and follow-ups. It covers your time only; add ABAP developer time separately in your plan.'
  };

  /* ------------------------------------------------------------------
     3. BEFORE-CHANGE SNAPSHOT - what to save before changing something
     ------------------------------------------------------------------ */
  const backupGuide = {
    issue: ['Screenshot of the error message and of the wrong document (FB03)', 'Line items of the affected account exported to Excel (FBL3N / FAGLL03 > export)', 'Screenshot of the current configuration node, before you change anything', 'List of the other documents with the same problem'],
    config: ['Screenshot of the current setting in the SPRO / T-code screen, before editing', 'Table download: SE16N on the customizing table (for example T030 account determination, T003 document types, T052 payment terms) > export to Excel', 'Note the transport request used for this change', 'Optional: compare DEV with QAS (SCMP) before you transport'],
    master: ['Download of the existing master data (SE16N or report) before the change', 'The original Excel and the corrected Excel', 'Screenshot of one sample object (FS00 / KS03 / AS03)'],
    report: ['Screenshot of the existing output with its variant and layout', 'Save the current layout under a clear name (Settings > Layout > Save)', 'Screenshot of the variant list'],
    fs: ['Existing spec and program name', 'Screenshot or PDF of the current output or behaviour', 'Ask the ABAP developer to note the program version before the change'],
    periodend: ['Trial balance and key reports before the activity (download to Excel)', 'Screenshot of the posting period variant (OB52) before changing it', 'Run the activity in test mode first where SAP offers it'],
    statutory: ['Working file of the last filed return', 'Reconciliation file of the last period', 'Screenshot of the tax code settings (FTXP) before any change'],
    auth: ['Screenshot of the current roles of the user (SU01)', 'Copy of the role authorisation values before the change'],
    other: ['Anything that will be changed: export or screenshot before the change']
  };

  /* ------------------------------------------------------------------
     4. UAT POINTS / AFTER-MOVE CHECKS / SOLUTION REGISTER FIELDS
     ------------------------------------------------------------------ */
  const qualityIdeas = ['Account or posting key different from expected', 'Wrong amount or rounding in the entry', 'Text / reference field missing on the document', 'Report total does not match the trial balance', 'Tax code or rate not applied correctly', 'Reversal / cancellation not working',
    'Authorisation missing for a user', 'Add a column / field in the report', 'Layout or variant to be changed', 'Another company code / plant to be covered', 'User guide needs more detail', 'Message text to be improved'];
  const afterMoveChecks = ['Transport imported in Production without errors (STMS log, return code)', 'First real document posted and checked in FB03', 'Entry and accounts match the QAS result', 'Reports and trial balance still agree', 'Users can post with their roles (no SU53 message)',
    'Old open items and documents are not affected', 'User informed and trained; user guide shared', 'Tax / reporting team told (if tax or accounts changed)', 'No complaint or short dump after 3 days'];
  const devRegisterFields = [
    { k: 'tcode', l: 'T-code / SPRO node', ph: 'OBYC, FBZP, AO90' }, { k: 'obj_name', l: 'What was configured / object name', ph: 'GBB-VBR account for plant 1000' }, { k: 'package', l: 'SPRO / IMG path', ph: 'SPRO > Financial Accounting > ...' },
    { k: 'scope', l: 'Scope (company code, plant, chart)', ph: 'Company code 1000' }, { k: 'version', l: 'CR / ticket no. or version', ph: 'CR-114' }, { k: 'developed_on', l: 'Done on', type: 'date' },
    { k: 'tables', l: 'Tables / accounts / objects', ph: 'T030, GL 400100' }, { k: 'signoff_by', l: 'UAT sign-off by', ph: 'Name of the user' }, { k: 'signoff_on', l: 'Sign-off date', type: 'date' },
    { k: 'what_done', l: 'What was configured / changed', area: 1 }, { k: 'how_to_use', l: 'How to use (steps for the user)', area: 1 }, { k: 'notes', l: 'Other notes for the future (things to remember)', area: 1 }
  ];

  /* Departments filled in automatically when you pick a module (change them freely) */
  const moduleDept = { 'FI-GL': 'Finance', 'FI-AP': 'Accounts Payable', 'FI-AR': 'Accounts Receivable', 'FI-AA': 'Fixed Assets', 'FI-BL': 'Treasury / Banking', 'CO-OM': 'Costing', 'CO-PC': 'Costing', 'CO-PA': 'Finance / MIS', 'TAX': 'Taxation', 'INT': 'Finance', 'GEN': '' };

  /* Sections shown in the SAP reference window, in this order */
  const moduleSections = [['tcodes', 'T-codes (daily work)'], ['spro', 'Configuration (SPRO / IMG)'], ['reports', 'Standard reports'], ['tables', 'Tables'], ['tools', 'BAPIs / upload tools'], ['auth', 'Authorisation objects'], ['notes', 'Good to know']];

  window.KB = {
    P: P, T: T,
    types: types, modules: {}, templates: [], estimate: estimate, backupGuide: backupGuide, qualityIdeas: qualityIdeas, afterMoveChecks: afterMoveChecks, devRegisterFields: devRegisterFields,
    moduleDept: moduleDept, moduleSections: moduleSections,
    /* Add the people who give you work. They appear as suggestions in "Requested by". Example: people: ['A. Sharma', 'R. Mehta'] */
    people: [],
    /* Optional: fill "Requested by" automatically when a module is picked. Example: { 'FI-AP': 'A. Sharma' } */
    moduleOwners: {},
    /* Who you wait for most often (shown in the "Waiting for" list) */
    waitingOn: ['User input', 'ABAP developer', 'Basis / transport', 'Tax team', 'Auditor', 'Approval', 'Bank / vendor', 'Other module consultant'],
    envs: ['DEV', 'QAS', 'PRD']
  };
})();
