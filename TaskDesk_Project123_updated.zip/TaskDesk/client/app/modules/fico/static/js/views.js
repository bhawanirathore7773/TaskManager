/* Views: dashboard, tasks, board, timeline, history, register, quality, library, settings. */
(function () {
  'use strict';
  const { h, ico, fld, sel, inp, modal, toast, cap, fmtD, fmtTs, fmtH, GET, POST, PUT, DEL } = App;
  const KB = window.KB, V = App.V, S = App.S;
  const STATUS_ORDER = ['new', 'analysis', 'dev', 'unit_test', 'quality', 'prod', 'closed', 'hold', 'cancelled'];
  const PW = { critical: 0, high: 1, medium: 2, low: 3 };
  const open = (id, tab) => App.openTask(id, tab);
  const lnk = (t, tab) => h('button', { class: 'lnk', type: 'button', onclick: (e) => { e.stopPropagation(); open(t.id, tab); } }, t.code);
  const empty = (title, text, actions) => h('div', { class: 'empty' }, h('b', null, title), text || null, actions ? h('div', { class: 'row', style: { justifyContent: 'center', marginTop: '12px' } }, actions) : null);
  const sampleBtn = () => h('button', { class: 'btn', type: 'button', onclick: async () => { await POST('/api/demo'); toast('Sample tasks added. Remove them any time in Settings.'); await App.refreshTasks(); } }, 'Load sample tasks');
  const newBtn = () => h('button', { class: 'btn primary', type: 'button', onclick: () => App.newTask() }, ico('plus'), 'New task');
  const pageHead = (title, sub, right) => h('div', { class: 'page-h' }, h('div', { class: 'grow' }, h('h1', null, title), sub ? h('div', { class: 'sub' }, sub) : null), right || null);
  function go(view, f) { if (f) setFilters(Object.assign({ q: '', scope: 'active', module: '', type: '', who: '', prio: '' }, f)); if (location.hash === '#/' + view) App.render(); else location.hash = '#/' + view; }
  App.go = go;

  /* ---------- filters (shared by Tasks) ---------- */
  function filters() { return S.filters || (S.filters = Object.assign({ q: '', scope: 'active', module: '', type: '', who: '', prio: '' }, App.LS.get('filters', {}))); }
  function setFilters(p) { Object.assign(filters(), p); App.LS.set('filters', filters()); }
  const lateU = ['overdue', 'crunch', 'urgent'];
  function scopeFn(s) {
    switch (s) {
      case 'active': return App.isActive;
      case 'attention': return (t) => App.isActive(t) && lateU.indexOf(t.urgency) >= 0;
      case 'week': return (t) => App.isActive(t) && t.days_left != null && t.days_left <= 7;
      case 'testing': return (t) => t.status === 'unit_test' || t.status === 'quality';
      case 'waiting': return (t) => App.isActive(t) && !!t.waiting_on;
      case 'finished': return App.isDone;
      case 'all': return () => true;
      default: return (t) => t.status === s;
    }
  }
  function applyFilters(list, f) {
    const sc = scopeFn(f.scope);
    return list.filter((t) => sc(t) && (!f.module || t.module === f.module) && (!f.type || t.task_type === f.type) && (!f.who || t.requested_by === f.who) && (!f.prio || t.priority === f.prio) && App.matchTask(t, f.q));
  }
  const SORT = { score: (t) => -t.score, code: (t) => t.id, title: (t) => t.title.toLowerCase(), who: (t) => (t.requested_by || '').toLowerCase(), priority: (t) => PW[t.priority], status: (t) => STATUS_ORDER.indexOf(t.status),
    progress: (t) => t.progress, due: (t) => t.due_date || '9999-99-99', work: (t) => t.est_hours || 0 };
  function sortList(list, key, dir) {
    const fn = SORT[key] || SORT.score;
    return list.slice().sort((a, b) => { const x = fn(a), y = fn(b); return (x < y ? -1 : x > y ? 1 : 0) * dir || a.id - b.id; });
  }
  async function setStatus(t, v) { await PUT('/api/tasks/' + t.id, { status: v }); toast(t.code + ' moved to ' + App.statusOf(v).label); await App.refreshTasks(); }

  /* ---------- Dashboard ---------- */
  function workdaysBetween(from, to) {
    const wd = String(S.meta.settings.work_days || '0,1,2,3,4').split(',').map(Number); let n = 0;
    for (let d = new Date(from.getTime()); d <= to; d = App.addDays(d, 1)) if (wd.indexOf((d.getDay() + 6) % 7) >= 0) n++;
    return n;
  }
  V.dashboard = function (root) {
    const T = S.tasks, act = T.filter(App.isActive), today = new Date();
    const dev = act.filter((t) => ['new', 'analysis', 'dev'].indexOf(t.status) >= 0 && !t.waiting_on).sort((a, b) => b.score - a.score);
    const waiting = act.filter((t) => t.waiting_on).sort((a, b) => (b.waiting_days || 0) - (a.waiting_days || 0) || b.score - a.score);
    const test = act.filter((t) => t.status === 'unit_test' || t.status === 'quality').sort((a, b) => b.score - a.score);
    const attention = act.filter((t) => lateU.indexOf(t.urgency) >= 0);
    const month = App.todayIso().slice(0, 7);
    const doneMonth = T.filter((t) => App.isDone(t) && t.completed_at && t.completed_at.slice(0, 7) === month).length;
    const qOpen = T.reduce((s, t) => s + (t.q_open || 0), 0), pOpen = T.reduce((s, t) => s + (t.p_open || 0), 0);
    const wk = act.filter((t) => t.days_left != null && t.days_left <= 7).length;
    const hr = today.getHours(), greet = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
    root.append(pageHead(greet, today.toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }) + '. ' + (act.length ? act.length + ' active tasks, ' + (attention.length ? attention.length + ' need attention.' : 'nothing is late.') : 'No active tasks.'), null));
    if (!T.length) { root.append(empty('No tasks yet', 'Add your first task, or load a few sample tasks to see how the dashboard works.', [newBtn(), sampleBtn()])); return; }
    const kpi = (n, label, cls, fn) => h('button', { class: 'kpi ' + (cls || ''), type: 'button', onclick: fn }, h('b', null, n), h('span', null, label));
    root.append(h('div', { class: 'kpis' },
      kpi(act.length, 'Active tasks', '', () => go('tasks', { scope: 'active' })), kpi(attention.length, 'Need attention', attention.length ? 'hot' : '', () => go('tasks', { scope: 'attention' })), kpi(wk, 'Due within 7 days', wk ? 'warm' : '', () => go('tasks', { scope: 'week' })),
      kpi(waiting.length, 'Waiting on others', waiting.some((t) => t.waiting_days >= 3) ? 'warm' : '', () => go('tasks', { scope: 'waiting' })), kpi(test.length, 'In UAT or testing', '', () => go('tasks', { scope: 'testing' })), kpi(qOpen, 'Open quality points', qOpen ? 'warm' : '', () => go('quality')), kpi(pOpen, 'Open production problems', pOpen ? 'hot' : '', () => go('quality')), kpi(doneMonth, 'Finished this month', '', () => go('history'))));

    /* left: work on next */
    const left = h('div');
    left.append(h('div', { class: 'sect-t' }, h('h2', null, 'Work on next'), h('span', null, 'Ranked by priority, due date and how long it has been open. Tasks waiting on others are listed below.')));
    const nextBox = h('div', { class: 'panel' });
    if (!dev.length) nextBox.append(h('div', { class: 'panel-b' }, 'Nothing is waiting for you to start. Nice.'));
    else {
      const t0 = dev[0];
      nextBox.append(h('div', { class: 'next-1', onclick: () => open(t0.id), tabindex: 0, role: 'button', onkeydown: (e) => { if (e.key === 'Enter') open(t0.id); } },
        h('div', { class: 'row wrap' }, h('span', { class: 'mono ink2' }, t0.code), App.light(t0), App.prio(t0.priority), App.statusChip(t0.status), t0.module ? App.tag(t0.module) : null, App.tag(App.typeLabel(t0.task_type))),
        h('div', { class: 'big' }, t0.title), h('p', { class: 'why' }, App.why(t0)),
        h('div', { class: 'row wrap' }, h('div', { style: { width: '240px' } }, App.progress(t0)), h('span', { class: 'small muted' }, t0.requested_by ? 'From ' + t0.requested_by : ''), t0.due_date ? h('span', { class: 'small muted' }, 'Due ' + fmtD(t0.due_date, true)) : null)));
      dev.slice(1, 8).forEach((t, i) => nextBox.append(h('div', { class: 'nrow', onclick: () => open(t.id), tabindex: 0, role: 'button', onkeydown: (e) => { if (e.key === 'Enter') open(t.id); } },
        h('span', { class: 'rank' }, i + 2), h('div', { style: { minWidth: 0 } }, h('span', { class: 'ttl trunc' }, t.title), h('span', { class: 'sub' }, t.code + (t.requested_by ? ', ' + t.requested_by : '') + (t.module ? ', ' + t.module : ''))),
        h('div', { class: 'row hide-s' }, App.prio(t.priority), App.light(t)), App.progress(t))));
      if (dev.length > 8) nextBox.append(h('div', { class: 'panel-b small muted' }, (dev.length - 8) + ' more waiting. ', h('button', { class: 'lnk', type: 'button', onclick: () => go('tasks', { scope: 'active' }) }, 'See all active tasks')));
    }
    left.append(nextBox);
    if (waiting.length) {
      left.append(h('div', { class: 'sect-t', style: { marginTop: '24px' } }, h('h2', null, 'Waiting on others'), h('span', null, 'Follow up: the longest wait is first')));
      const wb = h('div', { class: 'panel' });
      waiting.slice(0, 7).forEach((t) => wb.append(h('div', { class: 'nrow', style: { gridTemplateColumns: 'minmax(0,1fr) auto 110px' }, onclick: () => open(t.id), tabindex: 0, role: 'button', onkeydown: (e) => { if (e.key === 'Enter') open(t.id); } },
        h('div', { style: { minWidth: 0 } }, h('span', { class: 'ttl trunc' }, t.title), h('span', { class: 'sub' }, t.code + (t.requested_by ? ', ' + t.requested_by : '') + (t.module ? ', ' + t.module : ''))),
        h('div', { class: 'row' }, App.waitChip(t), App.light(t)), App.progress(t))));
      if (waiting.length > 7) wb.append(h('div', { class: 'panel-b small muted' }, (waiting.length - 7) + ' more. ', h('button', { class: 'lnk', type: 'button', onclick: () => go('tasks', { scope: 'waiting' }) }, 'See all waiting tasks')));
      left.append(wb);
    }
    if (test.length) {
      left.append(h('div', { class: 'sect-t', style: { marginTop: '24px' } }, h('h2', null, 'Waiting for UAT or approval'), h('span', null, 'Built, with the user for testing or sign-off')));
      const b = h('div', { class: 'panel' });
      test.slice(0, 6).forEach((t) => b.append(h('div', { class: 'nrow', style: { gridTemplateColumns: 'minmax(0,1fr) auto 110px' }, onclick: () => open(t.id, t.q_open ? 'release' : 'overview'), tabindex: 0, role: 'button' },
        h('div', { style: { minWidth: 0 } }, h('span', { class: 'ttl trunc' }, t.title), h('span', { class: 'sub' }, t.code + ', ' + App.statusOf(t.status).label + (t.requested_by ? ', ' + t.requested_by : ''))),
        h('div', { class: 'row' }, t.q_open ? h('span', { class: 'chip', style: { '--c': 'var(--c-warning)' } }, t.q_open + ' open ' + (t.q_open === 1 ? 'point' : 'points')) : h('span', { class: 'small muted' }, 'No open points'), App.light(t)), App.progress(t))));
      left.append(b);
    }
    const prod = T.filter((t) => t.status === 'prod').sort((a, b) => (b.prd_date || '').localeCompare(a.prd_date || ''));
    if (prod.length) {
      left.append(h('div', { class: 'sect-t', style: { marginTop: '24px' } }, h('h2', null, 'In production, watch for problems'), h('span', null, 'Until you close them. Check the first postings and the next report run.')));
      const b = h('div', { class: 'panel' });
      prod.slice(0, 5).forEach((t) => {
        const days = t.prd_date ? Math.max(0, App.daysBetween(App.pd(t.prd_date), today)) : null;
        b.append(h('div', { class: 'nrow', style: { gridTemplateColumns: 'minmax(0,1fr) auto' }, onclick: () => open(t.id, 'release'), tabindex: 0, role: 'button' },
          h('div', { style: { minWidth: 0 } }, h('span', { class: 'ttl trunc' }, t.title), h('span', { class: 'sub' }, t.code + (days != null ? ', in production for ' + days + (days === 1 ? ' day' : ' days') : ', transport not recorded yet'))),
          t.p_open ? h('span', { class: 'light l-overdue' }, t.p_open + ' open ' + (t.p_open === 1 ? 'problem' : 'problems')) : h('span', { class: 'light l-ok' }, t.p_total ? 'All problems fixed' : 'No problems reported')));
      });
      left.append(b);
    }

    /* right rail */
    const rail = h('div', { class: 'rail' });
    // deadline radar
    const late = act.filter((t) => t.urgency === 'overdue').sort((a, b) => a.days_left - b.days_left);
    const radar = h('div', { class: 'panel' });
    const rb = h('div', { class: 'panel-b' });
    if (late.length) rb.append(h('div', { class: 'radar-day' }, h('div', { class: 'd' }, h('b', { style: { color: 'var(--c-overdue)' } }, 'Late'), late.length + (late.length === 1 ? ' task' : ' tasks')),
      h('div', null, late.map((t) => h('div', { class: 'radar-item', onclick: () => open(t.id) }, h('span', { class: 'light l-overdue' }, ''), h('span', { class: 'ttl2 trunc' }, t.title), h('span', { class: 'small muted' }, (-t.days_left) + 'd'))))));
    let any = late.length > 0;
    for (let i = 0; i < 14; i++) {
      const d = App.addDays(today, i), key = App.iso(d), list = act.filter((t) => t.due_date === key);
      if (!list.length) continue; any = true;
      rb.append(h('div', { class: 'radar-day' + (i === 0 ? ' today' : '') }, h('div', { class: 'd' }, h('b', null, i === 0 ? 'Today' : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })), d.toLocaleDateString('en-GB', { weekday: 'short' })),
        h('div', null, list.map((t) => h('div', { class: 'radar-item', onclick: () => open(t.id) }, h('span', { class: 'light l-' + t.urgency }, ''), h('span', { class: 'ttl2 trunc' }, t.title), h('span', { class: 'small muted' }, t.code))))));
    }
    if (!any) rb.append(h('p', { class: 'muted' }, 'No due dates in the next two weeks.'));
    radar.append(h('div', { class: 'panel-h' }, h('h2', null, 'Deadlines'), h('span', { class: 'small muted' }, 'next 14 days')), rb);
    rail.append(radar);
    // workload
    const hpd = Number(S.meta.settings.hours_per_day || 6), end7 = App.addDays(today, 6);
    const due7 = act.filter((t) => t.due_date && App.pd(t.due_date) <= end7), noEst = due7.filter((t) => !t.est_hours).length;
    const need = due7.reduce((s, t) => s + (t.remaining_hours || 0), 0), cap7 = workdaysBetween(today, end7) * hpd, over = need - cap7;
    rail.append(h('div', { class: 'panel' }, h('div', { class: 'panel-h' }, h('h2', null, 'This week'), h('span', { class: 'small muted' }, 'work due vs your time')),
      h('div', { class: 'panel-b' }, h('div', { class: 'cap-line' }, h('span', null, 'Work due by ' + end7.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })), h('b', null, fmtH(need))),
        App.bar(cap7 ? Math.min(100, Math.round(100 * need / cap7)) : 100, over > 0 ? 'var(--c-overdue)' : 'var(--c-ok)', 'lg'), h('div', { class: 'cap-line' }, h('span', null, 'Working time available (' + hpd + ' h a day)'), h('b', null, fmtH(cap7))),
        over > 0 ? h('p', { style: { color: 'var(--c-overdue)', marginTop: '8px', fontWeight: 600 } }, 'About ' + fmtH(over) + ' more than you can do. Talk to the user about dates.') : h('p', { class: 'muted', style: { marginTop: '8px' } }, 'This week fits your available time.'),
        noEst ? h('p', { class: 'small muted', style: { marginTop: '4px' } }, noEst + (noEst === 1 ? ' task has' : ' tasks have') + ' no estimate yet, so they are not counted.') : null)));
    // pipeline
    const counts = STATUS_ORDER.map((k) => ({ k: k, n: T.filter((t) => t.status === k).length })).filter((x) => x.n);
    rail.append(h('div', { class: 'panel' }, h('div', { class: 'panel-h' }, h('h2', null, 'Where every task stands')),
      h('div', { class: 'panel-b' }, h('div', { class: 'pipe' }, counts.map((x) => h('button', { type: 'button', style: { flex: x.n + ' 1 0', '--c': 'var(--s-' + x.k + ')' }, title: App.statusOf(x.k).label, onclick: () => go('tasks', { scope: x.k }) }, x.n))),
        h('div', { class: 'pipe-legend' }, counts.map((x) => h('span', { style: { '--c': 'var(--s-' + x.k + ')' } }, App.statusOf(x.k).label + ' ' + x.n))))));
    // activity
    const actBox = h('div', { class: 'panel-b' }, h('span', { class: 'muted' }, 'Loading...'));
    rail.append(h('div', { class: 'panel' }, h('div', { class: 'panel-h' }, h('h2', null, 'Recent activity')), actBox));
    GET('/api/history?limit=8').then((rows) => actBox.replaceChildren(rows.length ? rows.map((e) => h('div', { class: 'act' }, h('span', { class: 'muted' }, fmtTs(e.ts).replace(', ', '\n')), h('span', null, h('b', null, e.code), ' ', e.text))) : h('span', { class: 'muted' }, 'Nothing yet.'))).catch(() => {});
    root.append(h('div', { class: 'dash' }, left, rail));
  };

  /* ---------- Tasks ---------- */
  V.tasks = function (root) {
    const f = filters(), T = S.tasks, sortKey = App.LS.get('sort', 'score'), dir = App.LS.get('dir', 1);
    const uniq = (k) => Array.from(new Set(T.map((t) => t[k]).filter(Boolean))).sort();
    const list = sortList(applyFilters(T, f), sortKey, dir);
    const redraw = () => { App.render(); };
    const scopes = [['active', 'Active tasks'], ['attention', 'Need attention'], ['week', 'Due within 7 days'], ['waiting', 'Waiting on others'], ['testing', 'In UAT or testing'], ['finished', 'Finished'], ['all', 'Everything']].concat(App.S.meta.statuses.map((s) => [s.key, 'Only: ' + s.label]));
    const q = h('input', { type: 'search', placeholder: 'Search title, code, T-code, person, waiting for...', value: f.q, 'aria-label': 'Search tasks' });
    q.addEventListener('input', App.debounce(() => { setFilters({ q: q.value }); redrawTable(); }, 200));
    const mk = (key, label, opts) => sel([['', label]].concat(opts), f[key], (v) => { setFilters({ [key]: v }); redraw(); });
    root.append(pageHead('Tasks'),
      h('div', { class: 'tools' }, h('div', { class: 'grow', style: { maxWidth: '360px' } }, q), sel(scopes, f.scope, (v) => { setFilters({ scope: v }); redraw(); }),
        mk('module', 'All modules', uniq('module')), mk('type', 'All types', uniq('task_type').map((k) => [k, App.typeLabel(k)])), mk('who', 'Anyone', uniq('requested_by')), mk('prio', 'Any priority', KB.estimate ? S.meta.priorities.map((p) => [p, cap(p)]) : []),
        h('button', { class: 'btn ghost', type: 'button', onclick: () => { setFilters({ q: '', scope: 'active', module: '', type: '', who: '', prio: '' }); redraw(); } }, 'Reset')));
    const holder = h('div');
    root.append(holder);
    function redrawTable() {
      const rows = sortList(applyFilters(S.tasks, filters()), App.LS.get('sort', 'score'), App.LS.get('dir', 1));
      holder.replaceChildren(rows.length ? table(rows) : empty(S.tasks.length ? 'No tasks match these filters' : 'No tasks yet', S.tasks.length ? 'Try "Everything" or reset the filters.' : 'Add your first task to start.', S.tasks.length ? null : [newBtn(), sampleBtn()]));
    }
    function th(label, key, cls) {
      const cur = App.LS.get('sort', 'score') === key, d = App.LS.get('dir', 1);
      return h('th', { class: 'sort ' + (cls || ''), 'aria-sort': cur ? (d === 1 ? 'ascending' : 'descending') : 'none', onclick: () => { if (cur) App.LS.set('dir', -d); else { App.LS.set('sort', key); App.LS.set('dir', 1); } redraw(); } }, label, cur ? h('span', { class: 'arr' }, d === 1 ? '▲' : '▼') : null);
    }
    function table(rows) {
      return h('div', { class: 'gridwrap' }, h('table', { class: 'grid' },
        h('thead', null, h('tr', null, th('Urgency', 'score'), th('Code', 'code'), th('Task', 'title'), th('Priority', 'priority'), th('Status', 'status'), th('Progress', 'progress'), th('Due', 'due'), th('Work', 'work', 'num'))),
        h('tbody', null, rows.map((t) => h('tr', { class: 'click', tabindex: 0, onclick: () => open(t.id), onkeydown: (e) => { if (e.key === 'Enter' && e.target.tagName === 'TR') open(t.id); } },
          h('td', null, App.light(t)), h('td', { class: 'mono' }, t.code),
          h('td', { style: { maxWidth: '420px' } }, h('span', { class: 'ttl' }, t.title), h('span', { class: 'sub' }, [App.typeLabel(t.task_type), t.module, t.requested_by].filter(Boolean).join(', ') + (t.q_open ? ', ' + t.q_open + ' quality ' + (t.q_open === 1 ? 'point' : 'points') + ' open' : '') + (t.p_open ? ', ' + t.p_open + ' production ' + (t.p_open === 1 ? 'problem' : 'problems') : '')), App.waitChip(t)),
          h('td', null, App.prio(t.priority)),
          h('td', { onclick: (e) => e.stopPropagation() }, sel(S.meta.statuses.map((s) => [s.key, s.label]), t.status, (v) => setStatus(t, v), { class: 'sel-inline', 'aria-label': 'Status of ' + t.code })),
          h('td', null, App.progress(t)), h('td', null, t.due_date ? h('div', null, fmtD(t.due_date)) : h('span', { class: 'muted' }, '—')),
          h('td', { class: 'num' }, h('div', null, t.est_hours ? fmtH(t.est_hours) : '—'), t.logged ? h('div', { class: 'sub' }, fmtH(t.logged) + ' logged') : null))))));
    }
    redrawTable();
    holder.after(h('p', { class: 'small muted', style: { marginTop: '8px' } }, list.length + ' of ' + T.length + ' tasks shown. Click a row to open it. Sorted by ' + (sortKey === 'score' ? 'urgency and priority' : sortKey) + '.'));
  };

  /* ---------- Board ---------- */
  V.board = function (root) {
    const cols = ['new', 'analysis', 'dev', 'unit_test', 'quality', 'prod', 'closed', 'hold'];
    const recent = App.addDays(new Date(), -21);
    root.append(pageHead('Board', 'Drag a card to another column to change its status.'));
    if (!S.tasks.length) { root.append(empty('No tasks yet', 'Add a task to see it here.', [newBtn(), sampleBtn()])); return; }
    const board = h('div', { class: 'board' });
    cols.forEach((k) => {
      let list = S.tasks.filter((t) => t.status === k);
      if (k === 'closed') list = list.filter((t) => !t.completed_at || App.pd(t.completed_at) >= recent);
      list = sortList(list, 'score', 1);
      const body = h('div', { class: 'col-b' }, list.length ? list.map((t) => card(t)) : h('div', { class: 'small muted', style: { padding: '8px', textAlign: 'center' } }, 'Empty'));
      const col = h('div', { class: 'col', style: { '--c': 'var(--s-' + k + ')' } }, h('div', { class: 'col-h' }, App.statusOf(k).label, h('span', { class: 'badge soft' }, list.length)), body);
      col.addEventListener('dragover', (e) => { e.preventDefault(); col.classList.add('over'); });
      col.addEventListener('dragleave', (e) => { if (!col.contains(e.relatedTarget)) col.classList.remove('over'); });
      col.addEventListener('drop', async (e) => {
        e.preventDefault(); col.classList.remove('over');
        const id = Number(e.dataTransfer.getData('text/plain')), t = App.byId(id);
        if (t && t.status !== k) await setStatus(t, k);
      });
      board.append(col);
    });
    root.append(board, h('p', { class: 'small muted' }, 'Closed tasks older than 3 weeks are hidden here. Find them in History.'));
    function card(t) {
      const c = h('div', { class: 'card', draggable: 'true', tabindex: 0, role: 'button', onclick: () => open(t.id), onkeydown: (e) => { if (e.key === 'Enter') open(t.id); } },
        h('div', { class: 'row' }, h('span', { class: 'mono small ink2' }, t.code), h('span', { class: 'grow' }), App.prio(t.priority)), h('span', { class: 'ttl' }, t.title),
        h('div', { class: 'row wrap' }, App.light(t), t.module ? App.tag(t.module) : null), App.waitChip(t), App.progress(t),
        t.q_open || t.p_open ? h('div', { class: 'small', style: { color: 'var(--c-warning)' } }, (t.q_open ? t.q_open + ' quality ' : '') + (t.p_open ? t.p_open + ' production problem' : (t.q_open ? 'open' : ''))) : null);
      c.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', String(t.id)); e.dataTransfer.effectAllowed = 'move'; setTimeout(() => c.classList.add('dragging'), 0); });
      c.addEventListener('dragend', () => c.classList.remove('dragging'));
      return c;
    }
  };

  /* ---------- Timeline ---------- */
  V.timeline = function (root) {
    const showDone = App.LS.get('tl_done', false);
    root.append(pageHead('Timeline', 'Each bar runs from the start (or received) date to the due date. The orange line is today.',
      h('label', { class: 'row', style: { cursor: 'pointer' } }, h('input', { type: 'checkbox', checked: showDone, onchange: (e) => { App.LS.set('tl_done', e.target.checked); App.render(); } }), 'Include finished tasks')));
    let list = S.tasks.filter((t) => showDone ? t.status !== 'cancelled' : App.isActive(t));
    if (!list.length) { root.append(empty('Nothing to show', 'Active tasks with dates appear here.', [newBtn()])); return; }
    list = list.sort((a, b) => (a.due_date || '9999').localeCompare(b.due_date || '9999') || b.score - a.score);
    const today = new Date(), dw = 28;
    let from = App.addDays(today, -10), to = App.addDays(today, 38);
    list.forEach((t) => { const s = App.pd(t.start_date || t.received_date), e = App.pd(t.due_date); if (s && s < from) from = s; if (e && e > to) to = e; });
    if (App.daysBetween(from, to) > 240) { from = App.addDays(to, -240); }
    const n = App.daysBetween(from, to) + 1, W = n * dw;
    const days = h('div', { class: 'tl-days', style: { width: W + 'px' } });
    for (let i = 0; i < n; i++) {
      const d = App.addDays(from, i), dow = d.getDay(), first = d.getDate() === 1 || i === 0;
      days.append(h('div', { class: 'tl-day' + (dow === 0 || dow === 6 ? ' we' : '') + (App.iso(d) === App.iso(today) ? ' td' : ''), style: { width: dw + 'px' }, title: d.toDateString() },
        h('span', { style: { display: 'block', fontSize: '9.5px', height: '11px' } }, first ? d.toLocaleDateString('en-GB', { month: 'short' }) : ''), h('b', null, d.getDate()), 'SMTWTFS'.charAt(dow)));
    }
    const todayX = App.daysBetween(from, today) * dw + dw / 2;
    const grid = h('div', { class: 'tl-grid' }, h('div', { class: 'tl-head' }, h('div', { class: 'tl-lab' }, 'Task'), days));
    list.forEach((t) => {
      const s = App.pd(t.start_date || t.received_date) || today, e = App.pd(t.due_date);
      const track = h('div', { class: 'tl-track', style: { width: W + 'px', '--c': App.barColor(t) } });
      for (let i = 0; i < n; i++) { const d = App.addDays(from, i); if (d.getDay() === 0 || d.getDay() === 6) track.append(h('div', { style: { position: 'absolute', top: 0, bottom: 0, left: (i * dw) + 'px', width: dw + 'px', background: 'rgba(128,140,150,.06)' } })); }
      if (e) {
        const a = s <= e ? s : e, b = s <= e ? e : s, x = App.daysBetween(from, a) * dw, w = (App.daysBetween(a, b) + 1) * dw;
        track.append(h('div', { class: 'tl-bar', style: { left: x + 'px', width: Math.max(w, 14) + 'px' }, title: t.title + ' (' + fmtD(a, true) + ' to ' + fmtD(b, true) + ')', onclick: () => open(t.id) }, h('i', { style: { width: t.progress + '%' } }), h('span', null, t.progress + '%')));
      } else track.append(h('div', { class: 'tl-bar', style: { left: App.daysBetween(from, s) * dw + 'px', width: '60px', borderStyle: 'dashed' }, title: 'No due date', onclick: () => open(t.id) }, h('span', null, 'no due date')));
      track.append(h('div', { class: 'tl-today', style: { left: todayX + 'px' } }));
      grid.append(h('div', { class: 'tl-row' }, h('div', { class: 'tl-lab', style: { cursor: 'pointer' }, onclick: () => open(t.id) }, h('div', { class: 'row' }, h('span', { class: 'mono small ink2' }, t.code), App.light(t)), h('div', { class: 'trunc small', style: { maxWidth: '245px' } }, t.title)), track));
    });
    const wrap = h('div', { class: 'tl' }, grid);
    root.append(wrap);
    setTimeout(() => { wrap.scrollLeft = Math.max(0, todayX - 360); }, 0);
  };

  /* ---------- History ---------- */
  V.history = function (root) {
    const tab = App.LS.get('hist_tab', 'done');
    root.append(pageHead('History', 'What has been finished, what went to production and how it went.'), h('div', { class: 'tools' }, h('div', { class: 'seg' },
      [['done', 'Completed work'], ['moves', 'Transports'], ['log', 'Activity log']].map((x) => h('button', { type: 'button', class: tab === x[0] ? 'on' : '', onclick: () => { App.LS.set('hist_tab', x[0]); App.render(); } }, x[1])))));
    const holder = h('div'); root.append(holder);
    if (tab === 'done') {
      const T = S.tasks, fin = T.filter(App.isDone).sort((a, b) => (b.completed_at || '').localeCompare(a.completed_at || ''));
      const month = App.todayIso().slice(0, 7), thisM = fin.filter((t) => t.completed_at && t.completed_at.slice(0, 7) === month).length;
      const withP = fin.filter((t) => t.p_total).length, meas = fin.filter((t) => t.est_hours && t.logged > 0);
      const acc = meas.length ? Math.round(100 * meas.reduce((s, t) => s + t.logged, 0) / meas.reduce((s, t) => s + t.est_hours, 0)) : null;
      const counts = STATUS_ORDER.map((k) => ({ k: k, n: T.filter((t) => t.status === k).length })).filter((x) => x.n);
      holder.append(h('div', { class: 'stat-line' }, h('span', null, h('b', null, fin.length), 'finished in total'), h('span', null, h('b', null, thisM), 'finished this month'), h('span', null, h('b', null, withP), 'had problems after production'),
        acc != null ? h('span', { title: 'Hours actually logged divided by hours estimated, for finished tasks that have both' }, h('b', null, acc + '%'), 'of estimated time actually used') : null),
        counts.length ? h('div', { style: { marginBottom: '16px' } }, h('div', { class: 'pipe' }, counts.map((x) => h('button', { type: 'button', style: { flex: x.n + ' 1 0', '--c': 'var(--s-' + x.k + ')' }, title: App.statusOf(x.k).label, onclick: () => go('tasks', { scope: x.k }) }, x.n))),
          h('div', { class: 'pipe-legend' }, counts.map((x) => h('span', { style: { '--c': 'var(--s-' + x.k + ')' } }, App.statusOf(x.k).label + ' ' + x.n)))) : null);
      if (!fin.length) holder.append(empty('Nothing finished yet', 'Tasks moved to "In Production" or "Closed" are listed here with their T-code and sign-off.'));
      else holder.append(h('div', { class: 'gridwrap' }, h('table', { class: 'grid' }, h('thead', null, h('tr', null, ['Code', 'Task', 'Requested by', 'T-code', 'What was done', 'Finished', 'In production', 'UAT sign-off', 'Quality points', 'After production', 'Time'].map((x) => h('th', null, x)))),
        h('tbody', null, fin.map((t) => h('tr', { class: 'click', onclick: () => open(t.id, 'release') },
          h('td', { class: 'mono' }, t.code), h('td', { style: { maxWidth: '340px' } }, h('span', { class: 'ttl' }, t.title), h('span', { class: 'sub' }, [App.typeLabel(t.task_type), t.module].filter(Boolean).join(', '))), h('td', null, t.requested_by || '—'),
          h('td', { class: 'mono' }, t.dev.tcode || h('span', { class: 'chip', style: { '--c': 'var(--c-warning)' }, title: 'Add the T-code in the Solution info tab' }, 'missing')), h('td', { style: { maxWidth: '240px' } }, t.dev.obj_name || '—'), h('td', null, fmtD(t.completed_at)), h('td', null, t.prd_date ? fmtD(t.prd_date) : '—'),
          h('td', null, t.dev.signoff_by ? h('span', { class: 'light l-ok', title: t.dev.signoff_on ? 'Signed off on ' + fmtD(t.dev.signoff_on, true) : '' }, t.dev.signoff_by) : h('span', { class: 'muted' }, '—')),
          h('td', null, t.q_total ? (t.q_total - t.q_open) + ' of ' + t.q_total + ' done' : '—'),
          h('td', null, t.p_open ? h('span', { class: 'light l-overdue' }, t.p_open + ' open') : t.p_total ? h('span', { class: 'light l-ok' }, 'All fixed') : t.prd_date ? h('span', { class: 'light l-ok' }, 'No problems') : h('span', { class: 'muted' }, '—')),
          h('td', null, t.logged ? fmtH(t.logged) + (t.est_hours ? ' / ' + fmtH(t.est_hours) : '') : '—')))))));
    } else if (tab === 'moves') {
      holder.append(h('p', { class: 'muted' }, 'Loading...'));
      GET('/api/moves').then((rows) => holder.replaceChildren(rows.length ? h('div', { class: 'gridwrap' }, h('table', { class: 'grid' }, h('thead', null, h('tr', null, ['Date', 'Task', 'System', 'Transport', 'Result', 'Note'].map((x) => h('th', null, x)))),
        h('tbody', null, rows.map((m) => h('tr', { class: 'click', onclick: () => open(m.task_id, 'release') }, h('td', null, fmtD(m.moved_on, true)), h('td', null, h('span', { class: 'mono' }, m.code), ' ', m.task_title), h('td', null, h('span', { class: 'chip', style: { '--c': m.env === 'PRD' ? 'var(--c-ok)' : m.env === 'QAS' ? 'var(--c-warning)' : 'var(--accent)' } }, m.env)),
          h('td', { class: 'mono' }, m.tr_number || '—'), h('td', null, m.result === 'issue' ? h('span', { class: 'light l-overdue' }, 'Issue after move') : h('span', { class: 'light l-ok' }, 'No problem')), h('td', null, m.note)))))) : empty('No transports recorded', 'Record each move in a task: Transport & UAT > Record move.')));
    } else {
      holder.append(h('p', { class: 'muted' }, 'Loading...'));
      GET('/api/history?limit=150').then((rows) => holder.replaceChildren(h('div', { class: 'panel panel-b tl-list' }, rows.length ? rows.map((e) => h('div', { class: 'ev' }, h('time', null, fmtTs(e.ts)), h('div', null, h('button', { class: 'lnk', type: 'button', onclick: () => open(e.task_id) }, e.code), ' ', h('span', { class: 'k ' + e.kind }, e.kind), e.text))) : 'Nothing yet.')));
    }
  };

  /* ---------- Register ---------- */
  V.register = function (root) {
    const q = App.LS.get('reg_q', ''), mod = App.LS.get('reg_mod', '');
    const all = S.tasks.filter((t) => (t.dev && (t.dev.obj_name || t.dev.tcode || t.dev.signoff_by)) || App.isDone(t));
    root.append(pageHead('Register', 'Every change and setting you made: T-code, SPRO path and what was done. Fill it in the Solution info tab of each task.'));
    const search = h('input', { type: 'search', placeholder: 'Search T-code, account, setting, description...', value: q, 'aria-label': 'Search register' });
    const mods = Array.from(new Set(all.map((t) => t.module).filter(Boolean))).sort();
    const holder = h('div');
    function draw() {
      const qq = App.LS.get('reg_q', ''), mm = App.LS.get('reg_mod', '');
      const rows = all.filter((t) => (!mm || t.module === mm) && App.matchTask(t, qq)).sort((a, b) => ((b.dev.developed_on || b.completed_at || '')).localeCompare(a.dev.developed_on || a.completed_at || ''));
      holder.replaceChildren(rows.length ? h('div', { class: 'gridwrap' }, h('table', { class: 'grid' }, h('thead', null, h('tr', null, ['What was configured', 'T-code / SPRO', 'What was done', 'Type', 'CR / version', 'Done on', 'In production', 'Signed off', 'Task'].map((x) => h('th', null, x)))),
        h('tbody', null, rows.map((t) => { const d = t.dev || {};
          return h('tr', { class: 'click', onclick: () => open(t.id, 'dev') },
            h('td', { style: { maxWidth: '260px' } }, d.obj_name ? h('span', { class: 'row' }, h('span', { style: { fontWeight: 600 } }, d.obj_name), h('button', { class: 'iconbtn sm', type: 'button', title: 'Copy', 'aria-label': 'Copy text', onclick: (e) => { e.stopPropagation(); App.copyText(d.obj_name, 'Copied'); } }, ico('copy'))) : h('span', { class: 'chip', style: { '--c': 'var(--c-warning)' } }, 'not filled')),
            h('td', null, d.tcode ? h('span', { class: 'row' }, h('span', { class: 'mono', style: { fontWeight: 600 } }, d.tcode), h('button', { class: 'iconbtn sm', type: 'button', title: 'Copy', 'aria-label': 'Copy T-code', onclick: (e) => { e.stopPropagation(); App.copyText(d.tcode, 'T-code copied'); } }, ico('copy'))) : h('span', { class: 'muted' }, '—')),
            h('td', { style: { maxWidth: '360px' } }, h('span', { class: 'ttl' }, t.title), h('span', { class: 'sub' }, d.what_done || t.summary || '')), h('td', null, [App.typeLabel(t.task_type), t.module].filter(Boolean).join(', ')),
            h('td', null, d.version || '—'), h('td', null, fmtD(d.developed_on || t.completed_at)), h('td', null, t.prd_date ? fmtD(t.prd_date) : App.isDone(t) ? 'Yes' : 'Not yet'), h('td', null, d.signoff_by ? d.signoff_by + (d.signoff_on ? ', ' + fmtD(d.signoff_on) : '') : '—'), h('td', { class: 'mono' }, t.code)); })))) :
        empty(all.length ? 'Nothing matches' : 'The register is empty', all.length ? 'Try another search.' : 'When a task is finished, add its T-code and what was done in the Solution info tab. It will appear here.'));
    }
    search.addEventListener('input', App.debounce(() => { App.LS.set('reg_q', search.value); draw(); }, 200));
    root.append(h('div', { class: 'tools' }, h('div', { class: 'grow', style: { maxWidth: '380px' } }, search), sel([['', 'All modules']].concat(mods.map((m) => [m, m])), mod, (v) => { App.LS.set('reg_mod', v); draw(); }),
      h('a', { class: 'btn', href: '/api/export.xlsx', download: '' }, ico('download'), 'Export to Excel')), holder);
    draw();
  };

  /* ---------- Quality & issues ---------- */
  V.quality = function (root) {
    const mode = App.LS.get('q_mode', 'open');
    root.append(pageHead('Quality and production problems', 'Points the user asked for during UAT, and problems found after the change went to production.'),
      h('div', { class: 'tools' }, h('div', { class: 'seg' }, [['open', 'Open'], ['all', 'All']].map((x) => h('button', { type: 'button', class: mode === x[0] ? 'on' : '', onclick: () => { App.LS.set('q_mode', x[0]); App.render(); } }, x[1])))));
    const holder = h('div', { class: 'stack', style: { gap: '24px' } }); root.append(holder);
    GET('/api/issues').then((rows) => {
      const show = (kind, title) => {
        const list = rows.filter((r) => r.kind === kind && (mode === 'all' || r.status === 'open'));
        const sec = h('section', null, h('div', { class: 'sect-t' }, h('h2', null, title), h('span', null, list.length + (list.length === 1 ? ' item' : ' items'))));
        sec.append(list.length ? h('div', { class: 'gridwrap', style: { maxHeight: 'none' } }, h('table', { class: 'grid' }, h('thead', null, h('tr', null, ['Done', 'Task', 'Point', 'Severity', 'Raised'].map((x) => h('th', null, x)))),
          h('tbody', null, list.map((i) => h('tr', null, h('td', null, h('input', { type: 'checkbox', checked: i.status === 'fixed', 'aria-label': 'Mark fixed', onchange: async (e) => { await PUT('/api/issues/' + i.id, { status: e.target.checked ? 'fixed' : 'open' }); await App.refreshTasks(); } })),
            h('td', { style: { maxWidth: '280px' } }, h('button', { class: 'lnk', type: 'button', onclick: () => open(i.task_id, 'release') }, i.code), ' ', h('span', { class: 'sub' }, i.task_title)),
            h('td', { style: { textDecoration: i.status === 'fixed' ? 'line-through' : 'none' } }, i.title), h('td', null, h('span', { class: 'chip', style: { '--c': i.severity === 'high' ? 'var(--c-overdue)' : i.severity === 'medium' ? 'var(--c-warning)' : 'var(--c-none)' } }, cap(i.severity))), h('td', null, fmtD(i.raised_on, true))))))) :
          empty(mode === 'open' ? 'Nothing open' : 'Nothing recorded', kind === 'prod' ? 'No problems reported after production moves.' : 'No quality points waiting.'));
        return sec;
      };
      holder.replaceChildren(show('prod', 'Problems after production'), show('quality', 'Quality and UAT points'));
    }).catch(() => {});
  };

  /* ---------- Library ---------- */
  function refBlock(modKey, q) {
    const m = KB.modules[modKey], ql = (q || '').toLowerCase(), box = h('div', { class: 'stack', style: { gap: '18px' } });
    const match = (x) => !ql || x.n.toLowerCase().indexOf(ql) >= 0 || x.d.toLowerCase().indexOf(ql) >= 0;
    (KB.moduleSections || []).filter((sc) => ['auth', 'notes'].indexOf(sc[0]) < 0).map((sc) => [sc[1], m[sc[0]] || []]).forEach((g) => {
      const items = g[1].filter(match); if (!items.length) return;
      box.append(h('section', null, h('div', { class: 'sect-t' }, h('h2', null, g[0]), h('span', null, items.length + ' (click to copy a name)')),
        h('div', { class: 'ref-list' }, items.map((x) => h('div', { class: 'ref', title: 'Copy', onclick: () => App.copyText(x.n.split(' / ')[0].split(' ')[0] === x.n ? x.n : x.n, 'Copied ' + x.n) }, h('span', { class: 'mono' }, x.n), h('span', { class: 'ink2' }, x.d))))));
    });
    if (!ql && m.auth.length) box.append(h('section', null, h('div', { class: 'sect-t' }, h('h2', null, 'Authorisation objects')), h('div', { class: 'row wrap' }, m.auth.map((a) => h('span', { class: 'tag mono' }, a)))));
    if (!ql && m.notes.length) box.append(h('section', null, h('div', { class: 'sect-t' }, h('h2', null, 'Good to know')), h('ul', { style: { margin: '0 0 0 18px', padding: 0 } }, m.notes.map((n) => h('li', { style: { marginBottom: '4px', maxWidth: '90ch' } }, n)))));
    if (!box.children.length) box.append(empty('Nothing matches', 'Try another word.'));
    return box;
  }
  function refPanel(startModule) {
    let cur = startModule && KB.modules[startModule] ? startModule : Object.keys(KB.modules)[0], q = '';
    const holder = h('div'), search = h('input', { type: 'search', placeholder: 'Search a T-code, SPRO node, report or table...' });
    const mods = h('div', { class: 'seg', style: { flexWrap: 'wrap' } });
    const draw = () => { mods.replaceChildren(Object.keys(KB.modules).map((k) => h('button', { type: 'button', class: cur === k ? 'on' : '', title: KB.modules[k].name, onclick: () => { cur = k; draw(); } }, k))); holder.replaceChildren(h('p', { class: 'ink2', style: { margin: '0 0 12px' } }, KB.modules[cur].name + '. ' + KB.modules[cur].hint + '.'), refBlock(cur, q)); };
    search.addEventListener('input', App.debounce(() => { q = search.value.trim(); draw(); }, 150));
    draw();
    return h('div', null, h('div', { class: 'tools' }, mods, h('div', { class: 'grow', style: { maxWidth: '360px' } }, search)), holder);
  }
  App.refModal = (m) => modal({ title: 'SAP reference', cls: 'xl', body: refPanel(m), actions: [{ label: 'Close' }] });
  V.library = function (root) {
    const tab = App.LS.get('lib_tab', 'tpl');
    root.append(pageHead('Library', 'Ready templates for common FICO requests and an SAP reference (T-codes, SPRO paths, reports, tables), so you do not start from zero.'), h('div', { class: 'tools' }, h('div', { class: 'seg' }, [['tpl', 'Ready templates'], ['ref', 'SAP reference']].map((x) => h('button', { type: 'button', class: tab === x[0] ? 'on' : '', onclick: () => { App.LS.set('lib_tab', x[0]); App.render(); } }, x[1])))));
    if (tab === 'ref') { root.append(refPanel()); return; }
    let q = '', mod = '', typ = '';
    const holder = h('div', { class: 'lib-grid' });
    function draw() {
      const ql = q.toLowerCase();
      const list = KB.templates.filter((t) => (!mod || t.module === mod) && (!typ || t.type === typ) && (!ql || (t.title + ' ' + t.summary + ' ' + (t.tables || []).join(' ')).toLowerCase().indexOf(ql) >= 0));
      holder.replaceChildren(list.length ? list.map((t) => h('div', { class: 'tpl' }, h('div', { class: 'row wrap' }, App.tag(t.module), App.tag(KB.types[t.type].label), h('span', { class: 'grow' }), t.hours ? h('span', { class: 'small muted' }, 'about ' + t.hours + ' h') : null),
        h('h3', null, t.title), h('p', { class: 'small ink2' }, t.summary), t.sel && t.sel.length ? h('div', { class: 'small' }, h('span', { class: 'muted' }, 'Scope: '), h('span', null, t.sel.slice(0, 5).map((s) => s.split(':')[0]).join(', '))) : null,
        t.tables && t.tables.length ? h('div', { class: 'small' }, h('span', { class: 'muted' }, 'T-codes / tables: '), h('span', { class: 'mono' }, t.tables.slice(0, 6).join(', '))) : null,
        h('div', { style: { marginTop: 'auto', paddingTop: '6px' } }, h('button', { class: 'btn sm primary', type: 'button', onclick: () => App.newTask(t) }, ico('plus'), 'Start a task from this')))) : empty('No template matches', 'Clear the filters.'));
    }
    const search = h('input', { type: 'search', placeholder: 'Search templates...' });
    search.addEventListener('input', App.debounce(() => { q = search.value.trim(); draw(); }, 150));
    root.append(h('div', { class: 'tools' }, h('div', { class: 'grow', style: { maxWidth: '340px' } }, search), sel([['', 'All modules']].concat(Object.keys(KB.modules).filter((m) => KB.templates.some((t) => t.module === m)).map((m) => [m, m])), '', (v) => { mod = v; draw(); }),
      sel([['', 'All types']].concat(Object.keys(KB.types).filter((k) => KB.templates.some((t) => t.type === k)).map((k) => [k, KB.types[k].label])), '', (v) => { typ = v; draw(); })), holder);
    draw();
  };

  /* ---------- Settings ---------- */
  V.settings = function (root) {
    const meta = S.meta, st = meta.settings, days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const wd = new Set(String(st.work_days).split(',').map(Number));
    const save = async (patch) => { const r = await PUT('/api/settings', patch); meta.settings = r; toast('Settings saved'); };
    const backups = h('div', { class: 'small muted' }, 'Loading...');
    GET('/api/backups').then((b) => backups.replaceChildren(b.length ? h('ul', { style: { margin: '6px 0 0 18px', padding: 0 } }, b.slice(0, 6).map((x) => h('li', null, x.name + ' (' + App.fmtSize(x.size) + ')'))) : 'No backups yet.')).catch(() => {});
    root.append(pageHead('Settings'), h('div', { class: 'stack', style: { maxWidth: '760px', gap: '26px' } },
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'Working time')), h('p', { class: 'ink2', style: { marginBottom: '10px' } }, 'Used to check whether a task can still be finished before its due date.'),
        h('div', { class: 'grid2' }, fld('Productive working hours in a day', inp(st.hours_per_day, (v) => save({ hours_per_day: v }), { type: 'number', min: '1', max: '16', step: '0.5' }), 'Be realistic: meetings and support take time.'),
          h('div', { class: 'fld' }, h('label', null, 'Working days'), h('div', { class: 'row wrap' }, days.map((d, i) => h('label', { class: 'row', style: { cursor: 'pointer' } }, h('input', { type: 'checkbox', checked: wd.has(i), onchange: (e) => { if (e.target.checked) wd.add(i); else wd.delete(i); save({ work_days: Array.from(wd).sort().join(',') }); } }), d)))))),
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'Warnings')),
        h('div', { class: 'grid2' }, fld('Amber warning when this many days are left', inp(st.warn_days, (v) => save({ warn_days: v }), { type: 'number', min: '0', max: '60' })), fld('Urgent (red) when this many days are left', inp(st.urgent_days, (v) => save({ urgent_days: v }), { type: 'number', min: '0', max: '60' }))),
        h('p', { class: 'small muted', style: { marginTop: '6px' } }, 'Overdue tasks are always red. "Not enough time" appears when the work left is more than the working time left.')),
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'Your data')), h('p', { class: 'ink2' }, 'Your working copy on this PC is in:'), h('p', { class: 'mono', style: { margin: '4px 0 10px', wordBreak: 'break-all' } }, meta.data_dir),
        h('div', { class: 'row wrap' }, h('button', { class: 'btn', type: 'button', onclick: () => POST('/api/open-data-folder').then(() => toast('Opened data folder')) }, ico('folder'), 'Open data folder'),
          h('button', { class: 'btn', type: 'button', onclick: async () => { const r = await POST('/api/backup'); toast('Backup saved: ' + r.file); App.render(); } }, ico('copy'), 'Back up database now'),
          h('a', { class: 'btn', href: '/api/export.xlsx', download: '' }, ico('download'), 'Export everything to Excel')),
        h('p', { class: 'small muted', style: { marginTop: '8px' } }, 'A database backup is made automatically once a day (last 30 kept in the "backups" folder). Your tasks and files are also kept safely in your TaskDesk cloud account. To work on another PC, install TaskDesk there and sign in.'), backups),
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'Sample tasks')), h('p', { class: 'ink2', style: { marginBottom: '8px' } }, meta.n_demo ? 'Sample tasks are loaded (' + meta.n_demo + '). Remove them before you start real work.' : 'Load a few example tasks to explore the app.'),
        h('div', { class: 'row' }, h('button', { class: 'btn', type: 'button', onclick: async () => { await POST('/api/demo'); toast('Sample tasks added'); await App.refreshTasks(); } }, 'Load sample tasks'),
          meta.n_demo ? h('button', { class: 'btn danger', type: 'button', onclick: async () => { if (await App.confirmBox('Remove all sample tasks and their files?', 'Remove samples')) { await DEL('/api/demo'); toast('Sample tasks removed'); await App.refreshTasks(); } } }, 'Remove sample tasks') : null)),
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'App')), h('p', { class: 'ink2', style: { marginBottom: '8px' } }, 'Version ' + meta.version + '. The app stops by itself a few minutes after you close its window. You can also stop it now.'),
        h('button', { class: 'btn danger', type: 'button', onclick: async () => { if (await App.confirmBox('Stop the FICO Task Manager now? Open it again from the desktop icon.', 'Stop app')) { try { await POST('/api/shutdown'); } catch (e) { /* ignore */ } document.body.innerHTML = '<div style="padding:60px;font:16px Segoe UI,sans-serif">FICO Task Manager has stopped. You can close this window.</div>'; } } }, ico('power'), 'Stop the app'))));
  };
})();
