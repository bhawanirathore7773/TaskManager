/* =====================================================================
   SAP MM (Materials Management) consultant knowledge base for the Task Manager (core part).
   Everything here is plain data: edit / extend it freely.
     kb.js            task types, estimate model, checklists, people  (this file)
     kb_modules.js    MM modules: T-codes, SPRO nodes, tables, notes
     kb_templates.js  ready templates for the "New task" screen
   T-codes, paths and table names differ a little between ECC and S/4HANA:
   always confirm on your own system (SE16N, SPRO search) before you rely on them.
   Release limits, tolerances, prices, duties and tax settings are decided by the
   company: keep them in configuration and confirm with the user or Finance,
   never write them into a task as facts.
   ===================================================================== */
(function () {
  const P = (n, d, m) => ({ n: n, d: d, m: !!m });          // scope / setting / field row
  const T = (n, d) => ({ n: n, d: d });                      // T-code / table / path row

  /* ------------------------------------------------------------------
     1. TASK TYPES - what to capture for each kind of work
        labels.entries is optional: only types with it show the
        "Stock and accounting effect" section.
     ------------------------------------------------------------------ */
  const types = {
    issue: {
      label: 'Support Issue / Ticket', icon: '\u{1F3AB}',
      intro: 'Something is wrong in a PO, goods movement, invoice, price, release, stock figure or print-out. Find the cause, fix it, confirm with the user.',
      ph: { n: 'PO / material document / material', d: 'Detail' },
      labels: { sel: 'Where it happens (T-code / document / process)', out: 'Expected vs actual result', entries: 'Stock and accounting effect (posted vs correct)', logic: 'Analysis / root cause', valid: 'Solution / correction applied', auth: 'Impact (plants, periods, other modules)', tables: 'Config / master data / tables checked', tests: 'Retest scenarios', qa: 'Questions to the user' },
      sel: [P('T-code / process', 'Where the user got the problem (ME21N, MIGO, MIRO, ME29N, MB51...)', 1), P('Document number(s)', 'PO, PR, material document, invoice document, accounting document'), P('Plant / storage location / purchasing org', 'Where it happens'), P('Material / vendor', 'Material number and vendor involved'),
        P('Posting date / period', 'Date used and period of the document'), P('User and time', 'Who got it and when'), P('Error message', 'Message class, number and exact text'), P('Since when', 'First seen; any recent transport, configuration or master data change')],
      out: [P('Expected result', 'What the user expects'), P('Actual result', 'What SAP does now'), P('Screenshot', 'Screen with the message or the wrong output (upload in Files)'), P('Quantity / value impact', 'Quantity, value and number of documents affected')],
      entries: [P('Posted entry', 'Movement type, Dr / Cr accounts and amounts that were posted (for example GR: Dr stock, Cr GR/IR)'), P('Correct entry', 'What should have posted'), P('Stock effect', 'Quantity and value in stock before and after (MMBE / MB52)'), P('Correction needed', 'Reversal, transfer posting, price change or reclass needed to fix stock and books (agree with Finance)')],
      logic: ['Reproduce in QAS / DEV with the same example (same material, plant, vendor)', 'Display the document (ME23N, MB03, MIR4) and compare with what was expected; check the PO history (EKBE) and the document change log',
        'Decide first: data problem, configuration problem or user error?', 'Price not picked: check the info record (ME13), the contract, the validity dates, the pricing schema and the condition analysis in the PO item',
        'Release strategy not triggered: compare the PO values (document type, purchasing group, plant, value) with the release strategy and its classification; check whether the PO was changed after release', 'Stock or value mismatch: compare MMBE / MB52 with the material documents (MB51); check price control (standard or moving average) and valuation class on the material',
        'Wrong or missing account: simulate with OMWB and check OBYC (BSX, WRX, GBB, PRD) together with the Finance consultant', 'GR/IR difference: check the PO history, MB5S and the invoices posted against the PO item',
        'Output not printing: check output determination (NACE), the message status in the PO (ME9F), the partner and the spool (SP01)', 'Check what changed before the problem started: recent transports (STMS, table E070), master data changes (change documents)',
        'Check authorisation with SU53 if the message is about authorisation', 'Keep the workaround and the permanent fix as two separate points'],
      valid: ['Fix tested with the same example document or material', 'Correction posting approved by Finance before it is made', 'Other documents or materials with the same problem listed', 'Stock quantity and value checked again after the fix (MMBE, MB5L)', 'Closed period effect confirmed (MM period and Finance period)'],
      auth: ['Which plants, storage locations and purchasing organisations are affected', 'Which periods are affected, and is the period closed', 'Impact on other modules (FI, PP, SD, QM)', 'Number of open POs, stock lines or invoices with the same problem', 'Who approved the correction (audit trail)'],
      tests: ['Original failing scenario now works', 'Normal scenario still works', 'Another plant / purchasing org / vendor', 'Reversal or cancellation of the document (MBST, MR8M)', 'Material document, accounting document and stock figure checked after the posting', 'Test with a user role that the end user really has'],
      qa: ['Exact steps and example PO / material document numbers?', 'Screenshot or message text?', 'Since when, and for all users and plants or one?', 'Is production, a dispatch or a vendor payment blocked (how urgent)?', 'Any workaround used so far?', 'Did anything change recently (master data, configuration, transport)?'],
      checklistNew: ['Issue reproduced / example documents received', 'Root cause found (data, configuration or user error)', 'Solution or workaround agreed with the user', 'Fix done in DEV (configuration) or data corrected', 'Tested with the failing example', 'Transport to QAS and tested (if configuration)', 'Moved to Production (if configuration)', 'Stock and accounting entries checked after the fix', 'User confirmed it works', 'Root cause and fix noted in Solution info'],
      checklistChange: ['Current setting captured (screenshot / table download)', 'Change made in DEV', 'Retested with the example document', 'Moved to Production', 'User confirmed'],
      devExtra: [{ k: 'root_cause', l: 'Root cause' }, { k: 'fix', l: 'Fix applied' }]
    },
    config: {
      label: 'Configuration / Change Request', icon: '\u{2699}\u{FE0F}',
      intro: 'A change in SPRO customizing: release strategy, movement types, tolerances, material type, plant and storage location, pricing schema, output determination, MRP parameters, account determination (with the Finance consultant).',
      ph: { n: 'Setting / field', d: 'Value / rule' },
      labels: { sel: 'Scope (plant, storage location, purchasing org, company code)', out: 'Settings to maintain (field = value)', entries: 'Stock and accounting effect expected (movement and posting)', logic: 'Business rules / design', valid: 'Dependencies and checks', auth: 'Authorisation / roles impact', tables: 'T-codes / SPRO path / tables', tests: 'Test scenarios', qa: 'Questions to the user' },
      sel: [P('Plant(s) / storage location(s)', 'Which plants and storage locations get this', 1), P('Purchasing organisation / group', 'For purchasing settings'), P('Company code / valuation area', 'Where the valuation or account determination applies'), P('Material type / material group', 'If the setting depends on it'),
        P('Document type / movement type', 'PO document type or movement type that is affected'), P('Transport type', 'Customizing request (client specific) or workbench')],
      out: [P('Release strategy', 'Release group, release codes, indicators, characteristic values and prerequisites'), P('Movement type setting', 'New or copied movement type, reason for movement, allowed transactions (OMJJ)'), P('Tolerance', 'Invoice tolerance keys (OMR6), delivery tolerance default'), P('Material type / number range', 'Material type, number range, price control, field selection'),
        P('Plant / storage location', 'New plant or storage location and its assignments'), P('Pricing schema / condition type', 'Calculation schema, condition type, access sequence'), P('Output determination', 'Output type, condition record, print program and form (NACE)'), P('MRP parameter', 'MRP type, lot-sizing procedure, MRP controller, planning settings'),
        P('Account determination entry', 'Transaction key, valuation class, modifier (with the Finance consultant)'), P('Document type / number range', 'PO or PR document type and its number range')],
      entries: [P('Business transaction', 'The event that posts, e.g. goods receipt against a PO, goods issue to a cost centre'), P('Goods receipt (101)', 'Dr stock (BSX), Cr GR/IR (WRX)'), P('Invoice receipt (MIRO)', 'Dr GR/IR (WRX), Cr vendor; price difference to PRD or to stock, as the price control decides'), P('Goods issue to cost centre (201)', 'Dr consumption (GBB-VBR), Cr stock (BSX)'),
        P('Transfer between storage locations (311)', 'Normally no accounting entry inside one plant'), P('Debit', 'Account and transaction key'), P('Credit', 'Account and transaction key'), P('Condition', 'Movement type, valuation class or plant where this entry applies')],
      logic: ['Check whether standard SAP already does it (existing setting, standard report, existing output type) before designing anything new', 'Find a similar existing setting and copy its pattern (for example copy a standard movement type or release strategy)', 'Find the node: SPRO (use the IMG search) or the T-code, for example OMJJ, OMR6, OMS2, OX10, OX09, NACE, OBYC',
        'Release strategy: characteristics and class (class type 032), release group, release codes, indicators, prerequisites and the strategy with its values; test with ME21N and ME29N', 'Decide the scope: one plant or all; client specific or cross-client', 'Plan the order: configuration first, then master data, then testing',
        'Think of other modules that use the same setting: FI (account determination), PP, SD, QM', 'Account determination changes go with the Finance consultant: agree the accounts before you configure', 'Keep a record of the old and new values (snapshot in Files)'],
      valid: ['Plant, storage location, purchasing org and company code assignments are complete (T001W, T001L, T024E)', 'Valuation class, material type and account category reference are in line (T025, T134)', 'Number range exists and has enough free numbers (SNRO)', 'Posting period is open in the test plant', 'Existing open POs, reservations and stock are not affected',
        'POs already in a release path are checked after a release strategy change', 'Effect on reports, PO print and MRP understood'],
      auth: ['New T-code or movement type needs a role change (PFCG)', 'Authorisation objects for plant, purchasing group, movement type and release code (M_BEST_WRK, M_BEST_EKG, M_MSEG_BWA, M_EINK_FRG)', 'Segregation of duties still correct (PO creator and releaser, GR and invoice)', 'Effect on users for old documents'],
      tests: ['Create a test PO or goods movement that uses the new setting', 'Create one that must NOT use it (old behaviour unchanged)', 'Reverse / cancel the document', 'Check the material document (MB03), the accounting document and the stock figure (MMBE)', 'Check the release path, price pick-up, tolerance result or PO print as relevant', 'Test with a user role that the end user really has', 'Check the transport in QAS before moving to production'],
      qa: ['Which plants, storage locations and purchasing organisations?', 'Is there a similar existing setting to copy?', 'Effective from which date or period?', 'Approval from Finance or the purchase head for the accounts, limits or release levels?', 'Effect on existing open POs, reservations and stock?', 'Who will do UAT and with which test cases?'],
      checklistNew: ['Requirement and scope confirmed (plants, purchasing orgs, accounts)', 'Standard SAP option checked', 'Current setting captured (screenshot) where relevant', 'Configuration done in DEV', 'Unit tested in DEV with test documents', 'Transport released to QAS', 'UAT done and user sign-off saved', 'Transport moved to Production', 'First live document checked after the move', 'Solution info filled (T-code, SPRO path, transport)'],
      checklistChange: ['Current setting captured (screenshot / table download) as snapshot', 'Effect on open POs, reservations and stock checked', 'Change made in DEV', 'Unit tested and old behaviour re-tested', 'Transport to QAS and UAT', 'Moved to Production', 'First live document checked', 'Solution info updated'],
      devExtra: [{ k: 'tr_list', l: 'Transport request(s)' }, { k: 'client_dep', l: 'Client specific / cross-client' }, { k: 'rollback', l: 'How to roll back' }]
    },
    master: {
      label: 'Master Data / Mass Upload', icon: '\u{1F5C3}\u{FE0F}',
      intro: 'Create or change master data in bulk (material master, vendor purchasing data, info records, source lists, contracts, scheduling agreements, batches, extension to plant or storage location) from an approved Excel.',
      ph: { n: 'Column / field', d: 'Rule / default' },
      labels: { sel: 'Data scope (what is created or changed)', out: 'Upload template columns', logic: 'Mapping and load method', valid: 'Checks before the upload', auth: 'Authorisation', tables: 'Tools / T-codes / BAPIs', tests: 'Test scenarios', qa: 'Questions to the user' },
      sel: [P('Object', 'Material / vendor purchasing data / info record / source list / contract / scheduling agreement / batch', 1), P('Plant / storage location / purchasing org', 'Scope'), P('Material type / material group', 'Group of materials in the file'), P('Number of records', 'Rough volume'),
        P('Create, extend or change', 'Create new, extend to another plant or storage location, or mass change'), P('Source file', 'Excel received from the user')],
      out: [P('Key field', 'Material number, vendor number, or info record key (material, vendor, purchasing org, plant)'), P('Description', 'Material description (40 characters) and long text'), P('Material type / industry sector', 'Controls the views and fields'), P('Base unit / material group', 'Base unit of measure, material group, division'),
        P('Purchasing data', 'Purchasing group, order unit, purchasing value key, GR processing time'), P('MRP data', 'MRP type, MRP controller, lot size, reorder point, safety stock, procurement type'), P('Storage data', 'Storage location, storage bin, batch management flag'), P('Accounting data', 'Valuation class, price control, price (as agreed with Finance)'),
        P('Vendor data', 'Vendor number, purchasing org, order currency, payment terms, Incoterms'), P('Info record data', 'Net price, price unit, validity dates, conditions, planned delivery time'), P('Status / message', 'Result column filled after the load')],
      logic: ['Choose the tool: standard function (MM01 / MM02, mass change with MM17 or MASS, MMSC for storage locations), LSMW, recording (SHDB), BAPI, or the migration cockpit in S/4HANA', 'Prefer a standard tool over a recording when one exists', 'Define the mapping: Excel column, SAP field, rule',
        'Convert values: leading zeros (material and vendor numbers), units of measure, dates, decimals, upper case', 'Material extension: create the views the material needs (basic data, purchasing, MRP, storage, accounting); the accounting view needs the valuation class and price as agreed with Finance', 'Load a small file first (3 to 5 rows) in DEV / QAS',
        'Capture the message of every row and keep the error list', 'Check number ranges: external or internal, and enough free numbers (MMNR for materials)', 'Keep the loaded file and the result log in the task folder'],
      valid: ['Mandatory columns are not empty', 'No duplicate keys, and no duplicate materials (same description, different number)', 'Material type, material group, base unit and plant exist in SAP', 'Valuation class and price control are right for the material type', 'Vendor exists and is not blocked for the purchasing organisation', 'Text length limits respected (material description is 40 characters)', 'Plant and storage location combination exists (T001L)'],
      auth: ['Create / change authorisation for the object (material master M_MATE_WRK and M_MATE_MAR, vendor purchasing data M_LFM1_EKO)', 'S_GUI for file upload', 'Creator and approver are different people (as agreed with the user)'],
      tests: ['3 to 5 row test file', 'A row with an error in the middle', 'Leading zeros, unit of measure and decimal format', 'Object already exists', 'Full file volume', 'Check created objects in MM03 / ME13 / ME03 and the vendor display (MK03 in ECC, BP in S/4HANA)', 'Create a test PO with the loaded data'],
      qa: ['Final approved Excel, and who approved it?', 'Create new, extend or change existing, and which fields?', 'Which plants, storage locations and purchasing organisations?', 'Numbering: given by the user or by SAP?', 'Valuation class, price control and MRP defaults to use (with Finance and Planning)?', 'Who verifies after the load?'],
      checklistNew: ['Approved Excel received', 'Mapping and defaults agreed', 'Test file prepared', 'Loaded in DEV / QAS and checked', 'Authorisation and approvals confirmed', 'Full load in Production', 'Result log checked and errors fixed', 'Test PO or goods movement done with the loaded data (where relevant)', 'Loaded data verified with the user', 'Files saved in the task folder'],
      checklistChange: ['Current data downloaded as snapshot (SE16N / report)', 'Change file approved', 'Test load', 'Production load', 'Result log and before / after comparison checked'],
      devExtra: [{ k: 'tool', l: 'Tool used (LSMW / BAPI / mass change)' }, { k: 'template', l: 'Template file name' }, { k: 'records', l: 'Records loaded' }]
    },
    report: {
      label: 'Report / MIS / Analysis', icon: '\u{1F4CA}',
      intro: 'A stock, purchasing or MIS report the user needs: stock ageing, slow and non-moving, pending PR / PO, GR/IR ageing, consumption, ABC, vendor performance, reservations. First check standard reports, variants and layouts; if nothing fits, raise it as a Functional Spec to ABAP.',
      ph: { n: 'Item', d: 'Rule / note' },
      labels: { sel: 'Selection criteria', out: 'Output columns / layout', logic: 'Calculations / rules', valid: 'Checks', auth: 'Authorisation', tables: 'Standard report / T-code / tables', tests: 'Test scenarios', qa: 'Questions to the user' },
      sel: [P('Plant', 'Mandatory in most reports', 1), P('Storage location', 'One or all'), P('Material / material type / material group', 'Number, type or group'), P('Vendor', 'Vendor or vendor group'), P('Purchasing organisation / group', 'Org unit'), P('Document date / delivery date', 'Range'),
        P('Movement type', 'For consumption and movement reports'), P('Special stock', 'Batch, consignment, subcontracting or project stock'), P('Key date', 'As-on date for stock and ageing', 1), P('Layout / variant', 'Saved layout')],
      out: [P('Material / description', 'Number and text'), P('Plant / storage location', 'Where the stock is'), P('Stock quantity and value', 'Unrestricted, quality inspection, blocked, in transit; value at the valuation price'), P('Last movement date', 'Last GR or GI date, used for slow and non-moving'),
        P('Ageing bucket', '0-30, 31-60, 61-90, 90+ days (buckets as agreed with the user)'), P('Open quantity / value', 'PR or PO quantity not yet received or invoiced'), P('Consumption', 'Issue quantity per month or period'), P('Vendor / PO number / item', 'For drill-down'),
        P('Delivery date and delay', 'Planned against actual receipt date'), P('Reservation / requirement', 'Reserved quantity, requirement date, cost centre or order'), P('Unit / currency', 'Base unit and local currency'), P('Remarks', 'Text from the PO or material document')],
      logic: ['Check the standard reports first (MB52, MMBE, MB51, MB5B, MB5L, ME2N, ME2M, ME2L, ME5A, MC46, MD04) and whether a variant or layout is enough', 'Define the data source: current stock (MARD, MBEW, MCHB), material documents (MKPF and MSEG; MATDOC in S/4HANA), PO tables (EKKO, EKPO, EKET, EKBE)',
        'Stock ageing and slow-moving: from the last movement date, or from the receipt date by batch? Confirm the day limits with the user', 'Pending PR / PO: open quantity = ordered quantity less received quantity; decide how to treat delivery completed and deleted items',
        'GR/IR ageing: goods received but not invoiced, aged from the GR posting date (MB5S, EKBE)', 'Consumption: decide which movement types count (for example goods issue to cost centre and to order, less their reversals) and confirm with the user', 'Special stock (consignment, subcontracting, project) sits in separate tables: decide whether to include it',
        'Reconcile the report total with the stock value in Finance (MB5L) before handing it over', 'Saved variant, layout and Excel download for the user', 'If standard cannot do it: write a Functional Spec to ABAP with a sample output'],
      valid: ['Stock quantity and value agree with MMBE / MB52 and the stock accounts (MB5L)', 'Reversed (cancelled) documents handled so nothing is counted twice', 'Delivery completed and deleted PO items treated as agreed', 'Base unit and order unit conversion is right', 'User sees only the plants and purchasing organisations allowed'],
      auth: ['M_MSEG_WWA - plant for goods movements and stock', 'M_BEST_WRK - plant for purchasing documents', 'M_BEST_EKO - purchasing organisation', 'S_TCODE'],
      tests: ['Compare the stock total with MMBE or MB52 and with the stock accounts (MB5L)', 'Compare 3 materials with MB51 (movement history)', 'Compare 3 POs with ME2N / ME23N', 'Material with no movement', 'Reversed documents and returns', 'Batch managed and special stock materials', 'Download to Excel and open it', 'User with limited plant authorisation'],
      qa: ['Who uses it and how often (daily, weekly, month-end)?', 'Which plants, storage locations and material types?', 'Why does a standard report not work, what is missing?', 'Sample output in Excel?', 'Ageing and slow-moving: which date and which day limits?', 'Should it be mailed or run as a background job?', 'Who must or must not see the data?'],
      checklistNew: ['Requirement and sample output understood', 'Standard reports and variants checked', 'Solution chosen (variant / layout / query / spec to ABAP)', 'Report built or spec written', 'Tested against stock figures (MMBE / MB5L) or the PO list', 'User walkthrough and feedback', 'Variant, layout and user guide shared', 'Solution info filled (T-code, variant, layout)'],
      checklistChange: ['Current variant / layout saved as snapshot', 'Change made', 'Compared with the old output', 'User confirmed', 'Solution info updated'],
      devExtra: [{ k: 'variant', l: 'Variant name' }, { k: 'layout', l: 'Layout name' }, { k: 'user_guide', l: 'User guide file' }]
    },
    fs: {
      label: 'Functional Spec (to ABAP)', icon: '\u{1F4DD}',
      intro: 'Standard SAP cannot do it (custom report, enhancement, user exit or BAdI, print form, workflow): you write the functional specification, the ABAP developer builds it, you test and take UAT.',
      ph: { n: 'Field / item', d: 'Rule / source' },
      labels: { sel: 'Trigger / selection screen', out: 'Output / expected behaviour', entries: 'Stock and accounting effect (if a posting is involved)', logic: 'Business logic / calculation rules', valid: 'Validations and messages', auth: 'Authorisation', tables: 'Tables / standard objects involved', tests: 'Functional test scenarios', qa: 'Questions to the user and developer' },
      sel: [P('Object type', 'Report / print form / enhancement (user exit or BAdI) / interface / validation / workflow', 1), P('Where it acts', 'T-code and event, e.g. on save of ME21N, at goods receipt in MIGO, on release of a PO, at MIRO posting'), P('Selection screen fields', 'Fields with F4 help and mandatory flags'),
        P('Plant / purchasing org condition', 'When the logic applies'), P('Document type / movement type condition', 'PO document type or movement type that triggers it'), P('Users / roles', 'Who is affected')],
      out: [P('Output fields', 'Column list with the source field'), P('Behaviour', 'Block / warn / default a value / create a document / send a mail'), P('Layout / print format', 'Sample output or form layout (PO print, GR slip, label)'), P('Download / mail', 'Excel, PDF, e-mail'), P('Messages', 'Text of errors and warnings')],
      entries: [P('Posting triggered', 'Movement type or Dr / Cr accounts, and the amount logic'), P('Stock effect', 'Quantity and value change, stock type (unrestricted, blocked, quality inspection)'), P('Reversal logic', 'What happens on cancellation or return'), P('Reference / text', 'Header text and reference fields on the material or accounting document')],
      logic: ['First confirm that standard SAP (configuration, release strategy, output determination, standard report) cannot do it', 'Give the exact rule with example numbers (input, expected output)', 'Name the standard tables and fields used as the source (for example EKKO, EKPO, EKET, EKBE, MKPF, MSEG, MARC, MBEW, EINA, EORD, LFA1)',
        'Say what must happen in edge cases: zero, negative, reversed or cancelled document, return, partial receipt, foreign currency, closed period', 'For an enhancement: name the transaction and the exact step (PO save, GR post, invoice post, release); the developer finds the exit or BAdI', 'Give the expected volume of documents (performance)',
        'Say what must be configurable (switch by plant or purchasing org) instead of hard coded', 'For a print form: give the layout, the output type and the print program used today', 'For a workflow: give the steps, the approvers and what happens on reject or no reply'],
      valid: ['Mandatory fields and exact message texts', 'Should it also apply to uploads / interfaces / background postings?', 'Authority checks needed', 'Behaviour in QAS with copies of real data'],
      auth: ['Authorisation object and roles for the new T-code', 'Plant and purchasing organisation level check', 'Who can run it in production'],
      tests: ['Each business rule: one positive and one negative case', 'Partial receipt, return and reversal', 'Foreign currency and a different unit of measure', 'Large volume', 'User without authorisation', 'Stock figure and accounting document checked after the posting', 'Order: developer unit test, your functional test, then user UAT'],
      qa: ['Exact rule with 2 or 3 numeric examples?', 'Who is the ABAP developer and by when is the technical design?', 'Sample output / paper format / Excel?', 'Which plants and purchasing organisations?', 'Should it also apply to uploads and interfaces?', 'Is a standard / configuration alternative possible (cost versus benefit)?', 'Who signs off the spec?'],
      checklistNew: ['Requirement understood and standard option checked', 'Functional spec written with examples', 'Spec shared and discussed with the ABAP developer', 'Technical design reviewed', 'Development done and unit tested by the developer', 'Functional test in QAS', 'UAT and user sign-off', 'Transport moved to Production', 'First live use checked', 'Solution info filled (program, T-code, spec file)'],
      checklistChange: ['Existing object and its spec / code reference found', 'Change spec written', 'Spec shared with the ABAP developer', 'Regression scenarios listed', 'Tested in QAS', 'UAT sign-off', 'Moved to Production', 'Solution info updated'],
      devExtra: [{ k: 'abap_dev', l: 'ABAP developer' }, { k: 'abap_ref', l: 'ABAP ticket / program / enhancement name' }, { k: 'fs_file', l: 'Spec file name' }]
    },
    inventory: {
      label: 'Physical Inventory / Stock Audit', icon: '\u{1F4E6}',
      intro: 'Physical inventory or stock audit: PI documents, count entry, difference posting, cycle counting, special stock, batch and stock reconciliation. Agree the cut-off with Stores before the count starts.',
      ph: { n: 'Material / storage location', d: 'Count / note' },
      labels: { sel: 'Scope (plant, storage location, materials, count date)', out: 'Deliverables / outputs', entries: 'Stock and accounting effect (difference posting)', logic: 'Count and posting steps', valid: 'Reconciliation checks', auth: 'Authorisation', tables: 'T-codes / reports used', tests: 'Check results', qa: 'Questions to Stores and Finance' },
      sel: [P('Plant / storage location(s)', 'Where the count is done', 1), P('Physical inventory procedure', 'Annual (periodic) count, cycle counting or inventory sampling', 1), P('Material selection', 'All materials, a material type or group, or the cycle counting indicator'), P('Stock type / special stock', 'Unrestricted, quality inspection, blocked; batch, consignment, subcontracting'),
        P('Count date and posting date', 'Date of the count and the date used for the difference posting'), P('Freeze book inventory', 'Freeze the book quantity or block goods movements during the count (yes or no)'), P('Counting teams', 'Who counts and who checks')],
      out: [P('PI documents', 'Created and printed count sheets (MI01, MI21)'), P('Count entry', 'Counted quantity entered for each item (MI04)'), P('Difference list', 'Book quantity against counted quantity, with value (MI20)'), P('Recount list', 'Items with large differences that need a recount (limit as agreed with the user and Finance)'),
        P('Posted differences', 'Gain (701) and loss (702) posted, with accounting documents'), P('Stock audit report', 'Items counted, differences, value, reasons and approvals'), P('Open points list', 'Items not counted, blocked items, items under investigation')],
      entries: [P('Difference gain (701)', 'Dr stock (BSX), Cr inventory difference (GBB-INV)'), P('Difference loss (702)', 'Dr inventory difference (GBB-INV), Cr stock (BSX)'), P('While the count is open', 'No entry; the book quantity is frozen or movements are blocked'), P('Batch or special stock difference', 'Same movement types, posted against the batch or the special stock'),
        P('Scrap after the audit', 'Scrapping (551): Dr scrapping expense (GBB-VNG), Cr stock; approval as agreed with Finance')],
      logic: ['Choose the procedure: annual count with PI documents, cycle counting (MICN, with the cycle counting indicator and ABC analysis in MIBC), or inventory sampling', 'Create the PI documents (MI01) and decide the posting block and the freeze of the book quantity before the count', 'Print the count sheets (MI21)',
        'Enter the counts (MI04); mark zero stock where the bin is empty', 'Check the difference list (MI20); investigate large differences first: unposted GR or GI, wrong storage location, wrong unit, stock in another plant', 'Recount where the difference is large (MI11) and enter the new count',
        'Post the differences (MI07) with the approval agreed with the user and Finance; the posting date and period must be open', 'Special stock: count consignment and subcontracting stock under the correct special stock indicator; vendor stock and own stock must not be mixed', 'Batch managed items are counted per batch',
        'Keep all count sheets, the difference list and the approvals'],
      valid: ['Every PI document is counted and posted, or deleted; none left open', 'Stock after posting equals the count (MMBE / MB52)', 'Goods movements between the count and the posting are explained', 'Posted difference value reconciles with the inventory difference account (MB5L, Finance)', 'Batch and special stock quantities match the count', 'Negative stock and zero stock items are reviewed'],
      auth: ['Who can create PI documents, enter counts and post differences (different people where the user wants control)', 'Physical inventory authorisation objects (M_ISEG_*) and plant check (M_MSEG_WWA)', 'Approval for difference posting as agreed with Finance'],
      tests: ['Create a PI document, enter a count with a difference, post it, check the stock', 'Zero stock count', 'Batch managed item and special stock item', 'Recount flow', 'Goods movement posted during the count', 'Material document (MB03) and accounting document of the difference checked', 'User role with limited plant access'],
      qa: ['Which plants, storage locations and material groups are counted, and on which dates?', 'Annual count, cycle counting or sampling?', 'Should stock movements stop during the count?', 'Which differences need approval, and from whom?', 'Who posts the differences?', 'How are scrap and non-moving items handled?', 'Any special stock (batch, consignment, subcontracting) to cover?'],
      checklistNew: ['Scope, count dates and procedure agreed', 'Cut-off for goods movements agreed with Stores and Purchase', 'Open GR, GI and transfers cleared before the count', 'PI documents created and count sheets printed', 'Counts entered', 'Difference list reviewed and large differences recounted', 'Differences approved by the user / Finance', 'Differences posted and accounting documents checked', 'Stock re-checked after posting (MMBE / MB52)', 'Count sheets, difference list and approvals saved in the task folder'],
      checklistChange: ['Current PI settings captured and open PI documents listed (MI22 or table IKPF)', 'Change agreed (procedure, indicator, tolerance)', 'Tested with a sample PI document', 'Applied in the next count', 'Result compared with the previous count'],
      devExtra: [{ k: 'counted_on', l: 'Count date' }, { k: 'posted_on', l: 'Differences posted on' }, { k: 'diff_value', l: 'Net difference value' }, { k: 'approved_by', l: 'Differences approved by' }]
    },
    periodend: {
      label: 'Month-end / Year-end Activity', icon: '\u{1F4C5}',
      intro: 'MM month-end and year-end work: MM period close, GR/IR review, open PR / PO clean-up, accruals input to Finance, stock and valuation checks, material ledger prerequisites. Set it to repeat and the next one is created for you.',
      ph: { n: 'Item', d: 'Note' },
      labels: { sel: 'Scope (plant, company code, period)', out: 'Deliverables / outputs', entries: 'Stock and accounting effect (period-end postings)', logic: 'Sequence and cut-off rules', valid: 'Reconciliation checks', auth: 'Authorisation / period control', tables: 'T-codes / reports used', tests: 'Check results', qa: 'Questions to Stores, Purchase and Finance' },
      sel: [P('Plant(s) / company code(s)', 'Scope', 1), P('Fiscal year / period', 'Period being closed', 1), P('Cut-off date', 'Last date for goods receipts, goods issues, transfers and invoices'), P('Open MM period', 'Period that is open now for goods movements (table MARV)'), P('Material ledger', 'Active or not, and who runs the closing (Finance)')],
      out: [P('MM period closed', 'MM period moved to the next period (MMPV)'), P('GR/IR list', 'GR/IR balances (MB5S) with reasons, given to Finance as input for accruals'), P('Open PR / PO list', 'Open and old items with the decision: keep, close or delete'), P('Stock and valuation reconciliation', 'Stock value (MB5L) agreed with the stock accounts'),
        P('Slow, non-moving and negative stock list', 'For Stores and Finance review'), P('Open points list', 'What is carried to the next month')],
      entries: [P('GR/IR accrual (Finance posts)', 'Goods received, invoice not received: the MM list is the input; accounts as agreed with Finance'), P('GR/IR clearing (MR11)', 'Clears old GR/IR balances to the account set up in account determination; only items agreed with Finance'), P('Price change (MR21)', 'Revaluation of stock when the price changes (transaction key UMB); only as agreed with Finance'),
        P('Consignment settlement (MRKO)', 'Clears the consignment liability against the vendor'), P('Evaluated receipt settlement (MRRL)', 'Invoice created from the goods receipt: Dr GR/IR, Cr vendor'), P('Inventory difference posting', 'From physical inventory: stock against the inventory difference account'), P('Scrapping (551)', 'Dr scrapping expense, Cr stock')],
      logic: ['Sequence: finish open goods movements (GR, GI, transfers), run settlement programs where used (MRRL, MRKO), post and release invoices, review GR/IR (MB5S) and give it to Finance, clean up open PR / PO, make price changes agreed with Finance (MR21), check stock value (MB5L), then close the MM period (MMPV)',
        'Cut-off: agree the last date for goods receipts, goods issues, transfers and invoices with Stores, Purchase and Accounts Payable', 'Goods received after the cut-off go to the next period; check the posting date used', 'Where a program has a test run, use it first, then check the log',
        'Open PR / PO clean-up: list old open items (ME2N, ME5A), ask Purchase and the users, then set delivery completed or the deletion indicator; do not close items with a partial receipt without checking', 'Give GR/IR items to Finance by reason: GR done and invoice pending, invoice done and GR pending, price difference, old items',
        'Material ledger (if active): complete all MM postings, invoices and price changes first; the closing run (CKMLCP) belongs to Finance; confirm the order with MMPV together with Finance', 'Year-end: finish the physical inventory and post the differences before the close; late postings to the previous period only with approval (MMRV)', 'Write down every manual posting with its reason'],
      valid: ['GR/IR balance is explained item by item (MB5S)', 'Stock value (MB5L) equals the inventory accounts in Finance', 'No negative stock left unexplained', 'No parked or blocked invoices left that should be posted (MIR6, MRBR)', 'No stuck goods movements; stock in transit explained', 'Consignment and subcontracting stock agree with the vendor quantities (MBLB, ME2O)', 'Open PO and PR list reviewed; old items closed', 'MM period and Finance period are as agreed'],
      auth: ['Who can run MMPV and MMRV (restricted to the MM lead and Finance)', 'Posting to the previous period needs approval', 'MR11, MR21, MRRL and MRKO are limited to the people who run them'],
      tests: ['MM period moved to the correct month (MMPV result or table MARV)', 'Goods receipt in the closed period is blocked or goes to the right period (test it)', 'Stock value before and after the activity (MB5L)', 'GR/IR balance before and after', 'Compare consumption and stock value with last month for large differences'],
      qa: ['Cut-off date and time for Stores, Purchase and Accounts Payable?', 'Is the previous period closed already?', 'Any old GR/IR or open PO items to be cleared this month?', 'Is the material ledger active, and who runs the closing?', 'Who signs off the stock value reconciliation?', 'Any change in scope (new plant, new storage location, new material type)?'],
      checklistNew: ['Cut-off date agreed with Stores, Purchase and Accounts Payable', 'Open goods movements cleared (stuck GR, pending transfers, stock in transit)', 'Settlement programs run where used (MRRL, MRKO)', 'Parked and blocked invoices cleaned up (MIR6, MRBR)', 'GR/IR reviewed by reason (MB5S) and the list given to Finance', 'Open PR and PO clean-up done (ME2N, ME5A)', 'Price changes done as agreed with Finance (MR21)',
        'Stock value checked against the stock accounts (MB5L)', 'Negative stock and slow / non-moving list reviewed', 'Material ledger prerequisites confirmed with Finance (if active)', 'MM period closed (MMPV)', 'Result and open points shared with Finance'],
      checklistChange: ['Change in the closing process agreed with Finance', 'Updated checklist shared with the team', 'Tested in QAS or on a copy period', 'Applied this period', 'Result compared with the previous month'],
      devExtra: [{ k: 'closed_on', l: 'MM period closed on' }, { k: 'recon_signoff', l: 'Stock reconciliation signed off by' }]
    },
    auth: {
      label: 'Authorisation / Role', icon: '\u{1F511}',
      intro: 'New or changed access for MM users: purchasing, goods movement, invoice verification and master data T-codes; plant, storage location, purchasing organisation and release authorisation; segregation of duties.',
      ph: { n: 'Item', d: 'Value' },
      labels: { sel: 'Who needs access (user / role / department)', out: 'Access required', logic: 'Design and segregation of duties', valid: 'Approvals', auth: 'Authorisation objects', tables: 'T-codes / roles', tests: 'Tests', qa: 'Questions' },
      sel: [P('User ID(s)', 'Users who need the access', 1), P('Role / position', 'Job role, e.g. purchase officer, store keeper'), P('Plants / storage locations', 'Org levels to open'), P('Purchasing organisation / group', 'Org levels to open'), P('Reason / approval', 'Who approved (manager, process owner)'), P('Valid from - to', 'For temporary access')],
      out: [P('T-codes', 'Transactions needed'), P('Activity', 'Display / create / change / release / reverse'), P('Org levels', 'Plant, storage location, purchasing org, purchasing group'), P('Document types / movement types', 'PO document types and movement types allowed'), P('Release codes', 'Release group and code for PO or PR release')],
      logic: ['Check if an existing role already fits (copy it, do not invent a new one)', 'Check segregation of duties: creating a PO, receiving the goods and posting the invoice should not all sit with one user; creating a vendor and releasing a PO should not sit with one user (as agreed with the user)',
        'Use SU53 (last failed check) and the authorisation trace (ST01) to find the missing value', 'Release authority is given by release group and code (M_EINK_FRG) and must match the release strategy', 'The role change is done by Basis / security: give them the exact T-codes and values', 'Temporary access needs an end date and must be removed', 'Keep the approval mail'],
      valid: ['Approval from manager / process owner', 'Segregation of duties check passed', 'Tested in QAS first if it is a new role', 'End date set for temporary access'],
      auth: ['M_BEST_BSA (PO document type)', 'M_BEST_EKG (purchasing group)', 'M_BEST_EKO (purchasing organisation)', 'M_BEST_WRK (plant)', 'M_EINK_FRG (release group and code)', 'M_MSEG_BWA (movement type)', 'M_MSEG_WWA (plant for goods movements)', 'M_MSEG_LGO (storage location)', 'M_MATE_WRK (material master, plant)', 'M_MATE_MAR (material master, material type)', 'M_RECH_WRK and M_RECH_EKG (invoice verification, plant and purchasing group)', 'M_LFM1_EKO (vendor purchasing data)'],
      tests: ['User can do the intended task', 'User cannot do what is not allowed', 'SU53 shows no missing authorisation after the change', 'Release works only for the intended release code', 'Reports and F4 help show only the allowed plants'],
      qa: ['Exact T-codes and what the user does in each?', 'Which plants, storage locations, purchasing organisations and purchasing groups?', 'Which release codes, if any?', 'Who approved, and is it temporary?', 'Is there an existing user to copy the access from?', 'Does it create a segregation of duties conflict?'],
      checklistNew: ['Request and approval received', 'Existing role checked', 'Exact T-codes and org values listed', 'Request sent to Basis / security', 'Tested by the user (SU53 clean)', 'Segregation of duties checked', 'End date noted for temporary access', 'Approval mail saved'],
      checklistChange: ['Current roles captured (SU01 screenshot)', 'Change requested with exact values', 'Tested by the user', 'Approval mail saved'],
      devExtra: [{ k: 'role', l: 'Role name' }, { k: 'ticket', l: 'Basis / security ticket no.' }]
    },
    other: {
      label: 'Other (training, document, project, data migration)', icon: '\u{1F4CC}',
      intro: 'Anything else: user training, process document, knowledge transfer, data migration, project work, meetings with users or vendors.',
      ph: { n: 'Item', d: 'Detail' },
      labels: { sel: 'Inputs', out: 'Deliverables', logic: 'Approach', valid: 'Checks', auth: 'Authorisation', tables: 'Objects', tests: 'Verification', qa: 'Questions' },
      sel: [], out: [P('Deliverable', 'What is to be handed over')], logic: ['Approach / steps'], valid: [], auth: [],
      tests: ['Verified with the requester'], qa: ['What exactly is expected and by when?', 'Who will check the result?'],
      checklistNew: ['Requirement understood', 'Work done', 'Verified with the requester', 'Documented'],
      checklistChange: ['Snapshot taken', 'Work done', 'Verified', 'Documented'], devExtra: []
    }
  };

  /* ------------------------------------------------------------------
     2. ESTIMATION - base hours by type and complexity (one consultant)
     ------------------------------------------------------------------ */
  const estimate = {
    base: {
      issue: { simple: 1, medium: 3, complex: 8 }, config: { simple: 2, medium: 6, complex: 16 }, master: { simple: 3, medium: 8, complex: 18 }, report: { simple: 3, medium: 8, complex: 20 },
      fs: { simple: 6, medium: 14, complex: 30 }, inventory: { simple: 3, medium: 8, complex: 20 }, periodend: { simple: 3, medium: 8, complex: 20 }, auth: { simple: 0.5, medium: 1.5, complex: 4 }, other: { simple: 2, medium: 5, complex: 12 }
    },
    changeFactor: 0.7,      // change to something that exists = 70 % of a fresh setup (snapshot and regression test included)
    factors: [
      { k: 'multi_plant', l: 'Multiple plants or storage locations', h: 2, types: null },
      { k: 'volume', l: 'Large volume (hundreds of records, materials or documents)', h: 2, types: ['master', 'inventory', 'report', 'periodend', 'issue'] },
      { k: 'nosample', l: 'Requirement unclear / no sample or example', h: 3, types: null },
      { k: 'othermod', l: 'Touches other modules (FI, PP, SD, QM)', h: 2, types: ['config', 'issue', 'fs', 'inventory'] },
      { k: 'abap', l: 'ABAP developer dependency (design review, follow-ups)', h: 3, types: ['fs', 'report'] },
      { k: 'recon', l: 'Reconciliation needed (stock value, GR/IR, count)', h: 2, types: ['report', 'periodend', 'inventory', 'issue'] },
      { k: 'excel', l: 'Excel template and mapping', h: 1.5, types: ['master', 'report', 'inventory'] },
      { k: 'upload', l: 'Test and production upload with error correction rounds', h: 2, types: ['master'] },
      { k: 'approval', l: 'Approval or release-strategy testing (several levels, several users)', h: 2, types: ['config', 'issue', 'fs', 'auth'] },
      { k: 'uat', l: 'UAT sessions with the users', h: 2, types: ['config', 'fs', 'report', 'master', 'inventory'] },
      { k: 'training', l: 'Vendor or user training', h: 1.5, types: ['config', 'fs', 'master', 'inventory', 'other'] },
      { k: 'foreign', l: 'Import or foreign currency scenarios', h: 2, types: ['config', 'report', 'issue', 'fs'] },
      { k: 'transport', l: 'Transport coordination with Basis (QAS and PRD)', h: 1, types: ['config', 'fs', 'auth'] },
      { k: 'doc', l: 'User guide / documentation', h: 1.5, types: null }
    ],
    uatBuffer: 0.15,       // +15 % for UAT fixes, transport and follow-ups
    hint: 'Estimate = base hours x complexity (x 0.7 for a change) + selected extras + 15 % buffer for UAT, transports and follow-ups. It covers your time only; add ABAP developer time and user or vendor waiting time separately in your plan.'
  };

  /* ------------------------------------------------------------------
     3. BEFORE-CHANGE SNAPSHOT - what to save before changing something
     ------------------------------------------------------------------ */
  const backupGuide = {
    issue: ['Screenshot of the error message and of the wrong document (ME23N, MB03 or MIR4)', 'Stock and movement history of the material exported to Excel (MB51, MMBE or MB52 > export)', 'Screenshot of the current configuration node or master data (material master, info record), before you change anything', 'List of the other POs, material documents or materials with the same problem'],
    config: ['Screenshot of the current setting in the SPRO / T-code screen (release strategy, movement type, tolerance, pricing schema), before editing', 'Table download: SE16N on the customizing table (for example T001L, T001W, T156, T161, T134, T024, T024E) > export to Excel', 'Release strategy: screenshot of the strategy with its classification values and release prerequisites',
      'Note the transport request used for this change', 'Sample material or PO documented before and after the change', 'Optional: compare DEV with QAS (SCMP) before you transport'],
    master: ['Download of the existing master data (SE16N or report) before the change, for example MARA, MARC, MARD, LFM1, EINA, EINE, EORD', 'The original Excel and the corrected Excel', 'Screenshot of one sample material, info record or vendor (MM03 / ME13 / ME03)'],
    report: ['Screenshot of the existing output with its variant and layout', 'Save the current layout under a clear name (Settings > Layout > Save)', 'Screenshot of the variant list', 'Export of the current output to Excel for comparison'],
    fs: ['Existing spec and program name', 'Screenshot or PDF of the current output or behaviour (PO print, message, posting)', 'Ask the ABAP developer to note the program version before the change'],
    inventory: ['Stock list with value before the count (MB52 or MMBE export) and the list of open PI documents (MI22 or table IKPF)', 'Screenshot of the PI settings: posting block, freeze of book inventory, difference limits', 'Export of the difference list (MI20) before you post', 'Screenshot of one sample material with its stock and value before posting'],
    periodend: ['Stock value list (MB5L) and GR/IR list (MB5S) before the activity (download to Excel)', 'Open PO and PR lists (ME2N, ME5A) before the clean-up', 'Screenshot of the MM period status (MMPV screen or table MARV) before changing it', 'Run the activity in test mode first where SAP offers it'],
    auth: ['Screenshot of the current roles of the user (SU01)', 'Copy of the role authorisation values before the change (PFCG)'],
    other: ['Anything that will be changed: export or screenshot before the change']
  };

  /* ------------------------------------------------------------------
     4. UAT POINTS / AFTER-MOVE CHECKS / SOLUTION REGISTER FIELDS
     ------------------------------------------------------------------ */
  const qualityIdeas = ['Wrong account or posting in the accounting document', 'Wrong stock quantity or value after GR / GI', 'Price not picked or wrong price in the PO', 'Release strategy not triggered or wrong approver', 'PO print or output layout to be changed', 'Reversal / cancellation not working',
    'Tolerance message comes (or does not come) as expected', 'Authorisation missing for a user', 'Add a column / field in the report', 'Layout or variant to be changed', 'Another plant / storage location to be covered', 'User guide needs more detail', 'Message text to be improved'];
  const afterMoveChecks = ['Transport imported in Production without errors (STMS log, return code)', 'First real PO, goods receipt or goods issue posted and checked (ME23N, MB03)', 'Accounting document and accounts match the QAS result', 'Stock figures are right after the posting (MMBE / MB52)', 'Release path, price pick-up and PO print checked on a real PO (where relevant)',
    'Users can post with their roles (no SU53 message)', 'Old open POs, reservations and stock are not affected', 'User informed and trained; user guide shared', 'Finance team told (if accounts or valuation changed)', 'No complaint or short dump after 3 days'];
  const devRegisterFields = [
    { k: 'tcode', l: 'T-code / SPRO node', ph: 'OMJJ, OMR6, NACE, ME21N' }, { k: 'obj_name', l: 'What was configured / object name', ph: 'Release strategy for plant 1000' }, { k: 'package', l: 'SPRO / IMG path', ph: 'SPRO > Materials Management > Purchasing > ...' },
    { k: 'scope', l: 'Scope (plant, storage location, purchasing org)', ph: 'Plant 1000, purchasing org 1000' }, { k: 'version', l: 'CR / ticket no. or version', ph: 'CR-114' }, { k: 'developed_on', l: 'Done on', type: 'date' },
    { k: 'tables', l: 'Tables / settings / objects', ph: 'T161, T16FS, EINA' }, { k: 'signoff_by', l: 'UAT sign-off by', ph: 'Name of the user' }, { k: 'signoff_on', l: 'Sign-off date', type: 'date' },
    { k: 'what_done', l: 'What was configured / changed', area: 1 }, { k: 'how_to_use', l: 'How to use (steps for the user)', area: 1 }, { k: 'notes', l: 'Other notes for the future (things to remember)', area: 1 }
  ];

  /* Departments filled in automatically when you pick a module (change them freely) */
  const moduleDept = { 'MM-PUR': 'Purchase', 'MM-CON': 'Purchase', 'MM-IM': 'Stores', 'MM-IV': 'Accounts Payable', 'MM-MD': 'Stores', 'MM-SRV': 'Purchase', 'MM-SUB': 'Purchase', 'MM-IMP': 'Purchase', 'MM-MRP': 'Planning', 'INT': 'Finance / Production', 'GEN': 'IT' };

  /* Sections shown in the SAP reference window, in this order */
  const moduleSections = [['tcodes', 'T-codes (daily work)'], ['spro', 'Configuration (SPRO / IMG)'], ['reports', 'Standard reports'], ['tables', 'Tables'], ['tools', 'BAPIs / upload tools'], ['auth', 'Authorisation objects'], ['notes', 'Good to know']];

  window.KB = {
    P: P, T: T,
    types: types, modules: {}, templates: [], estimate: estimate, backupGuide: backupGuide, qualityIdeas: qualityIdeas, afterMoveChecks: afterMoveChecks, devRegisterFields: devRegisterFields,
    moduleDept: moduleDept, moduleSections: moduleSections,
    /* Add the people who give you work. They appear as suggestions in "Requested by". Example: people: ['Name One', 'Name Two'] */
    people: [],
    /* Optional: fill "Requested by" automatically when a module is picked. Example: { 'MM-PUR': 'Name One' } */
    moduleOwners: {},
    /* Who you wait for most often (shown in the "Waiting for" list) */
    waitingOn: ['User / Stores', 'Purchase team', 'Vendor', 'ABAP developer', 'Basis / transport', 'Finance consultant', 'Approval', 'PP / SD / QM consultant', 'Accounts Payable', 'Other'],
    envs: ['DEV', 'QAS', 'PRD']
  };
})();
