/* Ready templates for the "New task" screen (type, module, summary, scope, settings, logic, hours).
   Item format:  'Name:Description'  or  'Name:Description:1'  (the last 1 means mandatory).
   Do not use a colon inside a name or a description. hours = estimate for your own time.
   repeat: 'monthly' makes the task create the next one when you finish it.
   Settings, T-codes and limits here are reminders. Confirm them on your own system. */
(function () {
  const tpl = (module, type, title, summary, extra) => Object.assign({ module: module, type: type, title: title, summary: summary, complexity: 'medium' }, extra || {});
  const L = window.KB.templates;
  const add = (...x) => x.forEach((t) => L.push(t));

  /* ---------- MM-PUR ---------- */
  add(
    tpl('MM-PUR', 'issue', 'PO release strategy not triggered or wrong approver', 'A purchase order is saved without a release, or goes to the wrong release code.', {
      complexity: 'medium', hours: 3,
      sel: ['PO number:PO that shows the problem:1', 'Document type:PO document type', 'Purchasing group and plant:Values on the PO', 'Net order value:Total value on the PO'],
      out: ['Expected:Release strategy and release codes the PO should get', 'Actual:No release, or a different strategy'],
      entries: ['Posting effect:No accounting posting at PO level, only the release status changes'],
      tables: ['ME23N', 'CL24N', 'CT04', 'CL02', 'CDHDR / CDPOS'],
      logic: ['Open the release strategy in CL24N and compare each characteristic value with the PO header values', 'Check the value range of the characteristic for the net order value in CT04', 'Check if the document was changed after the release and the reset indicator of the strategy', 'Check the release codes and the prerequisites between the codes'],
      valid: ['No other strategy of the same group also matches the PO', 'Change is moved through DEV, QAS and PRD with the classification objects']
    }),
    tpl('MM-PUR', 'issue', 'Wrong price or no price picked in the purchase order', 'PO shows zero price, an old price or a price that does not match the contract or info record.', {
      complexity: 'medium', hours: 3,
      sel: ['PO number and item:Where the price is wrong:1', 'Material and vendor:Material and vendor of the item:1', 'Purchasing org and plant:Org levels of the PO', 'PO date:Date used for the validity check'],
      out: ['Expected price:Price the user expects with its source', 'Actual price:Price in the PO'],
      tables: ['ME13', 'MEK3', 'ME33K', 'EINA / EINE', 'KONP'],
      logic: ['Check the source of the price in the PO item condition tab (info record, contract or manual)', 'Check the validity dates and the scale of the condition record in ME13 or MEK3', 'Check the calculation schema of the vendor and the purchasing org', 'Check if the item has a contract with a different price or a blocked condition'],
      valid: ['Price is picked for a new PO after the correction', 'Old POs are not changed by mistake']
    }),
    tpl('MM-PUR', 'issue', 'PO print or mail not coming (output determination)', 'Purchase order output is not created, is stuck in processing or goes to the wrong printer or e-mail.', {
      complexity: 'simple', hours: 2,
      sel: ['PO number:PO concerned:1', 'Output type:Output type of the PO, for example NEU', 'Vendor and purchasing org:Condition record keys', 'Printer or mail address:Where it should go'],
      out: ['Expected:Output printed or mailed', 'Actual:Not created, error status or wrong destination'],
      tables: ['ME9F', 'NACE', 'NAST', 'SP01', 'SOST'],
      logic: ['Open the message screen of the PO and read the status and the processing log', 'Check the condition record for the output type in NACE (purchasing org and vendor keys)', 'Check the printer in SP01 or the mail in SOST', 'Reprocess the output after the correction'],
      valid: ['Output works for a new PO of the same kind']
    }),
    tpl('MM-PUR', 'issue', 'Requisition not available for PO creation', 'User cannot find a purchase requisition when creating the PO, or the PR is not converted from MRP.', {
      complexity: 'simple', hours: 2,
      sel: ['PR number and item:Requisition concerned:1', 'Plant and purchasing group:Values of the PR', 'Created by:MRP or manual'],
      out: ['Expected:PR is available in the document overview of ME21N', 'Actual:PR is not found or is blocked'],
      tables: ['ME53N', 'ME5A', 'EBAN', 'ME58'],
      logic: ['Check the release status of the PR (release strategy) in ME53N', 'Check the processing status, closed or already ordered, and the deletion flag', 'Check the source determination, fixed vendor and the assignment in ME58', 'Check the selection variant and the purchasing group of the user']
    }),
    tpl('MM-PUR', 'config', 'Release strategy for purchase orders - new or changed value limit', 'New release codes or a new value range for PO approval by purchasing group and value.', {
      complexity: 'complex', hours: 10,
      sel: ['Plant and purchasing org:Where the strategy applies:1', 'Document types:PO document types covered', 'Transport:Customizing request and the request for the classification objects'],
      out: ['Release group:Group and class type 032 as per your system', 'Release codes:Codes and the name of the approver role', 'Release indicators:Status after each code', 'Release strategy:Prerequisites and release statuses', 'Classification:Characteristic values by value range, purchasing group and plant'],
      entries: ['Posting effect:No stock or accounting posting. The PO is not sent for delivery until the release is complete'],
      tables: ['CT04', 'CL02', 'CL24N', 'SPRO Purchase Order Release Procedure', 'SU21'],
      logic: ['Approval limits come from the business, get them in writing with the approvers', 'Use ranges that do not overlap so that only one strategy matches', 'Check that the release code is given to the authorisation role of the approver (M_EINK_FRG)', 'Decide what happens on a change after release'],
      valid: ['Test a PO below, at and above each limit', 'Test a change in value after release'],
      tests: ['PO below the lowest limit needs no release', 'PO between two limits goes to the right approver', 'PO changed to a higher value resets the release', 'Approver without the code cannot release'],
      qa: ['What are the approval limits and approvers for each value range?', 'Should a value change after release reset the release?', 'Which document types and plants are covered?']
    }),
    tpl('MM-PUR', 'config', 'Release strategy for purchase requisitions', 'Approval of purchase requisitions by value, plant, material group or account assignment.', {
      complexity: 'complex', hours: 10,
      sel: ['Plant and purchasing group:Where the strategy applies:1', 'Requisition document types:PR types covered', 'Transport:Customizing request'],
      out: ['Release group and codes:For the PR release procedure with classification', 'Characteristics:Value, plant, material group, account assignment category', 'Release strategy:Prerequisites and statuses', 'Release indicator:Effect on conversion to PO'],
      tables: ['CT04', 'CL02', 'CL24N', 'SPRO Purchase Requisition Release Procedure', 'ME54N'],
      logic: ['Decide if the release is at item level or at the overall requisition', 'Characteristics come from the communication structure of the PR (CEBAN)', 'Test PR creation from MRP and manual creation, both must follow the same rule'],
      tests: ['PR below the limit is released automatically or needs no release', 'PR above the limit goes to the right approver', 'Released PR can be converted to a PO']
    }),
    tpl('MM-PUR', 'config', 'PO document type and number range', 'New PO document type with its own number range and field selection.', {
      complexity: 'simple', hours: 3,
      sel: ['Purchasing org and plant:Where the type is used:1', 'Transport:Customizing request'],
      out: ['Document type:Key and description, copied from NB or FO', 'Number range:Internal interval and the external interval if needed', 'Item category:Item categories allowed', 'Field selection:Fields shown and mandatory', 'Release procedure:Release group if needed'],
      tables: ['SPRO Define Document Types', 'SPRO Number Range Maintenance', 'T161', 'T161T'],
      logic: ['Copy the standard type NB and change only what is needed', 'Check that the new type is allowed in the release strategy classification', 'Maintain the number range interval for the new type and its group']
    }),
    tpl('MM-PUR', 'config', 'New purchasing group or purchasing organisation assignment', 'Create a purchasing group for a buyer team, or assign a purchasing organisation to a plant.', {
      complexity: 'simple', hours: 3,
      sel: ['Purchasing group or org:Key and description:1', 'Plant:Plants to assign', 'Buyers:Users who work with the group'],
      out: ['Purchasing group:Key, description and contact data', 'Assignment:Purchasing org to plant (OX17) and purchasing org to company code', 'Authorisation:M_BEST_EKG and M_BEST_EKO values for the buyers'],
      tables: ['OME4', 'OX01', 'OX17', 'T024', 'T024E'],
      logic: ['Check if the purchasing org assignment is plant specific or cross plant', 'Existing release strategies and reports must include the new group', 'Add the group to the roles of the buyers']
    }),
    tpl('MM-PUR', 'report', 'Open PO and pending delivery report', 'Open purchase orders with delivery date, pending quantity, delay and the buyer.', {
      complexity: 'simple', hours: 5,
      sel: ['Plant:Plant:1', 'Purchasing group:Buyer team', 'Vendor:Vendor or vendor group', 'Delivery date:From and to'],
      out: ['PO number and item:Document and line', 'Vendor:Number and name', 'Material and description:Item', 'Ordered quantity:As on the PO', 'Delivered quantity:Goods receipts so far', 'Pending quantity:Open quantity', 'Delivery date and delay days:Days past the date', 'Buyer:Purchasing group'],
      tables: ['ME2N', 'ME2L', 'ME2M', 'EKKO', 'EKPO', 'EKET', 'EKBE'],
      logic: ['Start with ME2N and a saved variant for open items only', 'Pending quantity is the scheduled quantity minus the quantity received, check against the delivery completed indicator', 'Spec to ABAP only if a combined view with the vendor confirmation and the delay bucket is needed'],
      tests: ['A PO with a part delivery shows the right pending quantity', 'A PO closed with delivery completed does not show']
    }),
    tpl('MM-PUR', 'report', 'Purchase requisition ageing - not yet converted to PO', 'Open PRs by age and by purchasing group so that the buyers can follow up.', {
      complexity: 'simple', hours: 4,
      sel: ['Plant:Plant:1', 'Purchasing group:Buyer team', 'PR date:From and to', 'Release status:Released or not'],
      out: ['PR number and item:Requisition', 'Material and description:Item', 'Quantity:Requested quantity', 'Requirement date:Date wanted', 'Age in days:Days since the PR date', 'Buyer:Purchasing group'],
      tables: ['ME5A', 'ME5K', 'EBAN'],
      logic: ['Open items are those with an open quantity in EBAN and no deletion flag', 'Age bucket limits as agreed with Purchase'],
      tests: ['PR already converted to a PO does not show']
    }),
    tpl('MM-PUR', 'report', 'Vendor wise purchase value and price comparison', 'Value of POs by vendor and material with the last price against the previous price.', {
      complexity: 'medium', hours: 8,
      sel: ['Purchasing org:Org unit:1', 'Period:PO date from and to:1', 'Vendor and material group:Optional filters'],
      out: ['Vendor:Number and name', 'Material:Number and description', 'PO value:Net value of the period', 'Last price and previous price:From the PO history', 'Difference percent:Change in price'],
      tables: ['ME2L', 'ME81N', 'ME1P', 'EKKO', 'EKPO'],
      logic: ['ME1P gives the PO price history for a material, check it before asking for a new report', 'Convert foreign currency values with the rate on the PO or a rate agreed with Finance', 'Spec to ABAP when a single sheet with the comparison is needed']
    }),
    tpl('MM-PUR', 'fs', 'PO print form with company format', 'Change the PO print layout, terms and conditions, tax details and signature.', {
      complexity: 'complex', hours: 20,
      sel: ['Output type:PO output type and the form now used:1', 'Purchasing org and plant:Where the new layout applies', 'Print program and form:Standard program and the copied form'],
      out: ['Header:Company name, address, tax number, PO number, date, vendor and delivery address', 'Item table:Item, material, description, quantity, unit, price, delivery date, tax', 'Totals:Net value, tax, total and amount in words', 'Terms:Payment terms, delivery terms, special text from the PO header text', 'Signature and approval:Approver name from the release code', 'Download:PDF to the buyer by mail'],
      tables: ['NACE', 'SE71', 'SMARTFORMS', 'NAST', 'EKKO', 'EKPO', 'LFA1'],
      logic: ['Copy the standard form and the print program, never change the standard object', 'Texts come from PO header texts and item texts, list the text IDs needed', 'Output type and condition record are changed in NACE to call the new program'],
      valid: ['Form prints on the plant printer with the right page size', 'Item table continues on the second page with the header repeated'],
      tests: ['PO with 1 item', 'PO with more than 20 items', 'PO in foreign currency', 'Reprint of an old PO'],
      qa: ['Which fields must be on the form?', 'Which terms and conditions text is used per plant?', 'Is a signature or approver name needed?']
    }),
    tpl('MM-PUR', 'fs', 'Check on PO save (mandatory field or block)', 'Enhancement that checks a value when the PO is saved and gives an error or a warning.', {
      complexity: 'medium', hours: 10,
      sel: ['Where it acts:Save of the PO in ME21N or ME22N:1', 'Plant and document type condition:When the rule applies:1', 'Trigger:New PO, change or both'],
      out: ['Behaviour:Block the save, warn, or fill a default value', 'Message:Text of the error or warning and the message class', 'Exception:Users or document types that are free from the check'],
      tables: ['ME21N', 'SE18', 'EKKO', 'EKPO'],
      logic: ['The standard BAdI for the PO header and item checks is the place for this, the ABAP developer chooses the exact BAdI', 'Give the rule as a table, field and value, not as a sentence', 'Keep the exception list in a Z table so that it can be changed without a transport'],
      valid: ['Upload and BAPI created POs are checked in the same way or excluded on purpose'],
      tests: ['PO that meets the rule saves', 'PO that breaks the rule gets the message', 'PO of an excluded document type saves'],
      qa: ['What exactly must be blocked and when?', 'Should the check also run for POs created by program?']
    })
  );

  /* ---------- MM-CON ---------- */
  add(
    tpl('MM-CON', 'issue', 'Contract price not picked in the PO', 'PO created with reference to a contract shows another price, or the contract is not offered in the source list.', {
      complexity: 'medium', hours: 3,
      sel: ['Contract number and item:Contract concerned:1', 'PO number:PO created or being created', 'Material and plant:Item and plant', 'PO date:Date used for validity'],
      out: ['Expected:Price and source from the contract', 'Actual:Price from the info record or manual'],
      tables: ['ME33K', 'ME3N', 'ME13', 'ME01', 'EORD'],
      logic: ['Check the validity dates and the target value or quantity of the contract', 'Check the source list for the plant, a blocked or fixed source decides the pick', 'Check the plant and purchasing org on the contract item', 'Check the info record and the contract release status'],
      valid: ['New PO picks the contract price']
    }),
    tpl('MM-CON', 'config', 'Scheduling agreement release creation profile and release strategy', 'Set how releases are created and approved for scheduling agreements.', {
      complexity: 'medium', hours: 8,
      sel: ['Plant and purchasing org:Where it applies:1', 'Document type:Scheduling agreement type, for example LP', 'Transport:Customizing request'],
      out: ['Release creation profile:Creation period, firm and trade off zone, time unit', 'Release documentation:Level of release documentation kept', 'Output:Output type for the release to the vendor', 'Release strategy:If agreement releases need approval'],
      tables: ['ME84', 'ME38', 'ME9L', 'NACE', 'SPRO Scheduling Agreement'],
      logic: ['Releases are created by ME84 or by the MRP run, the profile says how far ahead', 'Check the vendor and the output type before testing', 'Check the forecast delivery schedule and JIT schedule if both are used'],
      tests: ['Release is created for the next period', 'Output reaches the vendor', 'Change of the schedule updates the release']
    }),
    tpl('MM-CON', 'master', 'Source list and quota arrangement upload', 'Create or change source list entries and quotas for many materials from Excel.', {
      complexity: 'medium', hours: 8,
      sel: ['Plant:Plant:1', 'Number of materials:Volume of the file', 'Create or change:Action', 'Source file:Excel from Purchase'],
      out: ['Material:Number', 'Plant:Plant', 'Vendor:Vendor number', 'Valid from and to:Dates', 'Fixed or blocked:Source indicator', 'Quota:Quota percent, if the quota arrangement is loaded', 'MRP indicator:Use in MRP'],
      tables: ['ME01', 'ME05', 'MEQ1', 'EORD', 'EQUK'],
      logic: ['For source lists a standard generate run (ME05) may be enough, check it first', 'For quotas the vendors must be on the source list with the same dates', 'Test 5 records in QAS and check in ME03 and MEQ3 before the full load'],
      valid: ['Dates do not overlap for the same material and vendor', 'Vendors exist for the purchasing org of the plant', 'Total quota of a material is 100 percent']
    }),
    tpl('MM-CON', 'report', 'Contract utilisation - target against released value', 'Contracts with the target value or quantity, the value released by POs and the balance.', {
      complexity: 'medium', hours: 7,
      sel: ['Purchasing org:Org unit:1', 'Vendor:Optional', 'Validity date:Contracts valid on the date', 'Document type:Quantity or value contract'],
      out: ['Contract and item:Number and line', 'Vendor:Number and name', 'Material or short text:Item', 'Target quantity or value:On the contract', 'Released:Quantity or value used by POs', 'Balance:Target less released', 'Valid to:End date'],
      tables: ['ME3L', 'ME3N', 'ME80FN', 'EKKO', 'EKPO', 'EKAB'],
      logic: ['Released quantity or value is the sum of the POs created with reference to the contract', 'Check ME3N and the contract release documentation first'],
      tests: ['Contract with 2 release POs shows the sum', 'Expired contract is listed only if asked']
    })
  );

  /* ---------- MM-IM ---------- */
  add(
    tpl('MM-IM', 'issue', 'Stock mismatch - system stock against physical or between reports', 'Stock in MMBE, MB52 or MB5B does not match, or the store says the physical stock is different.', {
      complexity: 'medium', hours: 4,
      sel: ['Material and plant:Item with the difference:1', 'Storage location and batch:Where the stock is held', 'Date:Date of the comparison', 'Stock type:Unrestricted, quality, blocked, in transit, special stock'],
      out: ['System stock:Quantity in MMBE and MB52', 'Physical stock:Quantity counted by the store', 'Difference:Quantity and value'],
      entries: ['Posted entry:Movement types posted for the material in the period (MB51)', 'Correct entry:Movement that should have been posted', 'Stock effect:Quantity and value before and after the correction'],
      tables: ['MMBE', 'MB52', 'MB5B', 'MB51', 'MARD', 'MCHB', 'MSEG'],
      logic: ['Compare the stock types, stock in transit and quality inspection stock are not in unrestricted stock', 'Read all material documents of the material in MB51, look for missing or double postings and wrong storage locations', 'Check goods receipts and returns, cancelled documents and transfer postings', 'If the store count is right, correct with a physical inventory difference, not with a manual change'],
      valid: ['MMBE, MB52 and MB5L agree after the correction', 'Correction is approved by Stores and Finance']
    }),
    tpl('MM-IM', 'issue', 'Goods receipt cannot be posted (period, tolerance or PO status)', 'MIGO gives an error such as posting period closed, delivery tolerance exceeded or PO item already delivered.', {
      complexity: 'simple', hours: 2,
      sel: ['PO number and item:Document in MIGO:1', 'Posting date:Date entered', 'Plant and storage location:Receiving location', 'Message text and number:Exact message from the screen'],
      out: ['Expected:Goods receipt is posted', 'Actual:Error message'],
      tables: ['MIGO', 'MMPV', 'ME23N', 'MSEG'],
      logic: ['Read the message and its long text, then use the matching check', 'Period closed means the MM period in MMPV and the FI period, ask Finance before opening', 'Over delivery means the tolerance of the PO item (unlimited delivery, over delivery percent)', 'Delivery completed or deleted item means the PO item has to be changed by the buyer'],
      valid: ['Goods receipt posts for the real case', 'No period is opened without written approval of Finance']
    }),
    tpl('MM-IM', 'issue', 'Material document cannot be cancelled (reversal error)', 'MBST or MIGO reversal fails because stock is not enough, the document is old, or a later invoice exists.', {
      complexity: 'simple', hours: 2,
      sel: ['Material document and year:Document to cancel:1', 'Movement type:Original movement', 'Posting date of the reversal:Date wanted'],
      out: ['Expected:Document is reversed', 'Actual:Error message'],
      entries: ['Original entry:Movement and accounts posted by the document', 'Reversal entry:Opposite posting with the reversal movement type'],
      tables: ['MB03', 'MBST', 'MIGO', 'MB51', 'T156'],
      logic: ['Check the stock of the item, the reversal needs the same stock to be there', 'If an invoice is posted against the goods receipt, cancel the invoice first (MR8M)', 'Check the period of the original document and the posting date of the reversal', 'Check the reversal movement type in the movement type settings'],
      valid: ['Stock and GR/IR are correct after the reversal']
    }),
    tpl('MM-IM', 'config', 'New movement type (copy of a standard one)', 'Create a movement type for a special goods issue or transfer with its own account posting.', {
      complexity: 'complex', hours: 10,
      sel: ['Based on movement type:Standard type to copy:1', 'Plants and storage locations:Where it will be used:1', 'Transport:Customizing request'],
      out: ['Movement type key:New key in the customer range and description', 'Field selection:Fields shown, required and hidden', 'Reason for movement:Reasons needed and their text', 'Reversal movement type:Type used to cancel', 'Account grouping:Value in the movement type for the offsetting account', 'Allowed transactions:MIGO, MB1A style or goods issue entry only'],
      entries: ['Posting effect:Dr consumption or expense account (key GBB with its modifier), Cr stock (BSX), as agreed with the Finance consultant'],
      tables: ['OMJJ', 'OMWB', 'OBYC', 'T156', 'T156T'],
      logic: ['Copy the standard type with the control in OMJJ, then change only what is needed', 'Create the account determination for the new type in OBYC with the Finance consultant', 'Simulate the account with OMWB before the first test posting', 'Add the movement type to the authorisation of the users (M_MSEG_BWA)'],
      valid: ['Reversal movement type is maintained', 'Account determination exists for each valuation class used'],
      tests: ['Post the movement and check the FI document', 'Reverse the movement', 'Post with a user that has no authorisation for the type'],
      qa: ['Which account should the movement post to and who approves it?', 'Which users and plants may use it?', 'Is a reason for movement needed?']
    }),
    tpl('MM-IM', 'config', 'New storage location and its settings', 'Create a storage location in a plant with the material views needed.', {
      complexity: 'simple', hours: 3,
      sel: ['Plant:Plant:1', 'Storage location:Key and description:1', 'Transport:Customizing request'],
      out: ['Storage location:Key and description in the plant', 'Address and partner:If needed for the store', 'Material views:Storage location views for the materials (MMSC)', 'Authorisation:M_MSEG_LGO value for the store users', 'MRP area:Only if separate planning is needed'],
      tables: ['OX09', 'MMSC', 'T001L', 'MARD'],
      logic: ['Storage location is created for a plant in OX09, no stock is posted yet', 'Extend the materials with MMSC or with a mass load before the first goods receipt', 'Add the location to the roles of the store users'],
      tests: ['Goods receipt to the new location', 'Transfer posting from another location', 'User without authorisation cannot post']
    }),
    tpl('MM-IM', 'config', 'Delivery tolerance and under or over delivery settings', 'Change the allowed over and under delivery for a vendor, material or PO item.', {
      complexity: 'simple', hours: 2,
      sel: ['Plant and purchasing org:Scope:1', 'Material or vendor:Where it is set', 'Transport:If a default is changed in customizing'],
      out: ['Over delivery tolerance:Percent as approved', 'Under delivery tolerance:Percent as approved', 'Unlimited delivery:Indicator, if approved', 'Default source:Material master, info record or the PO item'],
      tables: ['ME12', 'ME22N', 'MM02', 'EINE', 'EKPO'],
      logic: ['The tolerance on the PO item decides at goods receipt, it is copied from the info record or the vendor data', 'A change in master data does not change POs that exist, change the items if needed', 'Get the percent in writing from Purchase and Stores']
    }),
    tpl('MM-IM', 'master', 'Opening stock upload (initial stock entry)', 'Load opening stock quantity and value of materials with movement type 561 before go live.', {
      complexity: 'complex', hours: 14,
      sel: ['Plant and storage location:Where stock is loaded:1', 'Batch managed:Yes or no', 'Posting date:Date of the opening stock:1', 'Source file:Excel signed by Stores and Finance'],
      out: ['Material:Number', 'Plant and storage location:Location', 'Quantity and unit:Quantity in the base unit', 'Batch:Batch number, if batch managed', 'Value:Value for the material as agreed with Finance', 'Stock type:Unrestricted, quality or blocked'],
      entries: ['Initial stock entry (561):Dr stock (BSX), Cr inventory initial entry account (key GBB with the modifier for initial entry)'],
      tables: ['MIGO', 'BAPI_GOODSMVT_CREATE', 'MB51', 'MB52', 'MB5L'],
      logic: ['Load the material master, batches and the price before the stock', 'Price control and the price decide the stock value, set them first', 'Load 5 materials in QAS, check in MB52 and in the FI document, then load the rest', 'Reconcile the total value with the Finance sheet, MB5L and the GL'],
      valid: ['Materials exist in the plant and storage location', 'Quantity unit matches the base unit', 'Total value agrees with the approved sheet'],
      qa: ['Which date and period are used for the opening stock?', 'Who signs the opening quantity and the value?']
    }),
    tpl('MM-IM', 'report', 'Stock ageing - slow moving and non moving material', 'Stock quantity and value by days since the last movement, for Stores and Finance review.', {
      complexity: 'medium', hours: 8,
      sel: ['Plant:Plant:1', 'Storage location:One or all', 'Material type and group:Filters', 'As on date:Date of the report:1'],
      out: ['Material and description:Item', 'Stock quantity and value:Quantity and value at the valuation price', 'Last goods receipt date:Date', 'Last goods issue date:Date', 'Ageing bucket:0-30, 31-60, 61-90 and 90+ days or as agreed', 'Category:Slow or non moving as per the agreed rule'],
      tables: ['MC46', 'MC50', 'MB5B', 'MB52', 'MARD', 'MSEG'],
      logic: ['Start with the standard analysis for slow and non moving items (MC46 and MC50), they need the stock statistics to be updated', 'If the statistics are not active, the last movement date is taken from the material documents in a Z report', 'Agree the day limits and the movement types that count as consumption with Stores', 'Value uses the valuation price in the material master'],
      tests: ['Material with a recent issue is not in the old bucket', 'Value total agrees with MB5L for the plant'],
      qa: ['After how many days is an item slow moving and non moving?', 'Which movement types count as consumption?']
    }),
    tpl('MM-IM', 'report', 'Stock statement on a past date (storage location wise)', 'Opening and closing stock quantity and value for a period, by plant and storage location.', {
      complexity: 'simple', hours: 4,
      sel: ['Plant:Plant:1', 'Storage location:One or all', 'Date or period:Closing date or a period:1', 'Material type and group:Filters'],
      out: ['Material and description:Item', 'Opening stock:Quantity and value', 'Receipts:Quantity and value', 'Issues:Quantity and value', 'Closing stock:Quantity and value'],
      tables: ['MB5B', 'MB52', 'MB5L', 'MARDH', 'MBEWH'],
      logic: ['MB5B gives the stock on a posting date, use the same plant and date as the GL balance', 'For a past month the stock history tables are used, they depend on the period closing', 'Closing value should agree with the stock account balance, check with MB5L']
    }),
    tpl('MM-IM', 'report', 'Material consumption report', 'Consumption quantity and value by material, cost centre or production order for a period.', {
      complexity: 'medium', hours: 6,
      sel: ['Plant:Plant:1', 'Period:Posting date from and to:1', 'Movement types:For example 201 and 261, with the reversals', 'Cost centre or order:Optional'],
      out: ['Material and description:Item', 'Quantity and value consumed:Net of the reversals', 'Cost centre or order:Account assignment', 'Month:Month of the posting'],
      tables: ['MB51', 'MCBA', 'MSEG', 'COOIS'],
      logic: ['MB51 with the movement types gives the base list, reversals are netted by the reversal movement types', 'Use the standard consumption analysis of the stock statistics only if they are active', 'Agree with Stores which movement types are consumption']
    }),
    tpl('MM-IM', 'fs', 'Material issue slip or goods receipt slip print', 'Print form for goods issue and goods receipt documents with the store sign off.', {
      complexity: 'medium', hours: 14,
      sel: ['Output trigger:On posting in MIGO or by reprint:1', 'Movement types:Which movements print', 'Plant:Where the form is used'],
      out: ['Header:Slip number, date, plant, storage location, department', 'Item table:Material, description, quantity, unit, batch, cost centre or order', 'Signatures:Issued by, received by, approved by', 'Print count:Original or copy text'],
      tables: ['MB90', 'NACE', 'MIGO', 'MKPF', 'MSEG', 'SMARTFORMS'],
      logic: ['Output type for the goods movement is set in NACE for the application of material documents', 'Use a copy of the standard form and program', 'Give the movement types and plants for which the slip is created'],
      tests: ['Goods issue to a cost centre', 'Goods issue to a production order', 'Reprint of the slip with the copy text']
    }),
    tpl('MM-IM', 'fs', 'Check on goods movement (block or warning in MIGO)', 'Enhancement that checks a rule when a goods movement is posted.', {
      complexity: 'medium', hours: 10,
      sel: ['Where it acts:Posting of a material document in MIGO:1', 'Movement types:Types the rule applies to:1', 'Plant and storage location:Condition'],
      out: ['Behaviour:Block, warn or default a field', 'Message:Text and type', 'Exception:Users and plants outside the rule'],
      entries: ['Posting effect:The check runs before the posting. No stock or accounting entry is created when the document is blocked'],
      tables: ['MIGO', 'SE18', 'MKPF', 'MSEG'],
      logic: ['The goods movement BAdI of inventory management is used for the check, the ABAP developer chooses the exact one', 'Write the rule as fields and values', 'Keep the exception list in a Z table', 'Check postings from BAPI and from background jobs'],
      tests: ['Allowed movement posts', 'Blocked movement gets the message', 'Excluded user posts']
    })
  );

  /* ---------- Physical inventory ---------- */
  add(
    tpl('MM-IM', 'inventory', 'Annual physical inventory - count and difference posting', 'Yearly stock count for a plant with count sheets, recount, difference list and posting.', {
      complexity: 'complex', hours: 24, repeat: 'yearly',
      sel: ['Plant and storage locations:Count scope:1', 'Count date:Date of the physical count:1', 'Posting date:Date for the differences:1', 'Materials:All or a selection', 'Special stock:Batch, subcontractor, consignment'],
      out: ['PI documents:Created and printed (MI01)', 'Count entry:Counted quantity entered (MI04)', 'Difference list:Book against count with value (MI20)', 'Recount list:Items above the agreed limit', 'Posted differences:Gain 701 and loss 702 with the FI documents', 'Report to Finance:Net value of the differences'],
      entries: ['Difference gain (701):Dr stock (BSX), Cr inventory difference (GBB with the INV modifier)', 'Difference loss (702):Dr inventory difference (GBB with the INV modifier), Cr stock (BSX)'],
      tables: ['MI01', 'MI04', 'MI20', 'MI07', 'MI03', 'MIDO', 'IKPF / ISEG'],
      logic: ['Create the PI documents with the posting block so that no movement happens during the count', 'Enter the counts, check the difference list and ask for a recount of the large items', 'Post the differences only after the sign off of Stores and Finance', 'Check the tolerance group of the user who posts the differences', 'Keep the count sheets and the sign off in Files'],
      valid: ['All PI documents are counted or deleted', 'Difference value is approved before the posting', 'Stock in MB52 equals the count after the posting'],
      tests: ['Count equal to the book', 'Count above the book', 'Count below the book', 'Recount after a large difference'],
      qa: ['What is the recount limit in quantity and value?', 'Who signs the differences?', 'Which storage locations are in the count?']
    }),
    tpl('MM-IM', 'inventory', 'Cycle counting setup with ABC indicator', 'Set up cycle counting so that fast moving items are counted more often.', {
      complexity: 'medium', hours: 10,
      sel: ['Plant:Plant:1', 'Cycle counting indicators:A, B and C and their counting interval:1', 'Materials:Selection for the first run'],
      out: ['Cycle counting indicator:Set in the plant data of the materials', 'Counting intervals:Days between the counts for each indicator', 'ABC analysis:Result of the analysis run (MIBC)', 'Counting documents:Created by the run (MICN)'],
      tables: ['MIBC', 'MICN', 'MI01', 'MM17', 'SPRO Physical Inventory Cycle Counting'],
      logic: ['Run the ABC analysis (MIBC) with the limits agreed with Stores and Finance', 'Set the indicator by mass change on the plant data', 'Create the counting documents for the due items with the run for cycle counting', 'Same posting steps as the annual count follow'],
      tests: ['Material with indicator A is due after its interval', 'Counted material moves the date of the next count']
    })
  );

  /* ---------- MM-IV ---------- */
  add(
    tpl('MM-IV', 'issue', 'Invoice blocked for payment - price, quantity or date variance', 'MIRO posts the invoice but it is blocked and not paid. Find the reason and release it.', {
      complexity: 'simple', hours: 2,
      sel: ['Invoice document and year:Invoice blocked:1', 'PO number and item:Reference of the invoice', 'Vendor:Vendor number', 'Block reason:Price, quantity, date or stochastic'],
      out: ['Expected:Invoice is released and paid', 'Actual:Blocked for payment'],
      tables: ['MRBR', 'MIR4', 'MIR6', 'OMR6'],
      logic: ['Open the invoice in MIR4 and read the block reason in the item', 'Compare the invoice price and quantity with the PO and the goods receipt', 'Within the right tolerance it is the buyer or the accounts payable team that releases it, the release needs authorisation M_RECH_SPG', 'If the price on the PO is wrong, correct the PO or the info record first and release afterwards'],
      valid: ['Release is documented with the approver name', 'Tolerance is changed only with Finance approval']
    }),
    tpl('MM-IV', 'issue', 'Invoice cannot be posted - tax code, GR missing or account error', 'MIRO gives an error such as no goods receipt, tax code not allowed, or account not found.', {
      complexity: 'medium', hours: 3,
      sel: ['PO number and item:Document used in MIRO:1', 'Invoice date and posting date:Dates entered', 'Tax code:Code entered', 'Message text and number:Exact message from the screen'],
      out: ['Expected:Invoice is posted', 'Actual:Error message'],
      entries: ['Posted entry:Entry the invoice should create (Dr GR/IR, Dr tax, Cr vendor)', 'Correct entry:What the user expects'],
      tables: ['MIRO', 'MB5S', 'EKBE', 'OBCD', 'OMWB'],
      logic: ['Check the PO history (EKBE) for goods receipts, an item set as GR based invoice verification needs the receipt first', 'Check the tax code and the tax procedure for the company code with the Tax team', 'For account errors note the transaction key and check OBYC with the Finance consultant', 'Check that the invoice date, the posting date and the period are open'],
      valid: ['Invoice posts and the vendor line item is visible in FBL1N']
    }),
    tpl('MM-IV', 'issue', 'Price difference or exchange difference posted on the invoice', 'MIRO posted an unexpected price difference to the price difference account or to stock.', {
      complexity: 'medium', hours: 4,
      sel: ['Invoice document:Document concerned:1', 'Material and plant:Item', 'Price control:Standard price (S) or moving average (V)'],
      out: ['Expected:Difference to the right account', 'Actual:Difference posted to the other account'],
      entries: ['Standard price material:Difference between invoice and standard price goes to the price difference account (PRD)', 'Moving average material:Difference goes to stock if stock is available, otherwise to PRD'],
      tables: ['MIR4', 'FB03', 'MM03', 'OBYC', 'CKM3N'],
      logic: ['Read the accounting document of the invoice', 'Compare the price control and the stock at the time of the invoice', 'With a moving average price and not enough stock, part of the difference goes to the price difference account', 'Check the account determination for PRD and BSX'],
      valid: ['Finance agrees with the explanation or the correction']
    }),
    tpl('MM-IV', 'config', 'Tolerance limits for invoice verification', 'Change the tolerance keys so that small differences in price or quantity are not blocked.', {
      complexity: 'simple', hours: 3,
      sel: ['Company code:Company code:1', 'Tolerance keys:Keys to change, for example price variance and quantity variance:1', 'Transport:Customizing request'],
      out: ['Lower and upper limit:Percent and absolute value as approved', 'Check limit:Whether the check is active for each key', 'Approval:Finance approval for the limits'],
      tables: ['OMR6', 'MRBR', 'MIRO'],
      logic: ['Tolerance keys are set per company code', 'Percent and value limits are both checked, the system applies the stricter one', 'Get the limits in writing from Finance before the change'],
      tests: ['Invoice inside the limit posts without a block', 'Invoice outside the limit is blocked'],
      qa: ['Which tolerance keys and limits are approved by Finance?']
    }),
    tpl('MM-IV', 'config', 'Evaluated receipt settlement (ERS) setup', 'Automatic invoice posting from goods receipts for selected vendors.', {
      complexity: 'complex', hours: 12,
      sel: ['Plant and purchasing org:Scope:1', 'Vendors:Vendors for ERS:1', 'Transport:Customizing request'],
      out: ['Vendor master:ERS indicator in the purchasing data', 'PO item:ERS indicator and GR based invoice verification', 'Run:Evaluated receipt settlement (MRRL) with a variant', 'Output:Message to the vendor if needed', 'Tax code:Tax code on the PO items'],
      entries: ['ERS invoice:Dr GR/IR, Dr tax, Cr vendor, created by the run'],
      tables: ['MRRL', 'MIR4', 'MIR6', 'ME12', 'MK02'],
      logic: ['The vendor must agree to ERS, the price comes from the PO and not from a vendor invoice', 'Run MRRL in test mode first and review the list', 'Check the payment terms and the tax code on the PO items', 'Schedule the run as a job after the goods receipts are posted'],
      tests: ['Goods receipt of an ERS vendor creates an invoice', 'Second run does not create a second invoice', 'Cancel of the goods receipt before the run']
    }),
    tpl('MM-IV', 'report', 'GR/IR ageing list for Finance', 'Goods received but not invoiced and invoiced but not received, with age and vendor.', {
      complexity: 'medium', hours: 8,
      sel: ['Company code and plant:Scope:1', 'Key date:Date of the list:1', 'Vendor and PO:Optional', 'GR/IR account:Account of the key WRX'],
      out: ['PO and item:Reference', 'Vendor:Number and name', 'Material:Item', 'GR quantity and value:Received', 'Invoice quantity and value:Invoiced', 'Balance:Difference', 'Age in days:Days since the oldest goods receipt'],
      tables: ['MB5S', 'MR11SHOW', 'FBL3N', 'EKBE'],
      logic: ['MB5S gives the balance per PO, start with it', 'Age is counted from the posting date of the oldest open goods receipt or invoice', 'Total of the list should agree with the balance of the GR/IR account', 'Spec to ABAP only for the age bucket and the vendor view']
    })
  );

  /* ---------- MM-MD ---------- */
  add(
    tpl('MM-MD', 'issue', 'Material cannot be created or extended - error message', 'User gets an error in MM01 or MM50 such as a field is required, plant not maintained or number range error.', {
      complexity: 'simple', hours: 2,
      sel: ['T-code:MM01, MM02 or MM50:1', 'Material type and plant:Values entered', 'Message text and number:Exact message from the screen:1', 'User:User who got the error'],
      out: ['Expected:Material is created or extended', 'Actual:Error message'],
      tables: ['OMS9', 'OMS2', 'MMNR', 'OX10', 'MM03'],
      logic: ['Read the message long text, then check the matching setting', 'Required field errors come from the field selection of the material type or the plant (OMS9)', 'Number range errors come from the material type number range (MMNR)', 'Plant or storage location errors mean that the views of the reference material are not allowed for the plant', 'Check the authorisation with SU53 if the message is about a missing authorisation'],
      valid: ['User can create the material after the correction']
    }),
    tpl('MM-MD', 'config', 'New material type with number range and price control', 'Create a material type for a new kind of item with its views, number range and price control.', {
      complexity: 'complex', hours: 12,
      sel: ['Based on material type:Standard type to copy:1', 'Plants and company codes:Where used:1', 'Transport:Customizing request'],
      out: ['Material type:Key and description', 'Views:Views that can be maintained', 'Number range:Internal or external and the interval', 'Price control:Standard price or moving average', 'Quantity and value update:By plant', 'Valuation class:Allowed classes assigned to the type', 'Field selection:Required and hidden fields'],
      entries: ['Posting effect:The valuation class of the material type decides which stock account is used (key BSX), agree it with the Finance consultant'],
      tables: ['OMS2', 'MMNR', 'OMS9', 'T134'],
      logic: ['Copy a standard type and change only what is needed', 'Assign the valuation classes and make the account determination in OBYC with the Finance consultant', 'A material type cannot be changed later when stock exists, take the decision once', 'Add the type to the authorisation M_MATE_MAR of the creating users'],
      tests: ['Create a material of the new type in MM01', 'Post a goods receipt and check the FI document', 'Create a material with the number range'],
      qa: ['Which views and which price control are needed for the new type?', 'Should the material number be internal or external?', 'Which valuation class and account will Finance use?']
    }),
    tpl('MM-MD', 'config', 'Make a field mandatory, optional or hidden in the material master', 'Change the field selection for a material type, plant or transaction.', {
      complexity: 'simple', hours: 3,
      sel: ['Field:Field name or screen label:1', 'Material type and plant:Where it applies:1', 'Status wanted:Required, optional, display only or hidden:1'],
      out: ['Field reference:The field reference group used for the field', 'Setting:Field selection by transaction and by material type, plant or industry sector', 'Transport:Customizing request'],
      tables: ['OMS9', 'MM01', 'MM02'],
      logic: ['Field selection is controlled by several keys, the strictest setting wins', 'Check that existing materials that have no value can still be changed', 'Test the create, change and extend transactions'],
      tests: ['Create without the field fails with the required message', 'Existing material can be changed', 'Hidden field does not show']
    }),
    tpl('MM-MD', 'config', 'New material group', 'Create a material group and use it in the purchasing and reporting settings.', {
      complexity: 'simple', hours: 2,
      sel: ['Material group:Key and description:1', 'Used in:Release strategy, account assignment, reports', 'Transport:Customizing request'],
      out: ['Material group:Key and text', 'Release strategy:Characteristic values updated if the group is used', 'Authorisation:Roles updated if the group is checked'],
      tables: ['OMSF', 'MM02', 'T023', 'CT04'],
      logic: ['A material group is a customizing entry, create it in DEV and move it by transport', 'If a release strategy uses the material group as a characteristic, add the new value to the characteristic in CT04', 'Assign the group to the materials by mass change after the transport']
    }),
    tpl('MM-MD', 'master', 'Material master creation from Excel', 'Create many materials with the views needed from an approved Excel file.', {
      complexity: 'complex', hours: 16,
      sel: ['Material type:Type of the materials:1', 'Plants and storage locations:Extension scope:1', 'Number of materials:Volume of the file', 'Numbering:Internal or from the file', 'Source file:Approved Excel'],
      out: ['Material number:If external', 'Description:Up to 40 characters and the long text', 'Base unit and material group:Basic data', 'Purchasing data:Purchasing group, order unit, GR processing time', 'Plant data:MRP type, MRP controller, lot size, procurement type', 'Storage data:Storage location, storage bin', 'Accounting data:Valuation class, price control, price', 'Tax and classification:Control code and classification if used', 'Quality data:Inspection type, if used'],
      tables: ['BAPI_MATERIAL_SAVEDATA', 'MM01', 'MM03', 'MM60', 'LSMW'],
      logic: ['Valuation class, price control and the price are agreed with the Finance consultant before the load', 'Duplicate check on the description with MM60 before the load', 'Load 5 materials in QAS, check them in MM03 and the change documents, then load the rest', 'Keep the log with the material numbers created and send it to the user'],
      valid: ['Material group, base unit and plant exist', 'No duplicate descriptions', 'Valuation class is allowed for the material type'],
      qa: ['Who approves the Excel before the load?', 'Which views are needed for each material type?']
    }),
    tpl('MM-MD', 'master', 'Extend materials to another plant or storage location', 'Extend existing materials to a new plant or storage location with the views needed.', {
      complexity: 'medium', hours: 8,
      sel: ['From plant:Reference plant:1', 'To plant and storage location:Target:1', 'Materials:List or selection', 'Views:Views to extend'],
      out: ['Material:Number', 'Target plant and storage location:Where it is extended', 'Reference plant:Plant to copy the data from', 'Plant specific values:MRP controller, purchasing group, profit centre, valuation'],
      tables: ['MM50', 'MMSC', 'MM03', 'MARC', 'MARD', 'MBEW'],
      logic: ['Extension copies the data of the reference plant, check the MRP and purchasing values for the new plant', 'Valuation data is created for the valuation area of the plant, the price must be set by Finance', 'Check the profit centre assignment of the new plant with the Finance consultant', 'Test with 3 to 5 materials first'],
      valid: ['Plant is created and assigned to a company code', 'Storage location exists']
    }),
    tpl('MM-MD', 'master', 'Mass change of material master fields', 'Change fields such as purchasing group, MRP controller, lot size or reorder point for many materials.', {
      complexity: 'medium', hours: 6,
      sel: ['Plant:Plant:1', 'Materials:Selection by material type, group or list:1', 'Fields to change:Fields and new values:1', 'Number of materials:Volume'],
      out: ['Material:Number', 'Plant:Plant', 'Field:Field name', 'Old value:Value before the change', 'New value:Value after the change'],
      tables: ['MM17', 'MASS', 'MM02', 'MM04', 'BAPI_MATERIAL_SAVEDATA'],
      logic: ['Download the old values with SE16N before the change and keep the file in Files', 'MM17 or MASS can change the standard fields, the ABAP developer builds a program only if the field is not covered', 'Test with 3 to 5 materials in QAS and check the change documents in MM04', 'Run in PRD in a time when no MRP run is active'],
      valid: ['New values are allowed for the field', 'Before value file is saved'],
      tests: ['Changed material shows the new value in MM03', 'Change document exists in MM04']
    }),
    tpl('MM-MD', 'master', 'Info record upload for vendor and material prices', 'Create or change purchasing info records with prices and conditions from Excel.', {
      complexity: 'medium', hours: 8,
      sel: ['Purchasing org and plant:Scope:1', 'Vendor and materials:From the Excel:1', 'Create or change:Action', 'Number of records:Volume'],
      out: ['Vendor and material:Keys', 'Purchasing org and plant:Info record level', 'Net price and currency:Price per unit', 'Price unit and order unit:Basis of the price', 'Valid from and to:Condition validity', 'Planned delivery time:Days', 'Tolerances:Over and under delivery'],
      tables: ['ME11', 'ME12', 'ME13', 'ME1M', 'EINA', 'EINE'],
      logic: ['Check if an info record already exists for the same keys with ME1M', 'Conditions are created with the validity dates, an earlier price is not overwritten if the period differs', 'Load 5 records in QAS and check in ME13 and in a test PO', 'The ABAP developer uses the standard function module for info records if no BAPI fits'],
      valid: ['Vendor and material exist for the purchasing org', 'Dates do not overlap']
    }),
    tpl('MM-MD', 'report', 'Material master missing data and duplicate check', 'List of materials with blank important fields or similar descriptions, for the master data team.', {
      complexity: 'simple', hours: 5,
      sel: ['Plant:Plant:1', 'Material type:Filter', 'Created on:Date range', 'Fields to check:For example MRP controller, purchasing group, valuation class'],
      out: ['Material and description:Item', 'Plant:Plant', 'Missing field:Field that is blank', 'Created by and on:Creator and date'],
      tables: ['MM60', 'SE16N', 'MARA', 'MARC', 'MBEW'],
      logic: ['Use MM60 or SE16N on the plant data table with a filter on the blank field first', 'Duplicate check is by the description, ask the ABAP developer for a Z list only if it is needed often']
    })
  );

  /* ---------- MM-SRV ---------- */
  add(
    tpl('MM-SRV', 'issue', 'Service entry sheet cannot be saved or accepted', 'Entry sheet gives an error such as the limit is exceeded, the PO is not released, or the account assignment is missing.', {
      complexity: 'medium', hours: 3,
      sel: ['PO number and item:Service PO:1', 'Entry sheet number:If created', 'Message text and number:Exact message from the screen:1', 'User:Who got the error'],
      out: ['Expected:Entry sheet is accepted', 'Actual:Error message'],
      entries: ['Posted entry:Entry created at acceptance of the sheet', 'Correct entry:Expected account assignment (cost centre, order or asset)'],
      tables: ['ML81N', 'ML85', 'ME23N', 'ESSR', 'ESLL'],
      logic: ['Check that the PO is released and that the service item is not blocked or closed', 'Check the value limit and the unplanned services limit on the PO line', 'Check the account assignment on the PO line', 'Check the release status of the entry sheet and the release code of the approver'],
      valid: ['Entry sheet is accepted and the invoice can be posted']
    }),
    tpl('MM-SRV', 'config', 'Service master and entry sheet release procedure', 'Create service master numbers and the approval of entry sheets by value.', {
      complexity: 'complex', hours: 10,
      sel: ['Plant and purchasing org:Scope:1', 'Service categories:Groups of services', 'Transport:Customizing request'],
      out: ['Service master:Number ranges and service categories', 'Material group:Link of the service to a material group', 'Release procedure:Release codes and value ranges for entry sheets', 'Limits:Unplanned services and value limit on the PO'],
      tables: ['AC01', 'AC03', 'ML81N', 'CL24N', 'SPRO External Services Management'],
      logic: ['Entry sheet release works with its own release group and class type', 'Approval limits come from the business, get them in writing', 'Test the entry sheet from creation to the invoice'],
      tests: ['Sheet below the limit is accepted without release', 'Sheet above the limit goes to the approver', 'Invoice against the released sheet']
    }),
    tpl('MM-SRV', 'report', 'Service PO and entry sheet status', 'Service POs with value, entry sheets accepted, invoices posted and balance.', {
      complexity: 'medium', hours: 7,
      sel: ['Plant and purchasing group:Scope:1', 'PO date:Range:1', 'Vendor:Optional', 'Cost centre or order:Optional'],
      out: ['PO and item:Reference', 'Vendor:Number and name', 'Service text:Short text', 'PO value:Value of the item', 'Entry sheet value:Accepted value', 'Invoiced value:Invoice posted', 'Balance:PO value less invoiced'],
      tables: ['ME2N', 'ML85', 'ME80FN', 'MIR6', 'ESSR', 'EKBE'],
      logic: ['Entry sheet value and invoice value are read from the PO history', 'Use ME2N with the history display first', 'Spec to ABAP only for a single list with the balance']
    })
  );

  /* ---------- MM-SUB ---------- */
  add(
    tpl('MM-SUB', 'issue', 'Components not shown in the subcontracting PO', 'Subcontracting PO is created but the components are not copied from the BOM.', {
      complexity: 'medium', hours: 3,
      sel: ['PO number and item:Subcontracting PO:1', 'Finished material and plant:Item and plant:1', 'BOM usage and alternative:Used in the PO'],
      out: ['Expected:Components of the BOM in the PO item', 'Actual:No components or wrong components'],
      tables: ['ME23N', 'CS03', 'CS01', 'MARC', 'EKPO'],
      logic: ['Check the item category L on the PO item', 'Check that a BOM exists for the plant with the usage and the validity date of the PO', 'Check the special procurement key and the BOM selection in the material master', 'Components are created at the time of the PO save, an old PO needs the item to be changed'],
      valid: ['New PO shows the components']
    }),
    tpl('MM-SUB', 'issue', 'Stock at the subcontractor does not match', 'The stock lying with the vendor in the system is different from the vendor statement.', {
      complexity: 'medium', hours: 4,
      sel: ['Vendor:Subcontractor:1', 'Material and plant:Component:1', 'Date:Date of the comparison', 'Vendor statement:Quantity the vendor reports'],
      out: ['System stock:Quantity in MBLB and ME2O', 'Vendor stock:Quantity of the vendor', 'Difference:Quantity and value'],
      entries: ['Component issue (541):Component moves from the plant to the stock at the vendor, no change in value', 'Consumption (543):Posted with the goods receipt of the finished item, Dr consumption, Cr stock at vendor'],
      tables: ['MBLB', 'ME2O', 'MB51', 'MSLB', 'EKBE'],
      logic: ['Compare the issues (541) and the consumption (543) in MB51 for the vendor', 'Check goods receipts of the finished item for the right quantity, the consumption follows the BOM', 'Check scrap and returns from the vendor (542, 544)', 'Correct with the right movement type, agree it with Stores and Finance'],
      valid: ['MBLB and the vendor statement agree after the correction']
    }),
    tpl('MM-SUB', 'report', 'Material lying with subcontractors - ageing', 'Components at each vendor with the quantity, value and days since the issue.', {
      complexity: 'medium', hours: 7,
      sel: ['Plant:Plant:1', 'Vendor:One or all', 'Material:Optional', 'As on date:Date:1'],
      out: ['Vendor:Number and name', 'Material and description:Component', 'Quantity at vendor:Stock', 'Value:At the valuation price', 'Last issue date:Date of the last 541', 'Age in days:Days since the last issue'],
      tables: ['MBLB', 'ME2O', 'MB51', 'MSLB'],
      logic: ['MBLB gives the stock at each vendor, start with it', 'Age is taken from the date of the last issue movement 541 in MB51', 'Spec to ABAP only if the age bucket is needed']
    }),
    tpl('MM-SUB', 'inventory', 'Count of stock at subcontractor and consignment vendors', 'Physical inventory of special stock at the vendor with the confirmation from the vendor.', {
      complexity: 'medium', hours: 12, repeat: 'yearly',
      sel: ['Plant:Plant:1', 'Vendors:Vendors in the scope:1', 'Count date:Date of the vendor confirmation:1', 'Special stock type:Subcontracting or consignment'],
      out: ['Vendor statements:Signed confirmation of the stock at the vendor', 'PI documents:Created for the vendor stock (MI01 with the special stock indicator)', 'Differences:Book against confirmation', 'Posted differences:After approval'],
      entries: ['Difference posting:Same logic as the plant count, Dr or Cr inventory difference (GBB with the INV modifier) against stock at vendor'],
      tables: ['MI01', 'MI04', 'MI07', 'MBLB', 'MKOL'],
      logic: ['Ask each vendor for a signed statement of the stock at a fixed date', 'Create PI documents with the special stock indicator for the vendor', 'Post differences only after Stores and Finance sign off'],
      valid: ['Every vendor statement is received and filed']
    }),
    tpl('MM-SUB', 'periodend', 'Subcontracting cut-off - open POs and stock at vendors', 'Month-end check of components at vendors, open subcontracting POs and goods received but not invoiced.', {
      complexity: 'medium', hours: 6, repeat: 'monthly',
      sel: ['Plant:Plant:1', 'Period:Month being closed:1', 'Cut-off date:Last date for postings'],
      out: ['Stock at vendors:List with the value', 'Open POs:Old POs with the decision', 'Job work charge pending:Receipts without invoice', 'Open points:Carried to next month'],
      entries: ['Job work charge accrual (Finance posts):Goods received, charge not invoiced, the MM list is the input'],
      tables: ['MBLB', 'ME2O', 'MB5S', 'ME2N'],
      logic: ['Check all issues and receipts are posted up to the cut-off date', 'Send the list of old items to Stores and Purchase for a decision', 'Give the GR/IR list for the vendors to Finance']
    })
  );

  /* ---------- MM-IMP ---------- */
  add(
    tpl('MM-IMP', 'config', 'Planned delivery costs for imports - freight, insurance and duty conditions', 'Add condition types to the calculation schema so that the import cost is part of the stock value.', {
      complexity: 'complex', hours: 14,
      sel: ['Purchasing org and plant:Scope:1', 'Cost types:Freight, insurance, clearing, duty or others:1', 'Transport:Customizing request'],
      out: ['Condition types:New types with calculation type (fixed amount, percent or quantity)', 'Calculation schema:Position of each type and the subtotals', 'Account key:Key for the account of the cost, from the Finance consultant', 'Accrual or not:Whether the cost is accrued at goods receipt', 'Tax code:Treatment agreed with the Tax team'],
      entries: ['Goods receipt:Dr stock for the material price and the planned delivery cost, Cr GR/IR', 'Delivery cost invoice:Dr GR/IR for the planned cost, Cr vendor of the cost'],
      tables: ['SPRO Define Calculation Schema', 'SPRO Define Condition Types', 'OBYC', 'MEK1', 'ME23N'],
      logic: ['Planned delivery cost is a condition on the PO and is capitalised with the material', 'Set the condition with the Finance consultant and the Tax team, the duty treatment must follow their decision', 'Check the vendor schema group and the purchasing org schema group', 'Test with a PO, goods receipt and the invoice of the cost vendor'],
      tests: ['PO shows the cost', 'Goods receipt value includes the cost', 'Cost invoice clears the GR/IR'],
      qa: ['Which cost types are part of the stock value?', 'How is the duty treated and who confirms it?']
    }),
    tpl('MM-IMP', 'issue', 'Exchange rate difference on import goods receipt or invoice', 'Value posted at goods receipt differs from the invoice value because the exchange rate changed.', {
      complexity: 'medium', hours: 4,
      sel: ['PO number and item:Import PO:1', 'Goods receipt and invoice documents:Documents compared:1', 'Currency:PO currency', 'Rates used:Rate at goods receipt and at invoice'],
      out: ['Expected:Difference to the exchange difference account', 'Actual:Difference elsewhere or no difference'],
      entries: ['Goods receipt:Dr stock, Cr GR/IR at the rate of the goods receipt date', 'Invoice:Dr GR/IR at the rate of the goods receipt, Cr vendor at the invoice rate, the rest to the exchange difference account (key KDM)'],
      tables: ['MB03', 'MIR4', 'FB03', 'OB08', 'OBYC'],
      logic: ['Read both accounting documents and compare the rates', 'Check the PO header for a fixed exchange rate', 'Check the account determination for the exchange difference key', 'Finance decides on the correction'],
      valid: ['Finance agrees with the accounts used']
    }),
    tpl('MM-IMP', 'report', 'Import PO status and pending shipment', 'Import POs with order value in the foreign currency, shipment status, goods receipt and invoice.', {
      complexity: 'medium', hours: 8,
      sel: ['Purchasing org and plant:Scope:1', 'PO date:Range:1', 'Vendor and country:Optional', 'Incoterms:Optional'],
      out: ['PO and item:Reference', 'Vendor and country:Foreign vendor', 'Currency and value:PO currency and amount', 'Incoterms:Key and place', 'Delivery date:Confirmed date', 'Received and invoiced:Quantity and value', 'Pending quantity:Open'],
      tables: ['ME2N', 'ME2L', 'EKKO', 'EKPO', 'EKES'],
      logic: ['Incoterms and currency are on the PO header', 'Shipment and confirmation status are read from the vendor confirmations (EKES) if used', 'Spec to ABAP if bill of lading or bill of entry numbers are held in a Z table']
    })
  );

  /* ---------- MM-MRP ---------- */
  add(
    tpl('MM-MRP', 'issue', 'MRP does not create a requisition for a material', 'Stock is below the reorder level or a requirement exists but no PR or planned order is created.', {
      complexity: 'medium', hours: 3,
      sel: ['Material and plant:Item:1', 'MRP type and controller:Values in the plant data', 'Planning run:Date and type of the last run', 'Expected PR quantity:What the user expects'],
      out: ['Expected:PR or planned order for the shortage', 'Actual:No proposal'],
      tables: ['MD04', 'MD05', 'MD03', 'MD20', 'MM03'],
      logic: ['Check the MRP type, not planned or manual types create no proposal', 'Check the procurement type, the lot size and the planned delivery time in the MRP views', 'Check if the material is in the planning file (MD20) and if the plant is in the planning run', 'Check the stock, the open POs and the safety stock in MD04', 'Run the single item planning (MD03) in the test system to see the result'],
      valid: ['Single item planning creates the proposal']
    }),
    tpl('MM-MRP', 'config', 'MRP controller and planning parameters for a plant', 'Set MRP controllers, MRP types and lot sizes for the materials of a plant.', {
      complexity: 'medium', hours: 8,
      sel: ['Plant:Plant:1', 'Materials:Selection by type or group', 'Transport:Customizing request'],
      out: ['MRP controllers:Key, name and the e-mail of the controller', 'MRP types:Types used in the plant', 'Lot sizing:Procedures used, for example lot for lot or fixed', 'Planning parameters:Planned delivery time, safety stock, planning time fence', 'Scheduling:Schedule margin key and GR processing time'],
      tables: ['SPRO Consumption-Based Planning', 'MM17', 'MD04', 'MARC'],
      logic: ['MRP controllers are created per plant and assigned in the plant data of the materials', 'Planning values are decided with Planning and Stores, not by the consultant alone', 'Mass change the materials and run single item planning for a test material'],
      tests: ['Material with the new controller appears in the MRP list of the controller', 'Single item planning uses the new lot size']
    }),
    tpl('MM-MRP', 'master', 'Reorder point and safety stock load', 'Set reorder point, safety stock and lot size for materials from the approved Excel.', {
      complexity: 'medium', hours: 8,
      sel: ['Plant:Plant:1', 'Materials:List from the Excel:1', 'MRP type:Reorder point or forecast based', 'Number of materials:Volume'],
      out: ['Material:Number', 'Plant:Plant', 'MRP type:New type', 'Reorder point:Quantity', 'Safety stock:Quantity', 'Lot size:Procedure and the value', 'Planned delivery time:Days'],
      tables: ['MM17', 'MM02', 'MARC', 'MD04', 'BAPI_MATERIAL_SAVEDATA'],
      logic: ['Save the old values from MARC before the change', 'Reorder point values come from Stores and Planning based on the consumption', 'Test 5 materials, check MD04 and the next planning run', 'Do the load when no MRP run is active'],
      valid: ['MRP type is allowed in the plant', 'Old values are saved']
    }),
    tpl('MM-MRP', 'report', 'Materials below reorder level or safety stock', 'List of materials where the stock plus the open orders is below the reorder point or the safety stock.', {
      complexity: 'medium', hours: 8,
      sel: ['Plant:Plant:1', 'MRP controller:One or all', 'Material type and group:Filters', 'Date:Date of the check'],
      out: ['Material and description:Item', 'Unrestricted stock:Quantity', 'Open PO and PR quantity:Receipts expected', 'Reorder point and safety stock:Values from the plant data', 'Shortage:Reorder point less available quantity', 'Last purchase price and vendor:For the buyer'],
      tables: ['MD07', 'MD06', 'MMBE', 'MARC', 'EKPO'],
      logic: ['MD07 shows the stock and requirements for many materials, use it first', 'Available quantity is stock plus the open receipts less the reservations', 'Spec to ABAP only if the vendor and price columns are needed']
    })
  );

  /* ---------- INT ---------- */
  add(
    tpl('INT', 'issue', 'Account not found or not defined in a goods movement or invoice', 'MIGO or MIRO stops with a message that the account for a transaction key is not defined.', {
      complexity: 'medium', hours: 3,
      sel: ['T-code:MIGO, MIRO or other:1', 'Movement type:Movement type of the posting', 'Material and plant:Item', 'Message text and number:Exact message, with the transaction key and modifier:1', 'Valuation class:Class of the material'],
      out: ['Expected:Posting is done with the right account', 'Actual:Message that the account is not found'],
      entries: ['Posting expected:Dr and Cr accounts with the transaction keys, for example stock (BSX) and offsetting entry (GBB)', 'Missing key:Key, modifier and valuation class from the message'],
      tables: ['OMWB', 'OBYC', 'MM03', 'T030', 'OMJJ'],
      logic: ['Note the transaction key, the account modifier and the valuation class from the message', 'Simulate the posting with OMWB to see the account determination', 'Check the account grouping of the movement type for the offsetting entry (GBB)', 'Check the valuation class of the material and the chart of accounts of the company code', 'The account is created by the Finance consultant in DEV and moved by transport, not changed directly in PRD'],
      valid: ['Posting works in QAS after the transport', 'FI document shows the right accounts']
    }),
    tpl('INT', 'config', 'Valuation class and account determination for a new material type', 'New valuation class with its stock, GR/IR, price difference and consumption accounts.', {
      complexity: 'complex', hours: 14,
      sel: ['Company code and valuation area:Scope:1', 'Material type:Type that uses the class:1', 'Transport:Customizing request'],
      out: ['Valuation class:Key and the account category reference', 'Material type link:Class allowed for the material type', 'BSX:Stock account by valuation class', 'WRX:GR/IR account', 'PRD:Price difference account', 'GBB:Offsetting entry accounts by modifier, for example consumption, scrapping, differences, orders', 'UMB:Revaluation account'],
      entries: ['Goods receipt for PO:Dr stock (BSX), Cr GR/IR (WRX)', 'Goods issue to cost centre:Dr consumption (GBB with VBR), Cr stock (BSX)', 'Inventory difference:Dr or Cr (GBB with INV) against stock (BSX)'],
      tables: ['OBYC', 'OMWB', 'OMS2', 'FS00', 'T030'],
      logic: ['The Finance consultant creates the accounts and the account determination, the MM consultant gives the material types, valuation classes and movement types', 'Simulate each movement with OMWB before the postings', 'Check the posting of goods receipt, goods issue, invoice and physical inventory difference', 'Keep the old setting as a screenshot before the change'],
      tests: ['Goods receipt for a PO', 'Goods issue to a cost centre', 'Invoice with a price difference', 'Physical inventory difference', 'Scrapping'],
      qa: ['Which accounts does Finance want for each key and modifier?', 'Which material types use the new valuation class?']
    }),
    tpl('INT', 'issue', 'Stock value in MB5L does not match the stock account in the GL', 'The value in the stock list differs from the balance of the stock account. Find the reason.', {
      complexity: 'complex', hours: 8,
      sel: ['Company code and plant:Scope:1', 'Valuation class and account:Class and the stock account', 'Key date:Date of the comparison:1', 'Difference:Amount of the difference'],
      out: ['MB5L value:Total in the stock list', 'GL balance:Balance of the stock account', 'Difference:Amount and the likely reason'],
      entries: ['Manual postings:Direct postings to the stock account without a material document', 'Price changes:Revaluation documents from MR21 or a price change in the material master'],
      tables: ['MB5L', 'FBL3N', 'FAGLB03', 'CKM3N', 'MR21'],
      logic: ['Compare by valuation class, the difference is often in one class', 'Look for direct postings to the stock account in FBL3N that have no material document', 'Check price changes and revaluations in the period', 'Check goods movements in a period that was posted after the list date', 'Check that the plant and company code of the valuation area are right'],
      valid: ['Difference is explained document by document', 'Finance approves the correction']
    }),
    tpl('INT', 'issue', 'Production order goods issue or receipt gives an error', 'Backflush, goods issue to an order or goods receipt from an order fails or posts to the wrong account.', {
      complexity: 'medium', hours: 4,
      sel: ['Production order:Order number:1', 'Material and plant:Component or finished item:1', 'Movement type:261, 101 or other', 'Message text and number:Exact message'],
      out: ['Expected:Movement is posted to the order', 'Actual:Error message or wrong account'],
      entries: ['Goods issue (261):Dr work in process or order cost (GBB with the modifier for orders), Cr stock (BSX)', 'Goods receipt (101):Dr stock (BSX), Cr order credit (GBB with the order modifier)'],
      tables: ['COOIS', 'CO03', 'MIGO', 'MB51', 'OMWB'],
      logic: ['Check the status of the order, a closed or technically completed order does not allow the movement', 'Check the stock of the component in the issuing storage location', 'Check the account determination with OMWB for the movement type and the valuation class', 'Involve the PP consultant for the order and the BOM side']
    }),
    tpl('INT', 'config', 'Goods receipt into quality inspection stock', 'Set the inspection type so that the goods receipt of a material goes to quality inspection stock.', {
      complexity: 'medium', hours: 8,
      sel: ['Plant:Plant:1', 'Materials:Materials with the inspection', 'Transport:If a setting is changed'],
      out: ['Inspection type:Type 01 for goods receipt from a PO, active in the QM view of the material', 'Inspection setup:Inspection plan or the sample as agreed with the QM consultant', 'Stock posting:Goods receipt posts to quality inspection stock', 'Usage decision:Posts the stock to unrestricted or blocked'],
      entries: ['Goods receipt:Stock goes to quality inspection stock, the value is posted to the stock account as usual', 'Usage decision to unrestricted:Stock moves to unrestricted use without a change of value', 'Usage decision to blocked:Stock moves to blocked stock'],
      tables: ['QA32', 'QA03', 'QE51N', 'MM02', 'MMBE'],
      logic: ['The QM consultant sets the inspection plan, the MM consultant sets the QM view and the stock posting', 'Check the control key of the QM view of the material', 'Test the goods receipt, the inspection lot and the usage decision'],
      tests: ['Goods receipt creates an inspection lot', 'Stock shows as quality inspection stock', 'Usage decision moves the stock']
    }),
    tpl('INT', 'config', 'Plant to plant stock transfer with delivery', 'Stock transport order between plants with shipping data, delivery and goods receipt at the receiving plant.', {
      complexity: 'complex', hours: 14,
      sel: ['Supplying plant:Plant that sends:1', 'Receiving plant:Plant that receives:1', 'Document type:Stock transport order type, for example UB', 'Transport:Customizing request'],
      out: ['Supplying plant data:Shipping point and delivery type assigned to the supplying plant', 'Document type:Order type with the document flow', 'Movement types:Issue 351 or 641 and the goods receipt, with the transit stock', 'Valuation:Plant to plant price and the intercompany billing if the company codes differ'],
      entries: ['Goods issue at the sending plant:Stock goes into the stock in transit of the receiving plant', 'Goods receipt at the receiving plant:Stock in transit moves to the stock of the receiving plant'],
      tables: ['ME21N', 'VL10B', 'VL01N', 'MIGO', 'MB5T', 'SPRO Stock Transport Orders'],
      logic: ['Stock transport orders use the delivery of SD for the issue, involve the SD consultant', 'Check the plant assignment to the supplying plant, the shipping data and the delivery type', 'Check the tax and the billing if the plants are in different company codes or states, with the Tax team', 'Test the order, delivery, goods issue and goods receipt, then check MB5T'],
      tests: ['Order and delivery', 'Goods issue and stock in transit', 'Goods receipt at the receiving plant'],
      qa: ['Which plants send to which?', 'Is the transfer inside one company code?']
    })
  );

  /* ---------- Month-end and year-end ---------- */
  add(
    tpl('MM-IM', 'periodend', 'MM month-end - period closing and cut-off', 'Monthly steps for the MM period: cut-off, pending documents, open the next period, and hand over to Finance.', {
      complexity: 'medium', hours: 8, repeat: 'monthly',
      sel: ['Company code and plants:Scope:1', 'Period being closed:Month and year:1', 'Cut-off date:Last day for goods movements and invoices', 'Next period:Period to open'],
      out: ['Pending documents:Goods receipts, issues and transfers not yet posted', 'MM period moved:From the closed to the next period (MMPV)', 'GR/IR list:Given to Finance', 'Stock reconciliation:MB5L agrees with the GL', 'Open points:Carried to next month'],
      entries: ['Period change:No accounting entry, only the MM period is moved', 'Cut-off postings:Late goods receipts posted with the right posting date, as agreed with Finance'],
      tables: ['MMPV', 'MB5L', 'MB5S', 'MB51', 'OMSY'],
      logic: ['Get the cut-off date from Finance, inform Stores and Purchase', 'Check for pending goods movements and unprocessed documents before closing', 'Check the GR/IR and stock reconciliation before the period is moved', 'Close the MM period with MMPV only after Finance confirms', 'Do not open an old period without a written approval'],
      valid: ['Period is checked and closed on the same day as the FI period or as Finance agrees', 'Reports are saved in Files with the date'],
      tests: ['Posting in the old period gives a message', 'Posting in the new period works'],
      qa: ['What is the cut-off date and who confirms it?', 'Should the MM and the FI period be closed together?']
    }),
    tpl('MM-IV', 'periodend', 'GR/IR review and clearing', 'Monthly review of goods received but not invoiced and the clearing of old items.', {
      complexity: 'medium', hours: 8, repeat: 'monthly',
      sel: ['Company code:Company code:1', 'Period:Month being closed:1', 'Cut-off date:Key date of the list', 'Age limit:Age after which an item is reviewed'],
      out: ['GR/IR list:Open items by PO and vendor (MB5S)', 'Reasons:Reason for each old item, invoice not received, wrong price, quantity', 'Decision:Wait, post invoice, or clear', 'Cleared items:List posted with MR11 after approval'],
      entries: ['GR/IR accrual (Finance posts):Goods received, invoice not received, the list is the input', 'Clearing with MR11:Dr or Cr GR/IR against the account set up for it, only items approved by Finance'],
      tables: ['MB5S', 'MR11', 'MR11SHOW', 'MIR6', 'FBL3N'],
      logic: ['Run MB5S for the key date and sort by age', 'Send the old items to Purchase and the vendors for the invoice or the correction', 'Clear only the approved items with MR11 and keep the approval', 'Total of the list should agree with the balance of the GR/IR account'],
      valid: ['Balance of the GR/IR account equals the list total', 'Approval for each cleared item is in Files']
    }),
    tpl('INT', 'periodend', 'Stock value reconciliation with the GL (monthly)', 'Agree the stock value of the MM reports with the stock accounts of Finance at month-end.', {
      complexity: 'medium', hours: 6, repeat: 'monthly',
      sel: ['Company code and plants:Scope:1', 'Period:Month being closed:1', 'Valuation classes:Stock classes in use'],
      out: ['MB5L list:Stock value by valuation class', 'GL balance:Stock accounts for the same classes', 'Difference:Amount and explanation', 'Sign off:Finance and Stores'],
      entries: ['No new entry:This is a check. Differences are explained and corrected only with the approval of Finance'],
      tables: ['MB5L', 'FBL3N', 'FS10N', 'CKM3N', 'MB52'],
      logic: ['Run MB5L after the last movement of the period is posted', 'Compare by valuation class with the balance of the stock account', 'Explain the difference by direct postings, price changes and period differences', 'Keep the printout in Files with the date']
    }),
    tpl('MM-PUR', 'periodend', 'Open PR and PO review at period-end', 'List of old open requisitions and purchase orders with the decision to keep, close or delete.', {
      complexity: 'simple', hours: 4, repeat: 'quarterly',
      sel: ['Plant and purchasing group:Scope:1', 'Age limit:Age after which the item is reviewed:1', 'Document date:Cut-off date'],
      out: ['Old PRs:List with the age and the requester', 'Old POs:List with the pending quantity and the delivery date', 'Decision:Keep, close or delete', 'Updated documents:Closed with the delivery completed indicator or the deletion flag'],
      tables: ['ME5A', 'ME2N', 'ME22N', 'MEMASSPO', 'MEMASSRQ'],
      logic: ['Send the lists to the buyers and the requesters before closing', 'Use the mass change transactions for many documents, with a saved copy of the list', 'Closing an old PO frees the commitment, tell Finance if the commitments are used for reporting'],
      valid: ['No item is closed without the confirmation of the buyer']
    }),
    tpl('MM-IM', 'periodend', 'Negative, blocked and old stock review', 'Monthly review of negative stock, blocked stock and quality inspection stock for Stores and Finance.', {
      complexity: 'simple', hours: 4, repeat: 'monthly',
      sel: ['Plant:Plant:1', 'Period:Month:1', 'Stock types:Negative, blocked, quality inspection, in transit'],
      out: ['Negative stock list:Materials with negative stock and the likely reason', 'Blocked stock list:Quantity, value and age', 'Quality stock list:Items waiting for the usage decision', 'Action:Correction or decision for each item'],
      tables: ['MB52', 'MB5T', 'MMBE', 'MB51', 'QA32'],
      logic: ['Negative stock is mostly a goods issue before the goods receipt, find the receipt and post it with the right date', 'Blocked and quality stock need a decision from Stores or QM', 'Do not correct with a manual adjustment, use the right movement type'],
      valid: ['Negative stock is zero after the corrections']
    }),
    tpl('MM-IM', 'periodend', 'Year-end - MM activities', 'Yearly steps for MM at the fiscal year end: cut-off, physical inventory result, GR/IR, open documents and the new year period.', {
      complexity: 'complex', hours: 24, repeat: 'yearly',
      sel: ['Company code and plants:Scope:1', 'Fiscal year:Year being closed:1', 'Cut-off date:Last day for postings', 'Auditor requirements:Lists the auditors need'],
      out: ['Physical inventory result:Differences posted and signed', 'GR/IR list:Reviewed and cleared as approved', 'Open PRs and POs:Reviewed and closed', 'Stock reconciliation:MB5L agrees with the GL', 'Number ranges:Checked for the new year', 'Audit lists:Stock, GR/IR, open POs'],
      tables: ['MMPV', 'MMRV', 'MI07', 'MB5L', 'MB5S', 'SNRO'],
      logic: ['Agree the dates and the lists with Finance before the year end', 'Finish the physical inventory and the difference posting before the cut-off', 'Check that the MM period is open for the new fiscal year, MMPV moves it by period', 'Check the number ranges of the purchasing and material documents that are year dependent', 'Keep the audit lists in Files'],
      valid: ['Stock in the system agrees with the count', 'All lists are signed by Stores and Finance']
    })
  );

  /* ---------- GEN: authorisation and other ---------- */
  add(
    tpl('GEN', 'issue', 'Missing authorisation in an MM transaction', 'User gets a message that no authorisation exists in ME21N, MIGO, MIRO or MM02.', {
      complexity: 'simple', hours: 2,
      sel: ['User ID:User:1', 'T-code:Transaction:1', 'SU53 screenshot:Screenshot taken just after the error:1', 'Plant or purchasing group:Org values'],
      out: ['Expected:User can do the activity', 'Actual:No authorisation message'],
      tables: ['SU53', 'SU21', 'PFCG', 'SUIM'],
      logic: ['Read the missing authorisation object and the values from SU53', 'Check if the user should have the access for that plant, group or movement type, ask the process owner', 'If yes send the exact object, field values and activity to the Basis team for the role change', 'Never give a broader role only to solve one case'],
      valid: ['User can post after the role change in QAS and in PRD']
    }),
    tpl('GEN', 'auth', 'New role for a purchase officer', 'Role for a buyer to create and change purchase orders and requisitions in given plants and purchasing groups.', {
      complexity: 'medium', hours: 6,
      sel: ['User ID:Users:1', 'Plants:Plants allowed:1', 'Purchasing group and org:Values allowed:1', 'Approved by:Manager and process owner:1'],
      out: ['T-codes:ME21N, ME22N, ME23N, ME51N, ME52N, ME53N, ME2N, ME2L, ME2M, ME5A, ME11, ME13, ME9F', 'Activity:Create, change and display', 'Document types:PO and PR document types allowed', 'Release code:Only if the buyer releases'],
      auth: ['M_BEST_BSA (PO document type)', 'M_BEST_EKG (purchasing group)', 'M_BEST_EKO (purchasing organisation)', 'M_BEST_WRK (plant)', 'M_BANF_BSA, M_BANF_EKG, M_BANF_WRK (requisition)', 'M_EINF_EKO, M_EINF_WRK (info record)'],
      logic: ['Segregation of duties, the buyer who creates a PO does not post the invoice or the goods receipt for it', 'Release of the PO is given to the approver and not to the buyer, unless the policy says otherwise', 'Basis creates the role, the consultant gives the values and tests it'],
      valid: ['Approval of the manager is in Files'],
      tests: ['Create a PO in the allowed plant', 'Create a PO in a plant that is not allowed and get the message', 'Display only transactions do not allow a change']
    }),
    tpl('GEN', 'auth', 'Temporary store access for goods receipt and issue', 'Store user needs MIGO for a plant for a limited time, for example leave cover.', {
      complexity: 'simple', hours: 2,
      sel: ['User ID:User who gets the access:1', 'Plant and storage location:Where:1', 'Valid from and to:Dates:1', 'Approved by:Manager:1'],
      out: ['T-codes:MIGO, MB51, MMBE, MB52', 'Movement types:Only the types needed, for example 101 and 261', 'Activity:Post and display'],
      auth: ['M_MSEG_BWA (movement type)', 'M_MSEG_WWA (plant)', 'M_MSEG_LGO (storage location)'],
      logic: ['Temporary access gets an end date, ask Basis to remove it on that date', 'Give only the movement types and the plant needed', 'Keep the approval in Files'],
      tests: ['Posting in the allowed plant works', 'Posting in another plant is refused']
    }),
    tpl('GEN', 'auth', 'Release code for PO or PR approver', 'Give or remove a release code for an approver in the release strategy.', {
      complexity: 'simple', hours: 2,
      sel: ['User ID:Approver:1', 'Release group and code:Group and code:1', 'Valid from and to:Dates', 'Approved by:Who approved:1'],
      out: ['T-codes:ME28, ME29N, ME54N, ME55', 'Release group and code:Values in the role'],
      auth: ['M_EINK_FRG (release group and release code)', 'M_BEST_BSA, M_BEST_EKG, M_BEST_WRK (display of the PO)'],
      logic: ['Release codes are a part of the approval policy, the process owner decides', 'A user should not hold two codes of the same strategy if the policy says so', 'Check the open documents of the old approver and move them'],
      tests: ['Approver can release a PO of the right range', 'Approver cannot release a PO of another strategy']
    }),
    tpl('GEN', 'other', 'User guide and training for MIGO or purchase order', 'Short guide with screenshots for the users of a new process, and a training session.', {
      complexity: 'simple', hours: 8,
      sel: ['Process:Process or transaction:1', 'Users:Group of the trainees', 'Date:Training date'],
      out: ['User guide:Steps with screenshots and the common messages', 'Training:Session and the attendance', 'Test cases:Short cases for the users to try'],
      logic: ['Use the training system or QAS with the same master data', 'List the common errors with the fix', 'Keep the guide in Files']
    }),
    tpl('GEN', 'other', 'Cutover plan - open PO, open PR and stock load', 'Plan and checklist for loading open purchase orders, requisitions and stock at go live.', {
      complexity: 'complex', hours: 30,
      sel: ['Plants and company codes:Scope:1', 'Go live date:Date:1', 'Objects:Open POs, open PRs, stock, vendors, materials, info records'],
      out: ['Cutover plan:Steps, owners and times', 'Load files:Signed by the business', 'Reconciliation:Quantity and value of the stock, the open PO value', 'Go live sign off:Business and Finance'],
      logic: ['Load order is the master data first, then the info records and sources, then the open POs and the stock', 'Stock value must agree with Finance, post the stock with the opening movement', 'Do a full dry run in QAS and record the time of each step', 'Freeze the master data change before the load'],
      valid: ['Every load file has the sign off of the owner', 'Reconciliation is saved in Files']
    }),
    tpl('GEN', 'other', 'UAT support and go live checklist for a change', 'Checklist for the user test and the move to production of a change in MM.', {
      complexity: 'simple', hours: 6,
      sel: ['Change:Task or transport:1', 'Test users:Users who test:1', 'Test system:QAS client'],
      out: ['Test cases:Cases with the expected result', 'Sign off:User sign off with the date', 'Transport request:Request numbers and the order', 'Go live check:Check after the move'],
      logic: ['Test with real users and real roles', 'Get the sign off in writing before the transport to production', 'Keep the evidence in Files', 'After the move do the first real posting with the user and check the result']
    })
  );
})();
