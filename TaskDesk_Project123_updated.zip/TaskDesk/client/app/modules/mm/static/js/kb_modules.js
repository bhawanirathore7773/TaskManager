/* MM modules: what a materials management consultant looks up all day.
   Each module: name, hint, tcodes, spro, reports, tables, tools, auth, notes.
   ECC and S/4HANA differences are written in the notes. Confirm on your system. */
(function () {
  const T = window.KB.T;
  const M = window.KB.modules;

  M['MM-PUR'] = {
    name: 'Purchasing', hint: 'Purchase requisition, RFQ, purchase order, release strategy, output and pending lists',
    tcodes: [T('ME51N / ME52N / ME53N', 'Create / change / display purchase requisition'), T('ME54N / ME55', 'Release purchase requisition (single / collective)'), T('ME21N / ME22N / ME23N', 'Create / change / display purchase order'),
      T('ME29N / ME28', 'Release purchase order (single / collective)'), T('ME2N', 'PO list by PO number, with history and release status'), T('ME2M', 'POs by material'), T('ME2L', 'POs by vendor'), T('ME2K', 'POs by account assignment'),
      T('ME5A', 'PR list display'), T('ME58 / ME59N', 'Create POs from assigned PRs / automatic PO creation'), T('ME41 / ME47 / ME49', 'Create RFQ / maintain quotation / price comparison list'),
      T('ME9F', 'Message output (print or send) for purchase orders'), T('ME80FN', 'Purchasing documents with selection variants'), T('MEK1 / MEK2 / MEK3', 'Create / change / display purchasing conditions')],
    spro: [T('OX01', 'Define purchasing organisation'), T('OX17', 'Assign purchasing organisation to plant'), T('OME4', 'Define purchasing groups'),
      T('Release strategy (PR)', 'IMG: Materials Management > Purchasing > Purchase Requisition > Release Procedure > Procedure with Classification. Characteristics CT04, class CL02 (class type 032), strategy classification CL24N'),
      T('Release strategy (PO)', 'IMG: Materials Management > Purchasing > Purchase Order > Release Procedure for Purchase Orders > Set Up Procedure with Classification. Same CT04 / CL02 / CL24N objects'),
      T('Document types', 'IMG: Purchasing > Purchase Order > Define Document Types (NB standard PO, FO framework order, UB stock transport order, and your own)'),
      T('NACE', 'Output determination: output types, access sequences and condition records (application EF for purchase orders)'),
      T('Calculation schema', 'IMG: Purchasing > Conditions > Define Price Determination Process: condition types, access sequences, schema groups for vendor and purchasing organisation')],
    reports: [T('ME2N', 'Open and delivered POs with PO history'), T('ME2L', 'Vendor wise PO list, filter on open items'), T('ME2M', 'Material wise PO list'), T('ME5A', 'Requisitions by selection (open, not yet ordered)'), T('ME81N', 'Analysis of order values'), T('ME80FN', 'Flexible list of purchasing documents')],
    tables: [T('EKKO / EKPO', 'PO header / item'), T('EKET', 'PO schedule lines'), T('EKKN', 'PO account assignment'), T('EKBE', 'PO history (GR, invoice)'), T('EBAN', 'Purchase requisition'), T('EKES', 'Vendor confirmations'),
      T('T161', 'Purchasing document types'), T('T024 / T024E', 'Purchasing groups / purchasing organisations'), T('LFM1', 'Vendor purchasing data'), T('NAST', 'Message (output) status'), T('CDHDR / CDPOS', 'Change documents')],
    tools: [T('BAPI_PO_CREATE1', 'Create purchase order'), T('BAPI_PO_CHANGE', 'Change purchase order'), T('BAPI_PO_RELEASE', 'Release purchase order'), T('BAPI_PR_CREATE', 'Create purchase requisition'), T('MEMASSPO / MEMASSRQ', 'Mass change of POs / PRs'), T('LSMW / SHDB recording', 'Upload when no BAPI fits; test in QAS first')],
    auth: ['M_BEST_BSA (PO document type)', 'M_BEST_EKG (purchasing group)', 'M_BEST_EKO (purchasing organisation)', 'M_BEST_WRK (plant)', 'M_BANF_BSA / M_BANF_EKG / M_BANF_WRK (requisition document type, group, plant)', 'M_EINK_FRG (release code and release group)'],
    notes: ['Price pick-up in a PO normally follows: contract if valid, otherwise the info record, otherwise the price entered by hand. Check ME13 and the condition validity dates first when a price is wrong.',
      'A release strategy is selected by the characteristic values on the document (for example plant, purchasing group, total net order value). If it does not trigger, compare the values with the strategy classification in CL24N.',
      'Changing a document after release can reset the release. The reset behaviour is a setting on the release strategy.',
      'Output (print or mail) problems: check the condition record in NACE and the status in ME9F, then the processing log of the message.',
      'In S/4HANA the PR and PO transactions are the same ME21N / ME51N family; Fiori apps exist for the same work. Customizing paths stay the same.',
      'Keep the transport request number in the task: Basis and audit ask for it first.']
  };

  M['MM-CON'] = {
    name: 'Contracts and source determination', hint: 'Contracts, scheduling agreements, source list, quota arrangement, info record as a source',
    tcodes: [T('ME31K / ME32K / ME33K', 'Create / change / display contract'), T('ME31L / ME32L / ME33L', 'Create / change / display scheduling agreement'), T('ME38', 'Maintain scheduling agreement schedule'), T('ME84', 'Generate scheduling agreement releases'),
      T('ME35K / ME35L', 'Release contract / release scheduling agreement'), T('ME9L', 'Message output for scheduling agreements'), T('ME01 / ME03', 'Maintain / display source list'), T('ME05', 'Generate source list'), T('ME06', 'Analyse source list'),
      T('MEQ1 / MEQ3', 'Maintain / display quota arrangement'), T('ME11 / ME12 / ME13', 'Create / change / display purchasing info record'), T('ME3L / ME3M / ME3N', 'Outline agreements by vendor / material / agreement number')],
    spro: [T('Outline agreement types', 'IMG: Purchasing > Contract / Scheduling Agreement > Define Document Types (MK quantity contract, WK value contract, LP scheduling agreement)'),
      T('Release creation profile', 'IMG: Purchasing > Scheduling Agreement > Define Release Creation Profile (how often and in which form releases are created)'),
      T('Source list requirement', 'Source list indicator on the plant data of the material (purchasing view); IMG settings under Purchasing > Source Determination'),
      T('Quota arrangement usage', 'IMG: Purchasing > Source Determination > Define Quota Arrangement Usage (which procurement types use quotas)'),
      T('Release procedure', 'IMG: Purchasing > Contract and Scheduling Agreement > Release Procedure (same classification objects as PO release)'),
      T('Number ranges', 'Number ranges for contracts and scheduling agreements: IMG under each document type group')],
    reports: [T('ME3L', 'Contracts and agreements for a vendor'), T('ME3M', 'Contracts and agreements for a material'), T('ME3N', 'Agreement by document number'), T('ME06', 'Source list analysis'), T('MEQ3', 'Quota arrangement display'), T('ME80FN', 'Flexible list across document types')],
    tables: [T('EKKO / EKPO', 'Agreement header / item (document category K or L)'), T('EKAB', 'Release documentation of agreements'), T('EORD', 'Source list'), T('EQUK / EQUP', 'Quota arrangement header / item'), T('EINA / EINE', 'Info record general / purchasing organisation data'),
      T('KONH / KONP', 'Condition header / position (prices)'), T('EKET', 'Scheduling agreement schedule lines')],
    tools: [T('BAPI_CONTRACT_CREATE / BAPI_CONTRACT_CHANGE', 'Create / change contract'), T('BAPI_SAG_CREATE / BAPI_SAG_CHANGE', 'Create / change scheduling agreement'), T('ME05', 'Generate source lists for many materials at once'), T('LSMW / SHDB recording', 'For ME01 and MEQ1 uploads')],
    auth: ['M_BEST_BSA (document type of the agreement)', 'M_BEST_EKG / M_BEST_EKO / M_BEST_WRK (group, organisation, plant)', 'M_EINK_FRG (release code)', 'M_EINF_EKO / M_EINF_WRK (info record: purchasing organisation, plant)'],
    notes: ['A quantity contract fixes a target quantity, a value contract a target value. POs created with reference to the contract are the release orders.',
      'A scheduling agreement carries delivery schedules instead of separate POs. The releases are the schedule lines the vendor receives.',
      'A fixed source in the source list is picked first by MRP and by PO creation. A blocked source cannot be used.',
      'With a quota arrangement the system splits requirements across vendors by quota; the source list must contain the same vendors.',
      'Always check the validity dates of the condition records when a contract price is not picked.']
  };

  M['MM-IM'] = {
    name: 'Inventory management', hint: 'Goods receipt, goods issue, transfers, reservations, stock overview, physical inventory',
    tcodes: [T('MIGO', 'Goods receipt, goods issue, transfer posting, return delivery'), T('MB03', 'Display material document'), T('MBST', 'Cancel material document'), T('MB51', 'Material document list'), T('MB52', 'Warehouse stock of material'), T('MMBE', 'Stock overview for a material'), T('MB5B', 'Stock on a posting date'),
      T('MB5L', 'List of stock values (balances for reconciliation)'), T('MB5T', 'Stock in transit'), T('MB21 / MB22 / MB23', 'Create / change / display reservation'), T('MB25', 'Reservation list'), T('MB90', 'Output processing for goods movements'), T('MBLB', 'Stock with subcontractor'),
      T('MI01 / MI03', 'Create / display physical inventory document'), T('MI04', 'Enter inventory count'), T('MI07', 'Post inventory differences'), T('MI20', 'List of inventory differences'), T('MICN', 'Create PI documents for cycle counting'), T('MIBC', 'ABC analysis for cycle counting'), T('MIDO', 'Physical inventory overview')],
    spro: [T('OMJJ', 'Movement types: copy standard, set field selection, reversal movement type, account grouping'), T('OX09', 'Maintain storage locations'), T('OX10', 'Maintain plants'),
      T('Reasons for movement', 'IMG: Inventory Management > Goods Issue / Transfer Postings > Define Reasons for Goods Movement'),
      T('Negative stock', 'Allowed at plant, storage location and material level (all three must allow it)'),
      T('Reservation settings', 'IMG: Inventory Management > Reservation: item settings and automatic creation'),
      T('Physical inventory settings', 'IMG: Inventory Management > Physical Inventory: default values, tolerance groups for difference posting'),
      T('Output for goods movements', 'NACE application ME for material documents (goods receipt slip print)')],
    reports: [T('MB51', 'Movements by material, plant, movement type and date'), T('MB52', 'Stock by storage location and batch'), T('MB5B', 'Opening and closing stock on a date'), T('MB5L', 'Stock values per valuation class for the GL reconciliation'), T('MMBE', 'Stock, orders and requirements in one view'),
      T('MC46', 'Slow moving items'), T('MC50', 'Dead stock'), T('MB25', 'Open reservations')],
    tables: [T('MKPF / MSEG', 'Material document header / item'), T('MARD / MARC', 'Stock at storage location / plant data'), T('MCHB', 'Batch stock'), T('MKOL / MSLB', 'Consignment stock at the plant / special stock at the vendor'), T('RESB / RKPF', 'Reservation item / header'),
      T('IKPF / ISEG', 'Physical inventory document header / item'), T('T156', 'Movement types'), T('T001L / T001W', 'Storage locations / plants'), T('MBEW', 'Valuation data'), T('MARDH', 'Historical stock per period')],
    tools: [T('BAPI_GOODSMVT_CREATE', 'Post goods movements'), T('BAPI_GOODSMVT_CANCEL', 'Cancel a material document'), T('BAPI_RESERVATION_CREATE1', 'Create reservation'), T('BAPI_MATPHYSINV_CREATE_MULT', 'Create physical inventory documents'), T('BAPI_MATPHYSINV_COUNT', 'Enter counts'), T('BAPI_MATPHYSINV_POSTDIFF', 'Post differences')],
    auth: ['M_MSEG_BWA (movement type)', 'M_MSEG_WWA (plant for goods movements)', 'M_MSEG_LGO (storage location)', 'M_MRES_BWA / M_MRES_WWA (reservation: movement type, plant)', 'M_ISEG_WIB / M_ISEG_WZL / M_ISEG_WDB (physical inventory: create, count, post difference by plant)'],
    notes: ['Common standard movement types: 101 goods receipt for PO, 102 its reversal, 122 return to vendor, 201 issue to cost centre, 261 issue to production order, 301 plant to plant transfer, 311 storage location transfer, 551 scrapping, 561 initial stock entry, 701 and 702 physical inventory differences.',
      'A goods movement posts in the period of its posting date. If the posting period is closed in MMPV, the posting fails. Ask Finance before opening a period.',
      'Cancel a wrong document with the reversal movement type, not with a manual correction.',
      'For stock reconciliation compare MB52 (quantity), MB5L (value) and the stock accounts in the GL. A gap usually comes from manual postings, price changes or wrong account determination.',
      'Physical inventory: block posting during the count with the posting block on the PI document, post differences only after the recount is signed by the store.',
      'In S/4HANA the old MB1A / MB1B / MB1C are replaced by MIGO. The material document and the accounting document are both in the universal journal.']
  };

  M['MM-IV'] = {
    name: 'Invoice verification', hint: 'Vendor invoice posting, GR/IR clearing, tolerances, blocked invoices, evaluated receipt settlement',
    tcodes: [T('MIRO', 'Enter incoming invoice'), T('MIR4', 'Display invoice document'), T('MIR7', 'Park invoice'), T('MIRA', 'Fast invoice entry'), T('MIR6', 'Invoice overview'), T('MR8M', 'Cancel invoice document'), T('MRBR', 'Release blocked invoices'),
      T('MR11', 'GR/IR account maintenance (clear old items)'), T('MR11SHOW', 'Display GR/IR clearing documents'), T('MB5S', 'List of GR/IR balances'), T('MRRL', 'Evaluated receipt settlement (ERS)'), T('MRKO', 'Consignment and pipeline settlement'), T('MR21 / MR22', 'Price change / debit or credit material'), T('MR90', 'Message output for invoice documents')],
    spro: [T('OMR6', 'Tolerance limits for invoice verification (price variance PP, quantity variance DQ, date variance ST and others)'), T('Invoice block', 'IMG: Invoice Verification > Invoice Block: stochastic block, item amount check, blocking reasons'),
      T('OBYC WRX / PRD', 'GR/IR clearing account and price difference account (with the Finance consultant)'), T('OBCD', 'Define tax code per transaction'), T('Planned delivery costs', 'IMG: Invoice Verification > Incoming Invoice > Maintain Default Values for Tax Codes and Planned Delivery Costs settings')],
    reports: [T('MB5S', 'GR/IR balance by PO and account'), T('MR11SHOW', 'Documents posted by the GR/IR clearing'), T('MIR6', 'Invoice overview by date, vendor or status'), T('MRBR', 'List of blocked invoices with the reason'), T('FBL1N', 'Vendor line items (FI side of the invoice)')],
    tables: [T('RBKP / RSEG', 'Invoice document header / item'), T('RBKP_BLOCKED', 'Blocked invoices'), T('EKBE', 'PO history (goods receipts and invoices)'), T('BKPF / BSEG', 'Accounting document header / item'), T('BSIK / BSAK', 'Vendor open / cleared items'), T('T030', 'Automatic account determination')],
    tools: [T('BAPI_INCOMINGINVOICE_CREATE', 'Post an invoice'), T('BAPI_INCOMINGINVOICE_PARK', 'Park an invoice'), T('BAPI_INCOMINGINVOICE_RELEASE', 'Release a blocked invoice'), T('MRBR', 'Mass release of blocked invoices'), T('MRRL', 'Create invoices from goods receipts (ERS)')],
    auth: ['M_RECH_WRK (plant)', 'M_RECH_EKG (purchasing group)', 'M_RECH_SPG (release of blocked invoices)', 'F_BKPF_BUK (company code of the FI posting)', 'F_LFA1_BUK (vendor company code)'],
    notes: ['Three way match: PO, goods receipt and invoice. The system compares quantity and price and blocks the invoice when the tolerance in OMR6 is exceeded.',
      'GR/IR clearing account holds the value of goods received but not invoiced. A growing balance means invoices are not coming or are posted without PO reference.',
      'MR11 clears old GR/IR items. The posting goes to a price difference or expense account, so take approval from Finance first and keep the list as evidence.',
      'Cancel an invoice with MR8M. For a price or quantity correction after payment use a credit memo or subsequent debit.',
      'A parked invoice (MIR7) creates no FI posting until it is posted.',
      'The invoice date, posting date and the fiscal period must agree with the open FI periods and the tax return month.']
  };

  M['MM-MD'] = {
    name: 'Master data', hint: 'Material master, vendor purchasing data, info record, material types and field selection',
    tcodes: [T('MM01 / MM02 / MM03', 'Create / change / display material'), T('MM04', 'Display changes (change documents) of a material'), T('MM06', 'Flag material for deletion'), T('MM17 / MASS', 'Mass maintenance of material master'), T('MM50', 'Extend material to another plant or view'),
      T('MM60', 'Material list'), T('MMAM', 'Change material type'), T('MMSC', 'Create storage location views'), T('XK01 / XK02 / XK03', 'Create / change / display vendor (central)'), T('MK01 / MK02 / MK03', 'Vendor purchasing data'), T('ME11 / ME12 / ME13', 'Create / change / display info record'),
      T('ME15', 'Flag info record for deletion'), T('ME1M / ME1L', 'Info records by material / by vendor'), T('ME1P', 'Purchase order price history')],
    spro: [T('OMS2', 'Define attributes of material types: views, price control, number range, quantity and value update'), T('OMSF', 'Define material groups'), T('MMNR', 'Number ranges for material master'), T('OMS9', 'Field selection for the material master (field reference by material type or transaction)'),
      T('Valuation classes', 'IMG: Materials Management > Valuation and Account Assignment > Account Determination > Define Valuation Classes (with the Finance consultant)'), T('CUNI', 'Units of measure and dimensions'), T('OBD3', 'Vendor account groups and field selection'),
      T('OX10', 'Plants (valuation level and company code link)')],
    reports: [T('MM60', 'Material list by type, group or plant'), T('MM04', 'Who changed what in the material master'), T('ME1M', 'Info records for a material with prices'), T('ME1L', 'Info records for a vendor'), T('ME1P', 'Price history from POs'), T('SE16N', 'Direct table display for checks')],
    tables: [T('MARA', 'Material general data'), T('MARC', 'Material plant data (MRP, purchasing, HSN control code)'), T('MARD', 'Storage location data'), T('MBEW', 'Valuation data'), T('MAKT', 'Material description'), T('MARM', 'Units of measure'), T('LFA1 / LFB1 / LFM1', 'Vendor general / company code / purchasing data'),
      T('EINA / EINE', 'Info record general / purchasing organisation data'), T('T134 / T023', 'Material types / material groups'), T('T006', 'Units of measure')],
    tools: [T('BAPI_MATERIAL_SAVEDATA', 'Create or change material'), T('BAPI_MATERIAL_GET_DETAIL', 'Read material data'), T('BAPI_MATERIAL_EXISTENCECHECK', 'Check if a material exists'), T('ME_INFORECORD_MAINTAIN_MULTI', 'Function module to maintain many info records'), T('MM17 / MASS', 'Standard mass change tools'),
      T('LSMW / SHDB recording', 'Upload for materials, vendors and info records when no BAPI fits')],
    auth: ['M_MATE_WRK (plant)', 'M_MATE_STA (maintenance status / view)', 'M_MATE_MAR (material type)', 'M_MATE_NEU (create new material)', 'M_EINF_EKO / M_EINF_WRK (info record)', 'F_LFA1_BUK / F_LFA1_GRP (vendor master: company code, authorisation group)'],
    notes: ['The material type controls which views exist, whether stock is value updated and the price control. Changing it later is possible with MMAM only when there is no stock.',
      'Valuation class and price control (S standard, V moving average) are set in the accounting view and decide the GL accounts through OBYC. Change them only with the Finance consultant.',
      'A material number cannot be changed after creation. Create the right number or use a description change.',
      'Test every mass change or upload in QAS with 3 to 5 records and check the result in MM03 and MM04 before the full load.',
      'Field selection (OMS9) makes a field mandatory, optional or hidden by material type. Many create errors come from it.',
      'In India systems the HSN code is often held in the plant data control code field. Confirm the field with the Tax team.',
      'S/4HANA: vendors are maintained through business partner (BP) and the vendor integration; XK01 style transactions are replaced.']
  };

  M['MM-SRV'] = {
    name: 'Service procurement', hint: 'Service master, service PO, service entry sheet and its release',
    tcodes: [T('AC01 / AC02 / AC03', 'Create / change / display service master'), T('ME21N / ME22N / ME23N', 'Service purchase order (item category D)'), T('ML81N', 'Maintain service entry sheet'), T('ML85', 'Service entry sheet worklist'), T('ME2N', 'PO list incl. service items'),
      T('ME2L', 'POs by vendor'), T('MIRO', 'Invoice against the service entry sheet'), T('ME80FN', 'Flexible purchasing list')],
    spro: [T('Service master', 'IMG: Materials Management > External Services Management > Service Master: number ranges, service categories, material group link'), T('Item category D', 'Item category for services in the PO and the account assignment categories allowed with it'),
      T('Release of entry sheets', 'IMG: External Services Management > Define Release Procedure for Service Entry Sheets (class type 104)'), T('Limits', 'IMG: External Services Management > Maintain Limits for unplanned services and the value limit in the PO'),
      T('Conditions for services', 'Condition types and schema used for service lines and the tax code defaults')],
    reports: [T('ME2N', 'Service POs and their entry sheets'), T('ME2L', 'Vendor wise service orders'), T('ME80FN', 'Flexible list with service items'), T('ML85', 'Entry sheets still to be accepted'), T('MIR6', 'Invoices against service entry sheets')],
    tables: [T('ESSR', 'Service entry sheet header'), T('ESLL', 'Service lines (PO and entry sheet)'), T('ESLH', 'Service line header'), T('ASMD / ASMDT', 'Service master / texts'), T('EKPO', 'PO item (item category in PSTYP)'), T('EKKN', 'Account assignment'), T('EKBE', 'PO history incl. service entry sheet')],
    tools: [T('BAPI_PO_CREATE1', 'Create service PO (service lines in the services tables)'), T('BAPI_ENTRYSHEET_CREATE', 'Create entry sheet'), T('BAPI_ENTRYSHEET_GETDETAIL', 'Read entry sheet'), T('LSMW / SHDB recording', 'Service master upload (AC01)')],
    auth: ['M_BEST_BSA / M_BEST_EKG / M_BEST_WRK (service PO)', 'Entry sheet authorisation objects (search SU21, class Materials Management: Entry sheet)', 'Service master authorisation objects (search SU21 for service master)'],
    notes: ['Accepting the service entry sheet is the goods receipt for a service. The invoice is then posted against the entry sheet.',
      'Planned services are in the PO. Unplanned services are allowed only up to the limits set on the PO line.',
      'The entry sheet follows its own release strategy. A blocked release is the usual reason why the invoice cannot be posted.',
      'Account assignment (cost centre, order, asset) is copied from the PO line to the entry sheet. Check it before the acceptance posts to the GL.']
  };

  M['MM-SUB'] = {
    name: 'Subcontracting (job work)', hint: 'Subcontracting PO, components provided to the vendor, consumption and receipt of the finished item',
    tcodes: [T('ME21N / ME22N / ME23N', 'Subcontracting PO (item category L) with components'), T('MIGO', 'Provide components (541), receive finished item (101), consumption (543)'), T('ME2O', 'Monitor stock provided to subcontractors'), T('MBLB', 'Stock with subcontractor'),
      T('MB51', 'Material documents with movement types 541, 542, 543, 544'), T('MMBE', 'Stock overview incl. stock at vendor'), T('ME2L', 'POs by vendor'), T('ME2N', 'PO list'), T('MIRO', 'Invoice for the job work charge')],
    spro: [T('Item category L', 'Subcontracting item category in the PO and the document types that allow it'), T('Movement types', 'OMJJ: 541 issue to subcontractor, 542 reversal, 543 consumption posting, 544 reversal, 545 receipt of by-product'),
      T('Special procurement key 30', 'Subcontracting as special procurement in the MRP 2 view of the material'), T('Valuation of components', 'Components are valued at the price of the material master when consumed; check the price control and price'),
      T('Output', 'PO print and component delivery document: output determination in NACE')],
    reports: [T('ME2O', 'Requirement of components against provided stock'), T('MBLB', 'Stock lying with each vendor'), T('MB51 (541 / 543)', 'Components provided and consumed'), T('ME2N', 'Open subcontracting POs'), T('MMBE', 'Stock overview')],
    tables: [T('EKPO', 'PO item (item category L)'), T('RESB', 'Component requirements of the subcontracting PO'), T('MSLB', 'Special stock at the vendor'), T('MKPF / MSEG', 'Material documents'), T('STKO / STPO / MAST', 'BOM header / item / material link'), T('EKBE', 'PO history')],
    tools: [T('BAPI_PO_CREATE1', 'Create PO with components'), T('BAPI_PO_CHANGE', 'Change PO and components'), T('BAPI_GOODSMVT_CREATE', 'Post 541, 543 and 101 in a program'), T('ME2O', 'Check which components are still to be provided')],
    auth: ['M_BEST_BSA / M_BEST_EKG / M_BEST_WRK (PO)', 'M_MSEG_BWA (movement types 541, 543)', 'M_MSEG_WWA / M_MSEG_LGO (plant, storage location)'],
    notes: ['The components come from the BOM of the finished item in the plant. If the BOM is missing or the wrong usage, the PO shows no components.',
      'Provide components with 541. They stay in the stock of the plant but are shown as stock at the vendor. Receiving the finished item with 101 posts the consumption (543) automatically.',
      'Value of the received item is the job work charge plus the value of the components consumed.',
      'ME2O is the best place to answer how much material is lying with a vendor.',
      'Statutory documents for job work movements (for example challans) follow your Tax team format. Check with them and the ABAP developer who supports the form.']
  };

  M['MM-IMP'] = {
    name: 'Import procurement', hint: 'Import purchase order, currency and incoterms, planned delivery costs, goods receipt and invoice for imports',
    tcodes: [T('ME21N / ME22N / ME23N', 'Import PO with currency, incoterms and conditions'), T('ME31K', 'Contract for imported items'), T('MEK1 / MEK3', 'Maintain / display conditions (freight, duty, insurance)'), T('MIGO', 'Goods receipt for the import PO'), T('MIRO', 'Invoice posting incl. delivery costs'),
      T('MIR7', 'Park invoice until documents arrive'), T('ME2N / ME2L', 'Import PO lists'), T('MB5S', 'GR/IR balance for import POs'), T('MR11', 'GR/IR clearing for old import items')],
    spro: [T('Incoterms', 'Incoterm keys used in the PO header and the vendor purchasing data'), T('Planned delivery costs', 'Condition types in the calculation schema marked as delivery costs (freight, insurance, duty) and their account keys'),
      T('OBYC FR1 / FR2 / FR3', 'Freight clearing, freight provision and freight cost accounts (with the Finance consultant)'), T('OBYC KDM', 'Exchange rate differences on materials'), T('Exchange rates', 'Exchange rate type and rates are maintained by Finance (OB08); the PO can hold a fixed rate'),
      T('Tax codes for imports', 'Tax code and condition types agreed with the Tax team')],
    reports: [T('ME2N', 'Import POs with GR and invoice status'), T('ME2L', 'Vendor wise import orders'), T('MB5S', 'GR/IR balance'), T('MIR6', 'Invoice overview'), T('FBL1N', 'Foreign vendor line items')],
    tables: [T('EKKO', 'PO header (currency WAERS, rate WKURS, incoterms INCO1 / INCO2)'), T('EKPO', 'PO item'), T('EKBE', 'PO history incl. delivery cost lines'), T('KONV / PRCD_ELEMENTS', 'Pricing conditions on the document (ECC / S/4HANA)'), T('TCURR', 'Exchange rates'), T('TINC', 'Incoterms'), T('T685A', 'Condition types for purchasing'), T('MARC', 'Plant data (control code)')],
    tools: [T('BAPI_PO_CREATE1', 'Import PO with header currency, incoterms and conditions'), T('BAPI_PO_CHANGE', 'Change PO'), T('MEK1', 'Maintain conditions'), T('LSMW / SHDB recording', 'Only when no BAPI fits')],
    auth: ['M_BEST_BSA / M_BEST_EKG / M_BEST_EKO / M_BEST_WRK (PO)', 'M_MSEG_BWA (movement type for goods receipt)', 'F_BKPF_BUK (company code of the FI posting)'],
    notes: ['Planned delivery costs are added to the PO price and capitalised in stock at goods receipt. Unplanned costs come with the invoice.',
      'The exchange rate used at goods receipt and at invoice can differ. The difference goes to the account of key KDM. Keep the rate on the PO or the rate type clear to Finance.',
      'Customs duty and tax on imports follow the treatment the Tax team has approved. Check tax codes and condition types together with them before go live.',
      'If the documents arrive late, park the invoice with MIR7 and post it when the bill of entry is received.',
      'Fix the exchange rate on the PO header only when Finance asks for it.']
  };

  M['MM-MRP'] = {
    name: 'Planning parameters and MRP', hint: 'MRP type, lot size, reorder point, safety stock, planning run and MRP lists, as handled by the MM consultant',
    tcodes: [T('MD01', 'MRP run total planning'), T('MD02 / MD03', 'Single item multi level / single level planning'), T('MD04', 'Stock and requirements list for a material'), T('MD05 / MD06', 'MRP list display / collective display'), T('MD07', 'Stock and requirements list collective'), T('MD61 / MD62 / MD63', 'Planned independent requirements'),
      T('MD11 / MD12 / MD13', 'Create / change / display planned order'), T('MD20 / MD21', 'Create / display planning file entry'), T('MDBT', 'MRP run in background'), T('MD73', 'Total requirements'), T('ME5A', 'PRs created by MRP')],
    spro: [T('MRP types', 'IMG: Materials Management > Consumption-Based Planning > Master Data > Check MRP Types (PD MRP, VB manual reorder point, VM automatic reorder point, ND no planning)'), T('Lot size', 'IMG: Consumption-Based Planning > Planning > Lot-Size Calculation > Define Lot-Sizing Procedure (EX lot for lot, FX fixed, HB replenish to maximum, WB weekly, MB monthly)'),
      T('MRP controllers', 'IMG: Consumption-Based Planning > Master Data > Define MRP Controllers'), T('Planning time fence', 'Planning time fence and the planning run parameters in the MRP group'), T('Scheduling', 'Planned delivery time, goods receipt processing time and the schedule margin key'),
      T('Special procurement', 'Special procurement keys such as 30 subcontracting, stock transfer and phantom')],
    reports: [T('MD04', 'Dynamic view of stock, orders and requirements'), T('MD05', 'MRP list as created by the last run'), T('MD06', 'MRP lists for an MRP controller'), T('MD07', 'Stock and requirements for many materials'), T('MD73', 'Total requirements'), T('ME5A', 'Requisitions created by MRP')],
    tables: [T('MARC', 'Plant data: MRP type DISMM, controller DISPO, lot size DISLS, safety stock EISBE, reorder point MINBE, planned delivery time PLIFZ'), T('MDKP', 'MRP document header'), T('PLAF', 'Planned orders'), T('EBAN', 'Purchase requisitions'), T('RESB', 'Reservations and dependent requirements'), T('PBIM / PBED', 'Independent requirements header / item'),
      T('T438A', 'MRP types'), T('T024D', 'MRP controllers')],
    tools: [T('BAPI_MATERIAL_SAVEDATA', 'Change MRP fields of many materials'), T('MM17 / MASS', 'Mass change of MRP parameters'), T('MDBT', 'Schedule MRP in background'), T('LSMW / SHDB recording', 'When no BAPI fits')],
    auth: ['M_MATE_WRK / M_MATE_STA (plant data, MRP view)', 'MRP authorisation objects with prefix M_MTDI (confirm the names with SU21)', 'M_BANF_WRK / M_BANF_BSA (PRs created from MRP)'],
    notes: ['Reorder point planning needs consumption values or a forecast. Without them the reorder point and safety stock are only a guess.',
      'The planning run only plans materials in the planning file. A change in the material master or a movement adds the material to the file. Use MD20 to force it.',
      'MD04 is the live view, MD05 is the result of the last run. If they differ, something changed after the run.',
      'Changing MRP type, lot size or safety stock for many materials is a mass change. Test in QAS and keep the before values from MARC.',
      'The MRP run is usually scheduled by PP or planning. Check with them before running it in production.']
  };

  M['INT'] = {
    name: 'Integration with FI, PP, SD and QM', hint: 'Automatic account determination, stock postings, production order movements, stock transfer and inspection stock',
    tcodes: [T('OBYC', 'Automatic account determination for inventory postings (with the Finance consultant)'), T('OMWB', 'Simulate account determination for a material and movement'), T('MB03', 'Display material document with the linked accounting document'), T('FB03', 'Display FI document'), T('FBL3N', 'GL line items for stock accounts'),
      T('MB5L', 'Stock value balances for reconciliation'), T('CKM3N', 'Material price analysis'), T('CKMLCP', 'Material ledger period closing'), T('COOIS', 'Production order information (components, confirmations, goods movements)'), T('CO03', 'Display production order'), T('MB31', 'Goods receipt for production order'),
      T('VL01N / VL02N', 'Create / change outbound delivery (SD)'), T('QA32 / QA03', 'Inspection lot list / display inspection lot (QM)')],
    spro: [T('BSX', 'Inventory posting: the stock account per valuation class'), T('WRX', 'GR/IR clearing account'), T('GBB', 'Offsetting entry for inventory posting, with modifiers such as VBR consumption, VNG scrapping, INV inventory differences, AUF order'), T('PRD', 'Price differences'), T('UMB', 'Revaluation on price change'),
      T('Valuation class', 'Valuation class of the material decides the GL accounts (material type and account category reference)'), T('Movement type account grouping', 'Account grouping field in the movement type (OMJJ) selects the GBB modifier'), T('Valuation level', 'Plant level valuation and the link of plant to company code')],
    reports: [T('MB5L', 'Stock value per valuation class against the GL'), T('CKM3N', 'Price and value movement of a material'), T('FBL3N', 'GL line items of the stock and GR/IR accounts'), T('MB5S', 'GR/IR balance'), T('COOIS', 'Production order list with goods movements'), T('QA32', 'Inspection lots')],
    tables: [T('T030', 'Automatic account determination'), T('T156', 'Movement types'), T('T025', 'Valuation classes'), T('T001K', 'Valuation area to company code'), T('MBEW / MBEWH', 'Valuation data / history'), T('MKPF / MSEG', 'Material documents'), T('BKPF / BSEG', 'Accounting documents')],
    tools: [T('OMWB', 'Simulate the account determination before a test posting'), T('BAPI_GOODSMVT_CREATE', 'Post goods movements'), T('MR21 / MR22', 'Price change document / debit or credit to material'), T('CKMLCP', 'Material ledger closing steps (with the costing team)')],
    auth: ['M_MSEG_BWA / M_MSEG_WWA (movement type, plant)', 'F_BKPF_BUK (company code of the FI posting created by an MM transaction)', 'Production order goods movement objects (names starting with C_AFKO, check SU21)'],
    notes: ['A goods receipt for a PO posts Dr stock (key BSX), Cr GR/IR (key WRX). A goods issue to a cost centre posts Dr consumption (key GBB, modifier VBR), Cr stock (key BSX).',
      'When the message says account not found, note the transaction key and the account modifier in the message, then check OBYC for that key, the chart of accounts and the valuation class.',
      'Do not change OBYC in production. Make the change in DEV, test with MIGO and check the FI document with FB03 or MB03.',
      'Stock of material in quality inspection is a separate stock type. Check the inspection type in the material master QM view when a goods receipt blocks stock.',
      'Confirm every modifier and account on your own system: the standard keys are the same but the account grouping is set in your configuration.']
  };

  M['GEN'] = {
    name: 'General, authorisation and tools', hint: 'Roles, authorisation checks, table display, locks, dumps, output control, transports and change history',
    tcodes: [T('SU53', 'Display the last failed authorisation check'), T('SU21', 'Authorisation objects'), T('PFCG', 'Role maintenance (with the Basis team)'), T('SE16N', 'Table display'), T('SM12', 'Locked entries'), T('SM13', 'Update requests'), T('ST22', 'ABAP dumps'),
      T('SM35', 'Batch input sessions'), T('SM37', 'Background jobs'), T('SLG1', 'Application log'), T('NACE', 'Output control conditions'), T('SE09 / SE10', 'Transport organiser'), T('SM30', 'Table maintenance')],
    spro: [T('SNRO', 'Number range objects and intervals'), T('IMG', 'Every IMG activity records a customizing request in DEV. Note the request number in the task'), T('NACE', 'Output types, procedures and condition records'), T('SM30', 'Maintenance views for small customizing tables')],
    reports: [T('SU53', 'Why a user got a missing authorisation message'), T('SE16N', 'Table contents for checks'), T('CDHDR / CDPOS', 'Change documents for a master record or document'), T('SM37', 'Job log of the background run'), T('SLG1', 'Log of an interface or a mass upload')],
    tables: [T('CDHDR / CDPOS', 'Change document header / items'), T('NAST', 'Output message status'), T('USR02', 'Users'), T('AGR_USERS', 'Role assignment to users'), T('AGR_1251', 'Authorisation values in roles'), T('TSTC', 'Transaction codes'), T('NRIV', 'Number range intervals'), T('E070 / E071', 'Transport requests / objects')],
    tools: [T('LSMW', 'Legacy data upload with recording or BAPI'), T('SHDB recording', 'Record a transaction for a batch input'), T('MM17 / MASS', 'Mass change of material master data'), T('Excel upload', 'Ask the ABAP developer for a standard upload program when the volume is large')],
    auth: ['S_TCODE (start a transaction)', 'S_TABU_DIS / S_TABU_NAM (table display)', 'ACTVT in each object: 01 create, 02 change, 03 display, 06 delete', 'M_BEST_WRK / M_MSEG_WWA / M_MATE_WRK (plant level checks in MM)'],
    notes: ['After an authorisation error ask the user to run SU53 immediately and send a screenshot.',
      'Use the change documents (CDHDR / CDPOS) to find who changed a master record or document and when.',
      'Test every change in QAS with a real user role, not only with your own user.',
      'Keep the transport request number in the task. It is the first thing audit and Basis ask for.',
      'Never edit table data directly in production. Use the standard transaction or ask for a data correction approval.']
  };
})();
