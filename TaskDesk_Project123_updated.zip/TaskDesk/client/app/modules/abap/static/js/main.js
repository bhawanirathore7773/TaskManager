/* App start: navigation, top bar, search, routing, refresh. */
(function () {
  'use strict';
  const { h, $, ico, GET, debounce } = App;
  const S = App.S;
  const NAV = [['dashboard', 'Dashboard', 'dashboard'], ['tasks', 'Tasks', 'list'], ['board', 'Board', 'board'], ['timeline', 'Timeline', 'timeline'], ['history', 'History', 'history'], ['register', 'Register', 'register'], ['quality', 'Quality', 'alert'], ['library', 'Library', 'library'], ['settings', 'Settings', 'settings']];
  let lastView = null;

  const routeName = () => { const v = (location.hash.replace(/^#\//, '') || 'dashboard').split('?')[0]; return App.V[v] ? v : 'dashboard'; };

  function badges() {
    const T = S.tasks || [];
    const attention = T.filter((t) => App.isActive(t) && ['overdue', 'crunch', 'urgent'].indexOf(t.urgency) >= 0).length;
    const issues = T.reduce((s, t) => s + (t.q_open || 0) + (t.p_open || 0), 0);
    return { tasks: attention, quality: issues };
  }
  function renderNav() {
    const b = badges(), cur = S.view;
    $('#nav').replaceChildren(
      h('div', { class: 'brand' }, h('img', { src: '/icon.svg', alt: '' }), h('div', null, h('b', null, 'ABAP Tasks'), h('span', null, 'Developer desk'))),
      NAV.map((n) => h('a', { href: '#/' + n[0], class: cur === n[0] ? 'on' : '', 'aria-current': cur === n[0] ? 'page' : null, title: n[1] }, ico(n[2]), h('span', null, n[1]), b[n[0]] ? h('span', { class: 'cnt' }, b[n[0]]) : null)),
      h('div', { class: 'sp' }), h('div', { class: 'foot' }, 'Saved on this PC'));
  }

  App.render = function () {
    const v = routeName(), root = $('#view'), keep = lastView === v ? root.scrollTop : 0;
    S.view = v;
    root.replaceChildren();
    try { App.V[v](root); } catch (e) {
      console.error(e);
      root.append(h('div', { class: 'empty' }, h('b', null, 'This page could not be shown'), String(e && e.message ? e.message : e)));
    }
    root.scrollTop = keep; lastView = v;
    renderNav();
    document.title = (NAV.find((n) => n[0] === v) || NAV[0])[1] + ' - ABAP Task Manager';
  };
  App.refreshTasks = async function () {
    const r = await Promise.all([GET('/api/tasks'), GET('/api/meta')]);
    S.tasks = r[0]; S.meta = r[1];
    App.render();
  };
  App.softRefresh = App.refreshTasks;
  App.softRefreshSoon = debounce(async () => { try { S.tasks = await GET('/api/tasks'); renderNav(); } catch (e) { /* ignore */ } }, 900);

  /* ---------- top bar + search ---------- */
  function buildTop() {
    const input = h('input', { type: 'search', placeholder: 'Search tasks, T-codes, programs', 'aria-label': 'Search all tasks', autocomplete: 'off' });
    const box = h('div', { class: 'results hide', role: 'listbox' });
    let items = [], idx = -1;
    const close = () => { box.classList.add('hide'); idx = -1; };
    function draw() {
      box.replaceChildren(items.map((t, i) => h('button', { type: 'button', role: 'option', class: i === idx ? 'on' : '', onclick: () => { close(); input.value = ''; App.openTask(t.id); } },
        h('span', { class: 'mono ink2' }, t.code), h('span', { class: 'grow trunc' }, t.title), App.statusChip(t.status))));
      if (!items.length) box.append(h('div', { style: { padding: '12px' }, class: 'muted' }, 'No task matches.'));
      box.classList.remove('hide');
    }
    input.addEventListener('input', () => {
      const q = input.value.trim();
      if (!q) { close(); return; }
      items = S.tasks.filter((t) => App.matchTask(t, q)).slice(0, 8); idx = -1; draw();
    });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); idx = Math.min(items.length - 1, idx + 1); draw(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); idx = Math.max(0, idx - 1); draw(); }
      else if (e.key === 'Enter') { const t = items[Math.max(0, idx)]; if (t) { close(); input.value = ''; App.openTask(t.id); } }
      else if (e.key === 'Escape') { close(); input.blur(); }
    });
    document.addEventListener('click', (e) => { if (!box.contains(e.target) && e.target !== input) close(); });
    App.focusSearch = () => { input.focus(); input.select(); };
    const dark = () => document.documentElement.getAttribute('data-theme') === 'dark';
    const themeBtn = h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Switch between light and dark', title: 'Light or dark' });
    const drawTheme = () => themeBtn.replaceChildren(ico(dark() ? 'sun' : 'moon'));
    themeBtn.addEventListener('click', () => {
      const next = dark() ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next);
      try { localStorage.setItem('tm_theme', next); } catch (e) { /* ignore */ }
      drawTheme();
    });
    drawTheme();
    $('#top').replaceChildren(h('div', { class: 'search' }, ico('search'), input, h('kbd', null, 'Ctrl K'), box), h('span', { class: 'grow' }),
      h('span', { class: 'small muted' }, new Date().toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })), themeBtn,
      h('button', { class: 'btn primary', type: 'button', onclick: () => App.newTask() }, ico('plus'), 'New task'));
  }

  /* ---------- start ---------- */
  async function init() {
    try {
      const r = await Promise.all([GET('/api/meta'), GET('/api/tasks')]);
      S.meta = r[0]; S.tasks = r[1];
    } catch (e) {
      $('#view').replaceChildren(h('div', { class: 'empty' }, h('b', null, 'The Task Manager server is not running'), 'Close this window and open the app again from the desktop icon.'));
      return;
    }
    buildTop();
    window.addEventListener('hashchange', App.render);
    App.render();
    // keeps the local server alive while the window is open
    setInterval(() => { fetch('/api/ping').catch(() => {}); }, 20000);
    // dates roll over: refresh when coming back to the window
    document.addEventListener('visibilitychange', () => { if (!document.hidden && !App.drawerOpen()) App.refreshTasks().catch(() => {}); });
    // dropping a file outside a drop zone must not make the browser open it
    ['dragover', 'drop'].forEach((ev) => window.addEventListener(ev, (e) => e.preventDefault()));
    document.addEventListener('keydown', (e) => {
      const tg = e.target && e.target.tagName, typing = tg === 'INPUT' || tg === 'TEXTAREA' || tg === 'SELECT' || (e.target && e.target.isContentEditable);
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); App.focusSearch(); return; }
      if (typing || e.ctrlKey || e.metaKey || e.altKey || document.querySelector('dialog[open]') || App.drawerOpen()) return;
      if (e.key === 'n') { e.preventDefault(); App.newTask(); }
      else if (e.key === '/') { e.preventDefault(); App.focusSearch(); }
    });
  }
  init();
})();
