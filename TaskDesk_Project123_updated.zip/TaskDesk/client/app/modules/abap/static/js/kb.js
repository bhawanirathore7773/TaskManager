/* =====================================================================
   SAP ABAP knowledge base for the Task Manager.
   Everything here is plain data: edit / extend it freely.
   Names marked (ECC) or (S/4) differ between the two systems - always
   verify in SE11 on your own system before coding.
   ===================================================================== */
(function () {
  const P = (n, d, m) => ({ n: n, d: d, m: !!m });          // parameter / field
  const T = (n, d) => ({ n: n, d: d });                      // table / tcode / FM

  /* ------------------------------------------------------------------
     1. TASK TYPES - what to capture for each kind of development
     ------------------------------------------------------------------ */
  const types = {
    report: {
      label: 'ALV Report', icon: '\u{1F4CA}',
      intro: 'Selection screen + data fetch + ALV output. Most requests from the business are this.',
      labels: { sel: 'Selection screen fields', out: 'Output columns', logic: 'Business logic / calculations', valid: 'Validations & messages', auth: 'Authorization checks', tables: 'Tables / views / FMs', tests: 'Test scenarios', qa: 'Questions to requester' },
      sel: [P('WERKS', 'Plant', 1), P('BUKRS', 'Company code'), P('LGORT', 'Storage location'), P('MATNR', 'Material (select-option)'), P('MTART', 'Material type'), P('MATKL', 'Material group'),
        P('LIFNR', 'Vendor'), P('EKORG', 'Purchasing organisation'), P('EKGRP', 'Purchasing group'), P('BUDAT', 'Posting date (range)'), P('BLDAT', 'Document date (range)'),
        P('AUFNR', 'Production / maintenance order'), P('KUNNR', 'Customer'), P('VKORG', 'Sales organisation'), P('VBELN', 'Sales / delivery / billing document'),
        P('P_VARI', 'ALV layout variant'), P('P_DETAIL', 'Radio: Summary / Detail'), P('P_DEL', 'Checkbox: include deleted / blocked'), P('P_FILE', 'Excel download path (optional)'), P('P_BG', 'Run in background')],
      out: [P('MATNR', 'Material'), P('MAKTX', 'Material description'), P('MEINS', 'Base unit of measure'), P('MENGE', 'Quantity'), P('WRBTR', 'Amount / value'), P('WAERS', 'Currency'),
        P('WERKS', 'Plant'), P('LGORT', 'Storage location'), P('LIFNR', 'Vendor'), P('NAME1', 'Vendor / customer name'), P('EBELN', 'PO number'), P('EBELP', 'PO item'),
        P('BUDAT', 'Posting date'), P('ICON', 'Status icon (traffic light)'), P('ERNAM', 'Created by'), P('REMARK', 'Remarks / status text')],
      logic: ['Date range handling (from / to, default = current month)', 'Exclude reversed / cancelled documents (reversal movement types)', 'Convert quantities to base unit of measure',
        'Currency conversion / value at moving average or standard price', 'Totals and sub-totals (group by plant / material / vendor)', 'Exception colouring (red = overdue, amber = due soon, green = OK)',
        'Default sorting and column order', 'Hotspot / double-click drill-down to standard transaction', 'Aging / bucket calculation (0-30, 31-60, 61-90, 90+ days)'],
      valid: ['Plant is mandatory', 'Date from must be <= date to', 'Message when no data is found', 'Confirm / limit when output is very large (e.g. > 50,000 rows)', 'Check material / vendor exists'],
      auth: ['S_TCODE - transaction code check', 'M_MATE_WRK - plant level (material)', 'M_BEST_WRK / M_BEST_EKO / M_BEST_EKG - purchasing', 'V_VBAK_VKO - sales organisation', 'F_BKPF_BUK - company code (FI)', 'S_PROGRAM - program group'],
      tests: ['No data found (empty output)', 'Large date range - check run time (SAT / ST05)', 'Reversal / cancellation documents excluded correctly', 'Materials with different units of measure', 'User without plant authorisation',
        'Variant save / load works', 'Excel download opens without error', 'Totals match standard report / table', 'Background job run (SM36 / SM37)'],
      qa: ['Who will use it and how often (daily / weekly / month-end)?', 'Which plant(s) / company code(s) must it cover?', 'Can a standard report (MB51, MB52, ME2M, ME2N...) already give this - what is missing?',
        'Which date is meant: posting date, document date or entry date?', 'Should reversed / cancelled documents be included?', 'Is a sample output Excel available? (ask for it)', 'Need totals, sub-totals, colours or drill-down?',
        'Download to Excel / PDF / email required?', 'Should it run in background and be mailed daily?', 'Who needs access (roles) and should some users see only their plant?'],
      checklistNew: ['Requirement understood & sample output Excel received', 'Tables, joins and selection logic identified', 'Selection screen designed', 'Data fetch coded (performance checked)', 'ALV layout, totals, hotspots done',
        'Authority checks and validations added', 'Unit tested with real data', 'Transport released to Quality', 'UAT sign-off from requester', 'Transport moved to Production', 'T-code created and documented in Register'],
      checklistChange: ['Backup of existing program taken (download + version)', 'Where-used list checked', 'Change done in Development', 'Regression tested (old output unchanged)', 'Transport to Quality & UAT', 'Moved to Production', 'Register updated'],
      devExtra: [{ k: 'variant', l: 'Standard variant name' }, { k: 'job', l: 'Background job (if any)' }]
    },
    screen: {
      label: 'Screen / Module Pool', icon: '\u{1F5A5}',
      intro: 'Custom transaction with screens (SE51), table controls / ALV grid, Z tables and a T-code.',
      labels: { sel: 'Input fields on screen', out: 'Buttons / outputs / table-control columns', logic: 'Process logic (PBO / PAI)', valid: 'Validations & messages', auth: 'Authorization checks', tables: 'Z-tables / standard tables', tests: 'Test scenarios', qa: 'Questions to requester' },
      sel: [P('Header fields', 'Document / gate pass number, date, plant', 1), P('Vendor / customer', 'F4 help + name display'), P('Vehicle number', 'Free text, upper case'), P('Item table control', 'Material, qty, UoM, remarks'), P('Remarks', 'Long text / free text'), P('Status', 'Dropdown / radio')],
      out: [P('SAVE', 'Save button'), P('DISPLAY / CHANGE mode', 'Toggle between display and edit'), P('PRINT', 'Print / smartform call'), P('DELETE ROW', 'Delete item'), P('F4 helps', 'Search help for key fields'), P('Status message', 'Success / error message')],
      logic: ['Number range for document number (SNRO)', 'Lock object so two users cannot edit the same document (ENQUEUE / DEQUEUE)', 'Header / item split into Z tables', 'Partial / full processing logic', 'Status flow (created -> approved -> closed)', 'Auto-fill fields from standard documents (PO / delivery)', 'Change log (who changed what and when)'],
      valid: ['Mandatory fields checked in PAI', 'Quantity cannot exceed open quantity', 'Duplicate document check', 'Date cannot be in the past', 'Confirmation pop-up before delete / save'],
      auth: ['Z authorization object for create / change / display', 'S_TCODE', 'Plant check on header'],
      tests: ['Create, save, display, change, delete', 'Two users on the same document (lock)', 'Mandatory field left blank', 'Scroll / many items in table control', 'Back / Exit / Cancel buttons', 'Number range exhausted or missing', 'Authorisation for display-only user'],
      qa: ['Exact fields on the screen and which are mandatory?', 'Master data source for F4 helps?', 'Who can create / change / approve (roles)?', 'Is printing needed after save (smartform)?', 'Is any approval step needed?', 'Which standard documents does it refer to (PO, delivery, order)?', 'Reports needed on this data (list, history)?', 'Screen layout sketch / existing paper format available?'],
      checklistNew: ['Requirement & screen sketch approved', 'Z tables designed (SE11) with keys and technical settings', 'Number range object created (SNRO)', 'Lock object created (SE11)', 'Screens & GUI status built (SE51 / SE41)', 'PBO / PAI logic coded', 'Search helps & validations done',
        'T-code created (SE93) and authorisation added', 'Unit tested', 'Quality / UAT', 'Production move (tables + number range + T-code)', 'Documentation added to Register'],
      checklistChange: ['Backup taken (program source, screens, GUI status, table structure screenshot)', 'Where-used checked', 'Change done in Development', 'Existing data tested after change (table append / conversion)', 'Quality / UAT', 'Production move', 'Register updated'],
      devExtra: [{ k: 'z_tables', l: 'Z tables used' }, { k: 'number_range', l: 'Number range object' }, { k: 'auth_object', l: 'Authorization object' }]
    },
    form: {
      label: 'Smartform / Form', icon: '\u{1F5A8}',
      intro: 'Print layouts: Smartforms, SAPscript or Adobe forms called from a driver program or output type (NACE).',
      labels: { sel: 'Print trigger / driver parameters', out: 'Form fields & blocks', logic: 'Form logic', valid: 'Checks', auth: 'Authorization', tables: 'Data sources', tests: 'Test scenarios', qa: 'Questions to requester' },
      sel: [P('NAST output type', 'Output type in NACE (e.g. NEU for PO, LD00 for delivery)'), P('Document number', 'PO / delivery / invoice / order number'), P('Copies', 'Original / duplicate / triplicate'), P('Language', 'Print language'), P('Printer / spool', 'Default printer & print preview')],
      out: [P('Logo', 'Company logo (SE78)'), P('Header block', 'Company name, address, GSTIN, document no. and date'), P('Party block', 'Bill-to / ship-to / vendor details'), P('Item table', 'Item no., material, HSN, qty, unit, rate, amount'), P('Totals', 'Taxable value, GST split, grand total'),
        P('Amount in words', 'Function module SPELL_AMOUNT / custom'), P('Terms & conditions', 'Standard text (SO10) or fixed text'), P('Barcode / QR', 'Barcode or QR code (SE73 / SAP barcode)'), P('Footer', 'Signature, page number, copy label')],
      logic: ['Page break / item overflow on a second page', 'Original / duplicate / triplicate copy label', 'Conditional blocks (print only if field is filled)', 'Text elements read from SO10 / long text (READ_TEXT)', 'Totals / tax calculation', 'Amount in words'],
      valid: ['Print only for released / approved documents', 'No print if mandatory data is missing', 'Prevent duplicate print (or mark as duplicate)'],
      auth: ['Output type authorisation (NACE)', 'S_SPO_DEV printer access'],
      tests: ['One-page and multi-page document', 'Long text / long description overflow', 'Item with zero value / free item', 'Different currency and language', 'Print preview vs actual printer (A4, margins)', 'Reprint / duplicate copy', 'Other plant / company code'],
      qa: ['Existing paper format / old output to match?', 'Which logo, address, GSTIN, bank details?', 'How many copies and labels (Original for Recipient...)?', 'Paper size and orientation?', 'Barcode / QR code needed?', 'Which output type or T-code triggers the print?', 'Language(s) required?', 'Any fields which must be hidden when empty?'],
      checklistNew: ['Existing / paper format received', 'Data sources identified (driver program fields)', 'Form layout built (pages, windows, tables)', 'Driver / print program coded or changed', 'Output type & output determination (NACE) set', 'Tested with print preview', 'Tested on actual printer', 'Quality / UAT sign-off', 'Moved to Production', 'Registered with form name & output type'],
      checklistChange: ['Backup of existing form downloaded (XML) before change', 'Backup of driver program taken', 'Change done in Development', 'Print tested for old documents (no layout break)', 'Quality / UAT', 'Production move', 'Register updated'],
      devExtra: [{ k: 'form_name', l: 'Form name (Smartform / SAPscript)' }, { k: 'driver', l: 'Driver / print program' }, { k: 'output_type', l: 'Output type (NACE)' }, { k: 'paper', l: 'Paper size / printer' }]
    },
    bdc: {
      label: 'BDC / Upload', icon: '\u{1F4E4}',
      intro: 'Mass upload from Excel / text file using BDC, BAPI or LSMW with an error log.',
      labels: { sel: 'Upload selection screen', out: 'Excel template columns', logic: 'Upload logic', valid: 'Validations before upload', auth: 'Authorization', tables: 'Transactions / BAPIs / FMs', tests: 'Test scenarios', qa: 'Questions to requester' },
      sel: [P('P_FILE', 'Excel / text file path (F4 file dialog)', 1), P('P_TEST', 'Test run (validate only, no posting)'), P('P_MODE', 'Call transaction mode: A / E / N'), P('P_SESS', 'Create batch session instead of direct update'), P('P_HDR', 'Skip header row')],
      out: [P('Key field', 'Material / vendor / PO number'), P('Plant', 'Plant / org data'), P('Value fields', 'Fields to be created or changed'), P('STATUS', 'Result: success / error'), P('MESSAGE', 'SAP message text from log'), P('DOC_NO', 'Document / object created')],
      logic: ['Read Excel (ALSM_EXCEL_TO_INTERNAL_TABLE / CL_GUI_FRONTEND_SERVICES / TEXT_CONVERT_XLS_TO_SAP)', 'Convert data (conversion exits: ALPHA, units, dates, amounts)', 'Prefer BAPI over recorded BDC when a BAPI exists (stable, returns messages)', 'Method: CALL TRANSACTION USING (modes A / E / N, update S / A) or session (BDC_OPEN_GROUP / BDC_INSERT / BDC_CLOSE_GROUP)',
        'Collect messages (BDCMSGCOLL, FORMAT_MESSAGE) per row', 'Commit / rollback per record (BAPI_TRANSACTION_COMMIT)', 'Download error list to Excel for correction', 'Restart-able: upload only failed rows next time'],
      valid: ['File exists and extension is correct', 'Mandatory columns not empty', 'Master data exists (material, vendor, plant)', 'Duplicate key rows in the same file', 'Test run before real run', 'Limit on file rows per run'],
      auth: ['S_GUI - file upload / download', 'Authority of the transaction used (e.g. MM01 object M_MATE_WRK)'],
      tests: ['5-record test file first', 'Record with an error in the middle (others still post)', 'Empty cells / spaces / leading zeros', 'Decimal separator and date format (DD.MM.YYYY vs Excel date)', 'Full file volume', 'Run again with only the failed rows', 'Authorisation of the executing user'],
      qa: ['Which transaction / BAPI does the user do manually today?', 'Exact Excel template columns - which are mandatory?', 'How many records per upload?', 'What should happen on error (skip row, stop, partial post)?', 'Is a test / simulation run needed?', 'Who will run this and how often?', 'Do values need conversion (units, date formats, leading zeros)?', 'Is an approval or log of uploaded data required?'],
      checklistNew: ['Manual process understood (screens / fields)', 'Recording done (SHDB) or BAPI chosen', 'Excel template finalised and shared', 'File read & conversion coded', 'Validation and test run coded', 'Posting with message capture coded', 'Error log download added', 'Tested with 5 records', 'Tested with full file', 'Quality / UAT', 'Production move', 'Registered with template file'],
      checklistChange: ['Backup of program taken', 'Template change communicated to users', 'Change done in Development', 'Regression test with old template', 'Quality / UAT', 'Production move', 'Register updated'],
      devExtra: [{ k: 'method', l: 'Method (BAPI / Call transaction / Session / LSMW)' }, { k: 'bapi', l: 'BAPI / transaction used' }, { k: 'template', l: 'Excel template file name' }]
    },
    enhancement: {
      label: 'Enhancement / Exit', icon: '\u{1F9E9}',
      intro: 'Change in standard SAP behaviour using user exit, customer exit, BAdI or enhancement spot.',
      labels: { sel: 'Trigger / process (where it should act)', out: 'Expected behaviour', logic: 'Enhancement logic', valid: 'Error / warning messages', auth: 'Authorization', tables: 'Exit / BAdI / include used', tests: 'Test scenarios', qa: 'Questions to requester' },
      sel: [P('T-code / process', 'Where the user works (ME21N, MIGO, VL02N, CO01...)', 1), P('Event', 'On save / on field entry / on release / on print'), P('Plant / document type', 'Condition when the logic applies'), P('Users / roles', 'Who is affected')],
      out: [P('Block / error', 'Stop the transaction with an error message'), P('Warning', 'Allow but warn the user'), P('Auto-fill', 'Default / derive a field value'), P('Extra field', 'Custom field on standard screen (append / subscreen)'), P('Mail / log', 'Send an email or write a log')],
      logic: ['Find the exit: SE84, SMOD / CMOD, SE18 (BAdI), SE19, search "CALL CUSTOMER-FUNCTION" or CL_EXITHANDLER=>GET_INSTANCE in the standard program', 'Implement with the smallest possible code; no COMMIT WORK inside standard flow', 'Use a switch / TVARVC / Z-table for plant-wise activation', 'Keep behaviour identical for all other cases'],
      valid: ['Clear message text with document and item', 'Do not block background / interface updates unintentionally (check sy-batch, sy-binpt)'],
      auth: ['No new authorisation normally; check S_TCODE of the base transaction'],
      tests: ['Positive case (logic should act)', 'Negative case (normal documents unchanged)', 'Create, change and display modes', 'Via BAPI / BDC / IDoc (exit also fires there)', 'Different plants / document types', 'Performance impact on large documents'],
      qa: ['In which transaction and at which step exactly?', 'Exact condition (plant, document type, vendor...)?', 'Error or warning - who can override?', 'Should it also apply to uploads / interfaces?', 'Should it be switched off for some plant or user?', 'Is a standard SAP configuration (customizing) option possible instead?'],
      checklistNew: ['Exit / BAdI identified and documented', 'Impact on other processes assessed', 'Enhancement implementation created', 'Logic coded & activated', 'Tested positive and negative cases', 'Tested via BAPI / BDC if relevant', 'Quality / UAT', 'Production move (check activation of the implementation)', 'Registered with exit name'],
      checklistChange: ['Backup of existing implementation source taken', 'Change done in Development', 'Regression test of standard flow', 'Quality / UAT', 'Production move', 'Register updated'],
      devExtra: [{ k: 'exit_name', l: 'Exit / BAdI / enhancement spot' }, { k: 'impl', l: 'Implementation / project name' }]
    },
    interface: {
      label: 'Interface', icon: '\u{1F517}',
      intro: 'Data exchange with other systems: file (AL11), IDoc, RFC, web service, OData.',
      labels: { sel: 'Interface parameters', out: 'Field mapping', logic: 'Processing logic', valid: 'Checks & error handling', auth: 'Authorization / security', tables: 'Objects used', tests: 'Test scenarios', qa: 'Questions to requester' },
      sel: [P('Direction', 'Inbound / outbound', 1), P('Channel', 'File / IDoc / RFC / SOAP / REST / OData'), P('Frequency', 'Real time / hourly / daily job'), P('File path', 'Application server directory (AL11) or SFTP'), P('Format', 'CSV / XML / JSON / fixed length'), P('Partner system', 'Name, owner and contact')],
      out: [P('Field mapping', 'Source field -> SAP field -> rule'), P('Header / item structure', 'Segments or records'), P('Status field', 'Processed / error / pending'), P('Acknowledgement', 'Response back to partner')],
      logic: ['Scheduling through SM36 / SM37 background job', 'Archive processed files (move to /archive)', 'Retry for failed records', 'Application log (SLG1) for each run', 'Error mail to owner', 'Idempotency: no double posting of the same record'],
      valid: ['File / record format check', 'Master data existence check', 'Duplicate check', 'Size limit'],
      auth: ['Technical user with minimum roles', 'Directory access (S_DATASET)', 'RFC destination (SM59) security'],
      tests: ['Valid file', 'Wrong format / missing field', 'Empty file', 'Duplicate file', 'Large file', 'Partner system down (retry)', 'Re-processing of failed records'],
      qa: ['Who owns the partner system and what is the test setup?', 'Exact format and sample file?', 'Frequency and expected volume?', 'Error handling and who gets notified?', 'Security (VPN, SFTP, credentials)?', 'Is acknowledgement required?'],
      checklistNew: ['Interface specification signed off', 'Connectivity and directories set up', 'Mapping coded', 'Error handling and logging done', 'Job scheduled in Development / Quality', 'End-to-end test with partner', 'Production move & job scheduling', 'Monitoring / support document handed over'],
      checklistChange: ['Backup of program and mapping taken', 'Partner informed about the change', 'Change done in Development', 'End-to-end regression test', 'Quality / UAT', 'Production move', 'Register updated'],
      devExtra: [{ k: 'channel', l: 'Channel / protocol' }, { k: 'path', l: 'Directory / endpoint' }, { k: 'job', l: 'Job name & schedule' }]
    },
    issue: {
      label: 'Issue / Bug Fix', icon: '\u{1F41E}',
      intro: 'Something is wrong in an existing program, report, form or data. Find root cause, fix, retest.',
      labels: { sel: 'Where it happens (T-code / program / screen)', out: 'Expected vs actual result', logic: 'Root cause / analysis', valid: 'Fix applied', auth: 'Impact / authorisation notes', tables: 'Objects / tables involved', tests: 'Retest scenarios', qa: 'Questions to requester' },
      sel: [P('T-code / program', 'Where the problem occurs', 1), P('Document number(s)', 'Example documents where it fails'), P('User & date / time', 'Who got the error and when'), P('Error message / dump', 'Message number or ST22 short dump text'), P('Since when', 'First noticed / after which transport')],
      out: [P('Expected result', 'What should happen'), P('Actual result', 'What happens now'), P('Screenshot', 'Screen with the error (upload image)')],
      logic: ['Reproduce the issue in Development / Quality', 'Debug (/h) or use ST22, SM21, SLG1, SAT to find the failing statement', 'Check recent transports (SE09 / STMS) for a change that caused it', 'Data problem or code problem? (check master / transaction data first)', 'Smallest possible fix; no side effects'],
      valid: ['Fix verified with the same example documents', 'Related scenarios tested (regression)'],
      auth: ['Impact on other users / plants noted'],
      tests: ['Original failing scenario', 'Normal scenario still works', 'Boundary case (zero, blank, very large)', 'Different plant / user'],
      qa: ['Exact steps to reproduce and example document numbers?', 'Screenshot / message text?', 'Since when and does it happen for everyone?', 'Is it urgent (production stopped)? Is there a workaround?', 'Any recent change or transport before it started?'],
      checklistNew: ['Issue reproduced', 'Root cause found', 'Fix coded', 'Tested with the failing example', 'Regression test', 'Transport to Quality & confirmation from user', 'Moved to Production', 'Root cause & fix noted in Register'],
      checklistChange: ['Backup of current code (version / download)', 'Fix coded', 'Retested', 'Moved to Production'],
      devExtra: [{ k: 'root_cause', l: 'Root cause' }, { k: 'fix', l: 'Fix applied' }]
    },
    other: {
      label: 'Other', icon: '\u{1F4CC}',
      intro: 'Anything else: analysis, data correction, authorisation support, documentation, training.',
      labels: { sel: 'Inputs', out: 'Deliverables', logic: 'Approach / logic', valid: 'Checks', auth: 'Authorization', tables: 'Objects', tests: 'Test scenarios', qa: 'Questions' },
      sel: [], out: [P('Deliverable', 'What is to be handed over')], logic: ['Approach / steps'], valid: [], auth: [],
      tests: ['Verified with the requester'], qa: ['What exactly is expected and by when?', 'Who will verify the result?'],
      checklistNew: ['Requirement understood', 'Work done', 'Verified with requester', 'Documented'],
      checklistChange: ['Backup taken', 'Work done', 'Verified', 'Documented'], devExtra: []
    }
  };

  /* ------------------------------------------------------------------
     2. MODULE KNOWLEDGE - tables, T-codes, BAPIs, authorisation objects
     ------------------------------------------------------------------ */
  const modules = {
    MM: {
      name: 'Materials Management', hint: 'Purchasing, inventory, invoice verification, stores',
      tables: [T('MARA', 'Material master - general'), T('MARC', 'Material master - plant data'), T('MARD', 'Storage location stock'), T('MBEW', 'Material valuation (price, value)'), T('MAKT', 'Material descriptions'), T('MARM', 'Units of measure'),
        T('MKPF', 'Material document header'), T('MSEG', 'Material document item'), T('EKKO', 'PO header'), T('EKPO', 'PO item'), T('EKET', 'PO schedule lines'), T('EKBE', 'PO history (GR / IR)'), T('EKKN', 'PO account assignment'),
        T('EBAN', 'Purchase requisition'), T('EINA', 'Info record general'), T('EINE', 'Info record purchasing org'), T('EORD', 'Source list'), T('LFA1', 'Vendor general'), T('LFB1', 'Vendor company code'), T('LFM1', 'Vendor purchasing org'),
        T('RBKP', 'Invoice document header'), T('RSEG', 'Invoice document item'), T('RESB', 'Reservations / dependent requirements'), T('MCHB', 'Batch stock'), T('MCH1', 'Batch master'), T('MSKA', 'Sales order stock'), T('MSLB', 'Special stock at vendor'),
        T('IKPF', 'Physical inventory header'), T('ISEG', 'Physical inventory item'), T('T001W', 'Plants'), T('T001L', 'Storage locations'), T('T024', 'Purchasing groups'), T('T024E', 'Purchasing organisations'), T('T023T', 'Material group text'), T('T134T', 'Material type text')],
      tcodes: [T('MM01 / MM02 / MM03', 'Material create / change / display'), T('MB51', 'Material document list'), T('MB52', 'Warehouse stock of material'), T('MMBE', 'Stock overview'), T('MB5B', 'Stock on posting date'), T('MB5L', 'List of stock values'), T('MB5T', 'Stock in transit'),
        T('ME21N / ME22N / ME23N', 'PO create / change / display'), T('ME2M / ME2N / ME2L', 'PO list by material / PO number / vendor'), T('ME5A / ME5K', 'PR list'), T('ME51N', 'PR create'), T('ME31K / ME51N', 'Contract / PR'), T('ME11 / ME12', 'Info record'),
        T('MIGO', 'Goods receipt / issue / transfer'), T('MIRO', 'Invoice verification'), T('MB21 / MB22', 'Reservation create / change'), T('MB1A / MB1B / MB1C', 'Goods issue / transfer / other receipt (old)'), T('MI01 / MI04 / MI07', 'Physical inventory document / count / post'),
        T('MI20', 'Physical inventory differences list'), T('MD04', 'Stock / requirements list'), T('MRP: MD01 / MD02', 'MRP run'), T('ME28 / ME29N', 'PO release'), T('MRRL', 'ERS - evaluated receipt settlement'), T('MIR4 / MIR6', 'Invoice display / overview')],
      fms: [T('BAPI_PO_CREATE1', 'Create purchase order'), T('BAPI_PO_CHANGE', 'Change purchase order'), T('BAPI_PO_GETDETAIL1', 'Read PO'), T('BAPI_PR_CREATE', 'Create requisition'), T('BAPI_GOODSMVT_CREATE', 'Post goods movement'), T('BAPI_MATERIAL_SAVEDATA', 'Create / change material'),
        T('BAPI_MATERIAL_GET_DETAIL', 'Read material'), T('BAPI_INCOMINGINVOICE_CREATE', 'Post vendor invoice'), T('BAPI_RESERVATION_CREATE1', 'Create reservation'), T('BAPI_MATPHYSINV_CREATE_MULT', 'Physical inventory document'), T('MATERIAL_UNIT_CONVERSION', 'Unit conversion'), T('CONVERSION_EXIT_MATN1_OUTPUT', 'Material number formatting')],
      enh: [T('MM06E005', 'Customer exit - PO header / item (EXIT_SAPMM06E_012 / 016)'), T('MEREQ001', 'Customer exit - purchase requisition'), T('MBCF0002', 'Customer exit - goods movements (MB_CF001)'), T('ME_PROCESS_PO_CUST', 'BAdI - PO header / item checks'), T('ME_PROCESS_REQ_CUST', 'BAdI - PR checks'),
        T('MB_MIGO_BADI', 'BAdI - MIGO checks and fields'), T('MB_DOCUMENT_BADI', 'BAdI - material document update'), T('ME_GUI_PO_CUST', 'BAdI - custom tab on PO screen'), T('MRM_INVOICE_UPDATE', 'BAdI - invoice update')],
      auth: ['M_MATE_WRK (plant)', 'M_MATE_MAR (material type)', 'M_BEST_WRK (PO plant)', 'M_BEST_EKO (purch. org)', 'M_BEST_EKG (purch. group)', 'M_MSEG_BWA (movement type)', 'M_MSEG_WMB (plant for goods movement)', 'M_RECH_WRK (invoice verification plant)'],
      notes: ['Movement types: 101 GR, 102 GR reversal, 122 return to vendor, 201 issue to cost center, 261 issue to order, 262 reversal, 301 plant transfer, 311 sloc transfer, 551 scrap, 701 / 702 inventory difference.',
        'Cancel a GR with 102: exclude both the 101 and the 102 (check MSEG-SMBLN / SJAHR for reversal reference).', 'In S/4HANA stock is in MATDOC (MSEG/MKPF are compatibility views) and MARD-type tables are views - verify in SE11.', 'Use FOR ALL ENTRIES only after checking the driver table is not empty.']
    },
    PP: {
      name: 'Production Planning', hint: 'Production orders, BOM, routing, MRP, shop floor',
      tables: [T('AUFK', 'Order master data'), T('AFKO', 'Order header (dates, quantities)'), T('AFPO', 'Order item (material, plan qty, delivered qty)'), T('AFVC', 'Operation'), T('AFVV', 'Operation quantities / dates'), T('AFRU', 'Order confirmations'), T('RESB', 'Reservations / components'),
        T('STKO', 'BOM header'), T('STPO', 'BOM item'), T('MAST', 'Material to BOM link'), T('STAS', 'BOM - item selection'), T('PLKO', 'Routing header'), T('PLPO', 'Routing operations'), T('MAPL', 'Routing to material link'), T('MKAL', 'Production versions'),
        T('PLAF', 'Planned orders'), T('CRHD', 'Work centre header'), T('CRCO', 'Work centre cost center link'), T('JEST', 'Object status (STAT, INACT)'), T('TJ02T', 'Status text'), T('AUFM', 'Goods movements for order (ECC)'), T('MDKP / MDTB', 'MRP header / table')],
      tcodes: [T('CO01 / CO02 / CO03', 'Production order create / change / display'), T('COOIS', 'Order information system'), T('CO15', 'Confirm production order'), T('CORK', 'Confirm process order'), T('CO11N', 'Time ticket confirmation'), T('MFBF', 'Backflush'), T('COGI', 'Goods movements with errors'),
        T('COHV', 'Mass processing of orders'), T('CO24', 'Missing parts info system'), T('CS01 / CS02 / CS03', 'BOM'), T('CS11 / CS12 / CS13', 'BOM explosion'), T('CS15', 'BOM where-used'), T('CA01 / CA02 / CA03', 'Routing'), T('CR01 / CR02 / CR03', 'Work centre'),
        T('MD04', 'Stock / requirement list'), T('MD01 / MD02', 'MRP run'), T('MD07', 'Stock / requirement overview'), T('MD61 / MD62', 'Planned independent requirements'), T('CM01', 'Capacity load'), T('CM21', 'Capacity planning')],
      fms: [T('BAPI_PRODORD_CREATE', 'Create production order'), T('BAPI_PRODORD_CHANGE', 'Change production order'), T('BAPI_PRODORD_RELEASE', 'Release order'), T('BAPI_PRODORDCONF_CREATE_TT', 'Confirm order (time ticket)'), T('CSAP_MAT_BOM_READ', 'Read material BOM'),
        T('CS_BOM_EXPL_MAT_V2', 'BOM explosion'), T('STATUS_CHECK', 'Check an object status'), T('CO_BC_RESBD_READ', 'Read order components')],
      enh: [T('CONFPP01', 'Customer exit - confirmations'), T('CONFPM05', 'Customer exit - confirmation (PM / PP)'), T('COOPCP01', 'Customer exit - capacity / order'), T('WORKORDER_UPDATE', 'BAdI - production order update'), T('WORKORDER_GOODSMVT', 'BAdI - goods movements of order'), T('CO_ORDER_CONF', 'BAdI - confirmation')],
      auth: ['C_AFKO_AWK (order type / plant)', 'C_STUE_WRK (BOM plant)', 'C_ROUT_WRK (routing plant)', 'C_CRAP_WRK (work centre)'],
      notes: ['Status check: JEST with OBJNR = AUFK-OBJNR, INACT = space. Common statuses: I0002 REL (released), I0009 CNF (confirmed), I0045 TECO, I0046 CLSD.',
        'Delay = basic finish (GLTRP) vs today or actual finish (GETRI); planned qty AFPO-PSMNG, delivered AFPO-WEMNG.', 'Component shortage: RESB-BDMNG (requirement) vs RESB-ENMNG (withdrawn); consider RESB-XLOEK (deleted) and RESB-KZEAR (final issue).',
        'Use the logical database CAUFVD or the view CAUFV for order header + item in a single select.']
    },
    SD: {
      name: 'Sales & Distribution', hint: 'Sales orders, deliveries, billing, dispatch, pricing',
      tables: [T('VBAK', 'Sales document header'), T('VBAP', 'Sales document item'), T('VBEP', 'Schedule lines'), T('VBUK / VBUP', 'Status header / item (ECC; merged into VBAK / VBAP in S/4)'), T('LIKP', 'Delivery header'), T('LIPS', 'Delivery item'), T('VBRK', 'Billing header'), T('VBRP', 'Billing item'),
        T('VBFA', 'Document flow'), T('VBPA', 'Partners'), T('KNA1', 'Customer general'), T('KNVV', 'Customer sales area'), T('KNB1', 'Customer company code'), T('KONV', 'Pricing conditions (ECC; PRCD_ELEMENTS in S/4)'), T('NAST', 'Output messages'), T('VTTK / VTTP', 'Shipment header / item'),
        T('TVAK', 'Sales document types'), T('A304 etc.', 'Condition tables (pricing)'), T('MARM', 'Units of measure')],
      tcodes: [T('VA01 / VA02 / VA03', 'Sales order'), T('VA05N', 'List of sales orders'), T('VL01N / VL02N / VL03N', 'Outbound delivery'), T('VL06O', 'Outbound delivery monitor'), T('VF01 / VF02 / VF03', 'Billing'), T('VF04', 'Billing due list'),
        T('VK11 / VK12', 'Condition record'), T('NACE', 'Output determination'), T('V/08', 'Pricing procedure'), T('VOFM', 'Routines'), T('XD01 / XD02', 'Customer master'), T('VT01N', 'Shipment'), T('MD04', 'Availability')],
      fms: [T('BAPI_SALESORDER_CREATEFROMDAT2', 'Create sales order'), T('BAPI_SALESORDER_CHANGE', 'Change sales order'), T('BAPI_OUTB_DELIVERY_CHANGE', 'Change delivery'), T('BAPI_BILLINGDOC_CREATEMULTIPLE', 'Create billing'), T('BAPI_SALESORDER_GETLIST', 'List of sales orders'), T('SD_VBAP_READ', 'Read item (select)')],
      enh: [T('MV45AFZZ', 'User exits in sales order (include)'), T('USEREXIT_SAVE_DOCUMENT_PREPARE', 'Sales order save'), T('RV60AFZZ', 'Billing user exits'), T('LV50C', 'Delivery user exits'), T('BADI_SD_BILLING', 'BAdI billing'), T('LE_SHP_DELIVERY_PROC', 'BAdI delivery processing')],
      auth: ['V_VBAK_VKO (sales organisation)', 'V_VBAK_AAT (sales document type)', 'V_VBRK_VKO (billing)', 'V_LIKP_VST (shipping point)'],
      notes: ['Pending sales order = ordered qty (VBAP-KWMENG) - delivered qty (from VBFA / LIPS); consider rejection reasons (ABGRU) and delivery block.', 'Document flow: VBFA with VBELV / VBELN, VBTYP_N (J delivery, M invoice, C order).', 'GST: HSN code in MARC-STEUC, tax conditions in KONV (JOIG / JOCG / JOSG).']
    },
    FI: {
      name: 'Finance', hint: 'GL, AP, AR, assets, taxes',
      tables: [T('BKPF', 'Accounting document header'), T('BSEG', 'Accounting document item (cluster in ECC)'), T('BSIK / BSAK', 'Vendor open / cleared items'), T('BSID / BSAD', 'Customer open / cleared items'), T('BSIS / BSAS', 'GL open / cleared items'), T('LFA1 / LFB1', 'Vendor master'), T('KNA1 / KNB1', 'Customer master'),
        T('SKA1 / SKAT', 'GL account master / text'), T('SKB1', 'GL company code'), T('T001', 'Company codes'), T('ANLA / ANLZ / ANLC', 'Asset master / time-dep / values'), T('ANEP / ANEK', 'Asset line items'), T('FAGLFLEXA', 'New GL line items (ECC)'), T('ACDOCA', 'Universal journal (S/4)'), T('REGUH / REGUP', 'Payment run data'), T('J_1IG_HSN_SAC', 'India HSN master')],
      tcodes: [T('FB01 / FB03', 'Post / display document'), T('F-02 / F-43 / F-53', 'GL / vendor invoice / vendor payment'), T('FBL1N / FBL3N / FBL5N', 'Vendor / GL / customer line items'), T('FAGLB03 / FS10N', 'GL balances'), T('F110', 'Payment run'), T('F.01', 'Financial statements'),
        T('AS01 / AS03', 'Asset master'), T('ABAWN / AFAB', 'Asset sale / depreciation run'), T('FBV0', 'Park document release'), T('MIRO / MR8M', 'Invoice / cancel invoice'), T('J1IG', 'India GST (system-specific)')],
      fms: [T('BAPI_ACC_DOCUMENT_POST', 'Post accounting document'), T('BAPI_ACC_DOCUMENT_REV_POST', 'Reverse document'), T('BAPI_VENDOR_GETDETAIL', 'Read vendor'), T('BAPI_CUSTOMER_GETDETAIL2', 'Read customer'), T('BAPI_ASSET_ACQUISITION_POST', 'Asset acquisition'), T('CONVERT_TO_LOCAL_CURRENCY', 'Currency conversion'), T('SPELL_AMOUNT', 'Amount in words')],
      enh: [T('F_BKPF_BUK checks', 'Company code authorisation'), T('BADI_ACC_DOCUMENT', 'BAdI - accounting document'), T('FIEB0001 etc.', 'FI substitutions / validations (OB28 / OBBH)'), T('GGB0 / GGB1', 'Validations & substitutions'), T('BADI_FDCB_SUBBAS01', 'BAdI - cash management')],
      auth: ['F_BKPF_BUK (company code)', 'F_BKPF_KOA (account type)', 'F_BKPF_GSB (business area)', 'F_LFA1_BUK (vendor company code)'],
      notes: ['BSEG is a cluster table in ECC - avoid joins; use secondary index tables (BSIK / BSAK etc.) or BSEG with BELNR / GJAHR / BUKRS keys.', 'Vendor ageing: use due date = baseline date + payment terms (ZBD1T etc.).', 'Debit / credit: BSEG-SHKZG (S / H), amounts in BSEG-DMBTR (local) and WRBTR (document currency).']
    },
    CO: {
      name: 'Controlling', hint: 'Cost centers, internal orders, product costing',
      tables: [T('CSKS / CSKT', 'Cost centre master / text'), T('COBK', 'CO document header'), T('COEP', 'CO line items'), T('COSP / COSS', 'Totals - primary / secondary'), T('AUFK', 'Internal order master'), T('CSKA / CSKB', 'Cost element master'), T('CKMLHD / CKMLCR', 'Material ledger'), T('KEKO / KEPH', 'Product costing header / items'), T('CSSL', 'Cost centre and activity type')],
      tcodes: [T('KS01 / KS03', 'Cost centre'), T('KSB1', 'Cost centre line items'), T('KOB1', 'Order line items'), T('KO88', 'Order settlement'), T('KKBC_ORD', 'Order analysis'), T('CK11N / CK13N', 'Product cost estimate'), T('CO88', 'Production order settlement'), T('KSS2 / KSU5', 'Allocation cycles'), T('S_ALR_87013611', 'Cost centre actual / plan report')],
      fms: [T('BAPI_ACC_ACT_POSTINGS_POST', 'Post activity allocation'), T('BAPI_COSTCENTER_GETDETAIL', 'Read cost centre'), T('BAPI_INTERNALORDER_GETDETAIL', 'Read internal order')],
      enh: [T('COOMKO01 etc.', 'Customer exits in CO'), T('COOPA001', 'Exit - order'), T('KKR_CHANGE_ORDER', 'Exit - settlement')],
      auth: ['K_CCA (cost centre)', 'K_ORDER (orders)', 'K_CSKS (master data)'], notes: ['Production order cost: COEP with OBJNR of the order; plan vs actual via COSP / COSS versions (WRTTP 01 plan, 04 actual).']
    },
    QM: {
      name: 'Quality Management', hint: 'Inspection lots, usage decision, notifications, certificates',
      tables: [T('QALS', 'Inspection lot'), T('QAVE', 'Usage decision'), T('QAMV', 'Inspection characteristics'), T('QAMR', 'Characteristic results'), T('QASR', 'Sample results'), T('QMEL', 'Quality notification'), T('QMFE', 'Notification item defects'), T('MAPL / PLMK', 'Inspection plan / characteristics'),
        T('QPMK', 'Master inspection characteristic'), T('QPCD / QPCT', 'Code groups'), T('QMAT', 'Inspection type for material'), T('MARC-QMATV', 'QM active flag (plant data)')],
      tcodes: [T('QA01 / QA02 / QA03', 'Inspection lot'), T('QA32', 'Inspection lot list'), T('QE01 / QE11 / QE51N', 'Results recording'), T('QA11', 'Usage decision'), T('QM01 / QM02 / QM03', 'Quality notification'), T('QP01 / QP02', 'Inspection plan'), T('QS21 / QS23', 'Master inspection characteristic'), T('QGC1', 'Code group')],
      fms: [T('BAPI_INSPLOT_GETLIST', 'List of inspection lots'), T('BAPI_INSPOPER_GETDETAIL', 'Inspection operation detail'), T('BAPI_QUALNOT_CREATE', 'Create quality notification'), T('QRKA... exits', 'Result calculations')],
      enh: [T('QEVA0001', 'Exit - usage decision'), T('QPAK0001 etc.', 'Exits - quality tasks'), T('QQMA0014', 'Notification exit'), T('QEEM0007', 'Exit - results recording')],
      auth: ['Q_INSPLOT', 'Q_MATERIAL', 'Q_QMEL'], notes: ['COA (certificate of analysis) normally pulls QAMV / QAMR results for a batch (MCH1) - keep characteristic order and units.']
    },
    PM: {
      name: 'Plant Maintenance', hint: 'Equipment, functional locations, notifications, maintenance orders',
      tables: [T('EQUI / EQKT', 'Equipment / text'), T('IFLOT / IFLOTX', 'Functional location'), T('QMEL / VIQMEL', 'PM notification'), T('AUFK / AFIH', 'Maintenance order'), T('AFVC', 'Operations'), T('RESB', 'Order components (spares)'), T('MPOS / MPLA', 'Maintenance item / plan'), T('MHIS', 'Maintenance plan history'),
        T('IHPA', 'Partners'), T('OBJK', 'Object list'), T('JEST', 'Status'), T('IMPTT / MIMPT', 'Measuring points / documents'), T('ILOA', 'Location & account assignment')],
      tcodes: [T('IW21 / IW22 / IW23', 'PM notification'), T('IW31 / IW32 / IW33', 'Maintenance order'), T('IW28 / IW29', 'Notification list'), T('IW38 / IW39', 'Order list'), T('IE01 / IE02 / IE03', 'Equipment'), T('IL01 / IL02', 'Functional location'), T('IP10 / IP30', 'Scheduling of maintenance plan'), T('IK11 / IK22', 'Measuring point / document')],
      fms: [T('BAPI_ALM_ORDER_MAINTAIN', 'Create / change maintenance order'), T('BAPI_ALM_NOTIF_CREATE', 'Create notification'), T('BAPI_EQUI_GETDETAIL', 'Read equipment'), T('BAPI_FUNCLOC_GETDETAIL', 'Read functional location')],
      enh: [T('IWO10009', 'Exit - order'), T('IQS00001 etc.', 'Exit - notification'), T('IPW10001', 'Exit - maintenance plan'), T('WORKORDER_UPDATE', 'BAdI - order update')],
      auth: ['I_IWERK (planning plant)', 'I_TCODE', 'I_SWERK (maintenance plant)'], notes: ['Breakdown history: notification type M2 (breakdown) with malfunction start / end (QMEL-AUSVN / AUZTV...) - verify fields.', 'Spare consumption = RESB / MSEG with order number AUFNR.']
    },
    WM: {
      name: 'Warehouse / Stores', hint: 'Bins, transfer orders, stock placement',
      tables: [T('LAGP', 'Storage bins'), T('LQUA', 'Quants'), T('LTAK / LTAP', 'Transfer order header / item'), T('LTBK / LTBP', 'Transfer requirement'), T('T300', 'Warehouse numbers'), T('T301', 'Storage types'), T('MLGN / MLGT', 'Material warehouse data')],
      tcodes: [T('LT01 / LT03', 'Create TO'), T('LT21', 'TO list'), T('LS24 / LX02', 'Stock per material / bin'), T('LX03', 'Bin status'), T('LS01N', 'Bin master'), T('LI01N / LI11N', 'WM physical inventory')],
      fms: [T('L_TO_CREATE_SINGLE', 'Create TO'), T('BAPI_WHSE_STOCK_GET_LIST', 'Warehouse stock')], enh: [T('MWMTO001 etc.', 'WM exits')], auth: ['L_LGNUM (warehouse)', 'L_BWLVS (movement type)'], notes: []
    },
    HR: {
      name: 'HR / Payroll (basic)', hint: 'Employee, attendance, payroll data',
      tables: [T('PA0000', 'Actions'), T('PA0001', 'Organisational assignment'), T('PA0002', 'Personal data'), T('PA0008', 'Basic pay'), T('PA2001 / PA2002', 'Absences / attendance'), T('PCL1 / PCL2', 'Time / payroll clusters'), T('T001P', 'Personnel area / subarea')],
      tcodes: [T('PA20 / PA30', 'Display / maintain HR master'), T('PT60 / PT_BAL00', 'Time evaluation / balances'), T('PC00_M40_CALC', 'Payroll (India)'), T('PA10', 'Personnel file')],
      fms: [T('HR_READ_INFOTYPE', 'Read infotype'), T('BAPI_EMPLOYEE_GETDATA', 'Employee data')], enh: [T('PBAS0001', 'Exit - HR master')],
      auth: ['P_ORGIN', 'P_ORGXX'], notes: ['Always apply HR authorisation checks - personal data. Use logical database PNP / PNPCE with PROVIDE ... ENDPROVIDE.']
    },
    GEN: {
      name: 'Cross-module / Basis', hint: 'Transports, change documents, users, dictionary',
      tables: [T('CDHDR / CDPOS', 'Change document header / items'), T('USR02', 'User master (logon data)'), T('AGR_USERS / AGR_1251', 'User roles / role authorisations'), T('TSTC / TSTCT', 'Transaction codes / text'), T('TADIR', 'Repository objects'), T('E070 / E071', 'Transport requests / objects'),
        T('DD03L / DD04T', 'Dictionary fields / data element text'), T('TVARVC', 'Variables for selections'), T('T000', 'Clients'), T('NRIV', 'Number range intervals'), T('TBTCO / TBTCP', 'Background jobs'), T('BALHDR / BALDAT', 'Application log')],
      tcodes: [T('SE11', 'Dictionary'), T('SE16N', 'Table browser'), T('SE38 / SE80', 'Editor / Object navigator'), T('SE37 / SE24', 'Function builder / Class builder'), T('SE41 / SE51 / SE93', 'GUI status / Screen / T-code'), T('SMARTFORMS / SE71 / SFP', 'Forms'),
        T('SE09 / SE10 / STMS', 'Transports'), T('ST22 / SM21 / SLG1', 'Dumps / system log / application log'), T('SAT / ST05 / SE30', 'Runtime & SQL trace'), T('SM36 / SM37', 'Schedule / monitor jobs'), T('SNRO', 'Number ranges'), T('SM30 / SE54', 'Table maintenance'),
        T('SU01 / PFCG / SU53', 'Users / roles / failed authorisation'), T('SO10 / SE75', 'Standard texts'), T('AL11 / AL12', 'Application server files'), T('SE18 / SE19 / SE84', 'BAdI / enhancement search')],
      fms: [T('GUI_UPLOAD / GUI_DOWNLOAD', 'Local file transfer'), T('ALSM_EXCEL_TO_INTERNAL_TABLE', 'Read Excel'), T('REUSE_ALV_GRID_DISPLAY / CL_SALV_TABLE', 'ALV output'), T('POPUP_TO_CONFIRM', 'Confirmation pop-up'), T('F4IF_INT_TABLE_VALUE_REQUEST', 'Custom F4'), T('READ_TEXT / SAVE_TEXT', 'Long text'),
        T('SSF_FUNCTION_MODULE_NAME', 'Smartform FM name'), T('SO_NEW_DOCUMENT_SEND_API1 / CL_BCS', 'Send email'), T('NUMBER_GET_NEXT', 'Number range'), T('ENQUEUE_* / DEQUEUE_*', 'Lock object FMs'), T('CHANGEDOCUMENT_READ_HEADERS', 'Read change docs'), T('DATE_GET_WEEK / RP_CALC_DATE_IN_INTERVAL', 'Date helpers')],
      enh: [T('SE18 / SE19', 'BAdI definition / implementation'), T('CMOD / SMOD', 'Customer exit projects'), T('SE80 > Enhancement', 'Implicit / explicit enhancements'), T('SPAU / SPDD', 'Upgrade adjustment')],
      auth: ['S_TCODE', 'S_PROGRAM', 'S_GUI', 'S_DATASET', 'S_TABU_DIS (table display)', 'S_DEVELOP (developer)'], notes: []
    }
  };

  /* ------------------------------------------------------------------
     3. IDEA / TEMPLATE LIBRARY - typical manufacturing company asks.
        "Use template" pre-fills the new task form.
     ------------------------------------------------------------------ */
  const tpl = (module, type, title, summary, extra) => Object.assign({ module: module, type: type, title: title, summary: summary, complexity: 'medium' }, extra || {});
  const templates = [
    /* ---------- MM ---------- */
    tpl('MM', 'report', 'Stock Ageing Report', 'Plant / storage-location wise stock with ageing buckets from last goods-receipt date and stock value.', {
      sel: ['WERKS:Plant:1', 'LGORT:Storage location', 'MATNR:Material', 'MTART:Material type', 'P_VARI:Layout'], out: ['MATNR:Material', 'MAKTX:Description', 'LABST:Unrestricted stock', 'AGE_0_30:0-30 days', 'AGE_31_60:31-60 days', 'AGE_61_90:61-90 days', 'AGE_90P:Above 90 days', 'STOCK_VAL:Stock value'],
      tables: ['MARD', 'MBEW', 'MSEG', 'MKPF', 'MAKT'], logic: ['Age = today - last GR date (movement 101 / 501 / 561, excluding reversals)', 'Value = stock x moving average / standard price'], hours: 14
    }),
    tpl('MM', 'report', 'GRN Register', 'Date-wise goods receipt register with PO, vendor, challan / invoice number and value.', {
      sel: ['WERKS:Plant:1', 'BUDAT:Posting date:1', 'LIFNR:Vendor', 'EBELN:PO number', 'MATNR:Material'], out: ['MBLNR:Material document', 'BUDAT:Posting date', 'EBELN:PO', 'LIFNR:Vendor', 'NAME1:Vendor name', 'MATNR:Material', 'MENGE:Quantity', 'XBLNR:Challan / invoice no.', 'DMBTR:Value'],
      tables: ['MKPF', 'MSEG', 'EKKO', 'EKPO', 'LFA1', 'MAKT'], logic: ['Movement types 101 (and 102 reversal excluded / shown negative)', 'Vendor name from LFA1 through MSEG-LIFNR or EKKO-LIFNR'], hours: 12
    }),
    tpl('MM', 'report', 'Open / Pending PO Report', 'Purchase orders with pending quantity, delivery date, delay in days and vendor.', {
      sel: ['EKORG:Purchasing org', 'WERKS:Plant', 'LIFNR:Vendor', 'EKGRP:Purchasing group', 'BEDAT:PO date'], out: ['EBELN:PO', 'EBELP:Item', 'MATNR:Material', 'MENGE:PO qty', 'WEMNG:GR qty', 'PENDING:Pending qty', 'EINDT:Delivery date', 'DELAY:Delay days', 'ICON:Status'],
      tables: ['EKKO', 'EKPO', 'EKET', 'EKBE', 'LFA1'], logic: ['Pending = EKET-MENGE - EKET-WEMNG (or sum from EKBE)', 'Exclude deleted items (LOEKZ), finally delivered (ELIKZ)', 'Colour: red delay > 0, amber due within 3 days'], hours: 14
    }),
    tpl('MM', 'report', 'PR - PO - GRN - Invoice Tracking', 'Full procurement trail of a requisition: PR, PO, GRN, invoice and payment status in one list.', {
      sel: ['WERKS:Plant:1', 'BADAT:PR date', 'MATNR:Material', 'EKGRP:Purchasing group'], out: ['BANFN:PR', 'EBELN:PO', 'MBLNR:GRN', 'BELNR:Invoice', 'STATUS:Stage'], tables: ['EBAN', 'EKPO', 'EKBE', 'RSEG', 'RBKP'], logic: ['Link PR -> PO via EKPO-BANFN / BNFPO', 'GR and IR from EKBE (VGABE 1 / 2)'], complexity: 'complex', hours: 24
    }),
    tpl('MM', 'report', 'Slow / Non-moving Stock Report', 'Materials with no consumption for N days, with stock value and last movement date.', {
      sel: ['WERKS:Plant:1', 'MTART:Material type', 'DAYS:No-movement days:1'], out: ['MATNR:Material', 'MAKTX:Description', 'LABST:Stock', 'LAST_MOVE:Last movement date', 'STOCK_VAL:Value'], tables: ['MARD', 'MBEW', 'MSEG', 'MKPF'], logic: ['Last movement = max BUDAT of consumption movement types (201, 261, 301...)'], hours: 12
    }),
    tpl('MM', 'report', 'Min / Max / Reorder Level Alert', 'Materials where stock is below reorder level or above maximum, with suggested order quantity.', {
      sel: ['WERKS:Plant:1', 'MATKL:Material group', 'DISMM:MRP type'], out: ['MATNR:Material', 'LABST:Stock', 'MINBE:Reorder point', 'EISBE:Safety stock', 'MABST:Max stock', 'SUGG:Suggested qty'], tables: ['MARC', 'MARD', 'MAKT', 'EKPO'], logic: ['Open PO qty added to available stock before comparing'], hours: 10
    }),
    tpl('MM', 'report', 'Material Consumption Report', 'Issue / consumption quantity and value by cost center, order or department for a period.', {
      sel: ['WERKS:Plant:1', 'BUDAT:Posting date:1', 'KOSTL:Cost center', 'AUFNR:Order', 'MATNR:Material'], out: ['MATNR:Material', 'KOSTL:Cost center', 'AUFNR:Order', 'MENGE:Quantity', 'DMBTR:Value'], tables: ['MSEG', 'MKPF', 'MAKT', 'CSKT'], logic: ['Movement types 201 / 261 net of 202 / 262 reversals'], hours: 12
    }),
    tpl('MM', 'report', 'Reservation Pending Report', 'Open reservations (maintenance / production) with requirement date, withdrawn qty and stock availability.', {
      sel: ['WERKS:Plant:1', 'BDTER:Requirement date', 'MATNR:Material'], out: ['RSNUM:Reservation', 'MATNR:Material', 'BDMNG:Required', 'ENMNG:Withdrawn', 'OPEN:Open qty', 'STOCK:Available stock'], tables: ['RESB', 'MARD', 'MAKT'], logic: ['Exclude deleted (XLOEK) and final issued (KZEAR)'], hours: 10
    }),
    tpl('MM', 'report', 'Physical Inventory Difference Report', 'Physical inventory count vs book quantity with value of difference for approval.', {
      sel: ['WERKS:Plant:1', 'LGORT:Storage location', 'GJAHR:Fiscal year', 'IBLNR:PI document'], out: ['IBLNR:PI doc', 'MATNR:Material', 'BUCHM:Book qty', 'MENGE:Counted qty', 'DIFF:Difference', 'DIFF_VAL:Difference value'], tables: ['IKPF', 'ISEG', 'MAKT', 'MBEW'], logic: ['Zero-count items flagged (XNZAE)'], hours: 10
    }),
    tpl('MM', 'screen', 'Gate Entry / Gate Pass (In & Out)', 'Custom gate pass transaction: inward / outward vehicle entry against PO or delivery with partial and full out logic and print.', {
      sel: ['GATE_NO:Gate pass number:1', 'WERKS:Plant:1', 'VEHICLE:Vehicle number:1', 'DOC_REF:PO / delivery reference', 'DRIVER:Driver name', 'QTY:Quantity'], out: ['SAVE:Save', 'PRINT:Gate pass print', 'GATE_OUT:Gate out (partial / full)'], tables: ['Z header table', 'Z item table', 'EKPO / LIPS'], logic: ['Number range for gate pass', 'Partial out reduces balance quantity; full out closes document', 'Block GR without gate entry (optional BAdI)'], complexity: 'complex', hours: 40
    }),
    tpl('MM', 'bdc', 'Material Master Upload (MM01 / MM02)', 'Create or extend materials from Excel (basic data, plant, storage, valuation).', {
      sel: ['P_FILE:Excel file:1', 'P_TEST:Test run'], out: ['MTART:Material type', 'MAKTX:Description', 'MEINS:Base UoM', 'MATKL:Material group', 'WERKS:Plant', 'LGORT:Storage location', 'STEUC:HSN code', 'STATUS:Result', 'MESSAGE:Message'], tables: ['BAPI_MATERIAL_SAVEDATA'], logic: ['Prefer BAPI_MATERIAL_SAVEDATA; commit per material', 'Material number via internal / external number range'], hours: 14
    }),
    tpl('MM', 'bdc', 'PO Upload from Excel', 'Mass creation of purchase orders using BAPI with item and price conditions.', {
      sel: ['P_FILE:Excel file:1', 'P_TEST:Test run'], out: ['LIFNR:Vendor', 'EKORG:Purch org', 'EKGRP:Purch group', 'MATNR:Material', 'MENGE:Quantity', 'NETPR:Price', 'EINDT:Delivery date', 'EBELN:PO created'], tables: ['BAPI_PO_CREATE1'], logic: ['Group Excel rows by PO header key', 'Return table analysed for each PO'], hours: 16
    }),
    tpl('MM', 'bdc', 'Goods Movement Upload (opening stock / transfer)', 'Upload stock or transfer postings with BAPI_GOODSMVT_CREATE.', {
      sel: ['P_FILE:Excel file:1', 'P_TEST:Test run'], out: ['BWART:Movement type', 'MATNR:Material', 'WERKS:Plant', 'LGORT:Storage location', 'MENGE:Quantity', 'CHARG:Batch', 'MBLNR:Document'], tables: ['BAPI_GOODSMVT_CREATE'], logic: ['Test run using BAPI testrun parameter'], hours: 14
    }),
    tpl('MM', 'form', 'Purchase Order Print (with GST)', 'PO smartform with GSTIN, HSN, tax split, terms and amount in words.', {
      sel: ['NEU:Output type', 'EBELN:PO number:1'], out: ['Logo', 'Vendor block', 'Item table with HSN', 'Tax totals', 'Amount in words', 'Terms & conditions'], tables: ['EKKO', 'EKPO', 'LFA1', 'T001W', 'KONV / PRCD_ELEMENTS'], logic: ['Terms from SO10 text', 'Page 2 header repeat'], hours: 16
    }),
    tpl('MM', 'form', 'GRN Print / Material Receipt Slip', 'Print of goods receipt with PO, vendor, quantities and QC status.', {
      sel: ['MBLNR:Material document:1', 'MJAHR:Year'], out: ['Header', 'Item table', 'Received by / Store in-charge signature'], tables: ['MKPF', 'MSEG', 'EKKO', 'LFA1'], hours: 10
    }),
    tpl('MM', 'enhancement', 'Mandatory Field / Check in PO (ME21N)', 'Block PO save when a custom condition fails (e.g. missing delivery date or remark).', {
      sel: ['ME21N / ME22N:T-code:1'], out: ['Error message', 'Allow only for specific doc types'], tables: ['ME_PROCESS_PO_CUST - CHECK method'], logic: ['Read header / item via IF_PURCHASE_ORDER_MM', 'Message via MMPUR_MESSAGE'], hours: 8
    }),
    tpl('MM', 'enhancement', 'MIGO Check (e.g. GR only with gate entry)', 'Validation at goods receipt: block 101 if gate entry / QC clearance is missing.', {
      sel: ['MIGO:T-code:1'], out: ['Error on post'], tables: ['MB_MIGO_BADI (CHECK_ITEM / POST_DOCUMENT)'], logic: ['Check Z gate table for PO and vehicle'], hours: 8
    }),
    /* ---------- PP ---------- */
    tpl('PP', 'report', 'Production Order Status & Delay Report', 'Open orders with planned vs actual dates, confirmed qty, delay in days and component shortage.', {
      sel: ['WERKS:Plant:1', 'AUFNR:Order', 'GSTRP:Basic start', 'GLTRP:Basic finish', 'P_STAT:Status (REL / TECO / CNF)'], out: ['AUFNR:Order', 'MATNR:Material', 'PSMNG:Planned qty', 'WEMNG:Delivered qty', 'GSTRP:Start', 'GLTRP:Finish', 'DELAY:Delay days', 'STATUS:System status'], tables: ['AUFK', 'AFKO', 'AFPO', 'JEST', 'MAKT'], complexity: 'complex', hours: 24
    }),
    tpl('PP', 'report', 'Daily Production Report', 'Quantity produced per day / shift / work centre from confirmations with scrap and yield.', {
      sel: ['WERKS:Plant:1', 'BUDAT:Confirmation date:1', 'ARBPL:Work centre', 'MATNR:Material'], out: ['BUDAT:Date', 'ARBPL:Work centre', 'MATNR:Material', 'LMNGA:Yield', 'XMNGA:Scrap', 'ISMNW:Actual hours'], tables: ['AFRU', 'AFKO', 'CRHD', 'MAKT'], logic: ['Exclude cancelled confirmations (STZHL / STOKZ)'], hours: 14
    }),
    tpl('PP', 'report', 'Component Shortage (Missing Parts) Report', 'Production orders with components not fully available - required vs stock vs open PO.', {
      sel: ['WERKS:Plant:1', 'AUFNR:Order', 'BDTER:Requirement date'], out: ['AUFNR:Order', 'MATNR:Component', 'BDMNG:Required', 'ENMNG:Issued', 'STOCK:Available', 'SHORT:Shortage'], tables: ['RESB', 'AFKO', 'MARD', 'EKET'], complexity: 'complex', hours: 22
    }),
    tpl('PP', 'report', 'BOM Comparison / Where-used', 'Compare two BOMs or list all products using a component, multi-level.', {
      sel: ['MATNR:Material:1', 'WERKS:Plant:1', 'STLAN:BOM usage'], out: ['LEVEL:Level', 'IDNRK:Component', 'MENGE:Qty', 'MEINS:UoM'], tables: ['MAST', 'STKO', 'STPO'], logic: ['Use CS_BOM_EXPL_MAT_V2 for explosion'], hours: 14
    }),
    tpl('PP', 'report', 'Planned vs Actual Consumption Variance', 'BOM requirement vs actual issue per production order with variance % and value.', {
      sel: ['WERKS:Plant:1', 'AUFNR:Order', 'BUDAT:Date'], out: ['AUFNR:Order', 'MATNR:Component', 'PLAN_QTY:Planned', 'ACT_QTY:Actual', 'VAR_QTY:Variance', 'VAR_PCT:Variance %'], tables: ['RESB', 'AFKO', 'MBEW'], complexity: 'complex', hours: 20
    }),
    tpl('PP', 'form', 'Production Order Slip / Job Card (barcode)', 'Printable job card with components, operations and order barcode.', {
      sel: ['AUFNR:Order:1'], out: ['Header', 'Operation table', 'Component table', 'Barcode (order number)'], tables: ['AFKO', 'AFPO', 'AFVC', 'RESB'], hours: 14
    }),
    tpl('PP', 'bdc', 'BOM Upload (CS01)', 'Mass BOM creation from Excel.', {
      sel: ['P_FILE:Excel file:1', 'P_TEST:Test run'], out: ['MATNR:Header material', 'WERKS:Plant', 'STLAN:Usage', 'IDNRK:Component', 'MENGE:Quantity'], tables: ['CSAP_MAT_BOM_CREATE'], hours: 14
    }),
    tpl('PP', 'enhancement', 'Production Order Release Check', 'Block release if components / routing / quality conditions are not met.', {
      sel: ['CO02 / COHV:T-code:1'], out: ['Error on release'], tables: ['WORKORDER_UPDATE (BAdI)'], hours: 10
    }),
    /* ---------- SD ---------- */
    tpl('SD', 'report', 'Pending Sales Order / Backlog Report', 'Open sales order quantity by customer / material with delivery date and stock availability.', {
      sel: ['VKORG:Sales org:1', 'KUNNR:Customer', 'MATNR:Material', 'AUDAT:Order date'], out: ['VBELN:Order', 'POSNR:Item', 'KUNNR:Customer', 'KWMENG:Order qty', 'DELIV:Delivered', 'PENDING:Pending'], tables: ['VBAK', 'VBAP', 'VBEP', 'VBFA', 'KNA1'], hours: 16
    }),
    tpl('SD', 'report', 'Dispatch / Delivery Register', 'Delivery wise dispatch details with vehicle, LR number, transporter and invoice.', {
      sel: ['VSTEL:Shipping point:1', 'WADAT:Goods issue date:1', 'KUNNR:Customer'], out: ['VBELN:Delivery', 'KUNNR:Customer', 'MATNR:Material', 'LFIMG:Qty', 'VBELN_VF:Invoice', 'TRANSPORTER:Transporter', 'LR_NO:LR no.'], tables: ['LIKP', 'LIPS', 'VBRK', 'VBRP', 'VBFA', 'KNA1'], hours: 14
    }),
    tpl('SD', 'report', 'Invoice Register with GST', 'Billing register with taxable value, CGST / SGST / IGST, HSN, customer GSTIN.', {
      sel: ['BUKRS:Company code:1', 'FKDAT:Billing date:1', 'KUNNR:Customer'], out: ['VBELN:Invoice', 'FKDAT:Date', 'KUNAG:Customer', 'STCD3:GSTIN', 'NETWR:Taxable value', 'CGST:CGST', 'SGST:SGST', 'IGST:IGST'], tables: ['VBRK', 'VBRP', 'KONV / PRCD_ELEMENTS', 'KNA1'], logic: ['Tax amounts from condition types (JOCG / JOSG / JOIG - verify)'], complexity: 'complex', hours: 22
    }),
    tpl('SD', 'form', 'Delivery Challan (transporter, vehicle, LR)', 'Delivery challan smartform with transporter and LR details.', {
      sel: ['LD00:Output type', 'VBELN:Delivery:1'], out: ['Consignee block', 'Item table', 'Transporter / Vehicle / LR', 'Signature block'], tables: ['LIKP', 'LIPS', 'KNA1', 'VBPA'], hours: 12
    }),
    tpl('SD', 'form', 'Tax Invoice (GST) Layout', 'Customer invoice with IRN / QR, HSN, tax split and bank details.', {
      sel: ['RD00:Output type', 'VBELN:Billing document:1'], out: ['Logo', 'Buyer / consignee', 'Item table', 'Tax summary', 'QR code', 'Bank & terms'], tables: ['VBRK', 'VBRP', 'KNA1', 'KONV / PRCD_ELEMENTS'], complexity: 'complex', hours: 24
    }),
    /* ---------- FI / CO ---------- */
    tpl('FI', 'report', 'Vendor Ageing / Outstanding', 'Vendor-wise outstanding with ageing buckets by due date.', {
      sel: ['BUKRS:Company code:1', 'LIFNR:Vendor', 'KEYDATE:Key date:1'], out: ['LIFNR:Vendor', 'NAME1:Name', 'NOT_DUE:Not due', 'D_0_30:0-30', 'D_31_60:31-60', 'D_61_90:61-90', 'D_90P:90+'], tables: ['BSIK', 'LFA1', 'LFB1'], logic: ['Due date = baseline date + payment terms days'], hours: 14
    }),
    tpl('FI', 'report', 'Payment Advice / Vendor Payment Register', 'Payments made to vendors with invoice details and TDS.', {
      sel: ['BUKRS:Company code:1', 'AUGDT:Clearing date:1', 'LIFNR:Vendor'], out: ['BELNR:Payment doc', 'LIFNR:Vendor', 'WRBTR:Amount', 'TDS:TDS', 'INV:Invoice details'], tables: ['BSAK', 'BKPF', 'LFA1'], hours: 14
    }),
    tpl('FI', 'form', 'Payment Advice (Form)', 'Vendor payment advice print / email after payment run.', {
      sel: ['BELNR:Payment document:1'], out: ['Vendor block', 'Paid invoices', 'Net payable', 'Bank details'], tables: ['BKPF', 'BSAK', 'LFA1', 'LFBK'], hours: 12
    }),
    tpl('CO', 'report', 'Cost Centre Wise Expense Report', 'Actual vs plan expense by cost centre and cost element for a period.', {
      sel: ['KOKRS:Controlling area:1', 'KOSTL:Cost center', 'GJAHR:Year', 'PERIO:Period'], out: ['KOSTL:Cost center', 'KSTAR:Cost element', 'PLAN:Plan', 'ACT:Actual', 'VAR:Variance'], tables: ['COSP', 'COSS', 'CSKT', 'CSKU'], complexity: 'complex', hours: 20
    }),
    /* ---------- QM ---------- */
    tpl('QM', 'report', 'Inspection Lot Status Report', 'Inspection lots with stage, usage decision, lot quantity and pending days.', {
      sel: ['WERKS:Plant:1', 'ART:Inspection type', 'MATNR:Material', 'ENSTEHDAT:Lot creation date'], out: ['PRUEFLOS:Lot', 'MATNR:Material', 'LOSMENGE:Lot qty', 'STATUS:Status', 'VCODE:Usage decision', 'PENDING_DAYS:Pending days'], tables: ['QALS', 'QAVE', 'MAKT'], hours: 12
    }),
    tpl('QM', 'report', 'Vendor Rejection Analysis', 'Vendor wise inspected / accepted / rejected quantity and rejection %.', {
      sel: ['WERKS:Plant:1', 'LIFNR:Vendor', 'BUDAT:Period:1'], out: ['LIFNR:Vendor', 'LOSMENGE:Inspected', 'REJ:Rejected', 'REJ_PCT:Rejection %'], tables: ['QALS', 'QAVE', 'LFA1'], hours: 12
    }),
    tpl('QM', 'form', 'Certificate of Analysis (COA)', 'COA with batch, characteristics, specification and results.', {
      sel: ['CHARG:Batch:1', 'MATNR:Material:1', 'WERKS:Plant'], out: ['Batch / material header', 'Characteristic table (spec, result, unit)', 'Approval signature'], tables: ['QALS', 'QAMV', 'QAMR', 'MCH1'], complexity: 'complex', hours: 24
    }),
    /* ---------- PM ---------- */
    tpl('PM', 'report', 'Breakdown History by Equipment', 'Breakdown count, downtime and cost per equipment / functional location.', {
      sel: ['IWERK:Plant:1', 'EQUNR:Equipment', 'DATE:Period:1'], out: ['EQUNR:Equipment', 'BREAKS:Breakdowns', 'DOWNTIME:Downtime hours', 'COST:Cost'], tables: ['QMEL', 'AFIH', 'AUFK', 'EQUI'], complexity: 'complex', hours: 20
    }),
    tpl('PM', 'report', 'Spare Consumption by Equipment', 'Spares issued against maintenance orders with quantity and value per equipment.', {
      sel: ['WERKS:Plant:1', 'BUDAT:Date:1', 'EQUNR:Equipment'], out: ['AUFNR:Order', 'EQUNR:Equipment', 'MATNR:Spare', 'MENGE:Qty', 'DMBTR:Value'], tables: ['RESB', 'MSEG', 'AFIH', 'EQUI'], hours: 12
    }),
    tpl('PM', 'report', 'Preventive Maintenance Due List', 'Maintenance plans due in the next N days with equipment and last done date.', {
      sel: ['IWERK:Plant:1', 'DAYS:Due within days:1'], out: ['WARPL:Plan', 'EQUNR:Equipment', 'NPLDA:Planned date', 'LAST:Last completed'], tables: ['MPLA', 'MPOS', 'MHIS'], hours: 12
    }),
    /* ---------- Cross-module ---------- */
    tpl('GEN', 'screen', 'Z-Table Maintenance Screen (master data)', 'Simple maintenance transaction for a custom master table with add / change / delete and change log.', {
      sel: ['Key fields:Key fields:1', 'Data fields:Data fields'], out: ['SAVE:Save', 'DELETE:Delete', 'UPLOAD:Excel upload (optional)'], tables: ['Z table with SM30 maintenance generator'], logic: ['SM30 generator (SE54) is enough when no custom logic is needed', 'Add authorisation group and change-document logging'], complexity: 'simple', hours: 6
    }),
    tpl('GEN', 'report', 'Change Log / Audit Report (CDHDR / CDPOS)', 'Who changed which field, old value, new value and when - for any change-document object.', {
      sel: ['OBJECTCLAS:Change object class:1', 'OBJECTID:Object ID', 'UDATE:Change date:1', 'USERNAME:User'], out: ['OBJECTID:Object', 'USERNAME:User', 'UDATE:Date', 'FNAME:Field', 'VALUE_OLD:Old value', 'VALUE_NEW:New value'], tables: ['CDHDR', 'CDPOS'], hours: 10
    }),
    tpl('GEN', 'interface', 'Daily Report Mail (background job)', 'Report scheduled as job and e-mailed as Excel to a distribution list.', {
      sel: ['Mail recipients:Distribution list:1', 'Schedule:Daily time:1'], out: ['Excel attachment', 'Mail body with summary'], tables: ['CL_BCS', 'SM36 job'], logic: ['SUBMIT report ... EXPORTING LIST TO MEMORY or call logic directly', 'Variant per recipient group'], hours: 10
    }),
    tpl('GEN', 'issue', 'Report Performance Tuning', 'Existing report runs slowly: analyse with SAT / ST05 and optimise selects.', {
      sel: ['Program:Report name / T-code:1'], out: ['Run time before', 'Run time after'], tables: ['SAT', 'ST05', 'SE16N (index check)'], logic: ['Avoid SELECT * and nested selects; use FOR ALL ENTRIES with non-empty check or joins', 'Use index fields in WHERE; buffer repeated reads', 'Check missing secondary indexes with Basis'], complexity: 'medium', hours: 8
    })
  ];

  /* ------------------------------------------------------------------
     4. ESTIMATION - base hours by type and complexity (single developer)
     ------------------------------------------------------------------ */
  const estimate = {
    base: {
      report: { simple: 6, medium: 12, complex: 24 }, screen: { simple: 12, medium: 24, complex: 48 }, form: { simple: 6, medium: 12, complex: 24 }, bdc: { simple: 6, medium: 12, complex: 20 },
      enhancement: { simple: 4, medium: 8, complex: 16 }, interface: { simple: 16, medium: 32, complex: 64 }, issue: { simple: 1, medium: 3, complex: 8 }, other: { simple: 2, medium: 6, complex: 14 }
    },
    changeFactor: 0.6,      // change to an existing object = 60 % of a fresh build (backup + regression included)
    factors: [
      { k: 'excel', l: 'Excel download / upload', h: 1.5, types: ['report', 'screen', 'bdc'] },
      { k: 'drill', l: 'Drill-down / hotspot to standard T-code', h: 1.5, types: ['report'] },
      { k: 'auth', l: 'Authorisation checks', h: 1, types: ['report', 'screen', 'bdc'] },
      { k: 'mail', l: 'E-mail / PDF output', h: 2, types: ['report', 'form', 'interface'] },
      { k: 'job', l: 'Background job & variant', h: 1, types: ['report', 'bdc', 'interface'] },
      { k: 'barcode', l: 'Barcode / QR code', h: 2.5, types: ['form'] },
      { k: 'multilang', l: 'Multiple languages / copies', h: 1.5, types: ['form'] },
      { k: 'nosample', l: 'No sample output / unclear requirement', h: 3, types: null },
      { k: 'multi_plant', l: 'Multiple plants / company codes', h: 1.5, types: null },
      { k: 'perf', l: 'Large data volume (performance tuning)', h: 3, types: ['report', 'interface', 'bdc'] },
      { k: 'ztable', l: 'New Z table(s) + number range + lock object', h: 3, types: ['screen', 'interface', 'report'] },
      { k: 'doc', l: 'Technical documentation', h: 1, types: null }
    ],
    uatBuffer: 0.15,       // +15 % for UAT fixes / transport / handover
    hint: 'Estimate = base hours x complexity (x 0.6 for a change) + selected extras + 15 % buffer for UAT, transport and documentation.'
  };

  /* ------------------------------------------------------------------
     5. BACKUP HOW-TO - what to download before changing an existing object
     ------------------------------------------------------------------ */
  const backupGuide = {
    report: ['SE38 > program > Utilities > More utilities > Upload / Download > Download (saves .txt)', 'SE38 > Utilities > Versions > Version management (note version number)', 'Screenshot of the selection screen and a sample output', 'Save the variant list (SE38 > Goto > Variants)'],
    screen: ['SE38 program source download (.txt) incl. all includes', 'SE51 screens: screenshot of layout + flow logic copied to a text file', 'SE41 GUI status / title screenshots', 'SE11 table structures: screenshot or SE11 > Utilities > Display structure', 'Transport request with the original objects (transport of copies)'],
    form: ['SMARTFORMS > Utilities > Download form (XML) - upload the .xml here', 'SAPscript: RSTXSCRP export or SE71 > Utilities > Copy from client', 'Driver program source download (.txt)', 'Printed PDF of an existing output for comparison'],
    bdc: ['Program source download (.txt)', 'Current Excel template (.xlsx) used by users', 'One successful sample file with expected result'],
    enhancement: ['SE19 / CMOD: open the implementation > copy the source into a .txt', 'Screenshot of the implementation settings (active / filters)', 'SE80 > enhancement implementation name written in Register'],
    interface: ['Program source download (.txt)', 'Sample inbound / outbound file or IDoc (WE02) as .xml / .txt', 'SM59 / partner profile screenshot', 'Job definition (SM37) screenshot'],
    issue: ['Source of the program before the fix (download .txt)', 'Screenshot of the error / ST22 dump text', 'Example document numbers'],
    other: ['Anything that is being changed: export or screenshot before the change']
  };

  /* ------------------------------------------------------------------
     6. QUALITY / AFTER-PRODUCTION CHECKLISTS
     ------------------------------------------------------------------ */
  const qualityIdeas = ['Layout / alignment correction', 'Column missing or wrong order', 'Totals mismatch with standard report', 'Add another selection field', 'Add Excel download', 'Message text change', 'Add authorisation check', 'Performance is slow for big date range', 'Additional plant / company code to be covered', 'Unit of measure / decimal places', 'Field label rename'];
  const afterMoveChecks = ['Executed once in Production with real data', 'Output compared with Quality result', 'Authorisation roles working for end users', 'Variant / printer / job available in Production', 'T-code visible in user menu / role', 'User informed and trained', 'No short dump in ST22 after first day', 'No error message / complaint after 3 days'];
  const devRegisterFields = [
    { k: 'obj_name', l: 'Program / object name', ph: 'ZMMR_STOCK_AGEING' }, { k: 'tcode', l: 'T-code', ph: 'ZSTOCKAGE' }, { k: 'package', l: 'Package', ph: 'ZMM' }, { k: 'version', l: 'Version', ph: 'v1.0' },
    { k: 'developed_on', l: 'Developed on', type: 'date' }, { k: 'tables', l: 'Tables / FMs used', ph: 'MARD, MBEW, MSEG' }, { k: 'what_done', l: 'What was developed / changed', area: 1 }, { k: 'how_to_use', l: 'How to use (steps for user)', area: 1 }, { k: 'notes', l: 'Other notes for future', area: 1 }
  ];

  window.KB = {
    types: types, modules: modules, templates: templates, estimate: estimate, backupGuide: backupGuide, qualityIdeas: qualityIdeas, afterMoveChecks: afterMoveChecks, devRegisterFields: devRegisterFields,
    people: ['Kashish Khandelwal', 'Uday Sir'],
    moduleOwners: { MM: 'Kashish Khandelwal', PP: 'Uday Sir' },
    envs: ['DEV', 'QAS', 'PRD']
  };
})();
