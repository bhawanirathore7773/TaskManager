/* Estimate helper: "how long will this take to build?" Shared by New task and Task drawer. */
(function () {
  'use strict';
  const { h, modal } = App;
  const E = () => window.KB.estimate;

  function calc(type, complexity, nature, keys) {
    const e = E();
    let base = (e.base[type] || e.base.other)[complexity || 'medium'];
    if (nature === 'change') base = base * e.changeFactor;
    let extra = 0;
    e.factors.forEach((f) => { if (keys.has(f.k) && (!f.types || f.types.indexOf(type) >= 0)) extra += f.h; });
    const total = (base + extra) * (1 + e.uatBuffer);
    return { base: base, extra: extra, total: Math.max(0.5, Math.round(total * 2) / 2) };
  }

  /* ctx() -> { type, nature, complexity, setComplexity(fn) } ; onUse(hours) */
  function estimatorEl(ctx, onUse) {
    const keys = new Set();
    const wrap = h('div', { class: 'stack' });
    function render() {
      const c = ctx();
      const r = calc(c.type, c.complexity, c.nature, keys);
      const factors = E().factors.filter((f) => !f.types || f.types.indexOf(c.type) >= 0);
      wrap.replaceChildren(
        h('div', { class: 'row wrap' }, h('span', { class: 'lbl' }, 'Complexity'),
          h('div', { class: 'seg' }, ['simple', 'medium', 'complex'].map((k) => h('button', { type: 'button', class: c.complexity === k ? 'on' : '', onclick: () => { c.setComplexity(k); render(); } }, App.cap(k))))),
        h('div', { class: 'checks' }, factors.map((f) => h('label', null,
          h('input', { type: 'checkbox', checked: keys.has(f.k), onchange: (e) => { if (e.target.checked) keys.add(f.k); else keys.delete(f.k); render(); } }), f.l, h('span', { class: 'h' }, '+' + f.h + ' h')))),
        h('div', { class: 'est-box' },
          h('div', null, h('div', { class: 'num' }, r.total + ' h'), h('div', { class: 'small muted' }, '≈ ' + (Math.round(r.total / Number(App.S.meta.settings.hours_per_day || 6) * 10) / 10) + ' working days')),
          h('div', { class: 'small ink2 grow' }, 'Base ' + (Math.round(r.base * 10) / 10) + ' h' + (c.nature === 'change' ? ' (change in existing object)' : '') + ', extras ' + r.extra + ' h, plus ' + Math.round(E().uatBuffer * 100) + '% buffer for UAT, transport and documentation.'),
          h('button', { class: 'btn primary', type: 'button', onclick: () => onUse(r.total) }, 'Use this estimate')));
    }
    render();
    wrap.refresh = render;
    return wrap;
  }

  function estimateModal(task, onApply) {
    const st = { type: task.task_type, nature: task.nature, complexity: task.complexity || 'medium' };
    const el = estimatorEl(() => ({ type: st.type, nature: st.nature, complexity: st.complexity, setComplexity: (v) => { st.complexity = v; } }), (hrs) => { onApply(hrs, st.complexity); m.close(); });
    const m = modal({ title: 'Estimate helper', cls: 'wide', body: [h('p', { class: 'ink2', style: { marginBottom: '12px' } }, window.KB.estimate.hint), el], actions: [{ label: 'Close' }] });
  }

  App.estimatorEl = estimatorEl;
  App.estimateModal = estimateModal;
  App.calcEstimate = calc;
})();
