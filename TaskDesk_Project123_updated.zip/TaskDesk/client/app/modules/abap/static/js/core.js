/* Core helpers: DOM builder, API, formatting, small UI parts, modal. */
(function () {
  'use strict';
  const App = window.App = { S: { meta: null, tasks: [], view: 'dashboard', drawer: null, filters: null }, V: {}, D: {} };
  const NS = 'http://www.w3.org/2000/svg';

  /* ---------- DOM ---------- */
  // The native append() / replaceChildren() turn null into the text "null" and arrays into "[object ...]".
  // This app passes lists and optional (null) children everywhere, so make both calls flatten and skip empty values.
  (function () {
    const origAppend = Element.prototype.append, origReplace = Element.prototype.replaceChildren;
    const clean = (kids) => kids.flat(Infinity).filter((k) => k != null && k !== false && k !== true).map((k) => (k.nodeType ? k : document.createTextNode(String(k))));
    Element.prototype.append = function () { return origAppend.apply(this, clean(Array.from(arguments))); };
    Element.prototype.replaceChildren = function () { return origReplace.apply(this, clean(Array.from(arguments))); };
  })();
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  function add(el, kids) {
    for (const k of kids.flat(Infinity)) {
      if (k == null || k === false || k === true) continue;
      el.append(k.nodeType ? k : document.createTextNode(String(k)));
    }
  }
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    let later = null;
    if (attrs) {
      for (const k in attrs) {
        const v = attrs[k];
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'style') {
          if (typeof v === 'object') for (const p in v) { if (p.indexOf('-') >= 0) el.style.setProperty(p, v[p]); else el.style[p] = v[p]; }
          else el.setAttribute('style', v);
        } else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'value') later = v;
        else if (k === 'checked' || k === 'disabled' || k === 'selected' || k === 'multiple' || k === 'readOnly') el[k] = !!v;
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    add(el, kids);
    if (later !== null) el.value = later;
    return el;
  }
  const ICONS = {
    dashboard: 'M3 3h7v9H3z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5H3z', list: 'M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01',
    board: 'M4 4h4v16H4z M10 4h4v10h-4z M16 4h4v13h-4z', timeline: 'M3 6h9 M8 12h12 M5 18h8', history: 'M12 7v5l3 2 M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z',
    register: 'M4 19.5V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z M4 19.5A2.5 2.5 0 0 1 6.5 17H19', alert: 'M12 9v4 M12 17h.01 M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z',
    library: 'M2 4h6a4 4 0 0 1 4 4v12a3 3 0 0 0-3-3H2z M22 4h-6a4 4 0 0 0-4 4v12a3 3 0 0 1 3-3h7z', settings: 'M4 21v-7 M4 10V3 M12 21v-9 M12 8V3 M20 21v-5 M20 12V3 M1 14h6 M9 8h6 M17 16h6',
    plus: 'M12 5v14 M5 12h14', search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.3-4.3', x: 'M18 6L6 18 M6 6l12 12', check: 'M20 6L9 17l-5-5',
    folder: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z', upload: 'M12 16V4 M7 9l5-5 5 5 M4 20h16', download: 'M12 4v12 M7 11l5 5 5-5 M4 20h16',
    trash: 'M3 6h18 M8 6V4h8v2 M6 6l1 14h10l1-14', copy: 'M9 9h11v11H9z M5 15H4V4h11v1', file: 'M6 2h8l6 6v14H6z M14 2v6h6', eye: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    moon: 'M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z', sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M12 2v2 M12 20v2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M2 12h2 M20 12h2 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4',
    edit: 'M12 20h9 M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z', bolt: 'M13 2L3 14h9l-1 8 10-12h-9z', calc: 'M5 3h14v18H5z M8 7h8 M8 12h.01 M12 12h.01 M16 12h.01 M8 16h.01 M12 16h.01 M16 16h.01', power: 'M12 2v10 M18.4 6.6a9 9 0 1 1-12.8 0'
  };
  function ico(name, cls) {
    const s = document.createElementNS(NS, 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('class', 'ico' + (cls ? ' ' + cls : '')); s.setAttribute('aria-hidden', 'true');
    String(ICONS[name] || '').split(' M').forEach((d, i) => { const p = document.createElementNS(NS, 'path'); p.setAttribute('d', (i ? 'M' : '') + d); s.appendChild(p); });
    return s;
  }
  const debounce = (fn, ms) => { let t; return function () { const a = arguments; clearTimeout(t); t = setTimeout(() => fn.apply(null, a), ms || 400); }; };
  const LS = {
    get(k, d) { try { const v = localStorage.getItem('tm_' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('tm_' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };

  /* ---------- API ---------- */
  async function api(method, url, body) {
    const o = { method: method, headers: { 'X-TM': '1' } };
    if (body instanceof Blob) o.body = body;
    else if (body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(body); }
    let r;
    try { r = await fetch(url, o); } catch (e) { toast('Cannot reach the local server. Start the app again from the desktop icon.', 'err'); throw e; }
    const txt = await r.text();
    let data = null;
    try { data = txt ? JSON.parse(txt) : null; } catch (e) { data = null; }
    if (!r.ok) { const msg = (data && data.error) || ('Error ' + r.status); toast(msg, 'err'); throw new Error(msg); }
    return data;
  }
  const GET = (u) => api('GET', u), POST = (u, b) => api('POST', u, b || {}), PUT = (u, b) => api('PUT', u, b || {}), DEL = (u) => api('DELETE', u);
  function uploadFile(taskId, file, category, note, version) {
    const q = new URLSearchParams({ name: file.name || 'file', category: category || 'auto', note: note || '', version: version || '' });
    return api('POST', '/api/tasks/' + taskId + '/files?' + q.toString(), file);
  }

  /* ---------- toast / copy ---------- */
  function toast(msg, kind) {
    const t = h('div', { class: 'toast' + (kind === 'err' ? ' err' : ''), role: 'status' }, msg);
    $('#toasts').append(t);
    setTimeout(() => t.remove(), kind === 'err' ? 6000 : 2600);
  }
  function copyText(text, label) {
    const done = () => toast((label || 'Copied') + ' to clipboard');
    if (navigator.clipboard && window.isSecureContext !== false) navigator.clipboard.writeText(text).then(done, () => fallbackCopy(text, done));
    else fallbackCopy(text, done);
  }
  function fallbackCopy(text, done) {
    const ta = h('textarea', { style: { position: 'fixed', left: '-999px' } }); ta.value = text; document.body.append(ta); ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { toast('Copy failed', 'err'); } ta.remove();
  }

  /* ---------- formatting ---------- */
  const pad = (n) => String(n).padStart(2, '0');
  const iso = (d) => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const todayIso = () => iso(new Date());
  function pd(s) { if (!s) return null; const p = String(s).slice(0, 10).split('-').map(Number); return new Date(p[0], p[1] - 1, p[2]); }
  const addDays = (d, n) => { const x = new Date(d.getTime()); x.setDate(x.getDate() + n); return x; };
  const daysBetween = (a, b) => Math.round((pd(iso(b)) - pd(iso(a))) / 86400000);
  function fmtD(s, withYear) {
    const d = pd(s); if (!d) return '—';
    const o = { day: '2-digit', month: 'short' };
    if (withYear || d.getFullYear() !== new Date().getFullYear()) o.year = 'numeric';
    return d.toLocaleDateString('en-GB', o);
  }
  function fmtTs(ts) {
    if (!ts) return ''; const d = new Date(String(ts).replace(' ', 'T'));
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) + ', ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  const fmtH = (v) => (v == null || v === '' ? '—' : (Math.round(v * 10) / 10) + ' h');
  function fmtSize(n) { if (n < 1024) return n + ' B'; if (n < 1048576) return (n / 1024).toFixed(0) + ' KB'; return (n / 1048576).toFixed(1) + ' MB'; }
  const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : '');

  /* ---------- domain helpers ---------- */
  const statusOf = (k) => (App.S.meta ? App.S.meta.statuses.find((s) => s.key === k) : null) || { key: k, label: k };
  const typeLabel = (k) => (App.S.meta && App.S.meta.type_labels[k]) || k;
  const isActive = (t) => !!(statusOf(t.status).active);
  const isDone = (t) => t.status === 'prod' || t.status === 'closed';
  const byId = (id) => App.S.tasks.find((t) => t.id === id);
  function urgText(t) {
    const d = t.days_left;
    switch (t.urgency) {
      case 'overdue': return 'Overdue by ' + (-d) + (-d === 1 ? ' day' : ' days');
      case 'crunch': return 'Not enough time';
      case 'urgent': return d === 0 ? 'Due today' : (d === 1 ? 'Due tomorrow' : d + ' days left');
      case 'warning': case 'ok': return d + ' days left';
      case 'none': return 'No due date';
      case 'hold': return 'On hold'; case 'cancelled': return 'Cancelled';
      default: return t.status === 'closed' ? 'Closed' : 'In production';
    }
  }
  function urgTitle(t) {
    if (t.urgency === 'crunch') return 'About ' + fmtH(t.remaining_hours) + ' of work is left but only ' + fmtH(t.avail_hours) + ' of working time remains until the due date.';
    if (t.due_date) return 'Due ' + fmtD(t.due_date, true);
    return '';
  }
  const light = (t) => h('span', { class: 'light l-' + t.urgency, title: urgTitle(t) }, urgText(t));
  const barColor = (t) => ({ overdue: 'var(--c-overdue)', crunch: 'var(--c-crunch)', urgent: 'var(--c-urgent)', warning: 'var(--c-warning)', ok: 'var(--c-ok)', done: 'var(--c-ok)' }[t.urgency] || 'var(--accent)');
  const bar = (p, color, cls) => h('div', { class: 'bar' + (cls ? ' ' + cls : ''), role: 'progressbar', 'aria-valuenow': p, 'aria-valuemin': 0, 'aria-valuemax': 100, style: { '--c': color || 'var(--accent)' } }, h('i', { style: { width: Math.max(0, Math.min(100, p)) + '%' } }));
  const progress = (t) => h('div', { class: 'progress', title: t.cl_total ? t.cl_done + ' of ' + t.cl_total + ' checklist items done' : 'No checklist yet' }, bar(t.progress, barColor(t)), h('span', { class: 'pct' }, t.progress + '%'));
  const statusChip = (k) => h('span', { class: 'chip', style: { '--c': 'var(--s-' + k + ')' } }, statusOf(k).label);
  const prio = (p) => h('span', { class: 'prio ' + p }, h('i', null, h('b'), h('b'), h('b'), h('b')), cap(p));
  const tag = (txt, title) => h('span', { class: 'tag', title: title || null }, txt);

  /* ---------- form parts ---------- */
  const fld = (label, input, hint) => h('div', { class: 'fld' }, h('label', null, label), input, hint ? h('span', { class: 'hint' }, hint) : null);
  function sel(options, value, onChange, attrs) {
    const el = h('select', attrs || null, options.map((o) => { const v = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o; return h('option', { value: v }, l); }));
    el.value = value == null ? '' : value;
    if (onChange) el.addEventListener('change', () => onChange(el.value));
    return el;
  }
  function inp(value, onChange, attrs) {
    const el = h('input', Object.assign({ type: 'text' }, attrs || {}));
    el.value = value == null ? '' : value;
    if (onChange) el.addEventListener('change', () => onChange(el.value));
    return el;
  }
  function area(value, onChange, attrs) {
    const el = h('textarea', attrs || null); el.value = value == null ? '' : value;
    if (onChange) el.addEventListener('change', () => onChange(el.value));
    return el;
  }

  /* ---------- modal ---------- */
  function modal(opts) {
    const body = h('div', { class: 'md-b' }, opts.body);
    const foot = opts.actions && opts.actions.length ? h('div', { class: 'md-f' }, opts.foot || null, h('span', { class: 'grow' }), opts.actions.map((a) =>
      h('button', { class: 'btn ' + (a.cls || ''), type: 'button', onclick: () => { if (a.onClick) { const r = a.onClick(api2); if (r === false) return; } if (a.close !== false) dlg.close(); } }, a.label))) : null;
    const dlg = h('dialog', { class: opts.cls || '' },
      h('div', { class: 'md-h' }, h('h2', null, opts.title || ''), h('span', { class: 'grow' }), h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Close', onclick: () => dlg.close() }, ico('x'))), body, foot);
    const api2 = { el: dlg, body: body, close: () => dlg.close() };
    dlg.addEventListener('close', () => { dlg.remove(); if (opts.onClose) opts.onClose(); });
    dlg.addEventListener('mousedown', (e) => { if (e.target === dlg && opts.dismiss !== false) dlg.dataset.down = '1'; });
    dlg.addEventListener('click', (e) => { if (e.target === dlg && dlg.dataset.down) dlg.close(); delete dlg.dataset.down; });
    document.body.append(dlg);
    dlg.showModal();
    return api2;
  }
  function confirmBox(message, okLabel, danger) {
    return new Promise((resolve) => {
      let ans = false;
      modal({ title: 'Please confirm', body: h('p', null, message), onClose: () => resolve(ans),
        actions: [{ label: 'Cancel', cls: '' }, { label: okLabel || 'Delete', cls: danger === false ? 'primary' : 'danger', onClick: () => { ans = true; } }] });
    });
  }

  /* ---------- tasks: shared filter + search ---------- */
  function matchTask(t, q) {
    if (!q) return true; q = q.toLowerCase();
    const dv = t.dev || {};
    return [t.code, t.title, t.summary, t.requested_by, t.committed_to, t.module, typeLabel(t.task_type), dv.obj_name, dv.tcode, dv.tables, dv.what_done].some((x) => x && String(x).toLowerCase().indexOf(q) >= 0);
  }
  function why(t) {
    const p = [];
    if (t.urgency === 'overdue') p.push('Overdue by ' + (-t.days_left) + (-t.days_left === 1 ? ' day.' : ' days.'));
    else if (t.urgency === 'crunch') p.push('About ' + fmtH(t.remaining_hours) + ' of work left but only ' + fmtH(t.avail_hours) + ' of working time before the due date.');
    else if (t.urgency === 'urgent') p.push(t.days_left === 0 ? 'Due today.' : 'Due tomorrow.');
    else if (t.urgency === 'warning') p.push('Due in ' + t.days_left + ' days.');
    else if (t.urgency === 'ok') p.push('Due in ' + t.days_left + ' days, on track.');
    else if (t.urgency === 'none') p.push('No due date set yet.');
    if (t.priority === 'critical' || t.priority === 'high') p.push(cap(t.priority) + ' priority.');
    if (t.q_open) p.push(t.q_open + ' open quality ' + (t.q_open === 1 ? 'point' : 'points') + ' waiting.');
    if (t.remaining_hours != null && t.urgency !== 'crunch') p.push(fmtH(t.remaining_hours) + ' of work left.');
    return p.join(' ');
  }

  Object.assign(App, { $, $$, h, add, ico, debounce, LS, api, GET, POST, PUT, DEL, uploadFile, toast, copyText, iso, pd, todayIso, addDays, daysBetween, fmtD, fmtTs, fmtH, fmtSize, cap,
    statusOf, typeLabel, isActive, isDone, byId, urgText, urgTitle, light, barColor, bar, progress, statusChip, prio, tag, fld, sel, inp, area, modal, confirmBox, matchTask, why });
})();
