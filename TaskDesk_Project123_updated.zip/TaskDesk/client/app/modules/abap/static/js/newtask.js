/* New task dialog: pick type / template, fill details, estimate, queue files. */
(function () {
  'use strict';
  const { h, ico, fld, sel, inp, area, modal, toast, cap, POST } = App;
  const KB = window.KB;

  const parseItems = (arr) => (arr || []).map((s) => { const p = String(s).split(':'); return { n: p[0].trim(), d: (p[1] || '').trim(), m: p[2] === '1' }; });

  function newTask(preset) {
    const meta = App.S.meta, today = App.todayIso();
    const st = { type: 'report', nature: 'new', module: 'MM', title: '', summary: '', requested_by: '', committed_to: '', department: '', priority: 'medium', complexity: 'medium',
      received_date: today, start_date: '', due_date: '', est_hours: '', need: '', tpl: null, std: true, files: [] };
    const els = {};
    let whoTouched = false, creating = false;

    /* ----- 1. what is it ----- */
    const tiles = h('div', { class: 'tiles' });
    function drawTiles() {
      tiles.replaceChildren(Object.keys(KB.types).map((k) => h('button', { type: 'button', class: 'tile' + (st.type === k ? ' on' : ''), 'aria-pressed': st.type === k, onclick: () => { st.type = k; st.tpl = null; drawTiles(); drawTpl(); est.refresh(); drawStd(); } },
        h('span', { class: 'e', 'aria-hidden': 'true' }, KB.types[k].icon), h('div', null, h('b', null, KB.types[k].label), h('span', null, KB.types[k].intro.split('.')[0])))));
    }
    const natureBox = h('div', { class: 'seg' });
    function drawNature() {
      natureBox.replaceChildren([['new', 'New development'], ['change', 'Change in existing object']].map((x) => h('button', { type: 'button', class: st.nature === x[0] ? 'on' : '', onclick: () => { st.nature = x[0]; drawNature(); est.refresh(); drawStd(); } }, x[1])));
    }
    els.module = sel(Object.keys(KB.modules).map((m) => [m, m === 'GEN' ? 'General / Basis' : m + ' - ' + KB.modules[m].name]), st.module, (v) => {
      st.module = v;
      const o = KB.moduleOwners[v];
      if (!whoTouched && o) { els.who.value = o; els.committed.value = o; }
      else if (!whoTouched) { els.who.value = ''; els.committed.value = ''; }
    });
    const tplSel = h('select', { 'aria-label': 'Ready template' });
    tplSel.addEventListener('change', () => { const i = tplSel.value; if (i === '') { st.tpl = null; return; } applyTpl(KB.templates[Number(i)]); });
    function drawTpl() {
      const list = KB.templates.map((t, i) => ({ t: t, i: i })).filter((x) => x.t.type === st.type);
      tplSel.replaceChildren(h('option', { value: '' }, list.length ? 'Start blank (' + list.length + ' ready templates available)' : 'No ready template for this type, start blank'),
        list.map((x) => h('option', { value: x.i }, x.t.module + ' - ' + x.t.title)));
      tplSel.value = st.tpl == null ? '' : st.tpl;
    }
    function applyTpl(tp) {
      const K = KB.types[tp.type];
      st.tpl = KB.templates.indexOf(tp); st.type = tp.type; st.module = tp.module; st.complexity = tp.complexity || 'medium';
      els.title.value = tp.title; els.summary.value = tp.summary; els.module.value = tp.module; els.cx.value = st.complexity; els.est.value = tp.hours || '';
      st.req = { need: '', sel: parseItems(tp.sel), out: parseItems(tp.out), logic: (tp.logic || []).slice(), tables: (tp.tables || []).slice(), qa: (K.qa || []).map((q) => ({ q: q, a: '' })) };
      const o = KB.moduleOwners[tp.module];
      if (!whoTouched && o) { els.who.value = o; els.committed.value = o; }
      drawTiles(); drawTpl(); est.refresh(); drawStd();
      toast('Template applied. Review the details, then create the task.');
    }

    /* ----- 2. details ----- */
    const names = Array.from(new Set((meta.names || []).concat(KB.people)));
    const dl = h('datalist', { id: 'nt-names' }, names.map((n) => h('option', { value: n })));
    els.title = h('input', { type: 'text', placeholder: 'e.g. Stock ageing report, plant wise', 'aria-label': 'Task title' });
    els.summary = h('textarea', { rows: 2, placeholder: 'One or two lines: what does the user want?' });
    els.who = h('input', { type: 'text', list: 'nt-names', placeholder: 'Who explained the requirement' });
    els.who.addEventListener('input', () => { whoTouched = true; });
    els.committed = h('input', { type: 'text', list: 'nt-names', placeholder: 'Who you will give the date to' });
    els.dept = h('input', { type: 'text', placeholder: 'Stores, Production, Purchase...' });
    els.prio = sel(meta.priorities.map((p) => [p, cap(p)]), 'medium', (v) => { st.priority = v; });
    els.cx = sel([['simple', 'Simple'], ['medium', 'Medium'], ['complex', 'Complex']], 'medium', (v) => { st.complexity = v; est.refresh(); });

    /* ----- 3. timeline & estimate ----- */
    els.recv = h('input', { type: 'date', value: today });
    els.start = h('input', { type: 'date' });
    els.due = h('input', { type: 'date' });
    els.est = h('input', { type: 'number', step: '0.5', min: '0', placeholder: 'Hours' });
    const quick = (label, days) => h('button', { class: 'btn sm', type: 'button', onclick: () => { els.due.value = App.iso(App.addDays(new Date(), days)); } }, label);
    const est = App.estimatorEl(() => ({ type: st.type, nature: st.nature, complexity: st.complexity, setComplexity: (v) => { st.complexity = v; els.cx.value = v; } }), (hrs) => { els.est.value = hrs; });
    const estBox = h('div', { class: 'hide', style: { marginTop: '12px' } }, est);

    /* ----- 4. files ----- */
    const fileList = h('div', { class: 'stack', style: { marginTop: '8px', gap: '4px' } });
    function drawFiles() {
      fileList.replaceChildren(st.files.map((f, i) => h('div', { class: 'row' }, ico('file'), h('span', { class: 'grow trunc' }, f.name), h('span', { class: 'small muted' }, App.fmtSize(f.size)),
        h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Remove ' + f.name, onclick: () => { st.files.splice(i, 1); drawFiles(); } }, ico('x')))));
    }
    const picker = h('input', { type: 'file', multiple: true, class: 'hide', onchange: (e) => { Array.from(e.target.files).forEach((f) => st.files.push(f)); e.target.value = ''; drawFiles(); } });
    const drop = h('div', { class: 'drop' }, ico('upload'), ' Drop the requirement Excel, reference images or backup files here, or ', h('button', { class: 'btn sm', type: 'button', onclick: () => picker.click() }, 'choose files'), picker);
    ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => { Array.from(e.dataTransfer.files).forEach((f) => st.files.push(f)); drawFiles(); });

    /* ----- standard checklist toggle ----- */
    const stdBox = h('label', { class: 'row', style: { cursor: 'pointer' } });
    function drawStd() {
      const K = KB.types[st.type], n = (st.nature === 'change' ? K.checklistChange : K.checklistNew).length;
      stdBox.replaceChildren(h('input', { type: 'checkbox', checked: st.std, onchange: (e) => { st.std = e.target.checked; } }), 'Add the ' + n + ' standard steps for a ' + (st.nature === 'change' ? 'change to an existing ' : 'new ') + K.label.toLowerCase() + ' (you can edit them later)');
    }

    const body = h('div', { class: 'stack', style: { gap: '20px' } }, dl,
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'What needs to be done')), tiles,
        h('div', { class: 'grid3', style: { marginTop: '12px' } }, fld('New or change', natureBox), fld('SAP module', els.module), fld('Ready template', tplSel, 'Fills fields, columns and logic from common manufacturing requirements'))),
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'Details')),
        h('div', { class: 'stack' }, fld('Title', els.title), fld('Short summary', els.summary),
          h('div', { class: 'grid3' }, fld('Requested by', els.who), fld('Timeline committed to', els.committed), fld('Department', els.dept)),
          h('div', { class: 'grid3' }, fld('Priority', els.prio), fld('Complexity', els.cx)))),
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'Dates and effort')),
        h('div', { class: 'grid4' }, fld('Received on', els.recv), fld('Development start', els.start), fld('Due date', els.due), fld('Estimated hours', els.est)),
        h('div', { class: 'row wrap', style: { marginTop: '8px' } }, h('span', { class: 'small muted' }, 'Due in:'), quick('2 days', 2), quick('1 week', 7), quick('2 weeks', 14), quick('1 month', 30), h('span', { class: 'grow' }),
          h('button', { class: 'btn sm', type: 'button', onclick: () => { estBox.classList.toggle('hide'); est.refresh(); } }, ico('calc'), 'How long will it take?')), estBox),
      h('section', null, h('div', { class: 'sec-h' }, h('h3', null, 'Files')), drop, fileList),
      h('section', null, stdBox, h('p', { class: 'small muted', style: { marginTop: '4px' } }, 'After you create the task, its requirement page opens: add selection fields, output columns, logic, questions and more with one-click suggestions.')));
    drawTiles(); drawNature(); drawTpl(); drawFiles(); drawStd();

    async function create(m) {
      if (creating) return false;
      const title = els.title.value.trim();
      if (!title) { els.title.focus(); toast('Enter a title for the task', 'err'); return false; }
      creating = true;
      const K = KB.types[st.type];
      const req = st.req || { need: '', sel: [], out: [], logic: [], tables: [], qa: (K.qa || []).map((q) => ({ q: q, a: '' })) };
      const payload = { title: title, task_type: st.type, nature: st.nature, module: els.module.value, requested_by: els.who.value.trim(), committed_to: els.committed.value.trim(), department: els.dept.value.trim(),
        priority: els.prio.value, complexity: els.cx.value, status: 'new', received_date: els.recv.value || today, start_date: els.start.value || null, due_date: els.due.value || null,
        est_hours: els.est.value || null, summary: els.summary.value.trim(), req: req, checklist: st.std ? (st.nature === 'change' ? K.checklistChange : K.checklistNew).slice() : [] };
      try {
        const d = await POST('/api/tasks', payload);
        let up = 0;
        for (const f of st.files) { try { await App.uploadFile(d.task.id, f, 'auto', '', ''); up++; } catch (e) { /* toast shown */ } }
        toast(d.task.code + ' created' + (up ? ' with ' + up + ' file' + (up > 1 ? 's' : '') : ''));
        m.close();
        if (App.refreshTasks) await App.refreshTasks();
        App.openTask(d.task.id, 'req');
      } catch (e) { creating = false; return false; }
      return false;
    }
    const m = modal({ title: 'New task', cls: 'xl', body: body, dismiss: false,
      // create() is async: return false so the dialog stays open until the task is really saved (create() closes it itself)
      actions: [{ label: 'Cancel' }, { label: 'Create task', cls: 'primary', onClick: () => { create(m); return false; } }], foot: h('span', { class: 'small muted' }, 'Ctrl+Enter to create') });
    m.el.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); create(m); } });
    if (preset) applyTpl(preset);
    setTimeout(() => els.title.focus(), 40);
    return m;
  }
  App.newTask = newTask;
})();
