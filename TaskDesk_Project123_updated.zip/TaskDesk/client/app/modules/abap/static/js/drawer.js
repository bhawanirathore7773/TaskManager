/* Task drawer: everything about one task (details, requirement, checklist, files, release, register info, time). */
(function () {
  'use strict';
  const { h, $, ico, fld, sel, inp, area, modal, confirmBox, toast, fmtD, fmtTs, fmtH, fmtSize, cap, GET, POST, PUT, DEL } = App;
  const KB = window.KB;
  let D = null;       // current drawer state
  const TABS = [['overview', 'Overview'], ['req', 'Requirement'], ['check', 'Checklist'], ['files', 'Files'], ['release', 'Release & quality'], ['dev', 'Dev info'], ['log', 'Time & notes']];
  const CATS = ['image', 'excel', 'backup', 'doc', 'evidence', 'other'];
  const CHANGE_IDEAS = ['Add a new selection field', 'Add a new output column', 'Change column order / heading', 'Change calculation logic', 'Fix wrong total / value', 'Add Excel download', 'Add authorisation check', 'Change layout / alignment of the form', 'Add new field on the screen', 'Change message text', 'Improve performance', 'Add a new plant / company code'];

  /* ---------- open / close ---------- */
  async function openTask(id, tab) {
    if (D) closeDrawer(true);
    let d;
    try { d = await GET('/api/tasks/' + id); } catch (e) { return; }
    D = { id: id, d: d, tab: tab || App.LS.get('drawer_tab', 'overview'), req: d.task.req || {}, saved: '', reqTimer: null, reqDirty: false };
    if (!TABS.some((t) => t[0] === D.tab)) D.tab = 'overview';
    D.scrim = h('div', { class: 'scrim', onclick: () => closeDrawer() });
    D.head = h('div', { class: 'dr-h' });
    D.body = h('div', { class: 'dr-b' });
    D.el = h('aside', { class: 'drawer', role: 'dialog', 'aria-label': 'Task details' }, D.head, D.body);
    $('#drawer-root').replaceChildren(D.scrim, D.el);
    document.body.style.overflow = 'hidden';
    renderHead(); renderBody();
    App.S.drawer = id;
  }
  async function closeDrawer(silent) {
    if (!D) return;
    await flushReq();
    $('#drawer-root').replaceChildren();
    document.body.style.overflow = '';
    D = null; App.S.drawer = null;
    if (!silent && App.softRefresh) App.softRefresh();
  }
  function isOpen() { return !!D; }
  function commit(detail) { D.d = detail; renderHead(); }
  function marked() { D.saved = 'Saved ' + new Date().toTimeString().slice(0, 5); const el = $('#savestate'); if (el) el.textContent = D.saved; if (App.softRefreshSoon) App.softRefreshSoon(); }

  async function saveTask(patch, rerender) {
    try {
      const d = await PUT('/api/tasks/' + D.id, patch);
      commit(d); marked();
      if (rerender) renderBody();
    } catch (e) { /* toast shown by api() */ }
  }
  function queueReq() {
    D.reqDirty = true; clearTimeout(D.reqTimer);
    D.reqTimer = setTimeout(flushReq, 600);
  }
  async function flushReq() {
    if (!D || !D.reqDirty) return;
    clearTimeout(D.reqTimer); D.reqDirty = false;
    try { await PUT('/api/tasks/' + D.id, { req: D.req }); marked(); } catch (e) { D.reqDirty = true; }
  }
  async function reload() { D.d = await GET('/api/tasks/' + D.id); renderHead(); renderBody(); }
  function setTab(k) { flushReq(); D.tab = k; App.LS.set('drawer_tab', k); renderHead(); renderBody(); D.body.scrollTop = 0; }

  /* ---------- header ---------- */
  function renderHead() {
    const d = D.d, t = d.task, meta = App.S.meta;
    const openIssues = d.issues.filter((i) => i.status === 'open').length;
    const badge = { req: null, check: t.cl_total ? t.cl_done + '/' + t.cl_total : null, files: d.files.length || null, release: openIssues || null, log: d.time.length ? fmtH(t.logged) : null };
    D.head.replaceChildren(
      h('div', { class: 'row wrap' },
        h('span', { class: 'mono ink2' }, t.code), App.tag(t.nature === 'change' ? 'Change in existing' : 'New development'), App.tag(App.typeLabel(t.task_type)), t.module ? App.tag(t.module) : null,
        h('span', { class: 'grow' }),
        h('span', { class: 'small muted', id: 'savestate' }, D.saved),
        h('button', { class: 'btn sm', type: 'button', title: 'Open this task folder in Explorer', onclick: openFolder }, ico('folder'), 'Task folder'),
        h('button', { class: 'iconbtn', type: 'button', 'aria-label': 'Close', onclick: () => closeDrawer() }, ico('x'))),
      h('input', { class: 'dr-title', type: 'text', value: t.title, 'aria-label': 'Task title', onchange: (e) => { if (e.target.value.trim()) saveTask({ title: e.target.value }); else e.target.value = t.title; } }),
      h('div', { class: 'row wrap', style: { margin: '8px 0 2px' } },
        sel(meta.statuses.map((s) => [s.key, s.label]), t.status, (v) => saveTask({ status: v }, D.tab === 'overview'), { class: 'sel-inline', 'aria-label': 'Status' }),
        sel(meta.priorities.map((p) => [p, cap(p)]), t.priority, (v) => saveTask({ priority: v }, D.tab === 'overview'), { class: 'sel-inline', 'aria-label': 'Priority' }),
        App.light(t), t.due_date ? h('span', { class: 'small ink2' }, 'Due ' + fmtD(t.due_date, true)) : null,
        h('span', { class: 'grow' }), h('div', { style: { width: '220px' } }, App.progress(t))),
      h('div', { class: 'tabs', role: 'tablist' }, TABS.map((tb) => h('button', { role: 'tab', 'aria-selected': D.tab === tb[0], class: D.tab === tb[0] ? 'on' : '', onclick: () => setTab(tb[0]) }, tb[1], badge[tb[0]] ? h('span', { class: 'badge soft' }, badge[tb[0]]) : null))));
  }
  function renderBody() {
    const fn = { overview: tabOverview, req: tabReq, check: tabCheck, files: tabFiles, release: tabRelease, dev: tabDev, log: tabLog }[D.tab];
    D.body.replaceChildren(fn());
  }
  async function openFolder() {
    try { const r = await POST('/api/tasks/' + D.id + '/open-folder'); toast('Opened ' + r.path); } catch (e) { /* shown */ }
  }

  /* ---------- Overview ---------- */
  function tabOverview() {
    const t = D.d.task, meta = App.S.meta;
    const names = Array.from(new Set((meta.names || []).concat(KB.people)));
    const modOpts = Object.keys(KB.modules).map((m) => [m, m === 'GEN' ? 'General / Basis' : m + ' - ' + KB.modules[m].name]);
    if (t.module && !KB.modules[t.module]) modOpts.push([t.module, t.module]);
    modOpts.unshift(['', 'Not set']);
    const dl = h('datalist', { id: 'names-dl' }, names.map((n) => h('option', { value: n })));
    const save = (k, rr) => (v) => saveTask({ [k]: v }, rr);
    const dateF = (label, k) => fld(label, h('input', { type: 'date', value: t[k] || '', onchange: (e) => saveTask({ [k]: e.target.value || null }, true) }));
    return h('div', null, dl,
      h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'What is this task')),
        h('div', { class: 'grid3' },
          fld('Type', sel(Object.keys(meta.type_labels).map((k) => [k, meta.type_labels[k]]), t.task_type, (v) => saveTask({ task_type: v }, true))),
          fld('New or change', sel([['new', 'New development'], ['change', 'Change in existing object']], t.nature, (v) => saveTask({ nature: v }, true))),
          fld('SAP module', sel(modOpts, t.module, save('module')))),
        h('div', { class: 'grid3', style: { marginTop: '12px' } },
          fld('Requested by', inp(t.requested_by, save('requested_by'), { list: 'names-dl', placeholder: 'Who explained the requirement' })),
          fld('Timeline committed to', inp(t.committed_to, save('committed_to'), { list: 'names-dl', placeholder: 'Who you gave the date to' })),
          fld('Department', inp(t.department, save('department'), { placeholder: 'Stores, Production, Purchase...' }))),
        h('div', { style: { marginTop: '12px' } }, fld('Short summary', area(t.summary, save('summary'), { placeholder: 'One or two lines: what the user wants' })))),
      h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'Dates and effort')),
        h('div', { class: 'grid4' },
          dateF('Received on', 'received_date'), dateF('Development start', 'start_date'), dateF('Due date', 'due_date'),
          fld('Estimated hours', h('div', { class: 'row' }, inp(t.est_hours == null ? '' : t.est_hours, (v) => saveTask({ est_hours: v }, true), { type: 'number', step: '0.5', min: '0', placeholder: 'e.g. 12' }),
            h('button', { class: 'btn sm', type: 'button', title: 'Calculate from type and complexity', onclick: () => App.estimateModal(t, (hrs, cx) => saveTask({ est_hours: hrs, complexity: cx }, true)) }, ico('calc'), 'Help')))),
        h('div', { class: 'grid4', style: { marginTop: '12px' } },
          fld('Complexity', sel([['simple', 'Simple'], ['medium', 'Medium'], ['complex', 'Complex']], t.complexity, save('complexity', true))),
          h('div', { class: 'fld', style: { gridColumn: 'span 3' } }, h('label', null, 'Progress'),
            h('div', { class: 'row' },
              h('div', { class: 'seg' },
                h('button', { type: 'button', class: t.progress_mode !== 'manual' ? 'on' : '', onclick: () => saveTask({ progress_mode: 'auto' }, true) }, 'Automatic'),
                h('button', { type: 'button', class: t.progress_mode === 'manual' ? 'on' : '', onclick: () => saveTask({ progress_mode: 'manual', progress_manual: t.progress }, true) }, 'Manual')),
              t.progress_mode === 'manual'
                ? [h('input', { type: 'range', min: 0, max: 100, step: 5, value: t.progress_manual, style: { maxWidth: '300px' }, oninput: (e) => { e.target.nextSibling.textContent = e.target.value + '%'; }, onchange: (e) => saveTask({ progress_manual: Number(e.target.value) }, false) }), h('b', null, t.progress_manual + '%')]
                : h('span', { class: 'small muted' }, 'Calculated from the checklist and the status (' + t.progress + '% now).')))),
        h('div', { class: 'row wrap', style: { marginTop: '14px', gap: '22px' } },
          stat('Days left', t.days_left == null ? '—' : t.days_left), stat('Work left', fmtH(t.remaining_hours)), stat('Working time before due', t.avail_hours == null ? '—' : fmtH(t.avail_hours)), stat('Time logged', fmtH(t.logged)),
          stat('Ranking score', t.score, 'Higher means develop it earlier. Built from priority, due date, waiting time and open quality points.'))),
      h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'Task folder')),
        h('p', { class: 'ink2' }, 'Everything uploaded for this task is saved on this PC in:'),
        h('p', { class: 'mono', style: { margin: '4px 0 8px', wordBreak: 'break-all' } }, meta.data_dir + (meta.platform.indexOf('win') === 0 ? '\\files\\' : '/files/') + t.folder),
        h('button', { class: 'btn', type: 'button', onclick: openFolder }, ico('folder'), 'Open folder')),
      h('section', { class: 'sec' }, h('button', { class: 'btn danger', type: 'button', onclick: deleteTask }, ico('trash'), 'Delete this task')));
  }
  const stat = (l, v, title) => h('div', { title: title || null }, h('div', { style: { fontSize: '20px', fontWeight: 600 } }, v), h('div', { class: 'small muted' }, l));
  async function deleteTask() {
    const t = D.d.task;
    if (!(await confirmBox('Delete ' + t.code + ' "' + t.title + '" with its history and file records? Its folder is moved to the "trash" folder inside the data folder, not erased.', 'Delete task'))) return;
    D.reqDirty = false; clearTimeout(D.reqTimer);   // nothing to save for a task that is being deleted
    await DEL('/api/tasks/' + D.id); toast(t.code + ' deleted'); closeDrawer();
  }

  /* ---------- Requirement ---------- */
  const SEC_KEYS = ['sel', 'out', 'logic', 'valid', 'auth', 'tables', 'tests', 'qa'];
  function kbFor(t) { return KB.types[t.task_type] || KB.types.other; }
  function suggestions(t, key) {
    const K = kbFor(t), M = KB.modules[t.module] || KB.modules.GEN, list = D.req[key] || [];
    const have = new Set(list.map((x) => (typeof x === 'string' ? x : (x.n || x.q || x.t || '')).toLowerCase()));
    let src = [];
    if (key === 'sel' || key === 'out') src = (K[key] || []).map((p) => ({ label: p.n, sub: p.d, item: { n: p.n, d: p.d, m: !!p.m }, k: p.n.toLowerCase() }));
    else if (key === 'qa') src = (K.qa || []).map((q) => ({ label: q, item: { q: q, a: '' }, k: q.toLowerCase() }));
    else {
      let arr = K[key] || [];
      if (key === 'auth' && M) arr = arr.concat(M.auth);
      if (key === 'tables' && M) arr = M.tables.concat(M.fms, M.enh).map((x) => x.n + ' - ' + x.d);
      src = arr.map((s) => ({ label: s, item: s, k: String(s).toLowerCase() }));
    }
    return src.filter((s) => !have.has(s.k));
  }
  function parseLines(text, key) {
    return text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).map((l) => {
      if (key === 'qa') return { q: l, a: '' };
      if (key === 'sel' || key === 'out') { const m = l.match(/^([^\t]+?)\s*(?:\t|\s[-–]\s|:)\s*(.*)$/); return m ? { n: m[1].trim(), d: m[2].trim(), m: false } : { n: l, d: '', m: false }; }
      return l;
    });
  }
  function tabReq() {
    const t = D.d.task, K = kbFor(t), root = h('div');
    const textBox = (k, label, ph) => fld(label, area(D.req[k] || '', (v) => { D.req[k] = v; queueReq(); }, { placeholder: ph }));
    root.append(h('section', { class: 'sec' },
      h('div', { class: 'grid2' }, textBox('need', 'What the user wants (in your words)', 'Explain the requirement as understood from the requester'), textBox('expected', 'Expected result', 'What the user should see or get when it is done')),
      h('div', { style: { marginTop: '12px' } }, textBox('remarks', 'Remarks / special instructions', 'Anything else: rules, exceptions, who to call for testing...'))));
    if (t.nature === 'change') root.append(changeBlock(t));
    if (t.module && KB.modules[t.module] && App.refModal) {
      root.append(h('div', { class: 'row', style: { marginBottom: '14px' } },
        h('button', { class: 'btn sm', type: 'button', onclick: () => App.refModal(t.module) }, ico('library'), 'SAP reference for ' + t.module + ' (tables, T-codes, BAPIs, exits)'),
        h('span', { class: 'small muted' }, 'Use Suggestions in each section below to add points with one click.')));
    }
    SEC_KEYS.forEach((k) => root.append(reqSection(t, k, K)));
    return root;
  }
  function changeBlock(t) {
    const ex = D.req.existing = D.req.existing || { name: '', tcode: '', desc: '' };
    const box = h('div');
    function draw() {
      const list = D.req.changes = D.req.changes || [];
      const sg = CHANGE_IDEAS.filter((s) => !list.some((c) => c.t.toLowerCase() === s.toLowerCase()));
      box.replaceChildren(
        h('div', { class: 'note-box', style: { marginBottom: '14px' } }, h('b', null, 'Take a backup before you change anything'),
          h('ul', null, (KB.backupGuide[t.task_type] || KB.backupGuide.other).map((s) => h('li', null, s))),
          h('div', { style: { marginTop: '8px' } }, h('button', { class: 'btn sm', type: 'button', onclick: () => { D.tab = 'files'; D.uploadCat = 'backup'; renderHead(); renderBody(); } }, ico('upload'), 'Upload backup files'))),
        h('div', { class: 'sec-h' }, h('h3', null, 'Existing object to change')),
        h('div', { class: 'grid3' },
          fld('Program / form / table name', inp(ex.name, (v) => { ex.name = v; queueReq(); }, { class: 'mono', placeholder: 'ZMMR_STOCK_REPORT' })),
          fld('T-code', inp(ex.tcode, (v) => { ex.tcode = v; queueReq(); }, { class: 'mono', placeholder: 'ZSTOCK' })),
          fld('What it does today', inp(ex.desc, (v) => { ex.desc = v; queueReq(); }, { placeholder: 'Short description' }))),
        h('div', { class: 'sec-h', style: { marginTop: '16px' } }, h('h3', null, 'What to change'), h('span', { class: 'cnt' }, list.length ? list.filter((c) => c.done).length + ' of ' + list.length + ' done' : ''),
          h('div', { class: 'acts' }, h('button', { class: 'btn sm', type: 'button', onclick: () => { list.push({ t: '', done: false }); draw(); const ins = box.querySelectorAll('.i-chg input[type=text]'); if (ins.length) ins[ins.length - 1].focus(); } }, ico('plus'), 'Add change point'))),
        list.map((c, i) => h('div', { class: 'item i-chg' },
          h('input', { type: 'checkbox', checked: !!c.done, 'aria-label': 'Done', onchange: (e) => { c.done = e.target.checked; queueReq(); draw(); } }),
          inp(c.t, (v) => { c.t = v; queueReq(); }, { placeholder: 'Describe the change (e.g. add Vendor name column after PO number)' }),
          h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Remove', onclick: () => { list.splice(i, 1); queueReq(); draw(); } }, ico('x')))),
        !list.length ? h('div', { class: 'empty' }, h('b', null, 'No change points yet'), 'Write each change the user asked for, so you can tick them off.') : null,
        sg.length ? h('div', { class: 'sugg' }, sg.map((s) => h('button', { class: 'tag btn-like', type: 'button', onclick: () => { list.push({ t: s, done: false }); queueReq(); draw(); } }, '+ ' + s))) : null);
    }
    draw();
    return h('section', { class: 'sec' }, box);
  }
  function reqSection(t, key, K) {
    const kind = key === 'sel' || key === 'out' ? 'obj' : key === 'qa' ? 'qa' : 'str';
    const wrap = h('section', { class: 'sec' });
    let showS = false;
    function newItem() { return kind === 'obj' ? { n: '', d: '', m: false } : kind === 'qa' ? { q: '', a: '' } : ''; }
    function draw() {
      const list = D.req[key] = D.req[key] || [];
      const sg = suggestions(t, key);
      const label = (K.labels && K.labels[key]) || key;
      const xl = D.d.files.filter((f) => /\.(xlsx|xlsm|csv)$/i.test(f.filename));
      const acts = h('div', { class: 'acts' },
        sg.length ? h('button', { class: 'btn sm' + (showS ? ' primary' : ''), type: 'button', onclick: () => { showS = !showS; draw(); } }, ico('bolt'), 'Suggestions (' + sg.length + ')') : null,
        key === 'out' && xl.length ? h('button', { class: 'btn sm', type: 'button', title: 'Take the header row of the uploaded requirement Excel as output columns', onclick: () => importHeaders(list, draw) }, ico('file'), 'From Excel') : null,
        h('button', { class: 'btn sm', type: 'button', onclick: () => pasteList(key, list, draw) }, ico('copy'), 'Paste list'),
        h('button', { class: 'btn sm', type: 'button', onclick: () => {
          list.push(newItem()); queueReq(); draw();
          // focus the first input of the row that was just added
          const ins = wrap.querySelectorAll('.item input:not([type=checkbox])');
          const per = kind === 'str' ? 1 : 2;
          if (ins.length >= per) ins[ins.length - per].focus();
        } }, ico('plus'), 'Add'));
      const rows = list.map((it, i) => {
        const del = h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Remove', onclick: () => { list.splice(i, 1); queueReq(); draw(); } }, ico('x'));
        if (kind === 'obj') return h('div', { class: 'item ' + (key === 'sel' ? 'i-sel' : 'i-out') },
          inp(it.n, (v) => { it.n = v.trim(); queueReq(); }, { class: 'mono', placeholder: 'Field name', 'aria-label': 'Field name' }),
          inp(it.d, (v) => { it.d = v; queueReq(); }, { placeholder: 'Description / rule', 'aria-label': 'Description' }),
          key === 'sel' ? h('label', { class: 'mc' }, h('input', { type: 'checkbox', checked: !!it.m, onchange: (e) => { it.m = e.target.checked; queueReq(); } }), 'Mandatory') : null, del);
        if (kind === 'qa') return h('div', { class: 'item i-qa' }, inp(it.q, (v) => { it.q = v; queueReq(); }, { placeholder: 'Question for the requester', 'aria-label': 'Question' }), inp(it.a, (v) => { it.a = v; queueReq(); }, { placeholder: 'Answer', 'aria-label': 'Answer' }), del);
        return h('div', { class: 'item i-str' }, inp(it, (v) => { list[i] = v; queueReq(); }, { 'aria-label': label }), del);
      });
      wrap.replaceChildren(
        h('div', { class: 'sec-h' }, h('h3', null, cap(label)), h('span', { class: 'cnt' }, list.length ? list.length + (list.length === 1 ? ' item' : ' items') : ''), acts),
        showS && sg.length ? h('div', { class: 'sugg' }, sg.map((s) => h('button', { class: 'tag btn-like', type: 'button', title: 'Click to add', onclick: () => { list.push(s.item); queueReq(); draw(); } }, '+ ', s.sub ? [h('span', { class: 'mono' }, s.label), ' ', h('span', { class: 'm' }, s.sub)] : s.label))) : null,
        rows.length ? rows : h('div', { class: 'empty' }, 'Nothing added yet. Use Suggestions to add common points with one click, or Add to write your own.'));
    }
    draw();
    return wrap;
  }
  function pasteList(key, list, redraw) {
    const ta = h('textarea', { rows: 10, placeholder: 'One item per line.\nFor fields: NAME - description (or copy two columns from Excel).' });
    const m = modal({ title: 'Paste a list', body: [h('p', { class: 'ink2', style: { marginBottom: '8px' } }, 'Each line becomes one item. Useful for copying a column list from the requirement Excel.'), ta],
      actions: [{ label: 'Cancel' }, { label: 'Add items', cls: 'primary', onClick: () => { const items = parseLines(ta.value, key); if (!items.length) return false; items.forEach((x) => list.push(x)); queueReq(); redraw(); toast(items.length + ' items added'); } }] });
    setTimeout(() => ta.focus(), 30); return m;
  }
  async function importHeaders(list, redraw) {
    const xl = D.d.files.filter((f) => /\.(xlsx|xlsm|csv)$/i.test(f.filename));
    async function take(f) {
      try {
        const p = await GET('/api/files/' + f.id + '/preview');
        if (p.type !== 'sheet' || !p.rows.length) { toast('Could not read columns from ' + f.filename, 'err'); return; }
        const hdr = p.rows.find((r) => r.some((c) => String(c).trim())) || [];
        let n = 0;
        hdr.forEach((c) => { c = String(c).trim(); if (c && !list.some((x) => (x.n || '').toLowerCase() === c.toLowerCase())) { list.push({ n: c, d: '', m: false }); n++; } });
        queueReq(); redraw(); toast(n + ' columns added from ' + f.filename);
      } catch (e) { /* toast shown */ }
    }
    if (xl.length === 1) return take(xl[0]);
    const m = modal({ title: 'Take columns from which file?', body: h('div', { class: 'stack' }, xl.map((f) => h('button', { class: 'btn', type: 'button', onclick: () => { m.close(); take(f); } }, ico('file'), f.filename))), actions: [{ label: 'Cancel' }] });
  }

  /* ---------- Checklist ---------- */
  function tabCheck() {
    const t = D.d.task, items = D.d.checklist, K = kbFor(t);
    const std = (t.nature === 'change' ? K.checklistChange : K.checklistNew) || [];
    const missing = std.filter((s) => !items.some((c) => c.text.toLowerCase() === s.toLowerCase()));
    const addIn = h('input', { type: 'text', placeholder: 'Add a step and press Enter' });
    const addOne = async () => { const v = addIn.value.trim(); if (!v) return; addIn.value = ''; commit(await POST('/api/tasks/' + D.id + '/checklist', { text: v })); renderBody(); marked(); };
    addIn.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addOne(); } });
    const toggle = async (c, v) => { commit(await PUT('/api/checklist/' + c.id, { done: v })); renderBody(); marked(); };
    return h('div', null,
      h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'Steps to finish this task'), h('span', { class: 'cnt' }, t.cl_total ? t.cl_done + ' of ' + t.cl_total + ' done' : '')),
        t.cl_total ? h('div', { style: { margin: '0 0 12px' } }, App.bar(Math.round(100 * t.cl_done / t.cl_total), 'var(--c-ok)', 'lg')) : null,
        items.length ? items.map((c) => h('div', { class: 'item i-chg' },
          h('input', { type: 'checkbox', checked: !!c.done, 'aria-label': 'Done', onchange: (e) => toggle(c, e.target.checked) }),
          inp(c.text, async (v) => { if (v.trim()) { commit(await PUT('/api/checklist/' + c.id, { text: v })); marked(); } }, { style: { textDecoration: c.done ? 'line-through' : 'none', color: c.done ? 'var(--ink-3)' : '' }, 'aria-label': 'Step' }),
          h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Remove', onclick: async () => { commit(await DEL('/api/checklist/' + c.id)); renderBody(); } }, ico('x')))) :
          h('div', { class: 'empty' }, h('b', null, 'No steps yet'), 'Add the standard steps for this type of task with one click.'),
        h('div', { class: 'row', style: { marginTop: '10px' } }, addIn, h('button', { class: 'btn', type: 'button', onclick: addOne }, ico('plus'), 'Add')),
        missing.length ? h('div', { style: { marginTop: '12px' } }, h('button', { class: 'btn', type: 'button', onclick: async () => { commit(await POST('/api/tasks/' + D.id + '/checklist', { items: missing })); renderBody(); marked(); } }, ico('bolt'), 'Add the standard ' + App.typeLabel(t.task_type) + ' steps (' + missing.length + ')')) : null,
        h('p', { class: 'small muted', style: { marginTop: '12px' } }, t.progress_mode === 'manual' ? 'Progress is set manually in Overview.' : 'Progress is calculated from these steps together with the status, so ticking steps moves the bar.')));
  }

  /* ---------- Files ---------- */
  const EXT_ICON = (n) => (n.split('.').pop() || '').slice(0, 4).toUpperCase();
  const isImg = (n) => /\.(png|jpe?g|gif|bmp|webp)$/i.test(n);
  function tabFiles() {
    const t = D.d.task, meta = App.S.meta;
    const catSel = sel([['auto', 'Detect from file type']].concat(CATS.map((c) => [c, meta.cats[c]])), D.uploadCat || 'auto', (v) => { D.uploadCat = v; });
    const note = h('input', { type: 'text', placeholder: 'Note (e.g. before adding vendor column)' }), ver = h('input', { type: 'text', placeholder: 'Version / date (optional)', style: { maxWidth: '190px' } });
    const picker = h('input', { type: 'file', multiple: true, class: 'hide', onchange: (e) => { doUpload(Array.from(e.target.files), catSel.value, note.value, ver.value); e.target.value = ''; } });
    const drop = h('div', { class: 'drop' },
      h('div', { style: { marginBottom: '8px' } }, ico('upload'), ' Drop files here, paste a screenshot (Ctrl+V), or '), h('button', { class: 'btn', type: 'button', onclick: () => picker.click() }, 'Choose files'), picker,
      h('div', { class: 'small muted', style: { marginTop: '8px' } }, 'Images, Excel, backups (.txt .xml .abap), PDF, Word: any file type, up to 500 MB each.'));
    ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => doUpload(Array.from(e.dataTransfer.files), catSel.value, note.value, ver.value));
    const groups = CATS.map((c) => ({ c: c, list: D.d.files.filter((f) => f.category === c) })).filter((g) => g.list.length);
    return h('div', null,
      t.nature === 'change' ? h('div', { class: 'note-box', style: { marginBottom: '14px' } }, h('b', null, 'Backup before change'), h('div', { class: 'small', style: { marginTop: '3px' } }, 'Upload the current version (program source .txt, form .xml, template, screenshots) under "' + meta.cats.backup + '" so you can always go back.')) : null,
      h('section', { class: 'sec' },
        h('div', { class: 'grid3', style: { marginBottom: '10px' } }, fld('Save as', catSel), fld('Note', note), fld('Version', ver)), drop),
      groups.length ? groups.map((g) => h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, meta.cats[g.c]), h('span', { class: 'cnt' }, g.list.length)),
        h('div', { class: 'files' }, g.list.map(fileCard)))) : h('div', { class: 'empty', style: { marginTop: '16px' } }, h('b', null, 'No files yet'), 'Add the requirement Excel, reference images and backups here. They are saved in this task\'s own folder.'));
  }
  function fileCard(f) {
    const thumb = isImg(f.filename) ? h('img', { src: '/files/' + f.id, alt: f.filename, loading: 'lazy' }) : h('span', { class: 'ext' }, EXT_ICON(f.filename));
    return h('div', { class: 'file' },
      h('div', { class: 'thumb', onclick: () => previewFile(f), title: 'Preview' }, thumb),
      h('div', { class: 'meta' }, h('b', null, f.filename), h('span', { class: 'muted' }, fmtSize(f.size) + ', ' + fmtTs(f.uploaded_at)), f.version ? h('span', null, 'Version: ' + f.version) : null, f.note ? h('span', { class: 'ink2' }, f.note) : null),
      h('div', { class: 'fa' },
        h('button', { class: 'iconbtn sm', type: 'button', title: 'Preview', onclick: () => previewFile(f) }, ico('eye')),
        h('a', { class: 'iconbtn sm', href: '/files/' + f.id + '?dl=1', title: 'Download / open', download: f.filename }, ico('download')),
        h('button', { class: 'iconbtn sm', type: 'button', title: 'Edit note, version or category', onclick: () => editFile(f) }, ico('edit')),
        h('button', { class: 'iconbtn sm', type: 'button', title: 'Delete', onclick: async () => { if (await confirmBox('Delete ' + f.filename + '? It is moved to the trash folder.', 'Delete file')) { await DEL('/api/files/' + f.id); await reload(); } } }, ico('trash'))));
  }
  async function doUpload(files, category, note, version) {
    if (!files.length) return;
    let ok = 0;
    for (let i = 0; i < files.length; i++) {
      toast('Uploading ' + (i + 1) + ' of ' + files.length + ': ' + files[i].name);
      try { await App.uploadFile(D.id, files[i], category, note, version); ok++; } catch (e) { /* shown */ }
    }
    if (ok) { toast(ok + (ok === 1 ? ' file saved' : ' files saved')); await reload(); }
  }
  function previewFile(f) {
    if (isImg(f.filename)) {
      const lb = h('div', { class: 'lightbox', onclick: () => lb.remove() }, h('button', { class: 'btn x', type: 'button' }, 'Close'), h('img', { src: '/files/' + f.id, alt: f.filename }));
      document.body.append(lb);
      const esc = (e) => { if (e.key === 'Escape') { lb.remove(); document.removeEventListener('keydown', esc, true); e.stopPropagation(); } };
      document.addEventListener('keydown', esc, true); return;
    }
    const body = h('div', null, h('p', { class: 'muted' }, 'Loading preview...'));
    const m = modal({ title: f.filename, cls: 'wide', body: body, actions: [{ label: 'Close' }], foot: h('a', { class: 'btn', href: '/files/' + f.id + '?dl=1', download: f.filename }, ico('download'), 'Download') });
    function show(sheetIdx) {
      GET('/api/files/' + f.id + '/preview' + (sheetIdx ? '?sheet=' + sheetIdx : '')).then((p) => {
        if (p.type === 'sheet') {
          const rows = p.rows, w = Math.max.apply(null, rows.map((r) => r.length).concat([1]));
          body.replaceChildren(p.sheets.length > 1 ? h('div', { style: { marginBottom: '8px' } }, sel(p.sheets.map((s, i) => [i, s]), p.sheet, (v) => show(Number(v)), { style: { width: 'auto' } })) : null,
            h('div', { style: { overflow: 'auto', maxHeight: '60vh' } }, h('table', { class: 'sheet' }, rows.map((r, ri) => h('tr', null, Array.from({ length: w }, (_, ci) => h(ri === 0 ? 'th' : 'td', null, r[ci] == null ? '' : r[ci])))))),
            rows.length >= 300 ? h('p', { class: 'small muted' }, 'Showing the first 300 rows.') : null);
        } else if (p.type === 'text') body.replaceChildren(h('pre', { class: 'txt' }, p.text), p.truncated ? h('p', { class: 'small muted' }, 'Showing the first 400 KB.') : null);
        else body.replaceChildren(h('div', { class: 'empty' }, p.reason || 'No preview available.'));
      }).catch(() => body.replaceChildren(h('div', { class: 'empty' }, 'Preview failed.')));
    }
    show(0); return m;
  }
  function editFile(f) {
    const meta = App.S.meta;
    const note = inp(f.note), ver = inp(f.version), cat = sel(CATS.map((c) => [c, meta.cats[c]]), f.category);
    modal({ title: f.filename, body: h('div', { class: 'stack' }, fld('Category', cat), fld('Note', note), fld('Version', ver)),
      actions: [{ label: 'Cancel' }, { label: 'Save', cls: 'primary', onClick: async () => { await PUT('/api/files/' + f.id, { note: note.value, version: ver.value, category: cat.value }); await reload(); } }] });
  }
  function onPaste(e) {
    if (!D) return;
    const tg = e.target && e.target.tagName;
    if (tg === 'INPUT' || tg === 'TEXTAREA') return;
    const items = Array.from((e.clipboardData && e.clipboardData.items) || []).filter((i) => i.kind === 'file' && i.type.indexOf('image/') === 0);
    if (!items.length) return;
    e.preventDefault();
    const stamp = new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14);
    const files = items.map((it, i) => { const b = it.getAsFile(); return new File([b], 'screenshot_' + stamp + (i ? '_' + (i + 1) : '') + '.png', { type: b.type }); });
    doUpload(files, 'image', 'Pasted screenshot', '');
  }
  document.addEventListener('paste', onPaste);

  /* ---------- Release & quality ---------- */
  function tabRelease() {
    const t = D.d.task, d = D.d, root = h('div');
    root.append(movesSection(t, d), issuesSection('quality', 'Quality / UAT points', 'Changes or corrections the user asked for while testing or reviewing. Tick each one when done.', KB.qualityIdeas), issuesSection('prod', 'Problems after production move', 'Errors or complaints reported after the transport reached production.', []));
    return root;
  }
  function movesSection(t, d) {
    const env = sel(KB.envs.map((e) => [e, e === 'DEV' ? 'DEV (Development)' : e === 'QAS' ? 'QAS (Quality)' : 'PRD (Production)']), 'QAS', null, { style: { width: 'auto' } });
    const tr = h('input', { type: 'text', class: 'mono', placeholder: 'Transport e.g. DEVK900451', style: { maxWidth: '210px' } });
    const dt = h('input', { type: 'date', value: App.todayIso(), style: { maxWidth: '150px' } });
    const res = sel([['ok', 'No problem'], ['issue', 'Issue after move']], 'ok', null, { style: { width: 'auto' } });
    const nt = h('input', { type: 'text', placeholder: 'Note' });
    const prdMoves = d.moves.filter((m) => m.env === 'PRD');
    const last = prdMoves.length ? prdMoves[0] : null;
    return h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'Transports and movement'), h('span', { class: 'cnt' }, d.moves.length ? d.moves.length + ' moves' : '')),
      d.moves.length ? h('div', { class: 'gridwrap', style: { maxHeight: 'none' } }, h('table', { class: 'grid' },
        h('thead', null, h('tr', null, ['System', 'Transport', 'Date', 'Result', 'Note', ''].map((x) => h('th', null, x)))),
        h('tbody', null, d.moves.map((m) => h('tr', null, h('td', null, h('span', { class: 'chip', style: { '--c': m.env === 'PRD' ? 'var(--c-ok)' : m.env === 'QAS' ? 'var(--c-warning)' : 'var(--accent)' } }, m.env)), h('td', { class: 'mono' }, m.tr_number || '—'), h('td', null, fmtD(m.moved_on, true)),
          h('td', null, m.result === 'issue' ? h('span', { class: 'light l-overdue' }, 'Issue after move') : h('span', { class: 'light l-ok' }, 'No problem')), h('td', null, m.note), h('td', null, h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Remove', onclick: async () => { commit(await DEL('/api/moves/' + m.id)); renderBody(); } }, ico('x')))))))) : h('div', { class: 'empty' }, 'No transport recorded yet.'),
      last ? h('p', { class: 'small ink2', style: { margin: '8px 0 0' } }, 'In production since ' + fmtD(last.moved_on, true) + ' (' + Math.max(0, App.daysBetween(App.pd(last.moved_on), new Date())) + ' days). ' + (d.issues.some((i) => i.kind === 'prod') ? '' : 'No problems recorded after the move.'),
        !d.issues.some((i) => i.kind === 'prod') ? h('button', { class: 'btn sm', style: { marginLeft: '8px' }, type: 'button', onclick: async () => { commit(await POST('/api/tasks/' + D.id + '/notes', { text: 'Production check: no problems reported after the move.' })); renderBody(); marked(); } }, ico('check'), 'Confirm stable') : null) : null,
      h('div', { class: 'row wrap', style: { marginTop: '10px' } }, env, tr, dt, res, h('div', { class: 'grow' }, nt),
        h('button', { class: 'btn primary', type: 'button', onclick: async () => {
          const e = env.value; commit(await POST('/api/tasks/' + D.id + '/moves', { env: e, tr_number: tr.value, moved_on: dt.value, result: res.value, note: nt.value })); marked();
          const cur = D.d.task.status;
          const target = e === 'PRD' ? 'prod' : e === 'QAS' ? 'quality' : null;
          const order = ['new', 'analysis', 'dev', 'unit_test', 'quality', 'prod', 'closed'];
          if (target && order.indexOf(cur) >= 0 && order.indexOf(cur) < order.indexOf(target) && await confirmBox('Change status to "' + App.statusOf(target).label + '"?', 'Yes, change it', false)) await saveTask({ status: target });
          renderBody();
        } }, ico('plus'), 'Record move')));
  }
  function issuesSection(kind, title, hint, ideas) {
    const list = D.d.issues.filter((i) => i.kind === kind), open = list.filter((i) => i.status === 'open').length;
    const ti = h('input', { type: 'text', placeholder: kind === 'prod' ? 'What went wrong (e.g. short dump on page 2)' : 'What should be changed or added' });
    const sev = sel([['low', 'Low'], ['medium', 'Medium'], ['high', 'High']], kind === 'prod' ? 'high' : 'medium', null, { style: { width: 'auto' } });
    const add = async (text) => { const v = (text || ti.value).trim(); if (!v) return; commit(await POST('/api/tasks/' + D.id + '/issues', { kind: kind, title: v, severity: sev.value })); renderBody(); marked(); };
    ti.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } });
    const sg = (ideas || []).filter((s) => !list.some((i) => i.title.toLowerCase() === s.toLowerCase()));
    return h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, title), h('span', { class: 'cnt' }, list.length ? open + ' open of ' + list.length : '')),
      h('p', { class: 'small ink2', style: { marginBottom: '8px' } }, hint),
      kind === 'prod' ? h('div', { class: 'note-box info', style: { marginBottom: '10px' } }, h('b', null, 'After a production move, check'), h('ul', null, KB.afterMoveChecks.map((c) => h('li', null, c)))) : null,
      list.map((i) => h('div', { class: 'item', style: { gridTemplateColumns: '22px minmax(0,1fr) auto 30px', alignItems: 'center', borderBottom: '1px solid var(--line-2)', padding: '7px 0' } },
        h('input', { type: 'checkbox', checked: i.status === 'fixed', 'aria-label': 'Fixed', onchange: async (e) => { commit(await PUT('/api/issues/' + i.id, { status: e.target.checked ? 'fixed' : 'open' })); renderBody(); marked(); } }),
        h('div', null, h('div', { style: { textDecoration: i.status === 'fixed' ? 'line-through' : 'none', color: i.status === 'fixed' ? 'var(--ink-3)' : '', fontWeight: 500 } }, i.title),
          h('div', { class: 'small muted' }, 'Raised ' + fmtD(i.raised_on, true) + (i.fixed_on ? ', fixed ' + fmtD(i.fixed_on, true) : '') + (i.details ? ' - ' + i.details : ''))),
        h('span', { class: 'chip', style: { '--c': i.severity === 'high' ? 'var(--c-overdue)' : i.severity === 'medium' ? 'var(--c-warning)' : 'var(--c-none)' } }, cap(i.severity)),
        h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Remove', onclick: async () => { commit(await DEL('/api/issues/' + i.id)); renderBody(); } }, ico('x')))),
      !list.length ? h('div', { class: 'empty' }, kind === 'prod' ? 'No problems reported after production.' : 'No quality points yet.') : null,
      h('div', { class: 'row', style: { marginTop: '10px' } }, h('div', { class: 'grow' }, ti), sev, h('button', { class: 'btn primary', type: 'button', onclick: () => add() }, ico('plus'), 'Add')),
      sg.length ? h('div', { class: 'sugg' }, sg.map((s) => h('button', { class: 'tag btn-like', type: 'button', onclick: () => add(s) }, '+ ' + s))) : null);
  }

  /* ---------- Dev info (register) ---------- */
  function tabDev() {
    const t = D.d.task, K = kbFor(t);
    const dev = D.d.task.dev = D.d.task.dev || {};
    const put = (k) => (v) => { dev[k] = v; saveTask({ dev: dev }); };
    const field = (f) => f.area ? fld(f.l, area(dev[f.k], put(f.k), { placeholder: f.ph || '', rows: 3 })) : fld(f.l, inp(dev[f.k], put(f.k), { type: f.type || 'text', placeholder: f.ph || '', class: f.k === 'tcode' || f.k === 'obj_name' ? 'mono' : '' }));
    const base = KB.devRegisterFields.filter((f) => !f.area), long = KB.devRegisterFields.filter((f) => f.area);
    const pairs = dev.pairs = dev.pairs || [];
    const pairBox = h('div');
    function drawPairs() {
      pairBox.replaceChildren(pairs.map((p, i) => h('div', { class: 'item', style: { gridTemplateColumns: '200px minmax(0,1fr) 30px' } },
        inp(p.k, (v) => { p.k = v; saveTask({ dev: dev }); }, { placeholder: 'Label (e.g. Authorization object)' }), inp(p.v, (v) => { p.v = v; saveTask({ dev: dev }); }, { placeholder: 'Value' }),
        h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Remove', onclick: () => { pairs.splice(i, 1); saveTask({ dev: dev }); drawPairs(); } }, ico('x')))),
        h('button', { class: 'btn sm', type: 'button', onclick: () => { pairs.push({ k: '', v: '' }); drawPairs(); const ins = pairBox.querySelectorAll('input'); ins[ins.length - 2].focus(); } }, ico('plus'), 'Add another detail'));
    }
    drawPairs();
    return h('div', null,
      h('p', { class: 'ink2', style: { marginBottom: '14px', maxWidth: '75ch' } }, 'Fill this after development. It feeds the Register page, so months later you can find the T-code, program name and what was done in seconds.'),
      h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'Object details'), h('div', { class: 'acts' }, h('button', { class: 'btn sm', type: 'button', onclick: () => copyRegister(t, dev, K) }, ico('copy'), 'Copy as text'))),
        h('div', { class: 'grid3' }, base.map(field))),
      K.devExtra && K.devExtra.length ? h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, App.typeLabel(t.task_type) + ' details')), h('div', { class: 'grid3' }, K.devExtra.map((f) => fld(f.l, inp(dev[f.k], put(f.k)))))) : null,
      h('section', { class: 'sec' }, h('div', { class: 'stack' }, long.map(field))),
      h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'More details')), pairBox));
  }
  function copyRegister(t, dev, K) {
    const L = [t.code + '  ' + t.title, 'Type: ' + App.typeLabel(t.task_type) + (t.module ? '   Module: ' + t.module : '')];
    KB.devRegisterFields.forEach((f) => { if (dev[f.k]) L.push(f.l + ': ' + dev[f.k]); });
    (K.devExtra || []).forEach((f) => { if (dev[f.k]) L.push(f.l + ': ' + dev[f.k]); });
    (dev.pairs || []).forEach((p) => { if (p.k && p.v) L.push(p.k + ': ' + p.v); });
    App.copyText(L.join('\n'), 'Details copied');
  }

  /* ---------- Time & notes ---------- */
  function tabLog() {
    const t = D.d.task, d = D.d;
    const dt = h('input', { type: 'date', value: App.todayIso(), style: { maxWidth: '150px' } }), hr = h('input', { type: 'number', step: '0.25', min: '0.25', max: '24', placeholder: 'Hours', style: { maxWidth: '100px' } }), nt = h('input', { type: 'text', placeholder: 'What did you do' });
    const addT = async () => { if (!hr.value) { hr.focus(); return; } commit(await POST('/api/tasks/' + D.id + '/time', { log_date: dt.value, hours: hr.value, note: nt.value })); renderBody(); marked(); };
    nt.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addT(); } });
    const note = h('textarea', { rows: 2, placeholder: 'Write a note: what was discussed, a decision, something to remember' });
    const pct = t.est_hours ? Math.round(100 * t.logged / t.est_hours) : null;
    return h('div', null,
      h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'Time spent'), h('span', { class: 'cnt' }, fmtH(t.logged) + (t.est_hours ? ' of ' + fmtH(t.est_hours) + ' estimated' : ''))),
        pct != null ? h('div', { style: { marginBottom: '10px' } }, App.bar(Math.min(100, pct), pct > 100 ? 'var(--c-overdue)' : 'var(--accent)', 'lg'), pct > 100 ? h('div', { class: 'small', style: { color: 'var(--c-overdue)', marginTop: '3px' } }, 'Over the estimate by ' + fmtH(t.logged - t.est_hours) + '. Note this for future estimates.') : null) : null,
        h('div', { class: 'row wrap' }, dt, hr, h('div', { class: 'grow' }, nt), h('button', { class: 'btn primary', type: 'button', onclick: addT }, ico('plus'), 'Log time')),
        d.time.length ? h('div', { class: 'gridwrap', style: { maxHeight: '260px', marginTop: '10px' } }, h('table', { class: 'grid' }, h('tbody', null, d.time.map((x) => h('tr', null, h('td', null, fmtD(x.log_date, true)), h('td', { class: 'num' }, fmtH(x.hours)), h('td', null, x.note), h('td', null, h('button', { class: 'iconbtn sm', type: 'button', 'aria-label': 'Remove', onclick: async () => { commit(await DEL('/api/time/' + x.id)); renderBody(); } }, ico('x')))))))) : null),
      h('section', { class: 'sec' }, h('div', { class: 'sec-h' }, h('h3', null, 'Notes and activity')),
        note, h('div', { style: { margin: '6px 0 12px' } }, h('button', { class: 'btn', type: 'button', onclick: async () => { const v = note.value.trim(); if (!v) return; commit(await POST('/api/tasks/' + D.id + '/notes', { text: v })); renderBody(); marked(); } }, ico('plus'), 'Add note')),
        h('div', { class: 'tl-list' }, d.history.map((e) => h('div', { class: 'ev' }, h('time', null, fmtTs(e.ts)), h('div', null, h('span', { class: 'k ' + e.kind }, e.kind), e.text))))));
  }

  /* ---------- global keys ---------- */
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && D && !document.querySelector('dialog[open]') && !document.querySelector('.lightbox')) closeDrawer();
  });
  // if the window is closed right after typing, still save the pending requirement text
  window.addEventListener('beforeunload', () => {
    if (D && D.reqDirty) {
      try { fetch('/api/tasks/' + D.id, { method: 'PUT', keepalive: true, headers: { 'X-TM': '1', 'Content-Type': 'application/json' }, body: JSON.stringify({ req: D.req }) }); } catch (e) { /* ignore */ }
    }
  });

  App.openTask = openTask; App.closeDrawer = closeDrawer; App.drawerOpen = isOpen;
})();
