# -*- coding: utf-8 -*-
"""
TaskDesk launcher (what the desktop icon / Start menu entry runs).

1. Finds the running TaskDesk gate, or starts it (no black console window).
2. Opens the gate in an app-style window (Edge / Chrome without tabs and address bar).
The gate shows the sign-in screen, or - when you are already signed in - goes straight to your workspace.
"""
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
import webbrowser

APP_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP_ROOT)

from tmcore import paths                                     # noqa: E402


def message(title, text):
    try:
        if os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, text, title, 0x10)
            return
    except Exception:
        pass
    sys.stderr.write('%s\n%s\n' % (title, text))


def gate_info():
    info = paths.read_json(os.path.join(paths.run_dir(), 'gate.json'))
    if not info or not info.get('port'):
        return None
    try:
        with urllib.request.urlopen('http://127.0.0.1:%d/__gate/ping' % info['port'], timeout=1.5) as r:
            if json.loads(r.read().decode('utf-8')).get('app') == 'taskdesk-gate':
                return info
    except Exception:
        pass
    return None


def start_gate():
    logp = os.path.join(paths.log_dir(), 'gate.log')
    lf = open(logp, 'a', encoding='utf-8', errors='replace')
    lf.write('\n--- start %s ---\n' % time.strftime('%Y-%m-%d %H:%M:%S'))
    lf.flush()
    env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONUTF8='1')
    subprocess.Popen([paths.python_exe(), os.path.join(APP_ROOT, 'tmcore', 'gate.py')], cwd=APP_ROOT, env=env,
                     stdout=lf, stderr=lf, stdin=subprocess.DEVNULL, **paths.popen_flags())
    for _ in range(80):
        info = gate_info()
        if info:
            return info
        time.sleep(0.25)
    return None


def browsers():
    found = []
    if os.name == 'nt':
        for key in ('PROGRAMFILES', 'PROGRAMFILES(X86)', 'LOCALAPPDATA'):
            base = os.environ.get(key)
            if base:
                found.append(os.path.join(base, 'Microsoft', 'Edge', 'Application', 'msedge.exe'))
                found.append(os.path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe'))
    elif sys.platform == 'darwin':
        found += ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
    else:
        for n in ('google-chrome', 'chromium', 'chromium-browser', 'microsoft-edge'):
            p = shutil.which(n)
            if p:
                found.append(p)
    return [p for p in found if os.path.exists(p)]


def open_window(url):
    profile = os.path.join(paths.home(), 'browser')
    for exe in browsers():
        try:
            subprocess.Popen([exe, '--app=' + url, '--window-size=1400,880', '--user-data-dir=' + profile,
                              '--no-first-run', '--no-default-browser-check', '--disable-sync'],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
            return True
        except Exception:
            continue
    return webbrowser.open(url)


def quit_running():
    info = gate_info()
    if not info:
        return 0
    try:
        req = urllib.request.Request('http://127.0.0.1:%d/api/quit' % info['port'], data=b'{}', method='POST',
                                     headers={'X-TM': '1', 'Cookie': 'tdk_%d=%s' % (info['port'], info['key']), 'Content-Type': 'application/json'})
        urllib.request.urlopen(req, timeout=5).read()
    except Exception:
        pass
    for _ in range(60):
        if not gate_info():
            break
        time.sleep(0.5)
    return 0


def main():
    if '--quit' in sys.argv:
        return quit_running()
    info = gate_info() or start_gate()
    if not info:
        message('TaskDesk could not start', 'The TaskDesk background service did not start.\n\nLook at this log file:\n%s' % os.path.join(paths.log_dir(), 'gate.log'))
        return 1
    url = 'http://127.0.0.1:%d/__enter?k=%s' % (info['port'], info['key'])
    if os.environ.get('TASKDESK_NO_BROWSER'):
        print(url)
        return 0
    open_window(url)
    return 0


if __name__ == '__main__':
    sys.exit(main())
