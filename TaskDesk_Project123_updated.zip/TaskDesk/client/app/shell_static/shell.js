/* TaskDesk shell: account block, sync status, About and Sign out inside every module screen. */
(function () {
  'use strict';
  if (window.__TD_SHELL__) return;
  window.__TD_SHELL__ = true;
  const GET = (u) => fetch(u, { cache: 'no-store' }).then((r) => r.json());
  const POST = (u, b) => fetch(u, { method: 'POST', headers: { 'X-TM': '1', 'Content-Type': 'application/json' }, body: JSON.stringify(b || {}) }).then(async (r) => ({ status: r.status, data: await r.json().catch(() => ({})) }));
  let S = null, lastVersion = null, timer = null;

  function h(tag, attrs) {
    const el = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (let i = 2; i < arguments.length; i++) {
      for (const c of [].concat(arguments[i]).flat(Infinity)) if (c != null && c !== false) el.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return el;
  }
  const ago = (t) => {
    if (!t) return 'not yet';
    const s = Math.max(0, Math.round(Date.now() / 1000 - t));
    if (s < 10) return 'just now';
    if (s < 60) return s + ' s ago';
    if (s < 3600) return Math.round(s / 60) + ' min ago';
    if (s < 86400) return Math.round(s / 3600) + ' h ago';
    return Math.round(s / 86400) + ' d ago';
  };
  const LOGO = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 7h14M5 12h14M5 17h8"/></svg>';

  /* ---------- sync status text ---------- */
  function chip(sync) {
    const p = sync.pending || 0;
    switch (sync.state) {
      case 'syncing': return ['amber', 'Syncing...'];
      case 'offline': return ['grey', p ? 'Offline, ' + p + ' waiting' : 'Offline'];
      case 'error': return ['red', 'Sync problem'];
      case 'auth': return ['red', 'Sign in again'];
      case 'blocked': return ['red', 'Account stopped'];
      case 'upgrade': return ['red', 'Update needed'];
      case 'starting': return ['amber', 'Starting...'];
      default:
        if (p) return ['amber', p + ' change' + (p > 1 ? 's' : '') + ' waiting'];
        return ['green', 'Saved, ' + ago(sync.last_sync)];
    }
  }

  /* ---------- account block ---------- */
  function accountBlock() {
    const u = S.user, sync = S.sync, c = chip(sync);
    const initials = (u.display_name || u.username || '?').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
    return h('div', { class: 'td-acct', id: 'td-acct' },
      h('button', { class: 'td-who', type: 'button', title: 'My account and password', onclick: showAccount }, h('span', { class: 'td-av', 'aria-hidden': 'true' }, initials),
        h('div', { class: 'td-name' }, h('b', null, u.display_name || u.username), h('span', null, S.module.title))),
      h('button', { class: 'td-chip ' + c[0], type: 'button', title: 'Sync details', onclick: showDetails }, h('i'), h('span', null, c[1])),
      h('div', { class: 'td-btns' },
        h('button', { type: 'button', onclick: syncNow, title: 'Upload and download changes now' }, 'Sync now'),
        h('button', { type: 'button', onclick: showAbout }, 'About'),
        h('button', { type: 'button', onclick: showLogout }, 'Sign out')));
  }
  function mountAccount() {
    const nav = document.getElementById('nav');
    if (!nav || !S) return;
    const old = document.getElementById('td-acct');
    const c = chip(S.sync);
    const sig = [S.user.username, S.user.display_name, c[0], c[1]].join('|');
    if (old && old.dataset.sig === sig) return;
    const fresh = accountBlock();
    fresh.dataset.sig = sig;
    if (old) { old.replaceWith(fresh); } else nav.appendChild(fresh);
  }
  const navObserver = new MutationObserver(() => { if (S && !document.getElementById('td-acct')) mountAccount(); });

  /* ---------- banners and overlays ---------- */
  function clearBanner() { const b = document.getElementById('td-banner'); if (b) b.remove(); }
  const BLOCK_TITLE = { account_disabled: 'This account is switched off', account_expired: 'Your access has ended', account_pending: 'Waiting for approval',
    module_changed: 'Your account type changed' };
  function drawBlocked() {
    const sync = S.sync;
    let o = document.getElementById('td-block');
    const title = BLOCK_TITLE[sync.blocked_code] || 'This account cannot be used right now';
    const key = title + '|' + (sync.last_error || '');
    if (o && o.dataset.k === key) return;
    if (o) o.remove();
    const btn = h('button', { type: 'button', class: 'td-primary', onclick: async (e) => { const b = e.currentTarget; b.disabled = true; b.textContent = 'Checking...'; await syncNow(); b.disabled = false; b.textContent = 'Check again'; } }, 'Check again');
    o = h('div', { id: 'td-block', class: 'td-restore', role: 'alertdialog', 'aria-label': title, 'data-k': key },
      h('div', { class: 'td-rbox td-bbox' }, h('b', null, title),
        h('p', null, sync.last_error || 'Please contact the administrator.'),
        h('p', { class: 'td-note' }, 'Your data stays safe on this PC and in the cloud. If the administrator switches the account on again, press Check again.'),
        h('div', { class: 'td-actions' }, h('button', { type: 'button', onclick: () => doLogout(false, true) }, 'Sign out'), btn)));
    document.body.appendChild(o);
    btn.focus();
  }
  function drawBanner() {
    let b = document.getElementById('td-banner');
    const sync = S.sync;
    if (sync.state !== 'blocked') { const o = document.getElementById('td-block'); if (o) o.remove(); }
    let msg = null, act = null, kind = '';
    if (sync.state === 'auth' || S.sync.auth_lost) { msg = 'Your sign-in has expired on this PC.'; act = ['Sign in again', () => doLogout(false, true)]; kind = 'bad'; }
    else if (sync.state === 'blocked') { drawBlocked(); return clearBanner(); }
    else if (sync.state === 'upgrade') { msg = sync.upgrade_message || 'Please install the latest TaskDesk to keep syncing.'; kind = 'bad'; }
    else if (sync.state === 'offline' && sync.maintenance) { msg = (sync.last_error ? sync.last_error + ' ' : 'The server is under maintenance for a short time. ') + 'Everything still works and is saved on this PC. Changes upload automatically afterwards.'; kind = 'warn'; }
    else if (sync.state === 'offline') { msg = 'You are offline. Everything still works and is saved on this PC. Changes upload when the connection is back.'; kind = 'warn'; }
    else if (S.update && S.update.available) { msg = 'TaskDesk ' + S.update.latest + ' is available.'; if (S.update.url) act = ['Download', () => window.open(S.update.url, '_blank', 'noopener')]; }
    else if (sync.uploads_off) { msg = 'Uploading files is switched off for your account. Your files stay on this PC only.'; kind = 'warn'; }
    else if (sync.problems) { msg = sync.problems + ' item' + (sync.problems > 1 ? 's' : '') + ' could not be uploaded.'; act = ['Details', showDetails]; kind = 'warn'; }
    else if (S.update && S.update.notice) msg = S.update.notice;
    if (!msg) { if (b) b.remove(); return; }
    const key = msg + (act ? act[0] : '');
    if (b && b.dataset.k === key) return;
    if (b) b.remove();
    b = h('div', { id: 'td-banner', class: 'td-banner ' + kind, role: 'status', 'data-k': key }, h('span', null, msg), act ? h('button', { type: 'button', onclick: act[1] }, act[0]) : null,
      h('button', { type: 'button', class: 'td-x', 'aria-label': 'Dismiss', onclick: () => b.remove() }, '×'));
    document.body.appendChild(b);
  }
  function drawRestore() {
    const sync = S.sync;
    let o = document.getElementById('td-restore');
    if (!sync.restore_active) { if (o) { o.remove(); if (window.App && App.refreshTasks) App.refreshTasks().catch(() => {}); } return; }
    const pct = sync.restore_total ? Math.min(100, Math.round(100 * sync.restore_done / sync.restore_total)) : 0;
    if (!o) {
      o = h('div', { id: 'td-restore', class: 'td-restore', role: 'alertdialog', 'aria-label': 'Loading your workspace' },
        h('div', { class: 'td-rbox' }, h('div', { class: 'td-spin' }), h('b', null, 'Loading your workspace'), h('p', { id: 'td-rtxt' }), h('div', { class: 'td-bar' }, h('i', { id: 'td-rbar' }))));
      document.body.appendChild(o);
    }
    document.getElementById('td-rtxt').textContent = sync.restore_total ? sync.restore_done + ' of ' + sync.restore_total + ' items' : 'Getting your tasks from the cloud';
    document.getElementById('td-rbar').style.width = pct + '%';
  }
  function drawFiles() {
    const sync = S.sync;
    let f = document.getElementById('td-files');
    if (!sync.dl_left) { if (f) f.remove(); return; }
    if (!f) { f = h('div', { id: 'td-files', class: 'td-files', role: 'status' }); document.body.appendChild(f); }
    f.textContent = 'Restoring files: ' + sync.dl_left + ' left';
  }
  function maybeRefreshData() {
    const v = S.sync.data_version;
    if (lastVersion === null) { lastVersion = v; return; }
    if (v !== lastVersion && !S.sync.restore_active) {
      const open = window.App && App.drawerOpen && App.drawerOpen();
      if (!open && window.App && App.refreshTasks) { lastVersion = v; App.refreshTasks().catch(() => {}); }
    }
  }

  /* ---------- dialogs ---------- */
  function dialog(cls, ...kids) {
    const d = h('dialog', { class: 'td-dlg ' + cls }, ...kids);
    d.addEventListener('close', () => d.remove());
    d.addEventListener('click', (e) => { if (e.target === d) d.close(); });
    document.body.appendChild(d);
    d.showModal();
    d.scrollTop = 0;
    return d;
  }
  async function syncNow(e) {
    const b = e && e.currentTarget;
    if (b) { b.disabled = true; b.textContent = 'Syncing...'; }
    try { const r = await POST('/__td/sync'); if (r.data.sync) S.sync = r.data.sync; } catch (x) { /* ignore */ }
    await poll();
    if (b) { b.disabled = false; b.textContent = 'Sync now'; }
    if (window.App && App.refreshTasks && !(App.drawerOpen && App.drawerOpen())) App.refreshTasks().catch(() => {});
  }
  async function showDetails() {
    const s = S.sync;
    let probs = [];
    try { probs = (await GET('/__td/problems')).items || []; } catch (e) { /* ignore */ }
    const rows = [['Status', chip(s)[1]], ['Last sync', ago(s.last_sync)], ['Waiting to upload', String(s.pending)], ['Files still to download', String(s.dl_left)], ['Account', S.user.username]];
    const d = dialog('td-small', h('h2', null, 'Sync details'),
      h('dl', { class: 'td-dl' }, rows.map((r) => [h('dt', null, r[0]), h('dd', null, r[1])])),
      s.last_error ? h('p', { class: 'td-err' }, s.last_error) : null,
      probs.length ? h('div', null, h('h3', null, 'Recent problems'), h('ul', { class: 'td-probs' }, probs.slice(0, 8).map((p) => h('li', null, h('span', null, p.ts), ' ', p.msg)))) : null,
      h('div', { class: 'td-actions' },
        h('button', { type: 'button', onclick: async (e) => { e.target.disabled = true; e.target.textContent = 'Checking...'; await POST('/__td/verify'); e.target.textContent = 'Check started'; } }, 'Check files against the cloud'),
        h('button', { type: 'button', class: 'td-primary', onclick: () => d.close() }, 'Close')));
  }
  function showAccount() {
    const u = S.user, p = S.perms || {};
    const mb = (n) => (n >= 1024 ? (n / 1024).toFixed(n % 1024 ? 1 : 0) + ' GB' : n + ' MB');
    const used = p.bytes_used ? (p.bytes_used / 1048576).toFixed(1) + ' MB' : '0 MB';
    const rows = [['Name', u.display_name || u.username], ['Username', u.username], ['Edition', S.module.title]];
    if (p.quota_mb) rows.push(['Cloud files', used + ' of ' + mb(p.quota_mb)]);
    if (p.max_file_mb) rows.push(['Largest file', mb(p.max_file_mb)]);
    rows.push(['File uploads', p.can_upload === false ? 'Switched off by the administrator' : 'Allowed']);
    if (p.expires_at) rows.push(['Access until', p.expires_at]);
    const msg = h('p', { class: 'td-err', id: 'td-pmsg', role: 'alert' });
    const o = h('input', { type: 'password', id: 'td-po', autocomplete: 'current-password' });
    const n = h('input', { type: 'password', id: 'td-pn', autocomplete: 'new-password' });
    const n2 = h('input', { type: 'password', id: 'td-pn2', autocomplete: 'new-password' });
    const save = h('button', { type: 'submit', class: 'td-primary' }, 'Change password');
    const form = h('form', { class: 'td-pwform', onsubmit: async (e) => {
      e.preventDefault();
      msg.className = 'td-err';
      if (!o.value) { msg.textContent = 'Enter your current password.'; return; }
      if (n.value.length < 8) { msg.textContent = 'The new password needs at least 8 characters.'; return; }
      if (n.value !== n2.value) { msg.textContent = 'The two new passwords are not the same.'; return; }
      save.disabled = true; save.textContent = 'Saving...'; msg.textContent = '';
      let r;
      try { r = await POST('/__td/password', { old: o.value, new: n.value }); } catch (x) { r = { status: 0, data: { message: 'The app is not answering.' } }; }
      save.disabled = false; save.textContent = 'Change password';
      if (r.status === 200 && r.data.ok) { msg.className = 'td-ok'; msg.textContent = 'Your password was changed.'; o.value = n.value = n2.value = ''; }
      else msg.textContent = r.data.message || r.data.error || 'Could not change the password.';
    } },
      h('h3', null, 'Change password'),
      h('label', null, 'Current password', o), h('label', null, 'New password', n), h('label', null, 'Repeat new password', n2), msg,
      h('div', { class: 'td-actions' }, save));
    const d = dialog('td-small', h('h2', null, 'My account'),
      h('dl', { class: 'td-dl' }, rows.map((r) => [h('dt', null, r[0]), h('dd', null, r[1])])),
      form,
      h('div', { class: 'td-actions' }, h('button', { type: 'button', onclick: () => d.close() }, 'Close')));
  }
  function showLogout() {
    const pend = S.sync.pending || 0;
    const wipe = h('input', { type: 'checkbox', id: 'td-wipe' });
    const msg = h('p', { class: 'td-err', id: 'td-lmsg' });
    const go = h('button', { type: 'button', class: 'td-primary', onclick: () => doLogout(wipe.checked, false, go, msg) }, 'Sign out');
    dialog('td-small', h('h2', null, 'Sign out of TaskDesk?'),
      h('p', null, 'You will come back to the sign-in screen. Your data stays safe in your cloud account.'),
      pend ? h('p', { class: 'td-warn' }, pend + ' change' + (pend > 1 ? 's are' : ' is') + ' not uploaded yet. TaskDesk uploads them first.') : null,
      h('label', { class: 'td-chk' }, wipe, h('span', null, 'Also remove the copy of my data from this PC. Use this on a shared computer. The next sign-in downloads it again.')),
      msg, h('div', { class: 'td-actions' }, h('button', { type: 'button', onclick: (e) => e.target.closest('dialog').close() }, 'Cancel'), go));
  }
  async function doLogout(wipe, force, btn, msgEl) {
    if (btn) { btn.disabled = true; btn.textContent = 'Signing out...'; }
    let r;
    try { r = await POST('/__td/logout', { wipe: !!wipe, force: !!force }); } catch (e) { r = { status: 0, data: { error: 'The app is not answering.' } }; }
    if (r.status === 200 && r.data.redirect) {
      document.body.innerHTML = '<div style="padding:60px;font:16px Segoe UI,sans-serif">Signing out...</div>';
      setTimeout(() => { location.href = r.data.redirect; }, 500);
      return;
    }
    if (btn) { btn.disabled = false; btn.textContent = 'Sign out'; }
    if (msgEl) {
      msgEl.textContent = r.data.error || 'Could not sign out.';
      if (r.status === 409) msgEl.appendChild(h('div', null, h('button', { type: 'button', class: 'td-linkbtn', onclick: () => doLogout(wipe, true) }, 'Sign out anyway')));
    }
  }
  async function showAbout() {
    let a = {};
    try { a = await GET('/__td/about'); } catch (e) { /* ignore */ }
    const au = a.author || {};
    const initials = (au.name || 'T').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
    const contact = [['Email', au.email, 'mailto:' + au.email], ['Phone', au.phone], ['Website', au.website, au.website], ['LinkedIn', au.linkedin, au.linkedin]].filter((c) => c[1]);
    const d = dialog('td-about',
      h('div', { class: 'td-ab-head' }, h('span', { class: 'td-logo', html: LOGO }), h('div', null, h('h2', null, a.product || 'TaskDesk'), h('p', null, a.tagline || ''))),
      h('div', { class: 'td-ab-body' },
        h('section', null, h('h3', null, 'About the software'), h('p', null, a.summary || '')),
        h('section', null, h('h3', null, 'Designed and developed by'),
          h('div', { class: 'td-author' }, h('div', { class: 'td-avatar', 'aria-hidden': 'true' }, initials),
            h('div', null, h('b', null, au.name || ''), h('div', null, [au.title, au.company].filter(Boolean).join(' at ')),
              au.bio ? h('p', { class: 'td-bio' }, au.bio) : null,
              contact.length ? h('div', { class: 'td-contact' }, contact.map((c) => c[2] && /^(mailto:|https?:)/.test(c[2]) ? h('a', { href: c[2], target: '_blank', rel: 'noopener' }, c[1]) : h('span', null, c[0] + ': ' + c[1]))) : null))),
        (a.features || []).length ? h('section', null, h('h3', null, 'What you get'), h('ul', { class: 'td-feat' }, a.features.map((f) => h('li', null, h('b', null, f.title), h('span', null, f.text))))) : null,
        a.privacy ? h('section', null, h('h3', null, 'Your data'), h('p', null, a.privacy)) : null,
        (a.legal || []).length ? h('section', { class: 'td-legal' }, a.legal.map((t) => h('div', null, t))) : null),
      h('div', { class: 'td-ab-foot' }, h('span', null, a.copyright || ''), h('span', null, 'Version ' + (a.version || '')), h('button', { type: 'button', class: 'td-primary', onclick: () => d.close() }, 'Close')));
  }

  /* ---------- polling ---------- */
  async function poll() {
    try {
      S = await GET('/__td/state');
    } catch (e) {
      if (S) { S.sync.state = 'offline'; S.sync.last_error = 'The TaskDesk app on this PC stopped.'; mountAccount(); }
      return;
    }
    document.documentElement.style.setProperty('--td-accent', S.module.accent || '#4a54c7');
    mountAccount(); drawBanner(); drawRestore(); drawFiles(); maybeRefreshData();
  }
  function schedule() {
    clearTimeout(timer);
    const s = S && S.sync;
    const busy = s && (s.state === 'syncing' || s.restore_active || s.dl_left > 0);
    timer = setTimeout(async () => { await poll(); schedule(); }, document.hidden ? 20000 : busy ? 1200 : 4000);
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) { poll(); } });

  (async function start() {
    await poll();
    const nav = document.getElementById('nav');
    if (nav) navObserver.observe(nav, { childList: true });
    schedule();
  })();
})();
