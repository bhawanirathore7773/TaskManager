# TaskDesk Owner site: poore software ko manage karna (Hinglish guide)

Owner site aapka **control room** hai. Yahin se aap decide karte ho ki kaun TaskDesk use kar sakta hai, kitna, kab tak,
aur server ka address, updates aur maintenance kaise chalenge. Users ko isme kuch nahi karna padta: wo sirf **install karte hain aur login / create account**.

```
https://aapka-domain.com/taskdesk/owner/
```

(`setup.php` ke baad success page par ye link dikhta hai.)
Agar `.../owner/` kholne par "403" ya "Not found" aaye to seedha `.../owner/index.html` kholo, aur check karo ki `owner` folder aur `.htaccess` upload hui hai.

---

## 1. Pehli baar

1. `setup.php` me aapne **Owner username** aur **Owner password** (kam se kam 10 akshar) bhare the. Wahi se login karo.
2. Login ke baad pehle **Owner account** page par **Two-step sign-in** chalu kar lo (Google Authenticator / Microsoft Authenticator jaisi app).
   Fir password leak bhi ho jaye to bina phone ke koi andar nahi aa sakta.
3. Owner site sirf aapke liye hai. Normal users ko iska link dene ki zaroorat nahi, aur unke account se ye khulta bhi nahi.

### Owner password ya 2-step code bhool gaye?

Server ke **storage folder** (`taskdesk_storage`, jo `public_html` ke bahar hai) me `owner_reset.txt` naam ki file banao.
Pehli line me owner username, doosri line me naya password likho:

```
boss
Naya-Strong-Password-123
```

Fir owner site ka page ek baar kholo. Server file padhkar owner ka password set kar deta hai, **2-step band kar deta hai**, aur file apne aap delete kar deta hai.
Ye isliye safe hai ki storage folder tak sirf wahi pahunch sakta hai jiske paas aapka hosting panel hai.

---

## 2. Dashboard

Ek nazar me: kitne users, kitne active, kitne **approval ka intezaar** kar rahe, kitne blocked, module ke hisaab se count, kitni jagah use hui,
aur server ki health (database, storage, PHP limits). **Waiting for approval** ka number laal ho jaye to Users page par jao.

## 3. Users: kisko kya milega

**Users** page par list, search (naam ya username), aur filter (status, module). Kisi bhi user par dabao to uska poora panel khulta hai.

| Kaam | Kahan | Kya hota hai |
|---|---|---|
| Naya user banana | **Add user** | Aap username, naam, module chunte ho. Temporary password aur recovery key screen par dikhti hai. User ko pehli baar login par apna password khud chunna padta hai. |
| Active / Blocked / Pending | **Status** | **Blocked**: user ka app 1 minute ke andar band ho jata hai aur saaf message dikhata hai ("This account is switched off"). Data PC par aur cloud me safe rehta hai. Wapas **Active** karte hi user "Check again" dabakar (ya apne aap) pehle jaisa kaam karta hai. **Pending**: approval ka intezaar. |
| Kab tak access | **Access until** | Us din ke baad account apne aap band ("Your access has ended"). Khali = hamesha. Date hatane par turant chalu. |
| File upload band karna | **Can upload files** | Band hone par tasks sync hote rehte hain, par attachments sirf us PC par rehti hain. User ko chhota sa notice dikhta hai, error nahi. Wapas chalu karte hi bacha hua sab upload ho jata hai. |
| Space / badi file limit | **Storage limit**, **Biggest file** | Sirf is user ke liye. Khali = server ki default limit. Badi file limit hosting ki `post_max_size` se upar nahi ja sakti. |
| Module badalna | **Module** | **Sirf tab, jab account me abhi koi data nahi hai.** Data aa jane ke baad badalne se tasks ka matlab hi badal jata, isliye server mana kar deta hai. User ko app me "sign out and sign in again" ka message milta hai aur naya module khulta hai. |
| Password bhool gaya, recovery key bhi nahi | **Set a temporary password** | Aap ek temporary password dete ho (khud likho ya system bana de). Purane sab login band ho jate hain. User login karta hai to app usse **turant apna naya password** chunne ko kehti hai. Uske baad hi andar jaa sakta hai. |
| Recovery key kho gayi | **Issue a new recovery key** | Nayi key dikhti hai, purani band. Ye key user ko surakshit tareeke se dena. |
| Doosre PC se nikalna | **Sign out all devices** | Har device par user ko dobara login karna padega. |
| Account hatana | **Delete** (username type karke confirm) | Account, uska data aur files hamesha ke liye hat jate hain. Wapas nahi aate. Pehle backup le lo. |

Ek note (**Your note**) bhi likh sakte ho: ye sirf aapko dikhta hai (jaise "Mayur plant, SD team").

> Saari badlav (block, expiry, limit) **user ko dobara login karaye bina** lagoo hote hain. App har minute server se poochta hai, aur kuch bhi sync karne se pehle bhi.

## 4. Settings: naye accounts, limits, modules, maintenance

- **New accounts**
  - *Anyone with the app can create an account*: users khud banate hain (default).
  - *New accounts wait until you approve them*: user register kar sakta hai par app tab tak nahi khulti jab tak aap **Users** me use **Active** na karo. Dashboard par count dikhta hai.
  - *Nobody can create an account*: sirf aap **Add user** se banate ho.
  - **Invite code** (optional): code bataoge to hi register hoga.
- **Modules**: kaun si editions (ABAP / FICO / MM / BASIS) accounts ke liye available hain. Naya module aane par yahan jodo.
- **Default limits**: har user ki storage aur badi file ki default limit, aur **Stay signed in for (days)**.
- **Maintenance mode**: server par kaam karna ho (upgrade, backup restore) to ON karo aur ek line likho (jaise "Back at 6 pm."). Tab:
  - login screen par wo line dikhti hai;
  - jo users already kaam kar rahe hain wo **bina rukawat** kaam karte rehte hain (data PC par save hota hai) aur app "Server is under maintenance" batati hai;
  - maintenance khatam hote hi sab apne aap upload ho jata hai. **Kuch bhi kho nahi jata.**
  Owner site khud maintenance me bhi khuli rehti hai, taki aap wapas OFF kar sako.

## 5. Server and updates

### Server ka address

Users **kabhi address nahi likhte**. Address installer ke andar hota hai (guide 02), bilkul normal software ki tarah.
Agar kabhi domain badalna ho (jaise naya domain ya naya hosting):

1. Naye address par **poora server wahi database aur files ke saath** chalao (ya files/DB copy karke).
2. Owner site me **Server and updates > Moving to a new address** me naya address (`https://naya-domain.com/taskdesk/api.php`) daalo, **Announce** dabao.
3. Har chalti hui app **10 minute ke andar** naye address par chali jati hai. Jo app band hai wo agli baar khulte hi chali jati hai.
4. Purana address kuch din chalu rehne do, taki jo PC band tha wo bhi ek baar khulkar naya address seekh le.

**Safety:** app naye address par tabhi jati hai jab wahan **wahi Server ID** mile jo purane server ki hai (Server ID is page par dikhta hai). Isliye typing galti ya
kisi anjaan website ka address daalne se users us par nahi bhatakte; app purane, sahi server par hi rehti hai.
Sirf `https://` address allowed hai (testing ke liye `localhost`).

### Updates aur message

- **Latest version** + **Download link of the installer**: sabke app me "TaskDesk x.y.z is available" banner dikhta hai.
- **Oldest version still allowed**: isse purane app "Update needed" dikhate hain aur sync nahi karte (zaroori security fix ke liye).
- **Message for all users**: ek line ka notice jo sabko dikhta hai.

## 6. Activity log

Har owner action ka record: kisne, kab, kispar, kya badla (login, block, password set, setting change, delete). Search kar sakte ho.
Passwords ya keys is log me **kabhi nahi** likhe jate.

## 7. Owner account

Password badalna, **Two-step sign-in** chalu / band karna. Owner login me 6 galat koshish ke baad kuch der ke liye roka jata hai, aur 60 minute kuch na karne par
session apne aap khatam ho jata hai.

---

## Roz ke 3 kaam (yaad rakhne ke liye)

1. **Dashboard**: "Waiting for approval" ka number dekho.
2. **Users**: naye logon ko Active karo; jo chhod gaye unko Blocked ya Access until se band karo.
3. Kabhi bhi server par kaam ho: **Maintenance mode** ON, kaam, OFF.

## Jo yahan test hua aur jo nahi

Owner site ke saare control **asli PHP server aur asli desktop-app processes** ke saath test hue hain (block, expiry, approval, temporary password, upload band,
maintenance, module change, address move, galat address ka na maana jana, browser me screens). 
Lekin **MySQL par asli Hostinger me** pehli baar chalna hai: test SQLite par hue. Naya table-banane aur purane (v1) database ko naye (v2) me badalne wala code
MySQL ke liye likha gaya hai, par us par chala ke dekha nahi gaya. Isliye:

- **Naye install** me `setup.php` sab bana deta hai.
- **Purane install ko update karne se pehle** hPanel se database ka **backup/export** le lo. Pehli request par server khud upgrade karta hai.
  Kuch gadbad ho to `taskdesk_storage/logs/api.log` dekho.
