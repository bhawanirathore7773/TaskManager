# TaskDesk Server: Hostinger par setup (Hinglish guide)

Ye guide aapke **Hostinger Web hosting** plan ke liye hai. Aapke plan me PHP aur MySQL milta hai, aur TaskDesk ka API
exactly isi par chalne ke liye bana hai. **Naya plan ya VPS lene ki zaroorat nahi hai.**

Poora kaam lagbhag 10-15 minute ka hai.

---

## Step 1: Domain / folder decide karo

API ka address kuch aisa hoga:

```
https://aapka-domain.com/taskdesk/api.php
```

Agar aap alag subdomain chahte ho (jaise `taskdesk.aapka-domain.com`), to hPanel me pehle subdomain bana lo.
Dono tarah se kaam karta hai. Is guide me `public_html/taskdesk/` folder use kiya gaya hai.

## Step 2: MySQL database banao

1. hPanel kholo, apni website ke saamne **Manage** dabao.
2. Left menu me **Databases > Management** (ya **MySQL Databases**) kholo.
3. **Create new database** me ye bharo:
   - Database name: `taskdesk`
   - Username: `taskdesk`
   - Password: koi strong password (isko copy karke rakh lo)
4. **Create** dabao.

Hostinger naam ke aage apna prefix laga deta hai, jaise `u123456789_taskdesk`. List me jo **poora naam** dikhe,
wahi aage use hoga (database name aur username dono).

## Step 3: Server files upload karo

1. hPanel me **Files > File Manager** kholo.
2. `public_html` ke andar `taskdesk` naam ka folder banao.
3. Is project ke `server` folder ke **andar ki saari files aur folders** (`api.php`, `index.php`, `setup.php`,
   `config.sample.php`, `.htaccess`, `lib/`) us `taskdesk` folder me upload karo.
   Sabse aasaan: `TaskDesk_Server.zip` upload karo aur File Manager me **Extract** dabao.
4. Check karo ki `.htaccess` file aayi hai (hidden files dikhane ka option File Manager settings me hota hai).

## Step 4: HTTPS force karo

hPanel > **Security > SSL** me apne domain ka SSL active hona chahiye. Phir **Force HTTPS** ON kar do.
TaskDesk server http connection ko reject karta hai, kyunki password aur token plain text me nahi jaane chahiye.

## Step 5: Setup page chalao

Browser me kholo:

```
https://aapka-domain.com/taskdesk/setup.php
```

- Upar ke checks sab hare (ok) hone chahiye: PHP 7.4+, pdo_mysql, JSON, folder writable.
- **Database host**: `localhost`
- **Database name / user / password**: Step 2 wale poore naam aur password.
- **Storage folder**: page khud `public_html` ke **bahar** ka folder suggest karta hai
  (jaise `/home/u123456789/taskdesk_storage`). Ise waise hi rehne do. Files web se direct nahi khul sakti.
- **Owner username** aur **Owner password** (kam se kam 10 akshar): ye aapka **Owner site** ka login hai. Isi se aap baad me users ko
  active / blocked karoge, limits aur server address manage karoge (guide 06). Ise safe jagah likh lo.
- **Naye accounts** (registration): *Anyone* (koi bhi app se account bana sake), *Approval* (aap approve karo tab chale), ya *Closed* (sirf aap banao).
  Ye baad me owner site se kabhi bhi badal sakte ho.
- **Invite code** (optional): agar sirf aap aur jinko aap code do wahi account bana sakein, to koi shabd likh do.
  Khali chhodoge to registration mode ke hisaab se koi bhi register kar sakta hai.
- **Space per user** aur **max file size**: default 2048 MB aur 500 MB theek hai. (Owner site se baad me badal sakte ho, har user ke liye alag bhi.)

**Install** dabao. Success page aayega, usme **Owner site ka link** bhi hoga.

## Step 6: setup.php delete karo

File Manager se `taskdesk/setup.php` delete kar do. Ye zaroori hai. Ye file sirf ek baar ke liye hoti hai.

## Step 7: Check karo ki sab chal raha hai

Browser me kholo:

```
https://aapka-domain.com/taskdesk/api.php?r=health&deep=1
```

Aisa JSON dikhna chahiye:

```json
{"ok":true,"app":"taskdesk-api", ... "db":true,"storage":true, "max_file_mb": ...}
```

- `"db": true` = database connect ho gaya.
- `"storage": true` = files ka folder writable hai.
- `max_file_mb` = abhi server kitni badi file accept karega.

## Step 8: Badi files ke liye PHP limit badhao

Agar `max_file_mb` chhota dikhe (jaise 1 ya 7), to PDF/Excel upload fail ho sakte hain.
hPanel > **Advanced > PHP Configuration > PHP Options** me:

- `post_max_size` = `128M`
- `upload_max_filesize` = `128M`
- `max_execution_time` = `300`

Save karo, phir `?r=health` dobara kholo. `max_file_mb` badh jana chahiye.
(Server khud `post_max_size` ke hisaab se limit tay karta hai, isliye galat error nahi aayega.)

---

## Owner site kholo

```
https://aapka-domain.com/taskdesk/owner/
```

Setup page ke Owner username / password se login karo. Aage ka sab (users, permissions, address, maintenance) **guide 06** me hai.
Owner site ka **Two-step sign-in** pehle din hi chalu kar lo.

## Apna address desktop app me

Installer banate waqt ye address **andar daal diya jaata hai** (guide 02 dekho):

```
https://aapka-domain.com/taskdesk/api.php
```

Users ko ye address **kabhi nahi** likhna padta: app me koi "Server" option hai hi nahi. Wo sirf install karte hain aur login / create account.
Address kabhi badalna ho to owner site se ek baar "announce" karo, saari apps khud naye address par chali jaati hain (guide 06).

---

## Rozana ke kaam

| Kaam | Kaise |
|---|---|
| Backup | hPanel > Databases me database ka **backup/export**, aur `taskdesk_storage` folder ki copy. Hostinger ke automatic backups bhi plan ke hisaab se chalte hain. |
| User ko active / blocked karna, access ki last date, upload band karna | **Owner site > Users** |
| Naye registrations band karna ya approval ke baad chalana | **Owner site > Settings > New accounts** |
| Space ya file limit badalna | **Owner site > Settings** (sabke liye) ya user ke panel me (sirf us user ke liye) |
| Naya module add hua | **Owner site > Settings > Modules** |
| Users ko naya version dilana | **Owner site > Server and updates**: `Latest version`, `Download link`, `Message`. Purane version ko rokna ho to `Oldest version still allowed` badhao. |
| Server par kaam karna hai | **Owner site > Settings > Maintenance mode** ON, kaam, OFF |
| Owner password bhool gaye | `taskdesk_storage/owner_reset.txt` (guide 06, section 1) |
| Koi error dikhe | Storage folder ke andar `taskdesk_storage/logs/api.log` dekho. Ye `public_html` ke bahar hai, isliye web se nahi khulti. |

## Pehle se chal rahe server ko update karna (jaise BASIS module jodna)

Users, unka data aur `config.php` **nahi hilte**: users MySQL me hain, `config.php` zip me hota hi nahi, aur database ka structure (`lib/schema.php`) BASIS ke liye badla nahi.
Purane ABAP / FICO / MM users aur purane 1.0.0 apps bina kuch kiye chalte rehte hain.

BASIS ke liye sirf ye 4 files overwrite karo (File Manager > `public_html/taskdesk/`), `TaskDesk_Server_Update.zip` me yahi hain:
- `lib/bootstrap.php`
- `lib/owner.php`
- `owner/owner.js`
- `owner/owner.css`

`setup.php`, `config.sample.php`, `api.php` dobara upload karne ki zaroorat nahi. `config.php` ko kabhi overwrite / delete mat karo.

Upload ke baad **ek kaam zaroori**: Owner site > **Settings > Modules** me **SAP BASIS / IT** tick karke **Save** karo.
(Server purani `config.php` ki list ke hisaab se sirf ABAP / FICO / MM maanta hai, jab tak aap yahan BASIS tick na karo.)
Phir check karo: `https://aapka-domain.com/taskdesk/api.php?r=health` me `"modules":["abap","fico","mm","basis"]` dikhna chahiye.
Last me **Server and updates** me `Latest version` = `1.1.0` aur `Download link` daal do.

## Agar kuch na chale

- **App me "Cannot reach the TaskDesk server"**: us PC par `tools\Check_Server.bat` chalao. Wo address, DNS, HTTPS aur server ka jawab ek ek karke jaanchti hai aur batati hai ki dikkat kahan hai.
  Sabse aam wajah: installer banate waqt address galat likha gaya (end me `/api.php` nahi, `http://` likha, domain ka spelling, ya `/taskdesk/` folder ka naam alag).
  Sahi address wahi hai jo browser me `...?r=health` lagakar JSON deta hai. Galat address ho to sahi address ke saath installer dobara banao.

- **500 / blank page**: PHP version 7.4 ya usse upar rakho (hPanel > Advanced > PHP Configuration).
- **"https_required"**: SSL / Force HTTPS ON karo.
- **`"db": false`**: `config.php` me database ka naam, user ya password galat hai. Hostinger ka prefix (`u123456789_`) mat bhoolo.
- **Login pe "Server not reachable"**: URL galat hai ya `.htaccess` upload nahi hui. Health URL browser me kholke dekho.
- **config.php dobara banana ho**: File Manager se `config.php` delete karo, `setup.php` wapas upload karo.
  (Owner site ki settings database me hoti hain, isliye `config.php` dobara banane se wo nahi jaati.)
- **Owner site "Not found"**: `owner` folder (`index.html`, `owner.css`, `owner.js`) `taskdesk/owner/` me upload hona chahiye. `TaskDesk_Server.zip` me wo shamil hai.

## VPS kab chahiye?

Abhi bilkul nahi. Sirf tab jab future me server Python (Django) me likhna ho, ya hazaaron users ho jayein.
Tab Hostinger **VPS** (KVM 1 ya 2) lena. Desktop app ka API contract wahi rahega, isliye app me kuch nahi badlega.
