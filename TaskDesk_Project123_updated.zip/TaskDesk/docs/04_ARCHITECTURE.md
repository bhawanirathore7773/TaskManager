# TaskDesk architecture

This document is for whoever maintains TaskDesk (including future you). User-facing guides are in Hinglish (01 to 03).

## 1. Goals and the decisions that follow from them

| Goal | Decision |
|---|---|
| Installs like normal Windows software | Inno Setup 6 per-user installer, bundles the pinned Python 3.12 embeddable package. No admin rights, no Python needed on the PC. |
| Instant screens, fast reads and writes | **Local-first.** Each module keeps its own SQLite database on the PC and serves its UI from `127.0.0.1`. The cloud is a replica, never in the request path of a screen. |
| Data in the Hostinger database through an API | PHP 7.4+ API on the existing Hostinger Web hosting, MySQL through PDO. |
| Files stay in local folders as before, and are restored on login | Files are real files in per-task folders. Their bytes go to the server's storage folder; the folder structure is rebuilt from the task rows and the module's category map. |
| One product, four modules, one login | `modules/<id>/` registry. The **account** has a module. The gate starts that module for the session. |
| Future modules | Drop a folder in `modules/`, add the id to the server `modules` list, ship a new installer. |

The three original task managers (ABAP, FICO, MM) are used **unmodified**; the fourth module, **BASIS** (`modules/basis/`, IT support), was written for TaskDesk and has no standalone version (`server.py` + `static/`). TaskDesk patches them at run time
(`tmcore/module_host.py: patch_module`) and adds sync through SQLite triggers, so there is one code path for all modules.

## 2. Components

```
 Windows PC                                                         Hostinger
┌──────────────────────────────────────────────────────┐        ┌───────────────────────┐
│ launcher.pyw  ──starts/finds──▶  GATE  (tmcore/gate.py)│        │ public_html/taskdesk/ │
│   opens Edge/Chrome --app window     login, register,  │        │   api.php  (router)   │
│                                      recover, About    │        │   lib/*.php           │
│                                        │ starts        │        │                       │
│                                        ▼               │ HTTPS  │ MySQL                 │
│                            MODULE HOST (module_host.py)│◀──────▶│   td_users td_tokens  │
│                              patched module server.py  │  JSON  │   td_records td_files │
│                              SQLite + triggers (outbox)│  +raw  │   td_attempts         │
│                              SYNC ENGINE (engine.py)   │  files │ storage/ (outside web │
│                              local files/ folders      │        │   root): file blobs   │
└──────────────────────────────────────────────────────┘        └───────────────────────┘
```

### 2.1 Gate (`tmcore/gate.py`)
Login, register (with the module dropdown), recovery key screen, password recovery, About. **There is no server setting**: the address is baked into the
installer (`taskdesk_config.json`, or env `TASKDESK_CLOUD` in tests), like any installed software. It listens on
`127.0.0.1:8750-8759` (or a random port) and announces itself in `run/gate.json`.

Every sign-in is **verified with the server**: login / register answer with the account, its module and its permissions. Opening a saved session
(`/api/open`) asks `auth/me` first (6 s): a switched-off, expired or pending account clears the session and shows the reason; with no internet the app opens with the saved
account and syncs later. Special answers: `pending` (approval mode: account created, nothing opened), `must_change_password` (a short-lived in-memory ticket,
then `/api/change_password`, only after that the session is saved). After success it starts one **module child** for the account's module and redirects the
window to it. It exits after 300 s without a window.

### 2.2 Module host (`tmcore/module_host.py`)
One child process per signed-in session. It loads `modules/<id>/server.py` with `importlib`, points its data folder
(`data_env`) at `%LOCALAPPDATA%\TaskDesk\users\u<id>_<username>_<serverid>\data`, installs sync triggers, starts the engine, and
serves the module UI with two extra assets (`/__td/shell.js`, `/__td/shell.css`) injected into `index.html`:
account block, sync chip, About, Sign out, banners, restore progress.

### 2.3 Sync engine (`tmcore/engine.py`, `syncdb.py`, `cloud.py`)
See section 4.

### 2.4 Cloud API (`server/`)
Single entry `api.php?r=<route>` (no URL rewriting needed on any host). Routes:

| Route | Purpose |
|---|---|
| `health` (`&deep=1`) | version info, limits, `latest_client`, `min_client`, notice. Always allowed (also for old clients). |
| `auth/register`, `auth/login`, `auth/logout`, `auth/me`, `auth/password`, `auth/recover` | accounts, sessions |
| `sync/push`, `sync/pull`, `sync/status` | row replication, per-user increasing `rev` |
| `files/put`, `files/get`, `files/del`, `files/list` | file bytes |
| `owner/*` | the owner site API (section 5a) |

`health` also announces: `server_id`, `api_url` (the address the owner wants apps to use), `registration` / `approval_required`, `maintenance` + message.

### 2.5 Owner site (`server/owner/`, `server/lib/owner.php`)
A static page (`index.html`, `owner.css`, `owner.js`, no external resources) plus the `owner/*` routes of the same `api.php`. Section 5a explains the model.

## 3. Local security

- The gate and every module server bind to `127.0.0.1` only.
- Each requires a random per-launch key. It arrives once through `/__enter?k=` or `/__td/enter?k=` and is kept as an
  `HttpOnly; SameSite=Strict` cookie `tdk_<port>`. Another program or web page cannot use the local API without the key.
- The `Host` header is validated (DNS-rebinding protection). All writes require the header `X-TM: 1`.
- `/__td/ping` and `/__gate/ping` are public but return no data.
- The session token is stored in `session.json`, encrypted with Windows **DPAPI** (`dpapi:` prefix). On non-Windows
  (tests, source runs) it falls back to `plain:` with `chmod 600`.
- Sign out deletes the token locally and revokes it on the server; optionally wipes the user's folder.

## 4. Sync design

### 4.1 Change capture
SQLite triggers are generated for **every table with a single-column primary key** and re-created when the schema signature changes
(`_td_meta.trg_sig`). Each insert/update/delete adds a row to `_td_outbox` with op `u` (upsert), `d` (delete) or `f`
(file path changed; the old path is kept in `info`). Because the triggers are generic, a new module needs no sync code.

Support tables: `_td_meta` (applying flag, last_rev, last_verify), `_td_files` (rel, size, mtime_ns, sha256), `_td_log`.

### 4.2 Push
- **State based:** the engine reads the *current* row for each outbox key (or sends a delete if it is gone), so repeated edits coalesce into one record.
- Chunks of at most 200 ops or 3 MB.
- **Poison-record isolation:** a failing chunk is split in half until the single bad record is found; it is logged as a "problem" and dropped so it cannot block everything behind it.
- Order: file bytes first, then rows, then remote deletes of files.

### 4.3 Pull
- The server numbers every change per user (`rev`, strictly increasing). The client asks for everything after its `last_rev`.
- Applied in **one transaction** with `applying=1` (triggers do not echo back) and foreign keys off, using `INSERT ... ON CONFLICT DO UPDATE`.
- **Local wins:** a row that still has a pending local change is skipped; push always runs before pull.
- Echo suppression: when `server_rev - applied_count == last_rev` the client's own push is the only change, so it just advances `last_rev`.
- If the server `rev` is lower than local (server restored from an older backup) `last_rev` is reset to 0 and everything is re-compared.
- A `UNIQUE` conflict on `tasks.code` is logged and skipped.

### 4.4 Files
- Local files are scanned and compared with `_td_files` (size, mtime, sha256). The server stores bytes under an HMAC of the relative path, so no user text ever becomes a server path.
- Download queue in the background plus `ensure_local` on demand: when the user opens a file that is not on this PC yet, it is fetched first.
- Self-heal `verify_files` every 12 h compares local state with the server list.
- Upload is streamed; size is limited by `max_file_mb` = min(config, `post_max_size` - 1 MB), and the user's `quota_mb`.

### 4.5 Restore on a new PC
`last_rev == 0` triggers a restore: all rows are pulled with progress counters; folders are re-created from `tasks.folder` plus the module's `CATS`
map; files then download in the background.

### 4.6 States and timing
`starting`, `syncing`, `idle`, `offline`, `error`, `auth`, `upgrade`, **`blocked`** (+ `blocked_code`: `account_disabled`, `account_expired`, `account_pending`,
`module_changed`). Flags: `maintenance` (state `offline` caused by HTTP 503 `maintenance`), `uploads_off`. Fast loop every 20 s (env `TD_SYNC_FAST`), slow loop 90 s,
exponential back-off after failures, flush on sign out and on shutdown. The first non-GET request after start waits (up to 5 s) for the first pull to finish.

Account check: at the start of a cycle, at most every 60 s (env `TD_ACCOUNT_CHECK`), the engine calls `auth/me`: module changed -> `blocked`, new permissions
(`can_upload`, quotas) are applied. Address check: at most every 10 min (env `TD_HEALTH_CHECK`) and in the gate on every refresh (section 5a.4). A `blocked` account
keeps asking (60 s pause, or at once with "Check again"). While `blocked` the module's own `/api/*` answers 403 `account_blocked`, so nothing new is written, and the shell
shows a full screen message. `AccountBlocked` is never treated as a bad record (a blocked account cannot make the engine drop data).

## 5. Server design and security

- **Passwords:** `password_hash` (bcrypt/argon2 default). Login for an unknown user verifies against a real dummy hash so timing does not reveal accounts.
- **Rate limits** (`td_attempts`): 8 bad logins lock that username for 15 min; per-IP limits on login, register and recovery.
- **Recovery key:** 20 characters (`XXXX-XXXX-XXXX-XXXX-XXXX`), stored only as an HMAC. Using it rotates it, changes the password and revokes all sessions.
- **Tokens:** 256-bit random, stored as a hash, 90-day sliding expiry, max 20 devices per account.
- **Transport:** `require_https` (honours `X-Forwarded-Proto`).
- **Isolation:** every query is scoped by `user_id`. File paths are HMACs. Storage is outside `public_html` by default.
- **Hardening:** `.htaccess` denies `config.php` and logs; JSON-only errors; no stack traces to clients; `nosniff`, `X-Frame-Options`, no referrer.
- **Version control:** `min_client` makes old clients receive HTTP 426 and the app shows "Update needed"; `latest_client` only shows a banner.
- **Tombstones:** deletes are kept as records so offline PCs delete correctly when they come back.

## 5a. Owner site, permissions and the server address

### 5a.1 Owner authentication
Separate from end users: table `td_owners` (bcrypt password, optional TOTP secret sealed with AES-256-GCM), session cookie `tdo` (`HttpOnly`, `SameSite=Strict`,
`Secure` on https), header `X-TD-Owner: 1` required on every non-GET call (CSRF), idle timeout 60 min, absolute 12 h, rate limits (30 / 15 min per IP, 6 / 15 min per username),
audit log `td_audit` (never contains passwords or keys). The first owner is created by `setup.php`; a lost password is repaired with `owner_reset.txt` in the storage folder
(applied once, file deleted, TOTP turned off). The page uses `textContent` only (no `innerHTML` with data).

### 5a.2 Settings and schema
Settings the owner can change live in table `td_settings` and **override** `config.php` (`td_apply_settings`): registration (`open` / `approval` / `closed`), invite code, modules,
default quota and file size, token days, versions, notice, maintenance, `api_url`. `server_id` (16 hex) is generated once and never changes. Schema version 2 adds user columns
(`expires_at`, `quota_mb`, `max_file_mb`, `can_upload`, `must_change_pw`, `note`, `created_by`) and `td_audit` / `td_settings`; `td_migrate` upgrades a v1 database on first request.

### 5a.3 Permission enforcement (server side, so every client obeys)
`td_require_user()` runs on every authenticated route: status `0` -> 403 `account_disabled`; `2` -> 403 `account_pending`; past `expires_at` -> 403 `account_expired`;
`must_change_pw` -> 403 `password_change_required` (except `auth/password` and `auth/logout`); `can_upload = 0` -> 403 `uploads_disabled` on `files/put`;
per-user quota and file size override the defaults (file size is capped by PHP `post_max_size`). Maintenance -> 503 `maintenance` + `Retry-After` for everything except `health`
and `owner/*`. A module change is only accepted while the account has no records and no files; the client keeps old local data aside via the `module.txt` marker in the data folder.

### 5a.4 Moving the server address
The owner types the new address; `health` announces `api_url` + `server_id`. A client switches only after it has asked the new address and received the **same `server_id`**
(`tmcore/server_move.py`), so a typing mistake or a foreign site cannot capture the apps. The new address is saved in the user's `config.json` together with the baked address
it was valid for (`cloud_url_base`): a newer installer with a different baked address wins. The gate and the module host are separate processes: the engine also adopts an address the gate
already saved. The local data folder name uses `server_id`, not the address, so a move does not look like a new server.

## 6. Hosting analysis

| Option | Verdict |
|---|---|
| Hostinger **Web hosting** (existing plan) | **Fits.** PHP + MySQL. This is what the API targets. |
| Python/Django on Web hosting | Not available (Python is VPS only). |
| Node.js on Web hosting | Only on selected plans. Not needed. |
| Hostinger **VPS** | Needed only to move the API to Python/Django or for large scale. The desktop app talks to a documented JSON contract, so the server can be replaced without touching the client. |

## 7. Data layout on a PC

```
%LOCALAPPDATA%\TaskDesk\
   session.json            (DPAPI-protected token, server_id)
   config.json             (only a moved server address)
   run\gate.json
   logs\
   users\u<id>_<username>_<serverid6>\data\
       taskmanager.db   files\<task folder>\<category>\...   backups\   trash\
%LOCALAPPDATA%\Programs\TaskDesk\       (program files, replaced on update; python\, app\)
```
Env `TASKDESK_HOME` relocates the first tree (used by the tests to simulate several PCs).

## 8. Tests

| Suite | Checks | What it covers |
|---|---|---|
| `tests/test_server.py` | 99 | real `php -S` on SQLite: auth, rate limits, rev/pull/push, tombstones, files, quota, size limits, recovery, upgrade gate, path attacks |
| `tests/test_e2e.py` | 79 | two simulated PCs against the real API: first sync, restore on a new PC, module auto-convert, offline then online, conflicts, files, logout/wipe, recovery |
| `tests/test_ui.py` | 12 | headless Chromium: gate flows, theming, About, shell account block, screenshots |
| `tests/test_owner.py` | 115 | owner sign-in, 2-step code, rate limits, user management, every permission the apps must obey, settings, maintenance, audit, upgrade of a v1 database |
| `tests/test_owner_ui.py` | 27 | the owner site in headless Chromium (scrolling layout, drawers, forms, no `innerHTML` injection) |
| `tests/test_e2e_owner.py` | 67 | real PHP + real desktop processes: approval, block / unblock while running, expiry, uploads off, temporary password, My account, maintenance, module change, address move and a foreign address |
| `tests/test_ui_owner.py` | 32 | the screens a user sees (pending, choose password, blocked, expired, My account, notices) and the **fixed header and sidebar** of ABAP, FICO, MM and BASIS |
| `tests/test_basis.py` | 157 | the BASIS module's local server: tickets and SLA, stock and handover rules, joiner / leaver, TR flow, purchases, renewals, checks, reports, Excel, backup, demo data |
| `tests/test_ui_basis.py` | 45 | the BASIS screens in headless Chromium with real flows (new joiner, ticket to close, leaver), no console errors, no sideways scroll on a phone width |
| `tests/test_e2e_basis.py` | 43 | real PHP + two simulated PCs: BASIS data, files and history sync to the cloud and come back complete on a new PC; changes travel both ways |

Run: `python3 tests/<name>.py` (needs `php` CLI); the `*_ui*` suites need Playwright: `NODE_PATH=$(npm root -g) python3 tests/test_ui_owner.py <shots-dir>`.

## 9. Known limits (be honest with users)

1. **Single active device assumption.** Row ids come from each PC's own SQLite counters. Two PCs creating rows at the same time while both are offline can use the same id; the later push wins that row. A guard covers the short window right after start, but not long offline periods on two PCs.
2. Conflicts are **last writer wins per row** (not per field).
3. The MySQL schema was written for MySQL/MariaDB but only exercised against SQLite in tests. First real install: open `?r=health&deep=1` and register a test user.
4. The installer, DPAPI and the embedded-Python start-up path were not run on Windows during development. See the checklist in doc 02.
5. The installer is unsigned: Windows SmartScreen will warn on first run.
6. The old stand-alone task managers' data is not imported automatically.
7. All four modules ship in every install (needed for auto-convert). The wizard choice sets the default edition and icon.
8. **MySQL-only code was not run on MySQL**: the owner / v2 schema creation, the ALTER-based migration of a v1 database and `INSERT IGNORE` were tested on SQLite only. Back up before the first upgrade.
9. The owner site's TOTP, rate limits and sessions are tested against the real PHP code, but not behind Hostinger's own web server. IP based limits use `REMOTE_ADDR` only (a spoofable `X-Forwarded-For` is deliberately not trusted); if the host ever puts a proxy in front, all visitors share one IP bucket, while the per-username limits keep protecting the accounts.

## 10. Roadmap ideas

- Importer from the old stand-alone folders into a TaskDesk account.
- Code signing; automatic in-app update download.
- Per-field merge, or server-assigned ids, to remove limit 1.
- Optional VPS/Django API with the same contract.
