# SAP BASIS & IT module: Hameer Singh ke liye guide

Ye module TaskDesk ke andar **chautha module** hai (ABAP, FICO, MM ke baad). Install karte waqt wizard me **SAP BASIS / IT Support** chuno,
ya login screen par **Create account** me BASIS chuno. Baaki sab (login, backup, naya PC) pehle jaisa hi hai.

Ye module sab IT kaam ek jagah rakhta hai: **kaun sa issue aaya, kisko diya, hua ya nahi, kis ke paas kaun sa laptop hai, kis ko kaun sa mail / SAP id mila**.
Sab kuch Hameer Singh ki screen par dikhta hai, aur sab kuch yahin se banta aur badalta hai.

---

## 1. Pehli baar kya karna hai (5 minute)

1. **Settings** kholo. Apna naam (Basis lead), IT head (HOD) ka naam aur company ka naam bharo.
2. **Plants**: 1100 Jaitpura, 1200 Dhodhsar, 1600 Gavalior pehle se bhare hain. Badalna ho to yahin badlo.
3. **Team** page par apni team ke naam jodo (naam, plant, kaam jaise Hardware / SAP, mobile).
4. **Stock & assets** me jo laptop, PC, mouse, keyboard abhi maujood hain unko daalo (**Add stock**). Ek saath kai laptop ke serial number daal sakte ho.
5. **Daily checks** me **Add typical checks** se SAP backup, CCTV, UPS jaise roz ke checks ek click me bana lo.

Seekhne ke liye **Settings > Data and backup > Load demo data** dabao: nakli ticket, log, laptop aa jaate hain. Dekh lo, phir **Remove demo data** dabao.
Demo hatane se aapka asli data nahi hilta.

---

## 2. Screens (left menu)

| Screen | Kis liye |
|---|---|
| **Today** | Subah sabse pehle yahi dekho: late tickets, jinka kaam "Done" hai aur aapko check karna hai, bina assign wale tickets, 2 din se koi update nahi, kam stock, jo joiner ka setup adhura hai, jo leaver abhi bhi items / ids rakhe hue hai, TR (fail, approval chahiye, PRD ke liye tayyar), renewals aur warranty, checks me problem, kharidari follow-up, 14 din me expire hone wale user id. Har line par click karo, seedha wahi record khulta hai. |
| **Tickets** | Har complaint ya request. Plant, type, team member, priority sab. |
| **People** | Employee, operator, contractor, trainee. Unke items, mail / SAP id, joining aur leaving checklist, poori history. |
| **Stock & assets** | Laptop, PC, monitor, printer, CCTV, UPS, mouse, keyboard, cable, pen drive. Kitna stock hai, kiske paas hai, repair me kya hai. |
| **Transports** | SAP TR: requested, approved, QAS, PRD. |
| **Team** | Aapki team, plant ke hisaab se. Kiske paas kitne open ticket hain. |
| **Daily checks** | Roz / hafte / mahine ke checks. OK ya problem mark karo. |
| **Buy & renew** | Kharidari (laptop, mouse ka order) aur renewals (AMC, licence, SSL, internet line, warranty). |
| **Reports** | HOD ke liye report: kitne ticket aaye, kitne hue, kitne late, stock, TR. Print, WhatsApp text ya Excel. |
| **Settings** | Naam, plants, time limits, minimum stock, rules, checklists, backup. |

Upar header me **plant switch** hai: **All plants / 1100 / 1200 / 1600**. Ek plant chuno to poori app usi plant ka data dikhati hai.
**New** button (upar) se ticket, joiner, stock, TR, kharidari kuch bhi naya ban jaata hai. Search box me naam, serial number, mail id, TR number kuch bhi likho.

---

## 3. Roz ke kaam

### 3.1 Koi issue aaya (camera, PC, mouse, SAP, mail, kuch bhi)

1. **New > Ticket**. User ka naam chuno (list me nahi hai to type karo). Us user ke jo device hain wo chip ki tarah dikhte hain, jis device me problem hai use dabao.
2. Type chuno (Hardware, Software, SAP issue, SAP user request, Email, Network, CCTV, Printer, Phone, New joiner / Leaver, Purchase, Other) aur priority.
3. **Finish by** time apne aap aata hai (Critical 4 ghante, High 8, Medium 24, Low 72; Settings me badal sakte ho).
4. Team member chuno. Wo ticket us member ke naam par chala jaata hai. **Message** button se uske liye WhatsApp text ban jaata hai.
5. Agar kaam turant ho gaya, **"I already solved it - just keep a record"** tick karo: ticket seedha band ho jaata hai aur record bhi rehta hai.

Ticket ka rasta: **New > Assigned > In progress > (Waiting) > Done > Closed**.
Team member "Done" kare to ticket **To check** me aata hai. Aap result dekh kar **Checked - close it** dabate ho, tab hi band hota hai. Isse pata chalta hai ki kaam sach me hua.
"Waiting" me kaaran likhna padta hai (jaise "naya mouse stock me nahi") aur follow-up date. Wo date aane par Today par dikhta hai.
Galat bandh hua ho to **Reopen**.

### 3.2 Team ko kaam dena aur dekhna ki hua ya nahi

- Tickets > **Not assigned** me jo bina member wale hain, wahin se dropdown se member chuno.
- Tickets > **Overdue** me late kaam, **To check** me jo aapke check ka intezaar kar rahe hain.
- **Team** page par har member ke open aur late tickets ek nazar me. Plant me koi member nahi hai to warning dikhti hai.

### 3.3 SAP user create / delete / lock / password / role

Ticket type **SAP user request** chuno. Request ka prakar (create, delete, lock, unlock, password reset, role, validity badhana) alag select hota hai.
SAP user number us person ke **Mail & SAP ids** me jud jaata hai, aur person ki history me likha jaata hai.

### 3.4 TR production me move karni hai

**Transports > New transport**: TR number, description, kisne maanga. Rasta:
**Requested > Approved > QAS > Moved to PRD**. Har step par kaun aur kab, record hota hai.
Settings me "approval chahiye" rule ON ho (default) to bina approval ke PRD par nahi jaa sakti. Ek hi TR number do baar nahi ban sakta.
PRD me gayi TR delete nahi hoti, wo record me rehti hai.

---

## 4. Naya employee aaya (New joiner)

**New > New joiner**. Ek hi screen me:

1. Naam, employee code, plant, department, kaisa (employee / operator / contractor / trainee), mobile.
2. **Kya dena hai**: Laptop, Desktop, Monitor, Mouse, Keyboard waghera chip dabao. Har item ke liye app **stock dikhati hai**:
   - **Pehle purana lautaya hua item**, "Returned item - give this first" likha hota hai. Wahi pehle dena chahiye.
   - Uske baad naya stock.
   - Stock nahi hai to **Buy** chuno: kharidari ki request apne aap ban jaati hai, aur joiner ki checklist me "pending" dikhta hai.
3. Mail id, SAP user, Windows login ho to wahi daal do (baad me bhi daal sakte ho).
4. **Add joiner** dabao.

Ek click me: person ban gaya, jo items diye unka stock kam hua aur unki history likhi gayi, mail / SAP id jud gaye, joining checklist bani aur jo steps ho chuke wo tick ho gaye.
Agar beech me kuch galat nikla (jaise item pehle hi kisi aur ko de diya), **poora kaam wapas ho jaata hai**, aadha-adhura record nahi bachta.

Print: person ke page par **Print handover slip** dabao. Slip me items, serial number, mail id, tareekh aur sign ki jagah hoti hai. Print karke operator ya employee se sign karwao, phir photo / scan **Files > Handover form** me daal do.

Operator ke liye bhi yehi tarika hai: kind me **Operator / shop floor** chuno. Shop floor ke PC ya scanner ko **Deployed at a place** (jaise "Line 2 cutting") ki tarah bhi record kar sakte ho, kisi ek aadmi ke naam par zaroori nahi.

---

## 5. Laptop aur stock

- **Tracked item** (laptop, PC, monitor, printer, CCTV...): har ek ka apna serial number, condition, warranty, history.
- **Counted item** (mouse, keyboard, cable, pen drive): sirf quantity. "5 mouse hain, 1 diya, 4 bache."
- Item ke sab kaam: **Issue, Take back, Replace (swap), Send for repair, Back from repair, Scrap, Mark lost / Found, Add stock, Note**.
- **Swap**: purana laptop wapas lo aur naya do, ek hi step me. Purana apne aap "In stock" me jaata hai, to agla joiner ko wahi milega.
- Ek hi item do logo ko issue nahi ho sakta. Ek hi serial number do baar nahi daal sakte. App aise galat kaam par roak deti hai.
- **Stock summary** (upar ke cards): kitne In stock, Issued, Repair, Scrapped. Jo type minimum se neeche gaya wo Today par lal warning me aata hai (Settings > Minimum stock).
- Invoice, warranty card, photo har item ke saath file ki tarah rakh sakte ho.

---

## 6. Employee chhod ke gaya (Leaver)

Person ke page par **Mark as left**. App ek **leaving checklist** banati hai (aur **Print clearance slip** se clearance slip nikalti hai): laptop aur accessories wapas, mail id band, SAP user lock / delete, VPN band, data backup, handover slip close.
Jab tak items wapas nahi aate, person list me **"Items / ids pending"** dikhta hai. Items wapas lete hi (**Take back**) wo stock me aate hain aur agle joiner ko pehle wahi milte hain.
Kisi leaver ko naya item issue nahi ho sakta.

---

## 7. Daily checks

**Daily checks** me roz ke kaam ki list: SAP backup, CCTV recording, internet, UPS, antivirus update... Har check ka ek member zimmedar hota hai.
**OK** ya **Problem** dabao (problem me note zaroori). Problem par chaho to usi waqt ticket bhi khul jaata hai ("also open a ticket").
Check sirf **working days** par due hota hai (Settings me din chune ja sakte hain). Chhoota hua check "Missed" dikhta hai aur Today par aata hai.
Aaj ka aaj hi dobara mark karo to wahi entry badal jaati hai, duplicate nahi banta. Aaj se aage ki tareekh nahi daal sakte.

---

## 8. Kharidari aur renewals

- **Purchases**: Requested > Approved > Ordered > Received. Date par maal na aaye to **late** dikhta hai. **Received** karte waqt "stock me daal do" tick karo: item seedha stock me aa jaata hai.
- **Renewals**: AMC, software licence, domain, SSL, internet line, antivirus. Expiry se 30 din pehle (Settings me badal sakte ho) Today par aata hai. **Renew** dabao aur nayi expiry daalo.
- Laptop ki **warranty** bhi isi list me apne aap aati hai.

---

## 9. HOD ko report

**Reports**: period chuno (This week, Last 7 days, This month, Last month, Last 30 days ya apni tareekh) aur plant. Dikhta hai: aaye, band hue, late, average time, kis member ne kitna kiya, TR, stock, renewals, checks.
- **Print / save as PDF**: sidha print.
- **Copy WhatsApp summary**: chhota text, copy karke HOD ko bhej do.
- **Excel**: poora data (tickets, people, assets, TR, purchases...) ek workbook me.

---

## 10. Data kahan rehta hai, backup

- Sab data **aapke apne PC par** rehta hai (isliye tez chalta hai, internet band ho to bhi chalta hai) aur peeche se **Hostinger par backup** ho jaata hai. Naye PC par login karo to sab wapas aa jaata hai: tickets, log, laptop, history, files.
- Roz ek local backup apne aap banta hai. **Settings > Data and backup > Back up now** se kabhi bhi.
- **Excel with all data** se poora data nikal sakte ho.

---

## 11. Seemayein (sach me jaanne wali baatein)

- **Team members ke login nahi hain.** Team me sirf naam hain; kaam Hameer Singh hi update karte hain (ya unke kehne par). Alag-alag logon ko apne login dene wala "shared workspace" agla phase hai.
- **Ek samay par ek hi PC active** rakho (office PC ya ghar ka). Dono par ek saath nayi entries karoge to number (jaise ID) takra sakte hain. Doosre PC par jaane se pehle pehla PC sign out kar do.
- **HOD ke liye alag login abhi nahi hai.** Report print / WhatsApp / Excel se jaati hai.
- Tareekh daalne wale box browser ki bhasha / region ke hisaab se dikhte hain.
- Ye module ticket par automatic WhatsApp / SMS nahi bhejta. **Message** button text banata hai, aap copy karke bhejte ho.
- Windows installer, MySQL aur `.iss` compile yahan (Linux sandbox) me nahi chale. Unko aapko apne PC par pehli baar chalana hoga (docs 01 aur 02 me steps hain).
