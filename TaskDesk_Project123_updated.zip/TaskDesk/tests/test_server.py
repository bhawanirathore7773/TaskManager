#!/usr/bin/env python3
"""
Tests the TaskDesk PHP API with the real PHP interpreter (built-in web server) and a throw-away SQLite database.
Run:  python3 tests/test_server.py
"""
import hashlib
import json
import os
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SERVER_SRC = os.path.join(ROOT, 'server')

PASS = 0
FAIL = 0


def check(name, cond, extra=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('  ok   ' + name)
    else:
        FAIL += 1
        print('  FAIL ' + name + ('  -> ' + str(extra) if extra != '' else ''))


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def make_site(tmp, name, extra_cfg):
    site = os.path.join(tmp, name)
    shutil.copytree(SERVER_SRC, site, ignore=shutil.ignore_patterns('config.php', 'storage', '*.done'))
    cfg = {
        'db': {'driver': 'sqlite', 'path': os.path.join(tmp, name + '.sqlite')},
        'storage': os.path.join(tmp, name + '_storage'),
        'secret': 'x' * 64,
        'modules': ['abap', 'fico', 'mm', 'basis'],
        'allow_registration': True,
        'invite_code': '',
        'quota_mb': 5,
        'max_file_mb': 3,
        'token_days': 90,
        'require_https': False,
        'latest_client': '1.2.0',
        'min_client': '1.0.0',
        'download_url': 'https://example.com/get',
        'notice': 'hello',
    }
    cfg.update(extra_cfg)
    with open(os.path.join(site, 'config.php'), 'w') as f:
        f.write('<?php return ' + php_export(cfg) + ';')
    subprocess.check_call(['php', '-r',
                           'require "%s/lib/bootstrap.php"; require "%s/lib/schema.php"; '
                           '$c=td_config(); $p=td_db(); td_create_schema($p,"sqlite");' % (site, site)])
    return site


def php_export(v):
    if isinstance(v, dict):
        return 'array(' + ','.join(php_export(k) + '=>' + php_export(x) for k, x in v.items()) + ')'
    if isinstance(v, list):
        return 'array(' + ','.join(php_export(x) for x in v) + ')'
    if isinstance(v, bool):
        return 'true' if v else 'false'
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace('\\', '\\\\').replace("'", "\\'") + "'"


class Api:
    def __init__(self, port):
        self.base = 'http://127.0.0.1:%d/api.php' % port

    def call(self, route, method='GET', body=None, token=None, query='', raw=None, headers=None, bearer=False):
        url = self.base + '?r=' + route + (('&' + query) if query else '')
        data = None
        h = {}
        if body is not None:
            data = json.dumps(body).encode()
            h['Content-Type'] = 'application/json'
        if raw is not None:
            data = raw
            h['Content-Type'] = 'application/octet-stream'
        if token:
            if bearer:
                h['Authorization'] = 'Bearer ' + token
            else:
                h['X-TD-Token'] = token
        if headers:
            h.update(headers)
        req = urllib.request.Request(url, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                payload = r.read()
                return r.status, payload, dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(), dict(e.headers)

    def j(self, *a, **k):
        st, payload, hdr = self.call(*a, **k)
        try:
            return st, json.loads(payload.decode('utf-8'))
        except Exception:
            return st, {'_raw': payload[:200]}


def wait_up(port):
    for _ in range(60):
        try:
            socket.create_connection(('127.0.0.1', port), 0.2).close()
            return True
        except OSError:
            time.sleep(0.1)
    return False


def main():
    tmp = tempfile.mkdtemp(prefix='tdsrv_')
    procs = []
    try:
        site = make_site(tmp, 'main', {})
        port = free_port()
        env = dict(os.environ, PHP_CLI_SERVER_WORKERS='4')
        procs.append(subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', site], cwd=site, env=env,
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        check('php server starts', wait_up(port))
        api = Api(port)

        print('health and routing')
        st, d = api.j('health')
        check('health ok', st == 200 and d.get('ok') is True and d.get('modules') == ['abap', 'fico', 'mm', 'basis'], d)
        check('health shows update info', d.get('latest_client') == '1.2.0' and d.get('download_url') and d.get('notice') == 'hello')
        st, d = api.j('health', query='deep=1')
        check('deep health db+storage', d.get('db') is True and d.get('storage') is True, d)
        st, d = api.j('nothing/here')
        check('unknown call 404 json', st == 404 and d.get('error') == 'unknown_call', (st, d))
        st, d = api.j('auth/login', 'GET')
        check('wrong method 405', st == 405, (st, d))
        st, d = api.j('sync/pull')
        check('pull without token 401', st == 401 and d.get('error') == 'not_signed_in', (st, d))
        st, d = api.j('sync/pull', token='a' * 64)
        check('pull with unknown token 401', st == 401, (st, d))
        st, d = api.j('sync/pull', token='not-hex')
        check('pull with malformed token 401', st == 401, (st, d))
        st, payload, h = api.call('auth/register', 'POST', raw=b'{bad json')
        check('bad json -> 400 json', st == 400, (st, payload[:100]))

        print('register / login')
        st, d = api.j('auth/register', 'POST', {'username': 'A', 'password': 'longenough1', 'module': 'mm'})
        check('short username rejected', st == 400 and d.get('error') == 'bad_username', d)
        st, d = api.j('auth/register', 'POST', {'username': '../etc', 'password': 'longenough1', 'module': 'mm'})
        check('path-like username rejected', st == 400, d)
        st, d = api.j('auth/register', 'POST', {'username': 'bhawani', 'password': 'short', 'module': 'mm'})
        check('short password rejected', st == 400 and d.get('error') == 'weak_password', d)
        st, d = api.j('auth/register', 'POST', {'username': 'bhawani', 'password': 'bhawani', 'module': 'mm'})
        check('password == username rejected', st == 400, d)
        st, d = api.j('auth/register', 'POST', {'username': 'bhawani', 'password': 'longenough1', 'module': 'sd'})
        check('unknown module rejected', st == 400 and d.get('error') == 'bad_module', d)
        st, a = api.j('auth/register', 'POST', {'username': 'Bhawani', 'password': 'Passw0rd!x', 'module': 'mm',
                                                'display_name': 'Bhawani Singh', 'device': 'PC-1'})
        check('register ok', st == 200 and a.get('ok') and len(a.get('token', '')) == 64, a)
        check('username lower-cased', a['user']['username'] == 'bhawani' and a['user']['module'] == 'mm', a)
        check('recovery key format', len(a['recovery_key']) == 24 and a['recovery_key'].count('-') == 4, a['recovery_key'])
        st, d = api.j('auth/register', 'POST', {'username': 'BHAWANI', 'password': 'Passw0rd!x', 'module': 'abap'})
        check('duplicate username 409', st == 409 and d.get('error') == 'username_taken', d)
        tokA = a['token']
        st, d = api.j('auth/me', token=tokA)
        check('me via X-TD-Token', st == 200 and d['user']['username'] == 'bhawani', d)
        st, d = api.j('auth/me', token=tokA, bearer=True)
        check('me via Authorization: Bearer', st == 200 and d['user']['module'] == 'mm', d)

        st, d = api.j('auth/login', 'POST', {'username': 'bhawani', 'password': 'wrong-pass'})
        check('wrong password 401', st == 401 and d.get('error') == 'bad_credentials', d)
        st, d = api.j('auth/login', 'POST', {'username': 'nobody', 'password': 'wrong-pass'})
        check('unknown user same 401 message', st == 401 and d.get('error') == 'bad_credentials', d)
        st, l = api.j('auth/login', 'POST', {'username': 'Bhawani', 'password': 'Passw0rd!x', 'device': 'Laptop'})
        check('login ok, new token', st == 200 and l['token'] != tokA and l['user']['module'] == 'mm', l)
        tokA2 = l['token']

        print('login rate limit')
        st, lk = api.j('auth/register', 'POST', {'username': 'lockme', 'password': 'Passw0rd!x', 'module': 'mm'})
        for _ in range(8):
            api.j('auth/login', 'POST', {'username': 'lockme', 'password': 'bad-bad-bad'})
        st, d = api.j('auth/login', 'POST', {'username': 'lockme', 'password': 'Passw0rd!x'})
        check('locked after 8 bad logins, even with the right password (429)', st == 429 and d.get('error') == 'too_many_attempts', (st, d))
        st, d = api.j('auth/login', 'POST', {'username': 'bhawani', 'password': 'Passw0rd!x'})
        check('other accounts are not locked by it', st == 200, (st, d))

        print('second user (other module) + isolation')
        st, b = api.j('auth/register', 'POST', {'username': 'ravi.abap', 'password': 'Another#Pass1', 'module': 'abap'})
        check('register abap user', st == 200 and b['user']['module'] == 'abap', b)
        tokB = b['token']

        print('sync push / pull')
        ops = [
            {'op': 'put', 't': 'tasks', 'id': '1', 'd': {'id': 1, 'code': 'T-0001', 'title': 'PO release हिंदी ✓', 'status': 'Open'}},
            {'op': 'put', 't': 'tasks', 'id': '2', 'd': {'id': 2, 'code': 'T-0002', 'title': 'Second'}},
            {'op': 'put', 't': 'checklist', 'id': '10', 'd': {'id': 10, 'task_id': 1, 'text': 'step "one"', 'done': 0}},
            {'op': 'put', 't': 'settings', 'id': 'theme', 'd': {'key': 'theme', 'value': 'dark'}},
        ]
        st, d = api.j('sync/push', 'POST', {'ops': ops}, token=tokA)
        check('push 4 ops', st == 200 and d['applied'] == 4 and d['rev'] == 4, d)
        st, d = api.j('sync/pull', token=tokA, query='since=0')
        check('pull all', st == 200 and len(d['records']) == 4 and d['last'] == 4 and d['more'] is False, d)
        rec = {(r['t'], r['id']): r for r in d['records']}
        check('unicode + quotes round trip', rec[('tasks', '1')]['d']['title'] == 'PO release हिंदी ✓'
              and rec[('checklist', '10')]['d']['text'] == 'step "one"', rec)
        st, d = api.j('sync/pull', token=tokA, query='since=2')
        check('pull since=2 returns only newer', [r['rev'] for r in d['records']] == [3, 4], d)
        st, d = api.j('sync/pull', token=tokA, query='since=0&limit=3')
        check('pull limit sets more=true', len(d['records']) == 3 and d['more'] is True and d['last'] == 3, d)

        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'put', 't': 'tasks', 'id': '1', 'd': {'id': 1, 'code': 'T-0001', 'title': 'changed'}},
                                                   {'op': 'del', 't': 'tasks', 'id': '2'}]}, token=tokA)
        check('update + delete push', st == 200 and d['rev'] == 6, d)
        st, d = api.j('sync/pull', token=tokA, query='since=4')
        recs = {r['id']: r for r in d['records']}
        check('update visible with new rev', recs['1']['d']['title'] == 'changed' and recs['1']['rev'] == 5, d)
        check('delete is a tombstone', recs['2']['del'] == 1 and recs['2']['d'] is None and recs['2']['rev'] == 6, d)
        st, d = api.j('sync/pull', token=tokA, query='since=0')
        check('one record per row (not per change)', len(d['records']) == 4, len(d['records']))
        st, d = api.j('sync/status', token=tokA)
        check('status counts live records', st == 200 and d['records'] == 3 and d['rev'] == 6, d)

        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'put', 't': 'bad table!', 'id': '1', 'd': {'a': 1}}]}, token=tokA)
        check('bad table name rejected', st == 400, d)
        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'put', 't': 'tasks', 'id': '', 'd': {'a': 1}}]}, token=tokA)
        check('empty id rejected', st == 400, d)
        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'put', 't': 'tasks', 'id': '5'}]}, token=tokA)
        check('put without data rejected', st == 400, d)
        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'zap', 't': 'tasks', 'id': '5'}]}, token=tokA)
        check('unknown op rejected', st == 400, d)
        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'del', 't': 'tasks', 'id': '1'}] * 501}, token=tokA)
        check('more than 500 ops rejected', st == 400 and d.get('error') == 'too_many_ops', d)
        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'put', 't': 'tasks', 'id': '9', 'd': {'x': 'y' * 1100000}}]}, token=tokA)
        check('record over 1 MB rejected', st == 413, (st, d))
        st, d = api.j('sync/pull', token=tokA, query='since=0')
        check('rejected pushes changed nothing', len(d['records']) == 4 and d['last'] == 6, d)

        st, d = api.j('sync/pull', token=tokB, query='since=0')
        check('user B sees none of user A rows', st == 200 and d['records'] == [] and d['last'] == 0, d)
        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'put', 't': 'tasks', 'id': '1', 'd': {'id': 1, 'title': 'B task'}}]}, token=tokB)
        st, dA = api.j('sync/pull', token=tokA, query='since=0')
        titleA = [r for r in dA['records'] if r['id'] == '1' and r['t'] == 'tasks'][0]['d']['title']
        check('same row id for two users does not clash', titleA == 'changed', titleA)

        print('files')
        data = os.urandom(300000)
        sha = hashlib.sha256(data).hexdigest()
        rel = 'T-0001_PO release/2_Excel_Requirement/list हि.xlsx'
        q = 'rel=' + urllib.request.quote(rel) + '&sha=' + sha
        st, d = api.j('files/put', 'POST', raw=data, token=tokA, query=q)
        check('file put', st == 200 and d['size'] == len(data) and d['sha256'] == sha, d)
        st, payload, h = api.call('files/get', token=tokA, query='rel=' + urllib.request.quote(rel))
        check('file get returns identical bytes', st == 200 and payload == data, (st, len(payload)))
        check('file get has checksum header', h.get('X-TD-SHA256') == sha, h)
        st, d = api.j('files/list', token=tokA)
        check('file list', d['files'] == [{'rel': rel, 'size': len(data), 'sha': sha}], d)
        st, d = api.j('files/list', token=tokB)
        check('user B file list empty', d['files'] == [], d)
        st, payload, h = api.call('files/get', token=tokB, query='rel=' + urllib.request.quote(rel))
        check('user B cannot read user A file', st == 404, st)
        st, d = api.j('sync/status', token=tokA)
        check('bytes_used tracked', d['bytes_used'] == len(data) and d['files'] == 1, d)

        st, d = api.j('files/put', 'POST', raw=data, token=tokA, query='rel=x.bin&sha=' + '0' * 64)
        check('wrong checksum rejected 422', st == 422 and d.get('error') == 'checksum_mismatch', (st, d))
        for bad in ['../x.txt', '/abs.txt', 'a/../../b.txt', 'a//b.txt', '', 'dir/./f.txt', 'a\x00b.txt', 'a/b /c.txt']:
            st, d = api.j('files/put', 'POST', raw=b'zz', token=tokA, query='rel=' + urllib.request.quote(bad))
            check('bad path rejected: %r' % bad, st == 400, (st, d))
        st, d = api.j('files/put', 'POST', raw=b'zz', token=tokA, query='rel=ok.txt&sha=nothex')
        check('bad sha format rejected', st == 400, d)

        data2 = b'second version'
        st, d = api.j('files/put', 'POST', raw=data2, token=tokA, query='rel=' + urllib.request.quote(rel))
        check('overwrite file', st == 200, d)
        st, d = api.j('sync/status', token=tokA)
        check('bytes_used shrinks on overwrite', d['bytes_used'] == len(data2) and d['files'] == 1, d)
        st, payload, h = api.call('files/get', token=tokA, query='rel=' + urllib.request.quote(rel))
        check('new content served', payload == data2)

        big = os.urandom(3 * 1048576 + 10)
        st, d = api.j('files/put', 'POST', raw=big, token=tokA, query='rel=big.bin')
        check('file over max_file_mb rejected 413', st == 413, (st, d))
        chunk = os.urandom(2 * 1048576)
        ok1 = api.j('files/put', 'POST', raw=chunk, token=tokA, query='rel=c1.bin')[0]
        ok2 = api.j('files/put', 'POST', raw=chunk, token=tokA, query='rel=c2.bin')[0]
        st, d = api.j('files/put', 'POST', raw=chunk, token=tokA, query='rel=c3.bin')
        check('quota stops the third 2 MB file (5 MB quota)', ok1 == 200 and ok2 == 200 and st == 413 and d.get('error') == 'quota_exceeded', (ok1, ok2, st, d))
        st, d = api.j('files/list', token=tokA)
        check('rejected upload left no record', sorted(x['rel'] for x in d['files']) == sorted([rel, 'c1.bin', 'c2.bin']), d)

        st, d = api.j('files/del', 'POST', {'rel': 'c1.bin'}, token=tokA)
        check('file delete', st == 200, d)
        st, payload, h = api.call('files/get', token=tokA, query='rel=c1.bin')
        check('deleted file is gone (404)', st == 404, st)
        st, d = api.j('sync/status', token=tokA)
        check('bytes_used shrinks on delete', d['bytes_used'] == len(data2) + len(chunk), d)
        st, d = api.j('files/del', 'POST', {'rel': 'never-existed.txt'}, token=tokA)
        check('deleting a missing file is not an error', st == 200, d)
        st, d = api.j('files/put', 'POST', raw=chunk, token=tokA, query='rel=c3.bin')
        check('space is free again after delete', st == 200, d)

        print('password change / recovery / sessions')
        st, d = api.j('auth/password', 'POST', {'old_password': 'nope-nope', 'new_password': 'NewPassw0rd!'}, token=tokA)
        check('password change needs old password', st == 403, d)
        st, d = api.j('auth/password', 'POST', {'old_password': 'Passw0rd!x', 'new_password': 'short'}, token=tokA)
        check('new password must be strong enough', st == 400, d)
        st, d = api.j('auth/password', 'POST', {'old_password': 'Passw0rd!x', 'new_password': 'NewPassw0rd!'}, token=tokA)
        check('password changed', st == 200, d)
        st, d = api.j('auth/me', token=tokA2)
        check('other device signed out after password change', st == 401, (st, d))
        st, d = api.j('auth/me', token=tokA)
        check('current device stays signed in', st == 200, (st, d))
        st, d = api.j('auth/login', 'POST', {'username': 'bhawani', 'password': 'NewPassw0rd!'})
        check('login with the new password', st == 200, (st, d))

        st, d = api.j('auth/recover', 'POST', {'username': 'bhawani', 'recovery_key': 'AAAA-BBBB-CCCC-DDDD-EEEE', 'new_password': 'Recovered#99'})
        check('wrong recovery key rejected', st == 403, d)
        st, d = api.j('auth/recover', 'POST', {'username': 'bhawani', 'recovery_key': a['recovery_key'].lower().replace('-', ' '), 'new_password': 'Recovered#99'})
        check('recovery works (case and separators ignored)', st == 200 and len(d.get('recovery_key', '')) == 24 and d['recovery_key'] != a['recovery_key'], d)
        newKey = d.get('recovery_key', '')
        st, d = api.j('auth/me', token=tokA)
        check('recovery signs out every device', st == 401, (st, d))
        st, d = api.j('auth/recover', 'POST', {'username': 'bhawani', 'recovery_key': a['recovery_key'], 'new_password': 'Again#Pass99'})
        check('old recovery key is dead', st == 403, d)
        st, d = api.j('auth/recover', 'POST', {'username': 'ravi.abap', 'recovery_key': newKey, 'new_password': 'Hijack#Pass99'})
        check("one user's key does not open another account", st == 403, d)

        st, rr = api.j('auth/login', 'POST', {'username': 'ravi.abap', 'password': 'Another#Pass1', 'device': 'PC'})
        check('login ok for second user', st == 200, rr)
        st, d = api.j('auth/logout', 'POST', token=rr['token'])
        check('logout ok', st == 200, d)
        st, d = api.j('auth/me', token=rr['token'])
        check('token dead after logout', st == 401, d)

        print('client version gate')
        st, d = api.j('sync/pull', token=tokB, headers={'X-TD-Client': '0.9.0'})
        check('old client gets 426', st == 426 and d.get('error') == 'upgrade_required', (st, d))
        st, d = api.j('sync/pull', token=tokB, headers={'X-TD-Client': '1.0.0'})
        check('min client accepted', st == 200, (st, d))
        st, d = api.j('health', headers={'X-TD-Client': '0.1.0'})
        check('health always allowed for old clients', st == 200, (st, d))

        print('config switches (second server)')
        site2 = make_site(tmp, 'strict', {'require_https': True, 'invite_code': 'sesame', 'allow_registration': True})
        port2 = free_port()
        procs.append(subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port2, '-t', site2], cwd=site2, env=env,
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        wait_up(port2)
        api2 = Api(port2)
        st, d = api2.j('health')
        check('https required over plain http', st == 400 and d.get('error') == 'https_required', (st, d))
        hdr = {'X-Forwarded-Proto': 'https'}
        st, d = api2.j('health', headers=hdr)
        check('behind a TLS proxy it works, invite flag shown', st == 200 and d.get('invite_required') is True, (st, d))
        st, d = api2.j('auth/register', 'POST', {'username': 'newuser', 'password': 'Passw0rd!x', 'module': 'fico', 'invite': 'wrong'}, headers=hdr)
        check('wrong invite code rejected', st == 403 and d.get('error') == 'bad_invite', (st, d))
        st, d = api2.j('auth/register', 'POST', {'username': 'newuser', 'password': 'Passw0rd!x', 'module': 'fico', 'invite': 'sesame'}, headers=hdr)
        check('right invite code accepted', st == 200, (st, d))

        site3 = make_site(tmp, 'closed', {'allow_registration': False})
        port3 = free_port()
        procs.append(subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port3, '-t', site3], cwd=site3, env=env,
                                      stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))
        wait_up(port3)
        st, d = Api(port3).j('auth/register', 'POST', {'username': 'newuser', 'password': 'Passw0rd!x', 'module': 'fico'})
        check('registration can be closed', st == 403 and d.get('error') == 'registration_closed', (st, d))

        print('concurrency: parallel pushes keep revisions unique')
        import threading
        errs = []

        def worker(n):
            for i in range(10):
                s, dd = api.j('sync/push', 'POST', {'ops': [{'op': 'put', 't': 'timelog', 'id': 'w%d_%d' % (n, i), 'd': {'n': n, 'i': i}}]}, token=tokB)
                if s != 200:
                    errs.append((s, dd))
        ths = [threading.Thread(target=worker, args=(n,)) for n in range(6)]
        [t.start() for t in ths]
        [t.join() for t in ths]
        st, d = api.j('sync/pull', token=tokB, query='since=0&limit=2000')
        revs = [r['rev'] for r in d['records']]
        check('60 parallel pushes all succeeded', not errs, errs[:2])
        check('60 rows, 60 distinct growing revisions', len(d['records']) == 61 and len(set(revs)) == 61 and revs == sorted(revs), (len(revs), len(set(revs))))

        print('files cannot be fetched without being listed / direct config access is not served by the API')
        st, payload, h = api.call('files/get', token=tokB, query='rel=' + urllib.request.quote('../config.php'))
        check('cannot read config.php through files/get', st == 400, st)

    finally:
        for p in procs:
            try:
                p.send_signal(signal.SIGTERM)
                p.wait(timeout=5)
            except Exception:
                p.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nRESULT: %d passed, %d failed' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
