#!/usr/bin/env python3
"""
Tests the owner side of the TaskDesk server: owner sign-in, two-step code, user management, permissions that the
desktop apps must obey, settings, maintenance, audit trail and the upgrade of an older database.
Run:  python3 tests/test_owner.py
"""
import base64
import hashlib
import hmac
import json
import os
import shutil
import signal
import sqlite3
import struct
import subprocess
import sys
import tempfile
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import test_server as T                      # noqa: E402
from test_server import check, free_port, make_site, wait_up, Api   # noqa: E402


def totp(secret_b32, offset=0):
    key = base64.b32decode(secret_b32.upper() + '=' * (-len(secret_b32) % 8))
    counter = int(time.time() // 30) + offset
    h = hmac.new(key, struct.pack('>Q', counter), hashlib.sha1).digest()
    o = h[19] & 15
    n = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3]
    return '%06d' % (n % 1000000)


class Owner:
    """A browser session of the owner: keeps the cookie, always sends the required header."""
    def __init__(self, api):
        self.api = api
        self.cookie = ''

    def call(self, route, method='GET', body=None, query='', header=True, cookie=True):
        h = {}
        if header:
            h['X-TD-Owner'] = '1'
        if cookie and self.cookie:
            h['Cookie'] = 'tdo=' + self.cookie
        st, payload, hdr = self.api.call(route, method, body, query=query, headers=h)
        try:
            d = json.loads(payload.decode('utf-8'))
        except Exception:
            d = {'_raw': payload[:200]}
        sc = hdr.get('Set-Cookie') or hdr.get('set-cookie') or ''
        if sc.startswith('tdo=') and not sc.startswith('tdo=deleted') and not sc.startswith('tdo=;'):
            self.cookie = sc.split(';')[0][4:]
        return st, d, hdr


V1_DDL = [
    'CREATE TABLE td_users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL, module TEXT NOT NULL,'
    ' pass_hash TEXT NOT NULL, recovery_hash TEXT NOT NULL, rev INTEGER NOT NULL DEFAULT 0, bytes_used INTEGER NOT NULL DEFAULT 0,'
    ' status INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, last_login TEXT NULL)',
    'CREATE TABLE td_tokens (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, token_hash TEXT NOT NULL UNIQUE, device TEXT NOT NULL,'
    ' created_at TEXT NOT NULL, last_used TEXT NOT NULL, expires_at TEXT NOT NULL)',
    'CREATE TABLE td_records (user_id INTEGER NOT NULL, tbl TEXT NOT NULL, rid TEXT NOT NULL, data TEXT NOT NULL, deleted INTEGER NOT NULL DEFAULT 0,'
    ' rev INTEGER NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY (user_id, tbl, rid))',
    'CREATE TABLE td_files (user_id INTEGER NOT NULL, rel_hash TEXT NOT NULL, rel TEXT NOT NULL, size INTEGER NOT NULL, sha256 TEXT NOT NULL,'
    ' updated_at TEXT NOT NULL, PRIMARY KEY (user_id, rel_hash))',
    'CREATE TABLE td_attempts (id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, k TEXT NOT NULL, ts INTEGER NOT NULL)',
]


def start(site, env):
    port = free_port()
    p = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', site], cwd=site, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    wait_up(port)
    return port, p


def main():
    tmp = tempfile.mkdtemp(prefix='tdown_')
    procs = []
    env = dict(os.environ, PHP_CLI_SERVER_WORKERS='4')
    try:
        site = make_site(tmp, 'main', {'quota_mb': 50, 'max_file_mb': 20})
        storage = os.path.join(tmp, 'main_storage')
        os.makedirs(storage, exist_ok=True)
        port, p = start(site, env)
        procs.append(p)
        api = Api(port)
        o = Owner(api)

        print('owner site: no owner yet, then the reset file creates one')
        st, d, _ = o.call('owner/status')
        check('status says no owner yet', st == 200 and d.get('configured') is False and d.get('signed_in') is False, d)
        st, d, _ = o.call('owner/login', 'POST', {'username': 'boss', 'password': 'whatever-long'})
        check('cannot sign in before an owner exists', st == 401, (st, d))
        with open(os.path.join(storage, 'owner_reset.txt'), 'w') as f:
            f.write('Boss\nOwner-Pass-123\n')
        st, d, _ = o.call('owner/status')
        check('reset file creates the owner and is consumed', d.get('configured') is True and not os.path.exists(os.path.join(storage, 'owner_reset.txt')), d)

        print('owner sign-in')
        for r in ('owner/dashboard', 'owner/users', 'owner/user', 'owner/settings', 'owner/audit', 'owner/me'):
            st, d, _ = o.call(r)
            check('%s needs sign-in' % r, st == 401 and d.get('error') == 'owner_not_signed_in', (st, d))
        st, d, _ = o.call('owner/login', 'POST', {'username': 'boss', 'password': 'wrong-wrong-1'})
        check('wrong password 401', st == 401 and d.get('error') == 'bad_credentials', d)
        st, d, hdr = o.call('owner/login', 'POST', {'username': 'BOSS', 'password': 'Owner-Pass-123'})
        check('login ok (username not case sensitive)', st == 200 and d.get('ok') and len(o.cookie) == 64, (st, d))
        sc = hdr.get('Set-Cookie') or hdr.get('set-cookie') or ''
        check('cookie is HttpOnly + SameSite=Strict', 'HttpOnly' in sc and 'SameSite=Strict' in sc, sc)
        st, d, _ = o.call('owner/user/save', 'POST', {'id': 1, 'note': 'x'}, header=False)
        check('a change without the X-TD-Owner header is refused', st == 403, (st, d))
        st, d, _ = o.call('owner/dashboard')
        check('dashboard works when signed in', st == 200 and d['users'] == 0 and d['server']['database'] == 'sqlite', d)

        print('end users: registration modes')
        st, a = api.j('auth/register', 'POST', {'username': 'asha', 'password': 'Passw0rd!x', 'module': 'abap', 'display_name': 'Asha <b>X</b>'})
        check('open registration works', st == 200 and a.get('token'), a)
        tokA = a['token']
        st, d, _ = o.call('owner/settings/save', 'POST', {'registration': 'approval'})
        check('owner sets registration to approval', st == 200 and d['settings']['registration'] == 'approval', d)
        st, h = api.j('health')
        check('health tells apps that approval is needed', h.get('approval_required') is True and h.get('registration') is True, h)
        st, p1 = api.j('auth/register', 'POST', {'username': 'pending1', 'password': 'Passw0rd!x', 'module': 'mm'})
        check('approval mode: account created without a token', st == 200 and p1.get('pending') is True and 'token' not in p1 and p1.get('recovery_key'), p1)
        st, d = api.j('auth/login', 'POST', {'username': 'pending1', 'password': 'Passw0rd!x'})
        check('pending account cannot sign in', st == 403 and d.get('error') == 'account_pending', (st, d))
        st, d = api.j('auth/login', 'POST', {'username': 'pending1', 'password': 'wrong-password'})
        check('wrong password on a pending account still says bad_credentials', st == 401 and d.get('error') == 'bad_credentials', d)
        st, d, _ = o.call('owner/users', query='status=2')
        check('owner sees the pending account', d['total'] == 1 and d['users'][0]['username'] == 'pending1', d)
        pid = d['users'][0]['id']
        st, d, _ = o.call('owner/user/save', 'POST', {'id': pid, 'status': 1})
        check('owner approves', st == 200 and d['user']['status'] == 1, d)
        st, d = api.j('auth/login', 'POST', {'username': 'pending1', 'password': 'Passw0rd!x'})
        check('approved account signs in', st == 200 and d.get('token'), d)
        st, d, _ = o.call('owner/settings/save', 'POST', {'registration': 'closed'})
        st, d = api.j('auth/register', 'POST', {'username': 'late1', 'password': 'Passw0rd!x', 'module': 'mm'})
        check('closed registration', st == 403 and d.get('error') == 'registration_closed', d)
        st, d, _ = o.call('owner/settings/save', 'POST', {'registration': 'open', 'invite_code': 'sesame'})
        st, d = api.j('auth/register', 'POST', {'username': 'late2', 'password': 'Passw0rd!x', 'module': 'mm', 'invite': 'nope'})
        check('invite code set on the owner site is enforced', st == 403 and d.get('error') == 'bad_invite', d)
        st, d = api.j('auth/register', 'POST', {'username': 'late2', 'password': 'Passw0rd!x', 'module': 'mm', 'invite': 'sesame'})
        check('right invite code works', st == 200, d)
        o.call('owner/settings/save', 'POST', {'invite_code': ''})

        print('users: list, search, detail')
        st, d, _ = o.call('owner/users')
        check('list shows everyone', d['total'] == 3, d['total'])
        st, d, _ = o.call('owner/users', query='q=ASH')
        check('search is case insensitive', d['total'] == 1 and d['users'][0]['username'] == 'asha', d)
        st, d, _ = o.call('owner/users', query='module=mm')
        check('filter by module', d['total'] == 2, d['total'])
        aid = [u for u in o.call('owner/users', query='q=asha')[1]['users']][0]['id']
        st, d, _ = o.call('owner/user', query='id=%d' % aid)
        check('detail has devices and counts', d['user']['devices'] == 1 and len(d['devices']) == 1 and d['records'] == 0, d)
        check('display name is returned as plain text (the page shows it with textContent)', d['user']['display_name'] == 'Asha <b>X</b>', d['user'])

        print('switching a user off, expiry')
        st, d = api.j('sync/pull', token=tokA)
        check('active user syncs', st == 200, d)
        st, d, _ = o.call('owner/user/save', 'POST', {'id': aid, 'status': 0})
        st, d = api.j('sync/pull', token=tokA)
        check('blocked: the existing sign-in stops working (403 account_disabled)', st == 403 and d.get('error') == 'account_disabled', (st, d))
        st, d = api.j('auth/me', token=tokA)
        check('blocked: auth/me also says account_disabled', st == 403 and d.get('error') == 'account_disabled', d)
        st, d = api.j('auth/login', 'POST', {'username': 'asha', 'password': 'Passw0rd!x'})
        check('blocked: login refused with the reason', st == 403 and d.get('error') == 'account_disabled', d)
        st, d, _ = o.call('owner/user/save', 'POST', {'id': aid, 'status': 1})
        st, d = api.j('sync/pull', token=tokA)
        check('switched on again: the same sign-in works without logging in again', st == 200, (st, d))
        st, d, _ = o.call('owner/user/save', 'POST', {'id': aid, 'expires_at': '2020-01-31'})
        st, d = api.j('sync/pull', token=tokA)
        check('access date in the past: account_expired', st == 403 and d.get('error') == 'account_expired' and '2020-01-31' in d.get('message', ''), d)
        st, d = api.j('auth/login', 'POST', {'username': 'asha', 'password': 'Passw0rd!x'})
        check('expired: login refused', st == 403 and d.get('error') == 'account_expired', d)
        st, d, _ = o.call('owner/user/save', 'POST', {'id': aid, 'expires_at': '2099-12-31'})
        st, d = api.j('sync/pull', token=tokA)
        check('future access date works', st == 200, d)
        st, d, _ = o.call('owner/user/save', 'POST', {'id': aid, 'expires_at': 'tomorrow'})
        check('bad date rejected', st == 400, d)
        o.call('owner/user/save', 'POST', {'id': aid, 'expires_at': ''})

        print('permissions: uploads, storage, file size')
        body = b'x' * 200000
        st, d = api.j('files/put', 'POST', raw=body, token=tokA, query='rel=T-1/a.bin')
        check('upload works by default', st == 200, d)
        o.call('owner/user/save', 'POST', {'id': aid, 'can_upload': False})
        st, d = api.j('files/put', 'POST', raw=body, token=tokA, query='rel=T-1/b.bin')
        check('uploads switched off: 403 uploads_disabled', st == 403 and d.get('error') == 'uploads_disabled', (st, d))
        st, d = api.j('sync/push', 'POST', {'ops': [{'op': 'put', 't': 'tasks', 'id': '1', 'd': {'id': 1, 'title': 'still works'}}]}, token=tokA)
        check('rows still sync while uploads are off', st == 200, d)
        st, d = api.j('auth/me', token=tokA)
        check('auth/me tells the app about it', d['perms']['can_upload'] is False and d['perms']['quota_mb'] == 50, d)
        o.call('owner/user/save', 'POST', {'id': aid, 'can_upload': True, 'quota_mb': 1})
        st, d = api.j('files/put', 'POST', raw=b'y' * 900000, token=tokA, query='rel=T-1/c.bin')
        check('personal storage limit is enforced (quota 1 MB)', st == 413 and d.get('error') == 'quota_exceeded', (st, d))
        o.call('owner/user/save', 'POST', {'id': aid, 'quota_mb': 100, 'max_file_mb': 1})
        st, d = api.j('files/put', 'POST', raw=b'y' * 1100000, token=tokA, query='rel=T-1/d.bin')
        check('personal file size limit is enforced', st == 413 and d.get('error') == 'file_too_large', (st, d))
        st, d = api.j('sync/status', token=tokA)
        check('status shows the personal storage limit', d['quota_bytes'] == 100 * 1048576, d)
        o.call('owner/user/save', 'POST', {'id': aid, 'quota_mb': 0, 'max_file_mb': 0})
        st, d = api.j('auth/me', token=tokA)
        check('empty limit = server default again (file size also capped by PHP post_max_size)', d['perms']['quota_mb'] == 50 and 1 <= d['perms']['max_file_mb'] <= 20, d['perms'])
        st, d, _ = o.call('owner/user/save', 'POST', {'id': aid, 'quota_mb': -5})
        check('negative limit rejected', st == 400, d)

        print('changing the module')
        st, d, _ = o.call('owner/user/save', 'POST', {'id': aid, 'module': 'mm'})
        check('module change refused when the user already has data', st == 409 and d.get('error') == 'module_has_data', d)
        st, d, _ = o.call('owner/users', query='q=late2')
        lid = d['users'][0]['id']
        st, d, _ = o.call('owner/user/save', 'POST', {'id': lid, 'module': 'fico'})
        check('module change allowed on an empty account', st == 200 and d['user']['module'] == 'fico', d)
        st, d, _ = o.call('owner/user/save', 'POST', {'id': lid, 'module': 'sd'})
        check('module that is not enabled is refused', st == 400 and d.get('error') == 'bad_module', d)

        print('owner creates a user, temporary password, forced change')
        st, d, _ = o.call('owner/user/create', 'POST', {'username': 'meera', 'module': 'fico', 'display_name': 'Meera K'})
        check('owner creates a user with a generated password', st == 200 and d['generated'] and len(d['password']) == 10 and d['recovery_key'], d)
        tmpw, mid = d['password'], d['user']['id']
        st, d, _ = o.call('owner/user/create', 'POST', {'username': 'meera', 'module': 'fico'})
        check('duplicate username refused', st == 409, d)
        st, l = api.j('auth/login', 'POST', {'username': 'meera', 'password': tmpw, 'device': 'PC-M'})
        check('user signs in with the temporary password and is told to change it', st == 200 and l.get('must_change_password') is True, l)
        tokM = l['token']
        st, d = api.j('sync/pull', token=tokM)
        check('until then sync is refused (password_change_required)', st == 403 and d.get('error') == 'password_change_required', (st, d))
        st, d = api.j('auth/me', token=tokM)
        check('auth/me still works', st == 200 and d['perms']['must_change_password'] is True, d)
        st, d = api.j('auth/password', 'POST', {'old_password': tmpw, 'new_password': tmpw}, token=tokM)
        check('the temporary password cannot be reused', st == 400, d)
        st, d = api.j('auth/password', 'POST', {'old_password': tmpw, 'new_password': 'Fresh-Pass-77'}, token=tokM)
        check('password changed', st == 200, d)
        st, d = api.j('sync/pull', token=tokM)
        check('then everything works', st == 200, d)
        st, d = api.j('auth/login', 'POST', {'username': 'meera', 'password': 'Fresh-Pass-77'})
        check('new password works and no forced change any more', st == 200 and not d.get('must_change_password'), d)

        print('reset password / recovery key / devices')
        st, d, _ = o.call('owner/user/reset_password', 'POST', {'id': mid})
        newpw = d['password']
        check('owner resets the password', st == 200 and len(newpw) == 10, d)
        st, d = api.j('sync/pull', token=tokM)
        check('all devices of that user were signed out', st == 401, (st, d))
        st, d = api.j('auth/login', 'POST', {'username': 'meera', 'password': 'Fresh-Pass-77'})
        check('old password no longer works', st == 401, d)
        st, l = api.j('auth/login', 'POST', {'username': 'meera', 'password': newpw})
        check('new temporary password works and forces a change', st == 200 and l.get('must_change_password') is True, l)
        st, d, _ = o.call('owner/user/new_recovery', 'POST', {'id': mid})
        rk = d['recovery_key']
        check('owner issues a new recovery key', st == 200 and len(rk) == 24, d)
        st, d = api.j('auth/recover', 'POST', {'username': 'meera', 'recovery_key': rk, 'new_password': 'Another-Pass-9'})
        check('the new recovery key works', st == 200, d)
        st, d, _ = o.call('owner/user', query='id=%d' % mid)
        check('recovery also cleared the forced change', d['user']['must_change_pw'] is False, d['user'])
        api.j('auth/login', 'POST', {'username': 'meera', 'password': 'Another-Pass-9', 'device': 'D2'})
        api.j('auth/login', 'POST', {'username': 'meera', 'password': 'Another-Pass-9', 'device': 'D3'})
        st, d, _ = o.call('owner/user', query='id=%d' % mid)
        check('detail lists the devices', len(d['devices']) == 2, d['devices'])
        did = d['devices'][0]['id']
        st, d, _ = o.call('owner/user/signout', 'POST', {'id': mid, 'token_id': did})
        check('owner signs out one device', d['removed'] == 1, d)
        st, d, _ = o.call('owner/user/signout', 'POST', {'id': mid})
        check('owner signs out all devices', d['removed'] == 1, d)

        print('delete a user')
        st, d, _ = o.call('owner/user/delete', 'POST', {'id': mid, 'confirm': 'wrong'})
        check('delete needs the username typed', st == 400 and d.get('error') == 'confirm_needed', d)
        st, d, _ = o.call('owner/user/delete', 'POST', {'id': aid, 'confirm': 'asha'})
        check('delete removes the account', st == 200, d)
        check('and its stored files', not os.path.exists(os.path.join(storage, 'u%d' % aid)))
        st, d = api.j('sync/pull', token=tokA)
        check('deleted user token is dead', st == 401, (st, d))
        st, d, _ = o.call('owner/user', query='id=%d' % aid)
        check('deleted user is gone from the owner site', st == 404, d)

        print('settings: validation, updates, server address, maintenance')
        st, d, _ = o.call('owner/settings/save', 'POST', {'download_url': 'ftp://x'})
        check('download link must be https', st == 400, d)
        st, d, _ = o.call('owner/settings/save', 'POST', {'min_client': '2.0.0', 'latest_client': '1.5.0'})
        check('oldest allowed version cannot be newer than the latest', st == 400, d)
        st, d, _ = o.call('owner/settings/save', 'POST', {'latest_client': '1.5.0', 'min_client': '1.0.0', 'download_url': 'https://example.com/TaskDesk_Setup_1.5.0.exe', 'notice': 'New version ready'})
        st, h = api.j('health')
        check('health shows the new update info at once', h['latest_client'] == '1.5.0' and h['notice'] == 'New version ready' and h['download_url'].endswith('1.5.0.exe'), h)
        st, d, _ = o.call('owner/settings/save', 'POST', {'quota_mb': 10})
        check('quota below 50 MB refused', st == 400, d)
        st, d, _ = o.call('owner/settings/save', 'POST', {'modules': []})
        check('at least one module must stay enabled', st == 400, d)
        st, d, _ = o.call('owner/settings/save', 'POST', {'modules': ['abap', 'mm', 'sd']})
        st, h = api.j('health')
        check('modules list is changed from the site', h['modules'] == ['abap', 'mm', 'sd'], h)
        st, d, _ = o.call('owner/settings/save', 'POST', {'modules': ['abap', 'fico', 'mm', 'basis']})
        st, h = api.j('health')
        sid = h.get('server_id')
        check('health has a server_id and no announced address yet', len(sid) == 16 and h.get('api_url') == '', h)
        st, d, _ = o.call('owner/settings/save', 'POST', {'api_url': 'http://evil.example.com/api.php'})
        check('announced address must be https', st == 400, d)
        st, d, _ = o.call('owner/settings/save', 'POST', {'api_url': 'https://new.example.com/taskdesk/'})
        check('announced address must end with api.php', st == 400, d)
        st, d, _ = o.call('owner/settings/save', 'POST', {'api_url': 'https://new.example.com/taskdesk/api.php'})
        st, h = api.j('health')
        check('announced address reaches the apps through health', h['api_url'] == 'https://new.example.com/taskdesk/api.php' and h['server_id'] == sid, h)
        o.call('owner/settings/save', 'POST', {'api_url': ''})
        st, d, _ = o.call('owner/settings/save', 'POST', {'maintenance': True, 'maintenance_message': 'Back at 6 pm'})
        st, d = api.j('auth/login', 'POST', {'username': 'meera', 'password': 'x' * 10})
        check('maintenance: apps get 503 maintenance with the message', st == 503 and d.get('error') == 'maintenance' and d.get('message') == 'Back at 6 pm', (st, d))
        st, h = api.j('health')
        check('maintenance: health still answers and shows it', st == 200 and h['maintenance'] is True, h)
        st, d, _ = o.call('owner/dashboard')
        check('maintenance: the owner site keeps working', st == 200, d)
        o.call('owner/settings/save', 'POST', {'maintenance': False})
        st, d = api.j('auth/login', 'POST', {'username': 'meera', 'password': 'Another-Pass-9'})
        check('maintenance off: back to normal', st == 200, d)

        print('two-step sign-in (authenticator app)')
        st, d, _ = o.call('owner/totp/begin', 'POST', {'password': 'bad-bad-bad-1'})
        check('starting two-step needs the password', st == 403, d)
        st, d, _ = o.call('owner/totp/begin', 'POST', {'password': 'Owner-Pass-123'})
        secret = d['secret']
        check('secret and otpauth link are given', len(secret) == 32 and d['uri'].startswith('otpauth://totp/'), d)
        st, d, _ = o.call('owner/totp/enable', 'POST', {'code': '000000'})
        check('wrong code does not turn it on', st == 400, d)
        st, d, _ = o.call('owner/totp/enable', 'POST', {'code': totp(secret)})
        check('right code turns it on', st == 200, d)
        o2 = Owner(api)
        st, d, _ = o2.call('owner/login', 'POST', {'username': 'boss', 'password': 'Owner-Pass-123'})
        check('sign-in without a code asks for the code', st == 401 and d.get('error') == 'code_required', d)
        st, d, _ = o2.call('owner/login', 'POST', {'username': 'boss', 'password': 'Owner-Pass-123', 'code': '123456' if totp(secret) != '123456' else '654321'})
        check('sign-in with a wrong code fails', st == 401 and d.get('error') == 'bad_credentials', d)
        st, d, _ = o2.call('owner/login', 'POST', {'username': 'boss', 'password': 'Owner-Pass-123', 'code': totp(secret)})
        check('sign-in with the right code works', st == 200 and d.get('totp') is True, d)
        con = sqlite3.connect(os.path.join(tmp, 'main.sqlite'))
        stored = con.execute('select totp_secret from td_owners').fetchone()[0]
        con.close()
        check('the secret is not stored in plain text', secret not in stored and stored[:2] in ('g:', 'p:') and (stored[:2] == 'g:' or True), stored[:12])
        st, d, _ = o2.call('owner/totp/disable', 'POST', {'password': 'Owner-Pass-123', 'code': '000000' if totp(secret) != '000000' else '111111'})
        check('turning it off needs a valid code', st == 400, d)
        st, d, _ = o2.call('owner/totp/disable', 'POST', {'password': 'Owner-Pass-123', 'code': totp(secret)})
        check('turned off', st == 200, d)

        print('owner password, logout, brute force')
        st, d, _ = o.call('owner/password', 'POST', {'old_password': 'Owner-Pass-123', 'new_password': 'short'})
        check('owner password needs 10+ characters', st == 400, d)
        st, d, _ = o.call('owner/password', 'POST', {'old_password': 'Owner-Pass-123', 'new_password': 'Owner-Pass-456'})
        check('owner password changed', st == 200, d)
        st, d, _ = o2.call('owner/dashboard')
        check('other owner sessions are signed out by a password change', st == 401, d)
        st, d, _ = o.call('owner/logout', 'POST', {})
        st, d, _ = o.call('owner/dashboard')
        check('after logout the old cookie is dead', st == 401, d)
        o3 = Owner(api)
        for _ in range(6):
            o3.call('owner/login', 'POST', {'username': 'boss', 'password': 'bad-bad-bad-1'})
        st, d, _ = o3.call('owner/login', 'POST', {'username': 'boss', 'password': 'Owner-Pass-456'})
        check('owner login is rate limited (429), even with the right password', st == 429, (st, d))
        with open(os.path.join(storage, 'owner_reset.txt'), 'w') as f:
            f.write('boss\nBrand-New-Owner-1\n')
        o4 = Owner(api)
        st, d, _ = o4.call('owner/status')
        con = sqlite3.connect(os.path.join(tmp, 'main.sqlite'))
        con.execute("DELETE FROM td_attempts")
        con.commit()
        con.close()
        st, d, _ = o4.call('owner/login', 'POST', {'username': 'boss', 'password': 'Brand-New-Owner-1'})
        check('lost owner password: the reset file sets a new one', st == 200, d)

        print('audit trail')
        st, d, _ = o4.call('owner/audit', query='per=300')
        acts = {r['action'] for r in d['items']}
        check('audit has the important actions', {'owner_login', 'user_save', 'user_create', 'user_delete', 'settings_save', 'user_reset_password', 'owner_login_failed', 'totp_on', 'owner_reset_file'} <= acts, sorted(acts))
        st, d, _ = o4.call('owner/audit', query='q=asha')
        check('audit can be searched', len(d['items']) >= 2 and all('asha' in (r['target'] + r['actor'] + r['action']).lower() for r in d['items']), d)
        st, d, _ = o4.call('owner/audit', query='per=300')
        check('audit never contains passwords or recovery keys', not any(('Passw0rd' in json.dumps(r) or 'Fresh-Pass' in json.dumps(r) or tmpw in json.dumps(r)) for r in d['items']))

        print('upgrade of an older (version 1) database')
        site_v1 = os.path.join(tmp, 'v1')
        shutil.copytree(site, site_v1, ignore=shutil.ignore_patterns('config.php', 'storage', '*.done'))
        dbp = os.path.join(tmp, 'v1.sqlite')
        con = sqlite3.connect(dbp)
        for q in V1_DDL:
            con.execute(q)
        ph = subprocess.check_output(['php', '-r', 'echo password_hash("OldPass-123", PASSWORD_DEFAULT);']).decode()
        con.execute("INSERT INTO td_users(username,display_name,module,pass_hash,recovery_hash,rev,bytes_used,status,created_at) VALUES('olduser','Old User','mm',?,?,3,0,1,'2026-01-01 00:00:00')", (ph, 'a' * 64))
        con.commit()
        con.close()
        cfg = open(os.path.join(site, 'config.php')).read().replace(os.path.join(tmp, 'main.sqlite'), dbp).replace(os.path.join(tmp, 'main_storage'), os.path.join(tmp, 'v1_storage'))
        open(os.path.join(site_v1, 'config.php'), 'w').write(cfg)
        port1, p1p = start(site_v1, env)
        procs.append(p1p)
        api1 = Api(port1)
        st, h = api1.j('health')
        check('an old database is upgraded on the first request', st == 200 and len(h.get('server_id', '')) == 16, (st, h))
        con = sqlite3.connect(dbp)
        cols = [r[1] for r in con.execute('PRAGMA table_info(td_users)')]
        ver = con.execute("select v from td_settings where k='schema_version'").fetchone()[0]
        con.close()
        check('new columns and the version were added', all(c in cols for c in ('expires_at', 'quota_mb', 'max_file_mb', 'can_upload', 'must_change_pw', 'note', 'created_by')) and ver == '2', (cols, ver))
        st, l = api1.j('auth/login', 'POST', {'username': 'olduser', 'password': 'OldPass-123'})
        check('existing users keep working after the upgrade', st == 200 and l['user']['module'] == 'mm' and l['perms']['can_upload'] is True, l)
        st, h2 = api1.j('health')
        check('server_id stays the same', h2['server_id'] == h['server_id'])
        st, d = api1.j('owner/status')
        check('an upgraded server has no owner until the reset file is used', d.get('configured') is False, d)
        os.makedirs(os.path.join(tmp, 'v1_storage'), exist_ok=True)
        with open(os.path.join(tmp, 'v1_storage', 'owner_reset.txt'), 'w') as f:
            f.write('chief\nChief-Password-1\n')
        ow = Owner(api1)
        ow.call('owner/status')
        st, d, _ = ow.call('owner/login', 'POST', {'username': 'chief', 'password': 'Chief-Password-1'})
        check('the first owner of an upgraded server can be created with the file', st == 200, d)

    finally:
        for p in procs:
            try:
                p.send_signal(signal.SIGTERM)
                p.wait(timeout=5)
            except Exception:
                p.kill()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nRESULT: %d passed, %d failed' % (T.PASS, T.FAIL))
    return 1 if T.FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
