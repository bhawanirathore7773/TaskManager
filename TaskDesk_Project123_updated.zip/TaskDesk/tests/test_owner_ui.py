#!/usr/bin/env python3
"""Drives the owner site in a real (headless) Chromium. Saves screenshots to the folder given as argv[1]."""
import base64
import hashlib
import hmac
import os
import shutil
import struct
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import test_server as ts                      # noqa: E402
from playwright.sync_api import sync_playwright   # noqa: E402

check = ts.check


def totp(secret_b32):
    key = base64.b32decode(secret_b32.upper() + '=' * (-len(secret_b32) % 8))
    counter = int(time.time() // 30)
    h = hmac.new(key, struct.pack('>Q', counter), hashlib.sha1).digest()
    o = h[19] & 15
    n = ((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3]
    return '%06d' % (n % 1000000)


def main():
    shots = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix='tdownshots_')
    os.makedirs(shots, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix='tdownui_')
    php = None
    try:
        site = ts.make_site(tmp, 'cloud', {'quota_mb': 50, 'max_file_mb': 20})
        storage = os.path.join(tmp, 'cloud_storage')
        os.makedirs(storage, exist_ok=True)
        port = ts.free_port()
        php = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', site], cwd=site, env=dict(os.environ, PHP_CLI_SERVER_WORKERS='4'),
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        assert ts.wait_up(port)
        api = ts.Api(port)
        base = 'http://127.0.0.1:%d/owner/' % port
        errors = []
        with sync_playwright() as p:
            br = p.chromium.launch()
            ctx = br.new_context(viewport={'width': 1360, 'height': 800}, device_scale_factor=1)
            page = ctx.new_page()
            page.on('console', lambda m: errors.append('console: ' + m.text) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
            page.on('pageerror', lambda e: errors.append('pageerror: %s' % e))

            print('first visit: no owner yet')
            page.goto(base)
            page.wait_for_selector('#f-user')
            page.wait_for_selector('.msg.warn')
            check('the page explains how the first owner is created', 'owner_reset.txt' in page.inner_text('.msg.warn'))
            page.screenshot(path=os.path.join(shots, 'o01_first_visit.png'))
            with open(os.path.join(storage, 'owner_reset.txt'), 'w') as f:
                f.write('boss\nOwner-Pass-123\n')
            page.reload()
            page.wait_for_selector('#f-user')
            time.sleep(0.5)
            check('after the reset file the warning is gone', page.locator('.msg.warn').count() == 0)

            print('sign in')
            page.fill('#f-user', 'boss')
            page.fill('#f-pass', 'wrong-wrong-1')
            page.click('button[type=submit]')
            page.wait_for_selector('.msg.bad:not(.hidden)')
            check('wrong password shows an error', 'not correct' in page.inner_text('.msg.bad'))
            page.screenshot(path=os.path.join(shots, 'o02_login_error.png'))
            page.fill('#f-pass', 'Owner-Pass-123')
            page.click('button[type=submit]')
            page.wait_for_selector('.shell')
            check('signed in, dashboard is shown', page.inner_text('.topbar h1') == 'Dashboard' and 'boss' in page.inner_text('.rail-foot'))

            # a few users to look at
            for i, (u, m) in enumerate([('asha', 'abap'), ('meera', 'fico'), ('ravi', 'mm'), ('<script>x', 'mm')]):
                if u.startswith('<'):
                    continue
                api.j('auth/register', 'POST', {'username': u, 'password': 'Passw0rd!x', 'module': m, 'display_name': u.title() + ' Kumar'})
            api.j('auth/register', 'POST', {'username': 'xssuser', 'password': 'Passw0rd!x', 'module': 'mm', 'display_name': '<img src=x onerror=window.__pwned=1>'})
            page.click('a[data-r=dashboard]')
            page.reload()
            page.wait_for_selector('.stat')
            time.sleep(0.4)
            check('dashboard counts the users', page.locator('.stat .v').first.inner_text() == '4')
            page.screenshot(path=os.path.join(shots, 'o03_dashboard.png'))

            print('users')
            page.click('a[data-r=users]')
            page.wait_for_selector('tbody tr')
            check('four users listed', page.locator('tbody tr').count() == 4)
            check('a name that looks like HTML is shown as text and does nothing', page.evaluate('window.__pwned') is None and '<img src=x' in page.inner_text('tbody'))
            page.fill('input[type=search]', 'meer')
            time.sleep(0.7)
            check('search narrows the list', page.locator('tbody tr').count() == 1)
            page.fill('input[type=search]', '')
            time.sleep(0.7)
            page.screenshot(path=os.path.join(shots, 'o04_users.png'))

            page.click('text=Add user')
            page.wait_for_selector('dialog[open]')
            page.fill('dialog input >> nth=0', 'newbie')
            page.fill('dialog input >> nth=1', 'New Bie')
            page.select_option('dialog select', 'fico')
            page.screenshot(path=os.path.join(shots, 'o05_add_user.png'))
            page.click('dialog >> text=Create user')
            page.wait_for_selector('.cred')
            check('credentials are shown once', len(page.locator('.cred .r').all()) == 3 and 'newbie' in page.inner_text('.cred'))
            page.screenshot(path=os.path.join(shots, 'o06_credentials.png'))
            temp_pw = page.locator('.cred .r .v').nth(1).inner_text()
            page.click('dialog >> text=I have saved this')
            time.sleep(0.4)
            st, l = api.j('auth/login', 'POST', {'username': 'newbie', 'password': temp_pw})
            check('the shown temporary password really works and asks for a change', st == 200 and l.get('must_change_password') is True, l)

            page.click('tbody tr:has-text("Asha")')
            page.wait_for_selector('.drawer .body')
            time.sleep(0.4)
            page.screenshot(path=os.path.join(shots, 'o07_user_drawer.png'))
            page.click('.seg button:has-text("Blocked")')
            page.fill('.drawer input[type=number] >> nth=0', '25')
            page.uncheck('#u-up')
            page.click('.drawer footer >> text=Save changes')
            page.wait_for_selector('.toast')
            st, d = api.j('auth/login', 'POST', {'username': 'asha', 'password': 'Passw0rd!x'})
            check('blocking from the drawer takes effect at once', st == 403 and d.get('error') == 'account_disabled', d)
            st, d = api.j('auth/login', 'POST', {'username': 'ravi', 'password': 'Passw0rd!x'})
            token = d['token']
            page.click('.drawer header .x')
            time.sleep(0.3)
            check('status chip in the list shows Blocked', 'Blocked' in page.inner_text('tbody tr:has-text("Asha")'))
            page.select_option('select[aria-label=Status]', '0')
            time.sleep(0.6)
            check('status filter works', page.locator('tbody tr').count() == 1)
            page.select_option('select[aria-label=Status]', '')
            time.sleep(0.5)

            page.click('tbody tr:has-text("Ravi")')
            page.wait_for_selector('.drawer .body')
            page.click('.drawer >> text=Delete this user')
            page.wait_for_selector('dialog[open] input')
            page.fill('dialog input', 'ravi')
            page.click('dialog >> text=Delete forever')
            page.wait_for_selector('.toast')
            time.sleep(0.5)
            st, d = api.j('sync/pull', token=token)
            check('deleting from the site kills the user and their sign-in', st == 401, (st, d))

            print('settings')
            page.click('a[data-r=settings]')
            page.wait_for_selector('.radios')
            page.screenshot(path=os.path.join(shots, 'o08_settings.png'))
            page.check('input[name=reg][value=approval]')
            page.click('.card:has-text("New accounts") >> text=Save')
            page.wait_for_selector('.toast')
            st, h = api.j('health')
            check('registration mode is saved from the site', h.get('approval_required') is True, h)
            time.sleep(0.3)
            page.click('a[data-r=users]')
            time.sleep(0.4)
            st, d = api.j('auth/register', 'POST', {'username': 'waiter', 'password': 'Passw0rd!x', 'module': 'mm'})
            page.click('a[data-r=dashboard]')
            time.sleep(0.8)
            check('the Users menu shows how many wait for approval', page.locator('#pend-count').inner_text() == '1')
            page.click('a[data-r=settings]')
            page.wait_for_selector('.radios')
            page.check('input[name=reg][value=open]')
            page.click('.card:has-text("New accounts") >> text=Save')
            page.wait_for_selector('.toast')

            print('server and updates')
            page.click('a[data-r=server]')
            page.wait_for_selector('.addr')
            check('the address of this server is shown', page.inner_text('.addr code').endswith('/api.php'))
            page.fill('input[placeholder="https://new-domain.com/taskdesk/api.php"]', 'http://bad.example.com/api.php')
            page.click('text=Announce this address')
            page.wait_for_selector('dialog[open]')
            page.click('dialog >> text=Announce')
            page.wait_for_selector('.toast.bad')
            check('an insecure address is refused with a clear message', 'https' in page.inner_text('.toast'))
            page.screenshot(path=os.path.join(shots, 'o09_server.png'))
            page.fill('input[placeholder="1.1.0"]', '1.4.0')
            page.click('.card:has-text("Updates and messages") >> text=Save')
            page.wait_for_selector('.toast')
            st, h = api.j('health')
            check('the latest version set on the site is what apps see', h.get('latest_client') == '1.4.0', h)

            print('activity log and owner account')
            page.click('a[data-r=audit]')
            page.wait_for_selector('tbody tr')
            check('the log shows what happened', 'User deleted' in page.inner_text('tbody') and 'Owner signed in' in page.inner_text('tbody'))
            page.screenshot(path=os.path.join(shots, 'o10_audit.png'))
            page.click('a[data-r=account]')
            page.wait_for_selector('text=Set up two-step sign-in')
            page.fill('.card:has-text("Two-step") input[type=password]', 'Owner-Pass-123')
            page.click('text=Set up two-step sign-in')
            page.wait_for_selector('.addr code')
            secret = page.inner_text('.addr code').replace(' ', '')
            page.fill('.card:has-text("Two-step") input[inputmode=numeric]', totp(secret))
            page.click('.card:has-text("Two-step") >> text=Turn on')
            page.wait_for_selector('.msg.ok')
            check('two-step sign-in can be turned on from the page', 'On.' in page.inner_text('.msg.ok'))
            page.screenshot(path=os.path.join(shots, 'o11_account.png'))

            print('layout: header and menu stay in place')
            page.click('a[data-r=audit]')
            page.wait_for_selector('tbody tr')
            page.evaluate("""() => { const p = document.querySelector('.page-inner'); for (let i = 0; i < 60; i++) { const d = document.createElement('div'); d.style.height = '60px'; d.textContent = 'filler ' + i; p.appendChild(d); } }""")
            page.evaluate("document.querySelector('.page').scrollTop = 900")
            time.sleep(0.2)
            top = page.evaluate("document.querySelector('.topbar').getBoundingClientRect().top")
            rail = page.evaluate("document.querySelector('.rail').getBoundingClientRect().top")
            scrolled = page.evaluate("document.querySelector('.page').scrollTop")
            doc_scroll = page.evaluate("document.scrollingElement.scrollTop")
            check('the content scrolled', scrolled > 300, scrolled)
            check('header stays at the top, menu stays at the left', top == 0 and rail == 0 and doc_scroll == 0, (top, rail, doc_scroll))
            page.screenshot(path=os.path.join(shots, 'o12_scrolled.png'))

            print('sign out and the sign-in with a code')
            page.click('text=Sign out')
            page.wait_for_selector('#f-user')
            page.fill('#f-user', 'boss')
            page.fill('#f-pass', 'Owner-Pass-123')
            page.click('button[type=submit]')
            page.wait_for_selector('#f-code:visible')
            check('the code box appears when two-step sign-in is on', True)
            page.screenshot(path=os.path.join(shots, 'o13_code.png'))
            page.fill('#f-code', totp(secret))
            page.click('button[type=submit]')
            page.wait_for_selector('.shell')
            check('signing in with the code works', page.inner_text('.topbar h1') in ('Dashboard', 'Activity log'))

            print('narrow screen')
            page.set_viewport_size({'width': 390, 'height': 780})
            page.click('a[data-r=users]')
            time.sleep(0.6)
            overflow = page.evaluate("document.documentElement.scrollWidth > document.documentElement.clientWidth")
            check('no sideways scrolling of the whole page on a phone', not overflow)
            page.screenshot(path=os.path.join(shots, 'o14_phone.png'))
            br.close()
        check('no browser errors', not errors, errors[:3])
    finally:
        if php:
            php.terminate()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nRESULT: %d passed, %d failed' % (ts.PASS, ts.FAIL))
    return 1 if ts.FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
