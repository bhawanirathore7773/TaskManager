#!/usr/bin/env python3
"""
Browser test (headless Chromium) of everything a user SEES because of the owner site: pending approval, temporary password,
blocked / expired screens, My account, upload and maintenance notices, and the fixed header + sidebar in ABAP, FICO and MM.
Run:  NODE_PATH=$(npm root -g) python3 tests/test_ui_owner.py [screenshot-folder]
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import test_server as ts                      # noqa: E402
import test_e2e as e2e                        # noqa: E402
from test_owner import Owner                  # noqa: E402
from playwright.sync_api import sync_playwright   # noqa: E402

check = ts.check
ROUTES = ['dashboard', 'tasks', 'board', 'timeline', 'history']
BASIS_ROUTES = ['dashboard', 'tickets', 'people', 'stock', 'transports', 'team', 'checks', 'buy', 'reports', 'settings']


def settle(page, ms=700):
    time.sleep(ms / 1000.0)


def main():
    shots = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix='tdshots_')
    os.makedirs(shots, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix='tduio_')
    php = None
    pcs = []
    try:
        site = ts.make_site(tmp, 'cloud', {'quota_mb': 50, 'max_file_mb': 20, 'latest_client': '1.0.0'})
        storage = os.path.join(tmp, 'cloud_storage')
        os.makedirs(storage, exist_ok=True)
        port = ts.free_port()
        php = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', site], cwd=site, env=dict(os.environ, PHP_CLI_SERVER_WORKERS='6'),
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        assert ts.wait_up(port)
        capi = ts.Api(port)
        owner = Owner(capi)
        with open(os.path.join(storage, 'owner_reset.txt'), 'w') as f:
            f.write('boss\nOwner-Pass-123\n')
        owner.call('owner/status')
        st, d, _ = owner.call('owner/login', 'POST', {'username': 'boss', 'password': 'Owner-Pass-123'})
        assert st == 200, d
        cloud_url = 'http://127.0.0.1:%d/api.php' % port

        pc = e2e.Pc(tmp, 'pc', cloud_url, 'mm')
        pc.env.update(TD_ACCOUNT_CHECK='3', TD_HEALTH_CHECK='600')
        pcs.append(pc)
        pc.start_gate()
        errors = []
        with sync_playwright() as p:
            br = p.chromium.launch()
            ctx = br.new_context(viewport={'width': 1280, 'height': 760})
            page = ctx.new_page()
            page.on('console', lambda m: errors.append('console: ' + m.text) if m.type == 'error' and 'favicon' not in m.text and 'Failed to load resource' not in m.text else None)
            page.on('pageerror', lambda e: errors.append('pageerror: %s' % e))
            gate_url = 'http://127.0.0.1:%d/__enter?k=%s' % (pc.gate.port, pc.gate.key)

            print('login screen')
            page.goto(gate_url)
            page.wait_for_selector('#u')
            check('there is no Server button on the login screen', page.locator('#btn-server').count() == 0 and 'Server' not in page.inner_text('footer'), page.inner_text('footer'))
            page.screenshot(path=os.path.join(shots, 'o1_login.png'))

            print('approval needed')
            owner.call('owner/settings/save', 'POST', {'registration': 'approval'})
            page.reload()
            page.wait_for_selector('#u')
            page.click('text=Create an account')
            page.wait_for_selector('#m')
            check('the create account page says the owner approves new accounts', 'approves new accounts' in page.inner_text('#view'), page.inner_text('#view')[:200])
            page.fill('#n', 'Meera K')
            page.fill('#u', 'meera')
            page.fill('#p', 'Passw0rd!x')
            page.fill('#p2', 'Passw0rd!x')
            page.click('button[type=submit]')
            page.wait_for_selector('#key')
            check('the key page says "Account created" and offers "Back to sign in"', 'Account created' in page.inner_text('#view h2') and page.locator('text=Back to sign in').count() == 1)
            page.check('#saved')
            page.click('text=Back to sign in')
            page.wait_for_selector('#u')
            check('the sign in page explains the account waits for approval', 'approve' in page.inner_text('#view').lower(), page.inner_text('#view')[:300])
            page.screenshot(path=os.path.join(shots, 'o2_waiting_for_approval.png'))
            page.fill('#u', 'meera')
            page.fill('#p', 'Passw0rd!x')
            page.click('button[type=submit]')
            page.wait_for_selector('#form-msg', timeout=15000)
            check('trying to sign in shows the waiting message', 'approv' in page.inner_text('#form-msg').lower(), page.inner_text('#form-msg'))
            uid = owner.call('owner/users', query='q=meera')[1]['users'][0]['id']
            owner.call('owner/user/save', 'POST', {'id': uid, 'status': 1})
            owner.call('owner/settings/save', 'POST', {'registration': 'open'})

            print('temporary password')
            st, d, _ = owner.call('owner/user/reset_password', 'POST', {'id': uid})
            temp = d['password']
            page.fill('#u', 'meera')
            page.fill('#p', temp)
            page.click('button[type=submit]')
            page.wait_for_selector('#p2')
            check('a temporary password leads to "Choose your own password"', 'Choose your own password' in page.inner_text('#view h2') and 'Meera K' in page.inner_text('#view'), page.inner_text('#view')[:200])
            page.screenshot(path=os.path.join(shots, 'o3_choose_password.png'))
            page.fill('#p', 'abc')
            page.fill('#p2', 'abd')
            page.click('button[type=submit]')
            check('weak and different passwords are explained under the fields', 'At least 8' in page.inner_text('#p-err') and 'not the same' in page.inner_text('#p2-err'))
            page.fill('#p', 'My-Own-Pass-9')
            page.fill('#p2', 'My-Own-Pass-9')
            with page.expect_navigation(timeout=30000):
                page.click('button[type=submit]')
            page.wait_for_selector('#td-acct', timeout=30000)
            check('the MM workspace opens after choosing the password', 'Meera K' in page.inner_text('#td-acct'))
            settle(page, 1500)

            print('My account')
            page.click('.td-who')
            page.wait_for_selector('dialog.td-small[open]')
            txt = page.inner_text('dialog.td-small')
            check('My account shows name, username, edition and permissions', all(x in txt for x in ('Meera K', 'meera', 'MM Consultant', 'File uploads', 'Cloud files')) and 'http' not in txt, txt[:400])
            settle(page, 700)
            page.screenshot(path=os.path.join(shots, 'o4_my_account.png'))
            page.fill('#td-po', 'wrong-password')
            page.fill('#td-pn', 'Second-Pass-77')
            page.fill('#td-pn2', 'Second-Pass-77')
            page.click('dialog.td-small button:has-text("Change password")')
            page.wait_for_function("document.getElementById('td-pmsg').textContent.length > 0")
            check('a wrong current password is explained', 'not correct' in page.inner_text('#td-pmsg'), page.inner_text('#td-pmsg'))
            page.fill('#td-po', 'My-Own-Pass-9')
            page.click('dialog.td-small button:has-text("Change password")')
            page.wait_for_function("document.getElementById('td-pmsg').textContent.indexOf('changed') >= 0")
            check('the password change is confirmed', 'changed' in page.inner_text('#td-pmsg'))
            page.screenshot(path=os.path.join(shots, 'o5_password_changed.png'))
            page.click('dialog.td-small >> text=Close')

            print('switched off while using the app')
            owner.call('owner/user/save', 'POST', {'id': uid, 'status': 0})
            page.wait_for_selector('#td-block', timeout=30000)
            bt = page.inner_text('#td-block')
            check('a full screen message says why, and what to do', 'switched off' in bt.lower() and 'Check again' in bt and 'Sign out' in bt, bt)
            check('the sync chip says the account stopped', 'stopped' in page.inner_text('.td-chip').lower(), page.inner_text('.td-chip'))
            page.screenshot(path=os.path.join(shots, 'o6_blocked.png'))
            owner.call('owner/user/save', 'POST', {'id': uid, 'status': 1})
            page.click('#td-block button.td-primary')
            page.wait_for_selector('#td-block', state='detached', timeout=30000)
            check('after the owner switches the account on, "Check again" brings the app back', True)

            print('access end date')
            owner.call('owner/user/save', 'POST', {'id': uid, 'expires_at': '2020-01-31'})
            page.wait_for_selector('#td-block', timeout=30000)
            check('expired access has its own title', 'access has ended' in page.inner_text('#td-block').lower(), page.inner_text('#td-block'))
            page.screenshot(path=os.path.join(shots, 'o7_expired.png'))
            owner.call('owner/user/save', 'POST', {'id': uid, 'expires_at': ''})
            page.click('#td-block button.td-primary')
            page.wait_for_selector('#td-block', state='detached', timeout=30000)

            print('uploads switched off')
            owner.call('owner/user/save', 'POST', {'id': uid, 'can_upload': 0})
            page.wait_for_function("document.getElementById('td-banner') && document.getElementById('td-banner').textContent.indexOf('switched off') >= 0", timeout=30000)
            check('a quiet notice explains that files stay on this PC', 'stay on this PC' in page.inner_text('#td-banner'), page.inner_text('#td-banner'))
            page.screenshot(path=os.path.join(shots, 'o8_uploads_off.png'))
            owner.call('owner/user/save', 'POST', {'id': uid, 'can_upload': 1})
            page.wait_for_function("!document.getElementById('td-banner') || document.getElementById('td-banner').textContent.indexOf('switched off') < 0", timeout=30000)
            check('the notice goes away by itself', True)

            print('maintenance on the login screen')
            page.click('.td-btns >> text=Sign out')
            page.wait_for_selector('dialog.td-small[open]')
            with page.expect_navigation(timeout=20000):
                page.click('dialog.td-small >> button.td-primary')
            page.wait_for_selector('#u', timeout=20000)
            owner.call('owner/settings/save', 'POST', {'maintenance': True, 'maintenance_message': 'We are upgrading. Back at 6 pm.'})
            pc.gate.j('POST', '/api/refresh')                       # the app caches the server answer for 20 seconds
            page.reload()
            page.wait_for_selector('#u')
            check('the login screen shows the owner\'s maintenance message (before the update notice)', 'Back at 6 pm' in page.inner_text('#banner'), page.inner_text('#banner'))
            page.screenshot(path=os.path.join(shots, 'o9_maintenance_login.png'))
            owner.call('owner/settings/save', 'POST', {'maintenance': False})

            print('a switched-off account that tries to open the app')
            owner.call('owner/user/save', 'POST', {'id': uid, 'status': 0})
            page.reload()
            page.wait_for_selector('#u')
            page.fill('#u', 'meera')
            page.fill('#p', 'Second-Pass-77')
            page.click('button[type=submit]')
            page.wait_for_selector('#form-msg')
            check('sign in explains that the account is switched off', 'switched off' in page.inner_text('#form-msg').lower(), page.inner_text('#form-msg'))
            owner.call('owner/user/save', 'POST', {'id': uid, 'status': 1})
            ctx.close()

            print('header and sidebar stay fixed (ABAP, FICO, MM, BASIS)')
            for mid in ('abap', 'fico', 'mm', 'basis'):
                pcm = e2e.Pc(tmp, 'pc_' + mid, cloud_url, mid)
                pcs.append(pcm)
                pcm.start_gate()
                st, r = pcm.gate.j('POST', '/api/register', {'username': 'fix_' + mid, 'password': 'Passw0rd!x', 'module': mid, 'display_name': 'Fix ' + mid})
                assert st == 200, r
                pcm.attach(r['url'])
                if mid == 'basis':
                    pcm.mod.j('POST', '/api/demo')
                    for i in range(45):
                        pcm.mod.j('POST', '/api/tickets', {'title': 'Sample ticket number %d to make the page long' % i, 'plant': '1100', 'type': 'hardware'})
                else:
                    for i in range(45):
                        pcm.mod.j('POST', '/api/tasks', {'title': 'Sample task number %d to make the page long' % i})
                c2 = br.new_context(viewport={'width': 1280, 'height': 640})
                pg = c2.new_page()
                pg.on('pageerror', lambda e: errors.append('pageerror: %s' % e))
                pg.goto(pcm.mod_url)
                pg.wait_for_selector('#nav a')
                settle(pg, 1200)
                bad = []
                for rt in (BASIS_ROUTES if mid == 'basis' else ROUTES):
                    pg.evaluate("location.hash='#/%s'" % rt)
                    settle(pg, 600)
                    pg.mouse.move(900, 300)
                    pg.mouse.wheel(0, 900)
                    settle(pg, 400)
                    m = pg.evaluate("""() => {
                      const top = document.getElementById('top').getBoundingClientRect();
                      const nav = document.getElementById('nav').getBoundingClientRect();
                      const acct = document.getElementById('td-acct').getBoundingClientRect();
                      return {win: scrollY, top: top.top, topH: top.height, nav: nav.top, navB: nav.bottom, acctB: acct.bottom, h: innerHeight,
                              docOverflow: document.scrollingElement.scrollHeight - innerHeight};
                    }""")
                    if m['win'] != 0 or m['top'] != 0 or m['nav'] != 0 or m['docOverflow'] > 0 or m['acctB'] > m['h'] + 0.5 or m['navB'] > m['h'] + 0.5:
                        bad.append((rt, m))
                check('%s: header and sidebar do not move on any page while scrolling' % mid.upper(), not bad, bad)
                pg.evaluate("location.hash='#/dashboard'")
                settle(pg, 500)
                before = pg.evaluate("document.getElementById('view').scrollTop")
                pg.mouse.move(900, 300)
                pg.mouse.wheel(0, 600)
                settle(pg, 400)
                after = pg.evaluate("document.getElementById('view').scrollTop")
                check('%s: the content area is what scrolls' % mid.upper(), after > before, (before, after))
                pg.set_viewport_size({'width': 1100, 'height': 420})
                settle(pg, 500)
                m = pg.evaluate("() => { const a = document.getElementById('td-acct').getBoundingClientRect(); return {b: a.bottom, h: innerHeight, t: a.top}; }")
                check('%s: on a short window Sign out is still reachable' % mid.upper(), 0 <= m['t'] and m['b'] <= m['h'] + 0.5, m)
                pg.screenshot(path=os.path.join(shots, 'o10_fixed_%s.png' % mid))
                c2.close()
            br.close()
        check('no console or page errors', not errors, errors[:5])
    finally:
        for pc in pcs:
            pc.stop()
        if php and php.poll() is None:
            php.terminate()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nRESULT: %d passed, %d failed' % (ts.PASS, ts.FAIL))
    print('screenshots in', shots)
    return 1 if ts.FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
