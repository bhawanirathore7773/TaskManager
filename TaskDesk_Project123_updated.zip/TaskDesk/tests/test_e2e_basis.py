#!/usr/bin/env python3
"""
End-to-end test of the SAP BASIS module with the REAL PHP API and two separate "PCs".
Hameer's data (people, laptops, tickets, transports, purchases, renewals, checks, files, history) is made on PC 1,
synced to the cloud, and must come back complete on a brand new PC 2.
Run:  python3 tests/test_e2e_basis.py
"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import test_server as ts                                   # noqa: E402
import test_e2e as e2e                                     # noqa: E402

check = ts.check
wait_for = e2e.wait_for


def day(n):
    return time.strftime('%Y-%m-%d', time.localtime(time.time() + n * 86400))


def main():
    tmp = tempfile.mkdtemp(prefix='tdbasis_')
    php = None
    pcs = []
    try:
        site = ts.make_site(tmp, 'cloud', {'quota_mb': 50, 'max_file_mb': 20})
        port = ts.free_port()
        env = dict(os.environ, PHP_CLI_SERVER_WORKERS='6')
        php = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', site], cwd=site, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        assert ts.wait_up(port)
        cloud_url = 'http://127.0.0.1:%d/api.php' % port

        pc1 = e2e.Pc(tmp, 'pc1', cloud_url, 'basis')
        pc2 = e2e.Pc(tmp, 'pc2', cloud_url, 'basis')
        pcs += [pc1, pc2]
        pc1.start_gate()
        pc2.start_gate()

        print('register on PC 1 (BASIS installed)')
        st, d = pc1.gate.j('GET', '/api/state')
        check('BASIS is the installed edition and is offered', d['install_module'] == 'basis' and 'basis' in [m['id'] for m in d['modules']], d['modules'])
        st, r = pc1.gate.j('POST', '/api/register', {'username': 'hameer', 'password': 'Passw0rd!x', 'module': 'basis', 'display_name': 'Hameer Singh'})
        check('registered and BASIS workspace started', st == 200 and r['ok'] and r['url'] and r['user']['module'] == 'basis', r)
        pc1.attach(r['url'])
        m = pc1.mod
        st, meta = m.j('GET', '/api/meta')
        check('workspace answers with the three default plants', st == 200 and meta.get('app') == 'basis-task-manager' and [p['code'] for p in meta['settings']['plants']] == ['1100', '1200', '1600'], meta if st != 200 else '')

        print('Hameer fills the desk on PC 1')
        st, s = m.j('PUT', '/api/settings', {'manager': 'Hameer Singh', 'hod': 'IT Head', 'company': 'Mayur Uniquoters',
                                             'plants': [{'code': '1100', 'name': 'Jaitpura Plant'}, {'code': '1200', 'name': 'Dhodhsar Plant'}, {'code': '1600', 'name': 'Gavalior Plant'}]})
        check('settings saved', st == 200, s)
        ram = m.j('POST', '/api/team', {'name': 'Ramesh', 'plant': '1100', 'role': 'Hardware', 'mobile': '9811111111'})[1]
        sun = m.j('POST', '/api/team', {'name': 'Sunil', 'plant': '1100', 'role': 'SAP user'})[1]
        m.j('POST', '/api/team', {'name': 'Anil', 'plant': '1200'})
        lap = [m.j('POST', '/api/assets', {'kind': 'laptop', 'name': 'Dell 5420', 'serial': 'LAP%d' % i, 'plant': '1100', 'cond': 'good'})[1] for i in range(1, 4)]
        mouse = m.j('POST', '/api/assets', {'kind': 'mouse', 'name': 'Logitech', 'plant': '1100', 'qty': 5, 'min_qty': 2})[1]
        check('3 laptops and a counted mouse stock created', all(a.get('id') for a in lap) and mouse.get('id'), (lap, mouse))
        st, p1 = m.j('POST', '/api/people', {'name': 'Rakesh Gupta', 'emp_code': 'E101', 'plant': '1100', 'department': 'Stores', 'who': 'Ramesh',
                                             'issue': [{'asset_id': lap[0]['id']}, {'asset_id': mouse['id'], 'qty': 1}],
                                             'accounts': [{'kind': 'email', 'identifier': 'rakesh@mayur.test', 'system': 'Company mail'},
                                                          {'kind': 'sap', 'identifier': 'RAKESH.G', 'system': 'PRD 100'}],
                                             'buy': [{'kind': 'keyboard', 'qty': 1}]})
        check('joiner created with items, ids and a purchase request', st == 200 and len(p1['holdings']) == 2 and len(p1['accounts']) == 2, (st, p1 if st != 200 else ''))
        pid = p1['id']
        st, _ = m.j('POST', '/api/people/%d/note' % pid, {'text': 'Handed over in the stores office', 'who': 'Ramesh'})
        check('note on the person', st == 200)
        st, t1 = m.j('POST', '/api/tickets', {'title': 'Mouse not working', 'category': 'hardware', 'plant': '1100', 'priority': 'low', 'person_id': pid})
        check('ticket created', st == 200 and t1['id'], t1)
        m.j('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'assign', 'to': ram['id']})
        m.j('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'note', 'text': 'Will replace it from stock', 'who': 'Ramesh'})
        t2 = m.j('POST', '/api/tickets', {'title': 'Create SAP user for Stores', 'category': 'sap', 'plant': '1200', 'priority': 'high'})[1]
        blob_t = b'\x89PNG\r\n\x1a\n' + bytes(range(256)) * 20
        st, up_t, _h = m.call('POST', '/api/files?kind=ticket&id=%d&name=photo.png&category=photo' % t1['id'], raw=blob_t)
        up_t = json.loads(up_t.decode())
        check('photo attached to the ticket', st == 200 and up_t.get('rel_path'), up_t)
        blob_a = b'%PDF-1.4 invoice of the laptop ' + os.urandom(2000)
        st, up_a, _h = m.call('POST', '/api/files?kind=asset&id=%d&name=invoice.pdf&category=invoice' % lap[1]['id'], raw=blob_a)
        up_a = json.loads(up_a.decode())
        check('invoice attached to a laptop', st == 200 and up_a.get('rel_path'), up_a)
        blob_p = b'%PDF-1.4 signed handover slip ' + os.urandom(1500)
        st, up_p, _h = m.call('POST', '/api/files?kind=person&id=%d&name=handover.pdf&category=handover' % pid, raw=blob_p)
        up_p = json.loads(up_p.decode())
        check('signed handover slip attached to the person', st == 200 and up_p.get('rel_path'), up_p)
        r1 = m.j('POST', '/api/transports', {'tr_number': 'DEVK900001', 'description': 'ZGATE_OUT change', 'requested_by': 'Bhawani'})[1]
        m.j('POST', '/api/transports/%d/do' % r1['id'], {'do': 'qas'}) if r1.get('id') else None
        m.j('POST', '/api/renewals', {'title': 'CCTV AMC', 'kind': 'amc', 'plant': '1200', 'expires_on': day(10)})
        rt = m.j('POST', '/api/routines', {'title': 'SAP backup OK', 'frequency': 'daily', 'assigned_to': sun['id']})[1][0]
        m.j('POST', '/api/routines/%d/log' % rt['id'], {'status': 'ok', 'by_id': sun['id']})
        st, hist = m.j('GET', '/api/history?limit=500')
        n_hist = len(hist) if isinstance(hist, list) else -1
        check('history has entries', n_hist > 8, n_hist)
        counts1 = {k: len(m.j('GET', '/api/' + k)[1]) for k in ('tickets', 'people', 'assets', 'team', 'purchases', 'transports')}
        check('PC 1 counts look right', counts1['tickets'] == 2 and counts1['people'] == 1 and counts1['assets'] == 4 and counts1['team'] == 3 and counts1['purchases'] == 1 and counts1['transports'] == 1, counts1)
        check('PC 1 uploads everything', pc1.settled(60), pc1.state().get('sync'))

        print('cloud keeps everything in a generic table (no module-specific server schema)')
        tok = pc1.token()
        capi = ts.Api(port)
        st, d = capi.j('files/list', token=tok)
        rels = sorted(f['rel'] for f in d['files'])
        check('cloud has the three uploaded files', sum(1 for x in rels if x.endswith(('photo.png', 'invoice.pdf', 'handover.pdf'))) == 3, rels)

        print('sign out on PC 1 and sign in on PC 2 (new PC: restore everything)')
        st, d = pc1.mod.j('POST', '/__td/logout', {})
        check('PC 1 signed out', st == 200 and d['ok'], d)
        st, r2 = pc2.gate.j('POST', '/api/login', {'username': 'hameer', 'password': 'Passw0rd!x'})
        check('login on PC 2 opens the BASIS desk', st == 200 and r2['ok'] and r2['user']['module'] == 'basis', r2)
        pc2.attach(r2['url'])
        check('restore finishes on PC 2', pc2.settled(90), pc2.state().get('sync'))
        n = pc2.mod
        st, s2 = n.j('GET', '/api/settings')
        check('names and plants came along', s2.get('manager') == 'Hameer Singh' and [p['code'] for p in s2['plants']] == ['1100', '1200', '1600'], s2)
        counts2 = {k: len(n.j('GET', '/api/' + k)[1]) for k in ('tickets', 'people', 'assets', 'team', 'purchases', 'transports')}
        check('PC 2 has the same counts', counts2 == counts1, (counts1, counts2))
        st, pd = n.j('GET', '/api/people/%d' % pid)
        check('person has his laptop, mouse and ids on PC 2', st == 200 and len(pd['holdings']) == 2 and sorted(a['kind'] for a in pd['accounts']) == ['email', 'sap'], pd if st != 200 else {k: len(v) for k, v in pd.items() if isinstance(v, list)})
        hist_texts = ' | '.join(x.get('text', '') for x in pd.get('history', []))
        check('person history (issue and note) came along', 'Handed over in the stores office' in hist_texts, hist_texts[:300])
        st, td = n.j('GET', '/api/tickets/%d' % t1['id'])
        check('ticket keeps its assignee, notes and file', st == 200 and td.get('assigned_to') == ram['id'] and len(td.get('files', [])) == 1, {k: (len(v) if isinstance(v, list) else v) for k, v in td.items() if k in ('assigned_to', 'files', 'history')})
        st, ad = n.j('GET', '/api/assets/%d' % lap[1]['id'])
        check('laptop keeps its invoice', st == 200 and len(ad.get('files', [])) == 1, st)
        stock = n.j('GET', '/api/stock/summary')[1]
        check('stock summary works on PC 2', st == 200 and stock, stock)
        users = os.listdir(os.path.join(pc2.home, 'users'))
        data2 = os.path.join(pc2.home, 'users', users[0], 'data')
        check('ticket photo is byte-identical on PC 2', open(os.path.join(data2, 'files', up_t['rel_path']), 'rb').read() == blob_t)
        check('laptop invoice is byte-identical on PC 2', open(os.path.join(data2, 'files', up_a['rel_path']), 'rb').read() == blob_a)
        check('signed handover slip is byte-identical on PC 2', open(os.path.join(data2, 'files', up_p['rel_path']), 'rb').read() == blob_p)
        fid = ad['files'][0]['id']
        st, payload, h = n.call('GET', '/files/%d' % fid)
        check('file opens through the module on PC 2', st == 200 and payload == blob_a, st)
        # the folders of every record type are re-created like on PC 1
        c = sqlite3.connect(os.path.join(data2, 'taskmanager.db'))
        c.row_factory = sqlite3.Row
        missing = []
        for tbl in ('tickets', 'assets', 'people', 'transports', 'purchases', 'renewals'):
            for row in c.execute('SELECT folder FROM %s' % tbl).fetchall():
                if row['folder'] and not os.path.isdir(os.path.join(data2, 'files', row['folder'])):
                    missing.append((tbl, row['folder']))
        check('record folders were re-created on PC 2 (tickets, assets, people, transports, purchases, renewals)', not missing, missing[:5])
        check('local database is healthy', c.execute('PRAGMA integrity_check').fetchone()[0] == 'ok' and c.execute('PRAGMA foreign_key_check').fetchall() == [])
        check('restore left nothing waiting to upload (no echo)', c.execute('SELECT COUNT(*) FROM _td_outbox').fetchone()[0] == 0)
        c.close()
        st, rl = n.j('GET', '/api/routines')
        check('daily check and its OK log came along', st == 200 and len(rl) == 1 and rl[0]['state'] == 'ok', rl)
        st, rn = n.j('GET', '/api/renewals')
        check('renewal came along', st == 200 and len(rn['renewals']) == 1 and rn['renewals'][0]['title'] == 'CCTV AMC', rn)
        st, hist2 = n.j('GET', '/api/history?limit=500')
        check('whole history came along', isinstance(hist2, list) and len(hist2) == n_hist, (n_hist, len(hist2) if isinstance(hist2, list) else hist2))

        print('PC 2 keeps working: new records, the counted stock and the person drawer')
        st, p2 = n.j('POST', '/api/people', {'name': 'Neha Verma', 'emp_code': 'E102', 'plant': '1100', 'department': 'Accounts',
                                             'issue': [{'asset_id': lap[2]['id']}]})
        check('new joiner on PC 2 gets a fresh id (no clash)', st == 200 and p2['id'] != pid, (st, p2 if st != 200 else ''))
        st, t3 = n.j('POST', '/api/tickets', {'title': 'Made on PC 2', 'category': 'software', 'plant': '1600'})
        check('ticket made on PC 2', st == 200, t3)
        check('PC 2 uploads its changes', pc2.settled(60), pc2.state().get('sync'))

        print('two PCs signed in at once: PC 1 gets what PC 2 did')
        st, r1b = pc1.gate.j('POST', '/api/login', {'username': 'hameer', 'password': 'Passw0rd!x'})
        pc1.attach(r1b['url'])
        check('PC 1 signs in again (incremental)', pc1.settled(60), pc1.state().get('sync'))
        check('PC 1 receives the new person and ticket', wait_for(lambda: any(p['name'] == 'Neha Verma' for p in pc1.mod.j('GET', '/api/people')[1]) and
                                                                   any(t['title'] == 'Made on PC 2' for t in pc1.mod.j('GET', '/api/tickets')[1]), 40))
        st, _ = pc1.mod.j('POST', '/api/people/%d/note' % pid, {'text': 'Laptop bag also given', 'who': 'Ramesh'})
        pc1.settled(30)
        check('PC 2 receives a note written on PC 1', wait_for(lambda: 'Laptop bag also given' in json.dumps(pc2.mod.j('GET', '/api/people/%d' % pid)[1]), 40))
        st, _ = pc2.mod.j('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'status', 'status': 'done', 'resolution': 'Replaced the mouse from stock', 'who': 'Ramesh'})
        st, _ = pc2.mod.j('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'close', 'verify_note': 'Called the user'})
        pc2.settled(30)
        check('PC 1 sees the ticket closed on PC 2', wait_for(lambda: pc1.mod.j('GET', '/api/tickets/%d' % t1['id'])[1].get('status') == 'closed', 40), pc1.mod.j('GET', '/api/tickets/%d' % t1['id'])[1].get('status'))

        print('closing everything with the launcher')
        launcher = os.path.join(e2e.APP, 'launcher.pyw')
        subprocess.run([sys.executable, launcher, '--quit'], env=pc1.env, timeout=120)
        subprocess.run([sys.executable, launcher, '--quit'], env=pc2.env, timeout=120)
        check('both PCs closed cleanly', wait_for(lambda: pc1.gate_proc.poll() is not None and pc2.gate_proc.poll() is not None, 40))
    finally:
        for p in pcs:
            p.stop()
        if php and php.poll() is None:
            php.terminate()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nRESULT: %d passed, %d failed' % (ts.PASS, ts.FAIL))
    return 1 if ts.FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
