#!/usr/bin/env python3
"""
The owner site and the desktop app TOGETHER: every control the owner has must really change what a user's installed
app does. Real PHP server (SQLite), real gate + module processes of a simulated PC, the owner API as a browser would use it.

Run:  python3 tests/test_e2e_owner.py
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
APP = os.path.join(ROOT, 'client', 'app')
sys.path.insert(0, HERE)
import test_server as ts                                   # noqa: E402
from test_e2e import Pc, wait_for                          # noqa: E402
from test_owner import Owner                               # noqa: E402

check = ts.check


def php(site, port, env):
    p = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', site], cwd=site, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    assert ts.wait_up(port)
    return p


def sync_state(pc):
    return pc.state().get('sync', {})


def sync_now(pc):
    return pc.mod.j('POST', '/__td/sync')


def main():
    tmp = tempfile.mkdtemp(prefix='tdeo_')
    procs = []
    pcs = []
    env = dict(os.environ, PHP_CLI_SERVER_WORKERS='6')
    try:
        site = ts.make_site(tmp, 'cloud', {'quota_mb': 50, 'max_file_mb': 20})
        storage = os.path.join(tmp, 'cloud_storage')
        os.makedirs(storage, exist_ok=True)
        port = ts.free_port()
        procs.append(php(site, port, env))
        cloud_url = 'http://127.0.0.1:%d/api.php' % port
        capi = ts.Api(port)
        owner = Owner(capi)
        with open(os.path.join(storage, 'owner_reset.txt'), 'w') as f:
            f.write('boss\nOwner-Pass-123\n')
        st, d, _ = owner.call('owner/status')
        st, d, _ = owner.call('owner/login', 'POST', {'username': 'boss', 'password': 'Owner-Pass-123'})
        assert st == 200 and d.get('ok'), d

        pc1 = Pc(tmp, 'pc1', cloud_url, 'mm')
        pc1.env.update(TD_ACCOUNT_CHECK='3', TD_HEALTH_CHECK='3')
        pcs.append(pc1)
        pc1.start_gate()

        print('the app has no server setting: it knows its server like any installed software')
        st, d = pc1.gate.j('GET', '/api/state')
        check('state has no server address', st == 200 and 'server' not in d and d['configured'] is True, list(d.keys()))
        st, d = pc1.gate.j('POST', '/api/server', {'url': 'https://evil.example/api.php'})
        check('there is no way to change the server from the app', st != 200, (st, d))
        st, html, _ = pc1.gate.call('GET', '/')
        st2, js, _ = pc1.gate.call('GET', '/gate.js')
        check('login page has no Server button or dialog', b'btn-server' not in html and b'dlg-server' not in html and b'/api/server' not in js, st)

        print('approval mode: a new account waits for the owner')
        st, d, _ = owner.call('owner/settings/save', 'POST', {'registration': 'approval'})
        pc1.gate.j('POST', '/api/refresh')
        st, d = pc1.gate.j('GET', '/api/state')
        check('gate knows approval is needed', d['health']['approval_required'] is True and d['health']['registration'] is True, d['health'])
        st, d = pc1.gate.j('POST', '/api/register', {'username': 'meera', 'password': 'Passw0rd!x', 'module': 'mm', 'display_name': 'Meera K'})
        check('registration answers "pending" with a recovery key and opens nothing', st == 200 and d.get('pending') is True and len(d.get('recovery_key', '')) == 24 and 'url' not in d, d)
        st, s = pc1.gate.j('GET', '/api/state')
        check('no session after a pending registration', s['session'] is None)
        st, d = pc1.gate.j('POST', '/api/login', {'username': 'meera', 'password': 'Passw0rd!x'})
        check('sign in says the account is waiting for approval', st == 403 and d.get('error') == 'account_pending' and 'approv' in d.get('message', '').lower(), (st, d))
        st, d, _ = owner.call('owner/users', query='status=2')
        uid = d['users'][0]['id']
        owner.call('owner/user/save', 'POST', {'id': uid, 'status': 1})
        owner.call('owner/settings/save', 'POST', {'registration': 'open'})
        st, d = pc1.gate.j('POST', '/api/login', {'username': 'meera', 'password': 'Passw0rd!x'})
        check('after approval the same sign in works and opens the MM desk', st == 200 and d.get('url') and d['user']['module'] == 'mm', (st, d))
        pc1.attach(d['url'])
        check('first sync completes', pc1.settled(), sync_state(pc1))
        st, t = pc1.mod.j('POST', '/api/tasks', {'title': 'Task before the block'})
        check('a task can be created', st == 200, (st, str(t)[:100]))
        check('it syncs', pc1.settled())

        print('switch the account off while the app is running')
        owner.call('owner/user/save', 'POST', {'id': uid, 'status': 0})
        s = wait_for(lambda: sync_state(pc1).get('state') == 'blocked' and sync_state(pc1), 30)
        check('app goes into the blocked state with the reason', s and s['blocked_code'] == 'account_disabled' and 'switched off' in s['last_error'].lower(), s)
        st, d = pc1.mod.j('GET', '/api/tasks')
        check('the workspace itself refuses work while blocked', st == 403 and d.get('code') == 'account_blocked' and 'switched off' in d.get('error', ''), (st, d))
        st, d = pc1.mod.j('GET', '/__td/state')
        check('the shell can still read the state to show the message', st == 200 and d['sync']['state'] == 'blocked', st)
        owner.call('owner/user/save', 'POST', {'id': uid, 'status': 1})
        sync_now(pc1)
        check('switched on again: "Check again" restores everything', pc1.settled(20), sync_state(pc1))
        st, d = pc1.mod.j('GET', '/api/tasks')
        check('the data was never lost', st == 200 and [x['title'] for x in d] == ['Task before the block'], (st, str(d)[:200]))

        print('access end date')
        owner.call('owner/user/save', 'POST', {'id': uid, 'expires_at': '2020-01-31'})
        s = wait_for(lambda: sync_state(pc1).get('state') == 'blocked' and sync_state(pc1), 30)
        check('expired account is blocked with its own message', s and s['blocked_code'] == 'account_expired', s)
        owner.call('owner/user/save', 'POST', {'id': uid, 'expires_at': ''})
        sync_now(pc1)
        check('clearing the date restores access', pc1.settled(20), sync_state(pc1))

        print('the gate checks with the server when it opens a saved sign-in')
        st, d = pc1.gate.j('POST', '/api/open', {})
        check('open works for an allowed account', st == 200 and d.get('url'), (st, d))
        owner.call('owner/user/save', 'POST', {'id': uid, 'status': 0})
        st, d = pc1.gate.j('POST', '/api/open', {})
        check('open is refused for a switched-off account, with the reason', st == 400 and d.get('error') == 'account_disabled', (st, d))
        st, s = pc1.gate.j('GET', '/api/state')
        check('the saved sign-in was removed', s['session'] is None, s.get('session'))
        owner.call('owner/user/save', 'POST', {'id': uid, 'status': 1})
        st, d = pc1.gate.j('POST', '/api/login', {'username': 'meera', 'password': 'Passw0rd!x'})
        check('sign in again works and the local data is still there', st == 200, (st, d))
        pc1.attach(d['url'])
        check('settles', pc1.settled())
        st, d = pc1.mod.j('GET', '/api/tasks')
        check('task is still present after the whole block / unblock cycle', st == 200 and len(d) == 1, str(d)[:200])
        tid = d[0]['id']

        print('file uploads switched off')
        owner.call('owner/user/save', 'POST', {'id': uid, 'can_upload': 0})
        check('the app learns it (uploads_off)', wait_for(lambda: sync_state(pc1).get('uploads_off') is True, 30), sync_state(pc1))
        blob = os.urandom(40000)
        st, up = pc1.mod.j('POST', '/api/tasks/%d/files?name=notes.xlsx&category=excel' % tid, raw=blob)
        check('the user can still attach the file on this PC', st == 200, (st, up))
        rel = up['rel_path']
        sync_now(pc1)
        time.sleep(2)
        st, d = capi.j('files/list', token=pc1.token())
        check('but it is NOT uploaded to the cloud', st == 200 and rel not in [f['rel'] for f in d['files']], d)
        s = sync_state(pc1)
        check('no scary error: the app stays idle with a notice', s['state'] == 'idle' and s['uploads_off'] is True, s)
        owner.call('owner/user/save', 'POST', {'id': uid, 'can_upload': 1})
        check('uploads allowed again', wait_for(lambda: sync_state(pc1).get('uploads_off') is False, 30), sync_state(pc1))
        sync_now(pc1)

        def uploaded():
            st, d = capi.j('files/list', token=pc1.token())
            return st == 200 and rel in [f['rel'] for f in d['files']]
        check('the waiting file is now uploaded by itself', wait_for(uploaded, 40))

        print('temporary password from the owner')
        st, d, _ = owner.call('owner/user/reset_password', 'POST', {'id': uid})
        temp = d['password']
        check('owner gets a temporary password', st == 200 and len(temp) >= 8, d)
        check('the running app is asked to sign in again', wait_for(lambda: sync_state(pc1).get('state') == 'auth', 30), sync_state(pc1))
        st, d = pc1.gate.j('POST', '/api/signout', {})
        st, d = pc1.gate.j('POST', '/api/login', {'username': 'meera', 'password': 'Passw0rd!x'})
        check('the old password no longer works', st == 400 and 'not correct' in d.get('message', ''), (st, d))
        st, d = pc1.gate.j('POST', '/api/login', {'username': 'meera', 'password': temp})
        check('the temporary password asks for a new one first', st == 200 and d.get('must_change') is True and d.get('ticket') and 'url' not in d, d)
        ticket = d['ticket']
        st, s = pc1.gate.j('GET', '/api/state')
        check('nothing is opened or saved before the new password is chosen', s['session'] is None)
        st, d = pc1.gate.j('POST', '/api/change_password', {'ticket': ticket, 'new_password': 'short'})
        check('a weak new password is refused with a clear message', st == 400 and d.get('message'), (st, d))
        st, d = pc1.gate.j('POST', '/api/change_password', {'ticket': ticket, 'new_password': temp})
        check('the temporary password cannot be reused', st == 400, (st, d))
        st, d = pc1.gate.j('POST', '/api/change_password', {'ticket': 'f' * 32, 'new_password': 'Brand-New-Pass1'})
        check('an unknown ticket is refused', st == 400 and d.get('error') == 'ticket_expired', (st, d))
        st, d = pc1.gate.j('POST', '/api/change_password', {'ticket': ticket, 'new_password': 'Brand-New-Pass1'})
        check('choosing a new password signs in and opens the desk', st == 200 and d.get('url'), (st, d))
        pc1.attach(d['url'])
        check('settles', pc1.settled())
        st, d = capi.j('auth/login', 'POST', {'username': 'meera', 'password': 'Brand-New-Pass1'})
        check('the new password works for a later sign in', st == 200 and d.get('token'), (st, d))
        st, d, _ = owner.call('owner/user', query='id=%d' % uid)
        check('the owner site no longer lists a forced change', d['user'].get('must_change_pw') in (0, False, '0'), d['user'])

        print('change the password from inside the app (My account)')
        st, d = pc1.mod.j('POST', '/__td/password', {'old': 'wrong-password', 'new': 'Another-Pass-22'})
        check('wrong current password is refused', st in (400, 401) and not d.get('ok'), (st, d))
        st, d = pc1.mod.j('POST', '/__td/password', {'old': 'Brand-New-Pass1', 'new': 'Another-Pass-22'})
        check('password changes from inside the app', st == 200 and d.get('ok'), (st, d))
        check('the app keeps working (its own sign-in survived)', pc1.settled(20), sync_state(pc1))
        st, d = capi.j('auth/login', 'POST', {'username': 'meera', 'password': 'Another-Pass-22'})
        check('the server has the new password', st == 200, (st, d))

        print('maintenance mode')
        owner.call('owner/settings/save', 'POST', {'maintenance': True, 'maintenance_message': 'Back at 6 pm for a short upgrade.'})
        st, h = pc1.gate.j('POST', '/api/refresh')
        check('the login screen is told about maintenance', h['health']['maintenance'] is True and 'Back at 6 pm' in h['health']['maintenance_message'], h['health'])
        st, t2 = pc1.mod.j('POST', '/api/tasks', {'title': 'Written during maintenance'})
        check('the user keeps working (local first)', st == 200, (st, str(t2)[:100]))
        sync_now(pc1)
        s = wait_for(lambda: sync_state(pc1).get('maintenance') and sync_state(pc1), 20)
        check('the app says maintenance, not "error"', s and s['state'] == 'offline' and 'Back at 6 pm' in s['last_error'], s)
        owner.call('owner/settings/save', 'POST', {'maintenance': False})
        sync_now(pc1)
        check('after maintenance everything uploads', pc1.settled(30), sync_state(pc1))
        st, d = capi.j('sync/pull', token=pc1.token(), query='since=0&limit=2000')
        titles = [r['d'].get('title') for r in d.get('records', []) if r['t'] == 'tasks' and r['d']]
        if not titles:
            print('   debug pull:', st, str(d)[:300])
        check('the task written during maintenance reached the cloud', 'Written during maintenance' in titles, titles)

        print('the owner changes an account type (only possible while the account has no data)')
        pc2 = Pc(tmp, 'pc2', cloud_url, 'mm')
        pc2.env.update(TD_ACCOUNT_CHECK='3', TD_HEALTH_CHECK='3')
        pcs.append(pc2)
        pc2.start_gate()
        st, d = pc2.gate.j('POST', '/api/register', {'username': 'nilesh', 'password': 'Passw0rd!x', 'module': 'mm', 'display_name': 'Nilesh'})
        check('new account on PC 2', st == 200 and d.get('url'), (st, d))
        pc2.attach(d['url'])
        check('settles', pc2.settled())
        nid = owner.call('owner/users', query='q=nilesh')[1]['users'][0]['id']
        st, d, _ = owner.call('owner/user/save', 'POST', {'id': nid, 'module': 'abap'})
        check('owner switches it to ABAP', st == 200 and d['user']['module'] == 'abap', d)
        s = wait_for(lambda: sync_state(pc2).get('state') == 'blocked' and sync_state(pc2), 30)
        check('the running app asks the user to sign in again', s and s['blocked_code'] == 'module_changed', s)
        pc2.gate.j('POST', '/api/signout', {})
        st, d = pc2.gate.j('POST', '/api/login', {'username': 'nilesh', 'password': 'Passw0rd!x'})
        check('signing in opens the ABAP desk on a PC installed for MM', st == 200 and d['user']['module'] == 'abap', (st, d))
        pc2.attach(d['url'])
        st, d = pc2.mod.j('GET', '/__td/state')
        check('the workspace is ABAP now', d['module']['id'] == 'abap', d.get('module'))

        print('the owner moves the server to a new address')
        port_b = ts.free_port()
        procs.append(php(site, port_b, env))                  # the same code and database, reachable at a second address
        new_url = 'http://127.0.0.1:%d/api.php' % port_b
        st, d, _ = owner.call('owner/settings/save', 'POST', {'api_url': new_url})
        check('owner saves the new address', st == 200 and d['settings']['api_url'] == new_url, d)
        st, h = pc1.gate.j('POST', '/api/refresh')
        cfg_path = os.path.join(pc1.home, 'config.json')
        moved = wait_for(lambda: os.path.exists(cfg_path) and json.load(open(cfg_path)).get('cloud_url') == new_url, 20)
        check('the app followed to the new address (same server id)', moved, open(cfg_path).read() if os.path.exists(cfg_path) else 'no config')
        procs[0].terminate()
        procs[0].wait(timeout=10)                             # the old address goes away completely
        st, t3 = pc1.mod.j('POST', '/api/tasks', {'title': 'After the move'})
        sync_now(pc1)
        check('the running workspace keeps syncing through the new address', pc1.settled(40), sync_state(pc1))
        api_b = ts.Api(port_b)
        st, d = api_b.j('sync/pull', token=pc1.token(), query='since=0&limit=2000')
        check('the new task is on the new address', 'After the move' in json.dumps(d), st)

        print('a wrong or foreign address is never followed')
        owner_b = Owner(api_b)
        st, d, _ = owner_b.call('owner/login', 'POST', {'username': 'boss', 'password': 'Owner-Pass-123'})
        other = ts.make_site(tmp, 'other', {'quota_mb': 5})
        port_c = ts.free_port()
        procs.append(php(other, port_c, env))
        evil = 'http://127.0.0.1:%d/api.php' % port_c
        st, d, _ = owner_b.call('owner/settings/save', 'POST', {'api_url': evil})
        check('owner typed the address of a different server (mistake)', st == 200, d)
        pc1.gate.j('POST', '/api/refresh')
        time.sleep(5)
        cur = json.load(open(cfg_path)).get('cloud_url')
        check('the app stays with the real server (server ids differ)', cur == new_url, cur)
        check('and keeps working', pc1.settled(30), sync_state(pc1))

        print('only a safe address can be saved')
        st, d, _ = owner_b.call('owner/settings/save', 'POST', {'api_url': 'http://example.com/api.php'})
        check('plain http to a public host is refused', st == 400, (st, d))
        owner_b.call('owner/settings/save', 'POST', {'api_url': ''})

        print('install is not touched: a user config only counts for the build it was made for')
        sys.path.insert(0, APP)
        os.environ['TASKDESK_HOME'] = pc1.home
        os.environ['TASKDESK_CLOUD'] = cloud_url
        from tmcore import paths
        c = paths.config()
        check('moved address is used while the installed address is unchanged', c['cloud_url'] == new_url, c['cloud_url'])
        os.environ['TASKDESK_CLOUD'] = 'http://127.0.0.1:1/api.php'          # a newer build with another baked address
        c = paths.config()
        check('a newer build with its own address wins over an old saved move', c['cloud_url'] == 'http://127.0.0.1:1/api.php', c['cloud_url'])
    finally:
        for pc in pcs:
            pc.stop()
        for p in procs:
            if p.poll() is None:
                p.terminate()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nRESULT: %d passed, %d failed' % (ts.PASS, ts.FAIL))
    return 1 if ts.FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
