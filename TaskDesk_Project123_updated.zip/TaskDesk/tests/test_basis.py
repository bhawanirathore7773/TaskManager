#!/usr/bin/env python3
"""
Tests the BASIS module's local server (API + business rules) with a real HTTP server and a throw-away data folder.
Run:  python3 tests/test_basis.py
"""
import datetime as dt
import importlib.util
import io
import json
import os
import shutil
import sys
import tempfile
import threading
import urllib.error
import urllib.request
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PASS = FAIL = 0


def check(name, cond, extra=''):
    global PASS, FAIL
    if cond:
        PASS += 1
        print('  ok   ' + name)
    else:
        FAIL += 1
        print('  FAIL ' + name + ('  -> ' + str(extra) if extra != '' else ''))


def main():
    tmp = tempfile.mkdtemp(prefix='basis_test_')
    os.environ['BASIS_TM_DATA'] = os.path.join(tmp, 'data')
    spec = importlib.util.spec_from_file_location('basis_server', os.path.join(ROOT, 'client', 'app', 'modules', 'basis', 'server.py'))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.init_all()
    httpd = m.LocalServer(('127.0.0.1', 0), m.Handler)
    httpd.daemon_threads = True
    m.SERVER['httpd'] = httpd
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    base = 'http://127.0.0.1:%d' % httpd.server_address[1]

    def J(method, path, body=None, raw=None, headers=None):
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        req = urllib.request.Request(base + path, data=data, method=method)
        if method != 'GET':
            req.add_header('X-TM', '1')
        if raw is None and body is not None:
            req.add_header('Content-Type', 'application/json')
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                b = r.read()
                try:
                    return r.status, json.loads(b.decode())
                except Exception:
                    return r.status, b
        except urllib.error.HTTPError as e:
            b = e.read()
            try:
                return e.code, json.loads(b.decode())
            except Exception:
                return e.code, b

    def ok(r):
        return r[0] == 200

    def err(r):
        return (r[1].get('error') or '') if isinstance(r[1], dict) else ''
    day = lambda n: (dt.date.today() + dt.timedelta(days=n)).isoformat()
    ago = lambda h: (dt.datetime.now() - dt.timedelta(hours=h)).strftime('%Y-%m-%d %H:%M')

    print('basics')
    st, meta = J('GET', '/api/meta')
    check('meta works', st == 200 and meta['app'] == 'basis-task-manager' and len(meta['settings']['plants']) == 3, meta if st != 200 else '')
    check('three plants 1100 / 1200 / 1600 come by default', [p['code'] for p in meta['settings']['plants']] == ['1100', '1200', '1600'])
    check('manager name is set', meta['settings']['manager'] == 'Hameer Singh')
    req = urllib.request.Request(base + '/api/team', data=b'{"name":"x"}', method='POST')
    try:
        urllib.request.urlopen(req)
        refused = False
    except urllib.error.HTTPError as e:
        refused = e.code == 403
    check('write without X-TM header is refused (403)', refused)
    check('index.html is not served yet but the API says 404 for unknown paths', J('GET', '/api/nothing')[0] == 404)
    st, dash = J('GET', '/api/dashboard')
    check('empty dashboard says empty', st == 200 and dash['empty'] is True and dash['team_empty'] is True, (st, dash))

    print('team')
    check('team member needs a name', J('POST', '/api/team', {'name': ' '})[0] == 400)
    ram = J('POST', '/api/team', {'name': 'Ramesh', 'plant': '1100', 'role': 'Hardware', 'mobile': '9811111111'})[1]
    sun = J('POST', '/api/team', {'name': 'Sunil', 'plant': '1100', 'role': 'SAP user'})[1]
    ani = J('POST', '/api/team', {'name': 'Anil', 'plant': '1200'})[1]
    check('three team members', len(J('GET', '/api/team')[1]) == 3, J('GET', '/api/team'))

    print('people / joiner')
    st, p1 = J('POST', '/api/people', {'name': 'Neha Verma', 'emp_code': 'E1', 'department': 'Accounts', 'plant': '1100', 'email': 'neha@x.com'})
    check('person created with code, folder and joiner steps', st == 200 and p1['code'].startswith('P-') and len([s for s in p1['steps'] if s['flow'] == 'join']) == 8 and os.path.isdir(os.path.join(m.FILES_DIR, p1['folder'])), p1 if st != 200 else '')
    check('duplicate employee code refused', J('POST', '/api/people', {'name': 'Other', 'emp_code': 'e1'})[0] == 409)
    check('name is required', J('POST', '/api/people', {'name': ''})[0] == 400)
    st, pn = J('POST', '/api/people/%d/note' % p1['id'], {'text': 'Asked for a second monitor', 'who': 'Hameer Singh'})
    check('a note can be written on a person and shows in his history', st == 200 and any(h['kind'] == 'note' and 'second monitor' in h['text'] and h['who'] == 'Hameer Singh' for h in pn['history']), (st, pn if st != 200 else ''))
    check('an empty person note is refused', J('POST', '/api/people/%d/note' % p1['id'], {'text': '  '})[0] == 400)

    print('assets and stock')
    lap = [J('POST', '/api/assets', {'kind': 'laptop', 'name': 'Dell 5420', 'serial': 'S%d' % i, 'plant': '1100', 'cond': 'good'})[1] for i in range(1, 4)]
    check('three laptops in stock, code A-xxxx', all(a['status'] == 'in_stock' and a['code'].startswith('A-') for a in lap))
    check('duplicate serial refused', J('POST', '/api/assets', {'kind': 'laptop', 'serial': 's1'})[0] == 409)
    sug = J('GET', '/api/stock/suggest?kind=laptop&plant=1100')[1]
    check('stock suggestion: 3 free, all new', sug['free'] == 3 and sug['new'] == 3 and sug['used'] == 0)
    st, a1 = J('POST', '/api/assets/%d/op' % lap[0]['id'], {'op': 'issue', 'person_id': p1['id'], 'who': 'Ramesh'})
    check('laptop issued to Neha', st == 200 and a1['status'] == 'issued' and a1['holder'] == 'Neha Verma' and a1['times_issued'] == 1, a1)
    check('issuing again is refused', J('POST', '/api/assets/%d/op' % lap[0]['id'], {'op': 'issue', 'person_id': p1['id']})[0] == 409)
    check('issue needs a person or a place', J('POST', '/api/assets/%d/op' % lap[1]['id'], {'op': 'issue'})[0] == 400)
    pd = J('GET', '/api/people/%d' % p1['id'])[1]
    check('person sees what he holds', len(pd['holdings']) == 1 and pd['holdings'][0]['code'] == lap[0]['code'])
    check('step "Laptop / PC issued" ticked itself', any(s['done'] and 'Laptop' in s['text'] and s['done_by'] == 'automatic' for s in pd['steps']))
    check('person timeline has the issue', any(h['kind'] == 'issue' for h in pd['history']))
    st, a2 = J('POST', '/api/assets/%d/op' % lap[0]['id'], {'op': 'return', 'to': 'stock', 'cond': 'fair', 'note': 'Neha left the team'})
    check('laptop returned to stock as used', a2['status'] == 'in_stock' and a2['holder'] is None and a2['cond'] == 'fair' and a2['last_return'])
    sug = J('GET', '/api/stock/suggest?kind=laptop&plant=1100')[1]
    check('returned laptop is offered FIRST ("old before new")', sug['used'] == 1 and sug['items'][0]['id'] == lap[0]['id'] and 'Returned' in sug['items'][0]['advice'], sug['items'][0])
    check('new ones follow it', [i['is_new'] for i in sug['items']] == [False, True, True])
    st, a3 = J('POST', '/api/assets/%d/op' % lap[1]['id'], {'op': 'repair', 'note': 'keyboard'})
    check('repair', a3['status'] == 'repair')
    check('cannot issue a laptop that is in repair', J('POST', '/api/assets/%d/op' % lap[1]['id'], {'op': 'issue', 'person_id': p1['id']})[0] == 409)
    st, a3 = J('POST', '/api/assets/%d/op' % lap[1]['id'], {'op': 'repaired', 'cond': 'good'})
    check('back from repair to stock', a3['status'] == 'in_stock')
    J('POST', '/api/assets/%d/op' % lap[2]['id'], {'op': 'issue', 'person_id': p1['id']})
    check('cannot scrap an issued laptop', J('POST', '/api/assets/%d/op' % lap[2]['id'], {'op': 'scrap'})[0] == 409)
    st, sw = J('POST', '/api/assets/%d/op' % lap[2]['id'], {'op': 'swap', 'new_asset_id': lap[1]['id'], 'to': 'repair', 'note': 'screen broke'})
    pd = J('GET', '/api/people/%d' % p1['id'])[1]
    check('swap: old goes to repair, spare is with Neha', st == 200 and [h['code'] for h in pd['holdings'] if h['status'] == 'issued'] == [lap[1]['code']] and
          J('GET', '/api/assets/%d' % lap[2]['id'])[1]['status'] == 'repair', (st, pd['holdings']))
    # counted items
    mouse = J('POST', '/api/assets', {'kind': 'mouse', 'name': 'Logitech', 'plant': '1100', 'qty': 5, 'min_qty': 2})[1]
    check('mouse is a counted item with 5 in stock', mouse['tracked'] == 0 and mouse['qty'] == 5 and mouse['qty_free'] == 5)
    check('cannot issue more than in stock', J('POST', '/api/assets/%d/op' % mouse['id'], {'op': 'issue', 'person_id': p1['id'], 'qty': 6})[0] == 409)
    st, mm = J('POST', '/api/assets/%d/op' % mouse['id'], {'op': 'issue', 'person_id': p1['id'], 'qty': 2})
    check('2 mice issued, 3 left', mm['qty_free'] == 3 and mm['holders'][0]['qty'] == 2)
    check('cannot return more than was issued', J('POST', '/api/assets/%d/op' % mouse['id'], {'op': 'return', 'person_id': p1['id'], 'qty': 3})[0] == 409)
    st, mm = J('POST', '/api/assets/%d/op' % mouse['id'], {'op': 'return', 'person_id': p1['id'], 'qty': 1, 'to': 'stock'})
    check('1 mouse returned', mm['qty_free'] == 4 and mm['holders'][0]['qty'] == 1)
    st, mm = J('POST', '/api/assets/%d/op' % mouse['id'], {'op': 'restock', 'qty': 10})
    check('restock adds to total and free', mm['qty'] == 15 and mm['qty_free'] == 14)
    pd = J('GET', '/api/people/%d' % p1['id'])[1]
    check('person holds 1 mouse (counted) + laptop', any(h['qty'] == 1 and not h['tracked'] for h in pd['holdings']))
    pc = J('POST', '/api/assets', {'kind': 'desktop', 'name': 'HP shop-floor PC', 'serial': 'SF1', 'plant': '1100'})[1]
    st, pc = J('POST', '/api/assets/%d/op' % pc['id'], {'op': 'issue', 'location': 'Coating line 2'})
    check('PC installed at a place (operators share it)', st == 200 and pc['status'] == 'deployed' and pc['location'] == 'Coating line 2')
    summ = J('GET', '/api/stock/summary')[1]
    lk = [k for k in summ if k['kind'] == 'laptop'][0]
    check('stock summary counts laptops (3 total, 1 issued, 1 in stock, 1 repair)', lk['total'] == 3 and lk['issued'] == 1 and lk['in_stock'] == 1 and lk['repair'] == 1, lk)
    check('asset with history cannot be deleted', J('DELETE', '/api/assets/%d' % lap[0]['id'])[0] == 409)
    fresh = J('POST', '/api/assets', {'kind': 'monitor', 'name': 'x'})[1]
    check('asset entered by mistake can be deleted', J('DELETE', '/api/assets/%d' % fresh['id'])[0] == 200)

    print('accounts')
    st, ac = J('POST', '/api/accounts', {'person_id': p1['id'], 'kind': 'sap', 'identifier': 'NEHA.V', 'system': 'PRD 100', 'roles': 'FI_AP', 'valid_to': day(5)})
    check('SAP user recorded', st == 200 and ac['status'] == 'active')
    check('same SAP user twice refused', J('POST', '/api/accounts', {'person_id': p1['id'], 'kind': 'sap', 'identifier': 'neha.v', 'system': 'prd 100'})[0] == 409)
    check('account needs an owner', J('POST', '/api/accounts', {'kind': 'email', 'identifier': 'a@b.c'})[0] == 400)
    check('shared account (no employee) is possible with an owner name', J('POST', '/api/accounts', {'kind': 'email', 'identifier': 'plant1@x.com', 'owner_name': 'Plant 1 mail'})[0] == 200)
    pd = J('GET', '/api/people/%d' % p1['id'])[1]
    check('SAP step ticked itself', any(s['done'] and 'SAP' in s['text'] for s in pd['steps']))
    st, ac = J('PUT', '/api/accounts/%d' % ac['id'], {'status': 'locked'})
    check('SAP user locked', ac['status'] == 'locked')
    pd = J('GET', '/api/people/%d' % p1['id'])[1]
    check('lock is in the person history', any('locked' in h['text'] for h in pd['history'] if h['kind'] == 'account'))

    print('leaver')
    st, lv = J('POST', '/api/people/%d/leave' % p1['id'], {'left_on': day(0)})
    check('marked as left; pending items listed', st == 200 and lv['status'] == 'left' and len(lv['pending']['held']) >= 2 and len(lv['pending']['accounts']) == 1, lv.get('pending'))
    check('leave steps were created', len([s for s in lv['steps'] if s['flow'] == 'leave']) == 7)
    plist = J('GET', '/api/people')[1]
    check('leaver_pending flag set', [p for p in plist if p['id'] == p1['id']][0]['leaver_pending'] is True)
    dash = J('GET', '/api/dashboard')[1]
    check('dashboard warns about the leaver', any(g['key'] == 'leavers' for g in dash['attention']))
    check('cannot issue to a leaver', J('POST', '/api/assets/%d/op' % lap[0]['id'], {'op': 'issue', 'person_id': p1['id']})[0] == 409)
    check('cannot create a new account for a leaver', J('POST', '/api/accounts', {'person_id': p1['id'], 'kind': 'email', 'identifier': 'zz@x.com'})[0] == 409)
    check('badge on People shows 1', J('GET', '/api/meta')[1]['badges']['people'] == 1)
    for h in J('GET', '/api/people/%d' % p1['id'])[1]['holdings']:
        J('POST', '/api/assets/%d/op' % h['asset_id'], {'op': 'return', 'to': 'stock', 'person_id': p1['id'], 'qty': h['qty']})
    J('PUT', '/api/accounts/%d' % ac['id'], {'status': 'deleted'})
    pd = J('GET', '/api/people/%d' % p1['id'])[1]
    check('after returning everything nothing is pending', pd['leaver_pending'] is False and not pd['holdings'])
    check('leave steps for items and SAP ticked automatically', any(s['done'] and s['flow'] == 'leave' and 'collected' in s['text'] for s in pd['steps']) and any(s['done'] and s['flow'] == 'leave' and 'SAP' in s['text'] for s in pd['steps']), [(s['text'], s['done']) for s in pd['steps'] if s['flow'] == 'leave'])
    check('person with history cannot be deleted', J('DELETE', '/api/people/%d' % p1['id'])[0] == 409)
    check('badge cleared', J('GET', '/api/meta')[1]['badges']['people'] == 0)

    print('joiner in one go (person + items + ids + purchase for what is missing)')
    suggest = J('GET', '/api/stock/suggest?kind=laptop&plant=1100')[1]
    st, p2 = J('POST', '/api/people', {'name': 'Rakesh G', 'emp_code': 'E2', 'plant': '1100', 'department': 'Stores', 'who': 'Ramesh',
                                       'issue': [{'asset_id': suggest['items'][0]['id']}, {'asset_id': mouse['id'], 'qty': 1}],
                                       'accounts': [{'kind': 'email', 'identifier': 'rakesh@x.com', 'system': 'Company mail'}, {'kind': 'sap', 'identifier': 'RAKESH.G', 'system': 'PRD 100'}],
                                       'buy': [{'kind': 'keyboard', 'qty': 1}]})
    check('joiner created with items, accounts and a purchase request', st == 200 and len(p2['holdings']) == 2 and len(p2['accounts']) == 2, (st, p2 if st != 200 else ''))
    done = [s['text'] for s in p2['steps'] if s['flow'] == 'join' and s['done']]
    check('joiner steps ticked: laptop, mouse, mail id, SAP', len(done) >= 4, done)
    buys = J('GET', '/api/purchases')[1]
    check('purchase request exists for the joiner', len(buys) == 1 and buys[0]['person_name'] == 'Rakesh G' and buys[0]['kind'] == 'keyboard')
    check('joiner flow is atomic: error rolls everything back', J('POST', '/api/people', {'name': 'Bad Joiner', 'emp_code': 'E9', 'issue': [{'asset_id': 99999}]})[0] == 404 and
          not [p for p in J('GET', '/api/people')[1] if p['name'] == 'Bad Joiner'])

    print('tickets')
    check('ticket needs a title', J('POST', '/api/tickets', {'title': ''})[0] == 400)
    st, t1 = J('POST', '/api/tickets', {'title': 'Mouse not working', 'category': 'hardware', 'plant': '1100', 'priority': 'low', 'person_id': p2['id']})
    check('ticket created: code, SLA due, requester from employee', st == 200 and t1['code'].startswith('T-') and t1['requester'] == 'Rakesh G' and t1['status'] == 'new' and t1['due_at'], t1 if st != 200 else '')
    st, t2 = J('POST', '/api/tickets', {'title': 'SAP FB60 error', 'category': 'sap', 'plant': '1200', 'priority': 'critical', 'assigned_to': sun['id'], 'received_at': ago(30), 'due_at': ago(26)})
    check('assigned at creation -> status Assigned, and it is overdue', t2['status'] == 'assigned' and t2['assignee'] == 'Sunil' and t2['overdue'] is True)
    st, t3 = J('POST', '/api/tickets', {'title': 'Wifi password', 'category': 'network', 'solved': True, 'resolution': 'Gave the new password'})
    check('already-solved ticket is logged in one step', t3['status'] == 'closed' and t3['resolution'])
    check('solved ticket needs the solution text', J('POST', '/api/tickets', {'title': 'x', 'solved': True})[0] == 400)
    st, t1 = J('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'assign', 'to': ram['id']})
    check('assign', t1['status'] == 'assigned' and t1['assignee'] == 'Ramesh')
    st, t1 = J('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'status', 'status': 'progress', 'who': 'Ramesh'})
    check('progress sets started_at', t1['status'] == 'progress' and t1['started_at'])
    st, t1 = J('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'status', 'status': 'waiting', 'waiting_for': 'new mouse from stock', 'follow_up_on': day(0)})
    check('waiting with reason and follow-up date', t1['status'] == 'waiting' and t1['waiting_for'] and t1['follow_due'] is True)
    st, t1 = J('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'status', 'status': 'done', 'resolution': 'Replaced the mouse'})
    check('team marks done -> waits for the manager\'s check', t1['status'] == 'done' and t1['done_at'])
    dash = J('GET', '/api/dashboard')[1]
    check('dashboard: one ticket to check, one overdue, one unassigned? (none)', dash['kpi']['to_check'] == 1 and dash['kpi']['overdue'] == 1, dash['kpi'])
    check('closing needs the resolution', J('POST', '/api/tickets/%d/do' % t2['id'], {'do': 'close'})[0] == 400)
    st, t1 = J('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'close', 'verify_note': 'Called user'})
    check('closed after check', t1['status'] == 'closed' and t1['closed_at'] and t1['sla_met'] is True and t1['age_hours'] is not None)
    st, t1 = J('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'reopen', 'note': 'comes again'})
    check('re-open', t1['status'] == 'progress')
    check('note needs text', J('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'note'})[0] == 400)
    st, t1 = J('POST', '/api/tickets/%d/do' % t1['id'], {'do': 'note', 'text': 'Ramesh: tried another mouse', 'who': 'Ramesh'})
    check('team note kept with who wrote it', t1['history'][0]['who'] == 'Ramesh' and t1['history'][0]['kind'] == 'note')
    st, t1 = J('PUT', '/api/tickets/%d' % t1['id'], {'priority': 'high'})
    check('edit is written to the history with old -> new', any('Priority' in h['text'] and 'high' in h['text'] for h in t1['history']))
    check('person timeline shows his ticket history', any(h['ticket_id'] == t1['id'] for h in J('GET', '/api/people/%d' % p2['id'])[1]['history']))
    st, t4 = J('POST', '/api/tickets', {'title': 'Laptop dead', 'category': 'hardware', 'asset_id': lap[1]['id'], 'person_id': p2['id']})
    ad = J('GET', '/api/assets/%d' % lap[1]['id'])[1]
    check('ticket is on the asset (repair history of the laptop)', len(ad['tickets']) == 1 and ad['n_open_tickets'] == 1)
    check('related tickets of the same employee shown', len(J('GET', '/api/tickets/%d' % t4['id'])[1]['related']) >= 1)
    check('cancel', J('POST', '/api/tickets/%d/do' % t4['id'], {'do': 'cancel', 'note': 'duplicate'})[1]['status'] == 'cancelled')
    check('cancelled ticket cannot get a new assignee', J('POST', '/api/tickets/%d/do' % t4['id'], {'do': 'assign', 'to': ram['id']})[0] == 409)
    check('unknown action', J('POST', '/api/tickets/%d/do' % t4['id'], {'do': 'dance'})[0] == 400)
    check('unknown team member refused', J('POST', '/api/tickets/%d/do' % t2['id'], {'do': 'assign', 'to': 9999})[0] == 400)
    st, t2 = J('POST', '/api/tickets/%d/do' % t2['id'], {'do': 'assign', 'to': 0})
    check('assigned to the manager himself (0)', t2['assignee'] == 'Hameer Singh')
    st, t2 = J('POST', '/api/tickets/%d/do' % t2['id'], {'do': 'assign', 'to': None})
    check('taken back -> unassigned and New', t2['status'] == 'new' and t2['assigned_to'] is None)
    check('sap_user request type is kept only for SAP user tickets', J('POST', '/api/tickets', {'title': 'Create user', 'category': 'sap_user', 'req_type': 'create'})[1]['req_type'] == 'create' and
          J('POST', '/api/tickets', {'title': 'x', 'category': 'hardware', 'req_type': 'create'})[1]['req_type'] == '')
    check('delete ticket', J('DELETE', '/api/tickets/%d' % t4['id'])[0] == 200 and J('GET', '/api/tickets/%d' % t4['id'])[0] == 404)
    check('invalid date refused', J('POST', '/api/tickets', {'title': 'x', 'due_at': 'tomorrow'})[0] == 400)
    check('invalid category refused', J('POST', '/api/tickets', {'title': 'x', 'category': 'banana'})[0] == 400)

    print('transports')
    st, r1 = J('POST', '/api/transports', {'tr_number': 'devk900001', 'description': 'ZGATE_OUT change', 'requested_by': 'Bhawani'})
    check('TR requested; number upper-cased', st == 200 and r1['tr_number'] == 'DEVK900001' and r1['status'] == 'requested')
    check('same TR number twice refused', J('POST', '/api/transports', {'tr_number': 'DEVK900001', 'description': 'again'})[0] == 409)
    check('cannot go to PRD without approval', J('POST', '/api/transports/%d/do' % r1['id'], {'do': 'prd', 'by': 'Hameer'})[0] == 409)
    st, r1 = J('POST', '/api/transports/%d/do' % r1['id'], {'do': 'qas', 'by': 'Hameer'})
    check('moved to QAS', r1['status'] == 'qas' and r1['qas_on'])
    check('approval needs a name', J('POST', '/api/transports/%d/do' % r1['id'], {'do': 'approve'})[0] == 400)
    st, r1 = J('POST', '/api/transports/%d/do' % r1['id'], {'do': 'approve', 'approver': 'HOD'})
    check('approved', r1['status'] == 'approved' and r1['approved_on'] and r1['approver'] == 'HOD')
    dash = J('GET', '/api/dashboard')[1]
    check('dashboard: approved TR is ready for production', any(g['key'] == 'tr_ready' for g in dash['attention']))
    st, r1 = J('POST', '/api/transports/%d/do' % r1['id'], {'do': 'prd', 'by': 'Hameer', 'rc': '0'})
    check('moved to production', r1['status'] == 'prd' and r1['prd_on'] and r1['rc'] == '0')
    check('moved TR cannot be moved again', J('POST', '/api/transports/%d/do' % r1['id'], {'do': 'prd'})[0] == 409)
    check('moved TR cannot be deleted', J('DELETE', '/api/transports/%d' % r1['id'])[0] == 409)
    r2 = J('POST', '/api/transports', {'tr_number': 'DEVK900002', 'description': 'Another'})[1]
    J('POST', '/api/transports/%d/do' % r2['id'], {'do': 'approve', 'approver': 'HOD'})
    st, r2 = J('POST', '/api/transports/%d/do' % r2['id'], {'do': 'prd', 'rc': '8'})
    check('return code 8 -> Failed, not Moved', r2['status'] == 'failed')
    check('failed TR can be re-opened', J('POST', '/api/transports/%d/do' % r2['id'], {'do': 'reopen'})[1]['status'] == 'approved')
    J('PUT', '/api/settings', {'tr_need_approval': '0'})
    r3 = J('POST', '/api/transports', {'tr_number': 'DEVK900003', 'description': 'No approval rule'})[1]
    check('with the approval rule switched off a TR can go directly', J('POST', '/api/transports/%d/do' % r3['id'], {'do': 'prd', 'by': 'H'})[1]['status'] == 'prd')
    J('PUT', '/api/settings', {'tr_need_approval': '1'})

    print('purchases')
    b = J('GET', '/api/purchases')[1][0]
    check('cannot order before approval? (ordering a requested item is allowed, approval is optional)', J('POST', '/api/purchases/%d/do' % b['id'], {'do': 'approve'})[0] == 400)
    J('POST', '/api/purchases/%d/do' % b['id'], {'do': 'approve', 'approved_by': 'HOD'})
    st, b2 = J('POST', '/api/purchases/%d/do' % b['id'], {'do': 'order', 'vendor': 'ABC', 'po_no': 'PO1', 'expected_on': day(-1)})
    check('ordered and late', b2['status'] == 'ordered' and [x for x in J('GET', '/api/purchases')[1] if x['id'] == b['id']][0]['late'] is True)
    st, b2 = J('POST', '/api/purchases/%d/do' % b['id'], {'do': 'receive', 'add_to_stock': True})
    check('received: added to stock as a counted keyboard', st == 200 and len(b2['created_assets']) == 1)
    kb = J('GET', '/api/assets/%d' % b2['created_assets'][0])[1]
    check('keyboard in stock with quantity 1 and vendor', kb['kind'] == 'keyboard' and kb['qty'] == 1 and kb['vendor'] == '' or kb['qty'] == 1)
    bl = J('POST', '/api/purchases', {'item': 'Dell laptops', 'kind': 'laptop', 'qty': 2, 'plant': '1200'})[1]
    st, bl = J('POST', '/api/purchases/%d/do' % bl['id'], {'do': 'receive', 'add_to_stock': True, 'serials': 'NEW1\nNEW2'})
    check('two laptops with serials added to stock', len(bl['created_assets']) == 2 and J('GET', '/api/assets/%d' % bl['created_assets'][1])[1]['serial'] == 'NEW2')
    check('received purchase cannot be deleted', J('DELETE', '/api/purchases/%d' % bl['id'])[0] == 409)
    check('purchase needs an item', J('POST', '/api/purchases', {'item': ''})[0] == 400)

    print('renewals')
    st, rn = J('POST', '/api/renewals', {'title': 'CCTV AMC', 'kind': 'amc', 'plant': '1200', 'expires_on': day(10), 'owner_id': ani['id']})
    check('renewal created', st == 200 and rn['code'].startswith('N-'))
    rr = J('GET', '/api/renewals')[1]
    check('due in 10 days -> state due (remind 30 days)', rr['renewals'][0]['state'] == 'due' and rr['renewals'][0]['days_left'] == 10 and rr['renewals'][0]['owner'] == 'Anil')
    check('new expiry must be later', J('POST', '/api/renewals/%d/renew' % rn['id'], {'expires_on': day(5)})[0] == 400)
    st, rn = J('POST', '/api/renewals/%d/renew' % rn['id'], {'expires_on': day(375), 'cost': 12000})
    check('renewed -> ok state and in history', J('GET', '/api/renewals')[1]['renewals'][0]['state'] == 'ok' and any(h['kind'] == 'renew' for h in rn['history']))
    check('renewal needs expiry date', J('POST', '/api/renewals', {'title': 'x'})[0] == 400)

    print('daily checks')
    st, rl = J('POST', '/api/routines', {'title': 'SAP backup OK', 'frequency': 'daily', 'assigned_to': sun['id']})
    rid = rl[0]['id']
    check('check created, due today or last working day', st == 200 and rl[0]['cur_due'] <= day(0))
    only = J('GET', '/api/routines')[1][0]
    check('new check starts as pending (today) or missed (weekend)', only['state'] in ('pending', 'missed'))
    check('problem needs a note', J('POST', '/api/routines/%d/log' % rid, {'status': 'issue'})[0] == 400)
    check('future date refused', J('POST', '/api/routines/%d/log' % rid, {'status': 'ok', 'on_date': day(2)})[0] == 400)
    st, rl = J('POST', '/api/routines/%d/log' % rid, {'status': 'ok', 'by_id': sun['id']})
    check('marked OK', rl[0]['state'] == 'ok' and rl[0]['cur_log']['by_name'] == 'Sunil')
    st, rl = J('POST', '/api/routines/%d/log' % rid, {'status': 'issue', 'note': 'backup failed at 2 am'})
    check('logging again updates the same day (no duplicates)', rl[0]['state'] == 'issue' and len(J('GET', '/api/routines/%d/logs' % rid)[1]) == 1)
    dash = J('GET', '/api/dashboard')[1]
    check('dashboard shows the check problem', any(g['key'] == 'routine_bad' for g in dash['attention']))
    wk = J('POST', '/api/routines', {'title': 'Antivirus update', 'frequency': 'weekly', 'weekday': 0})[1]
    mo = J('POST', '/api/routines', {'title': 'Restore test', 'frequency': 'monthly', 'month_day': 31})[1]
    check('weekly and monthly checks have due dates', all(r['cur_due'] for r in mo) and all(r['prev_due'] < r['cur_due'] for r in mo))
    check('monthly day is limited to 28', [r for r in mo if r['title'] == 'Restore test'][0]['month_day'] == 28)

    print('files')
    st, up = J('POST', '/api/files?kind=ticket&id=%d&name=photo.png&category=photo' % t2['id'], raw=b'\x89PNG....')
    check('photo uploaded into the ticket folder', st == 200 and up['rel_path'].startswith('tickets/') and up['rel_path'].endswith('1_Photos/photo.png'), up)
    st, up2 = J('POST', '/api/files?kind=asset&id=%d&name=invoice.pdf&category=invoice' % lap[0]['id'], raw=b'%PDF-1.4 x')
    check('invoice uploaded into the asset folder', st == 200 and '2_Invoice_Warranty' in up2['rel_path'])
    check('file is served', J('GET', '/files/%d' % up['id'])[0] == 200)
    st, mv = J('PUT', '/api/files/%d' % up2['id'], {'category': 'handover'})
    check('file moved to another category folder', st == 200 and '3_Handover_Forms' in mv['rel_path'] and os.path.isfile(os.path.join(m.FILES_DIR, mv['rel_path'])) and not os.path.exists(os.path.join(m.FILES_DIR, up2['rel_path'])))
    check('upload to an unknown record type refused', J('POST', '/api/files?kind=banana&id=1&name=x.png', raw=b'x')[0] == 400)
    check('ticket detail lists the file', len(J('GET', '/api/tickets/%d' % t2['id'])[1]['files']) == 1)
    check('delete file', J('DELETE', '/api/files/%d' % up['id'])[0] == 200 and J('GET', '/files/%d' % up['id'])[0] == 404)
    tdel = J('POST', '/api/tickets', {'title': 'temp'})[1]
    J('POST', '/api/files?kind=ticket&id=%d&name=a.txt' % tdel['id'], raw=b'hello')
    J('DELETE', '/api/tickets/%d' % tdel['id'])
    check('deleting a ticket removes its file records', J('GET', '/api/files/999/preview')[0] == 404)

    print('search, report, export, settings')
    sr = J('GET', '/api/search?q=Neha')[1]
    check('search finds the employee', any(x['kind'] == 'person' for x in sr))
    check('search by serial finds the laptop', any(x['kind'] == 'asset' for x in J('GET', '/api/search?q=S1')[1]))
    check('search by TR number', any(x['kind'] == 'transport' for x in J('GET', '/api/search?q=DEVK9000')[1]))
    check('search ignores 1-character queries', J('GET', '/api/search?q=a')[1] == [])
    rep = J('GET', '/api/report?from=%s&to=%s' % (day(-7), day(0)))[1]
    check('report: tickets, plants, team, stock, TR, checks', rep['tickets']['opened'] >= 3 and len(rep['by_plant']) == 3 and rep['transports']['moved_prd'] >= 1 and rep['checks']['expected'] >= 1 and rep['by_member'])
    check('report for one plant', J('GET', '/api/report?plant=1200')[1]['plant_label'].startswith('1200'))
    st, x = J('GET', '/api/export.xlsx')
    z = zipfile.ZipFile(io.BytesIO(x)) if st == 200 else None
    names = z.namelist() if z else []
    check('Excel export is a valid workbook with 10 sheets', st == 200 and sum(1 for n in names if n.startswith('xl/worksheets/')) == 10, st)
    check('settings: bad plant list refused', J('PUT', '/api/settings', {'plants': []})[0] == 400)
    check('settings: duplicate plant code refused', J('PUT', '/api/settings', {'plants': [{'code': '1', 'name': 'a'}, {'code': '1', 'name': 'b'}]})[0] == 400)
    st, s = J('PUT', '/api/settings', {'sla_high': '6', 'min_stock': {'laptop': 50, 'banana': 4}, 'tpl_join': 'Laptop issued\nMail id created\n'})
    check('settings saved and cleaned', s['min_stock'] == {'laptop': 50} and s['sla_high'] == '6' and s['tpl_join'] == 'Laptop issued\nMail id created')
    check('SLA hours must be a number', J('PUT', '/api/settings', {'sla_high': 'abc'})[0] == 400)
    p3 = J('POST', '/api/people', {'name': 'New With Template', 'plant': '1100', 'emp_code': 'E7'})[1]
    check('the joiner checklist follows the edited template', [s['text'] for s in p3['steps']] == ['Laptop issued', 'Mail id created'])
    lowdash = J('GET', '/api/dashboard')[1]
    check('low stock warning when below the minimum', any(g['key'] == 'stock' for g in lowdash['attention']), [g['key'] for g in lowdash['attention']])
    J('PUT', '/api/settings', {'tpl_join': '\n'.join(m.TPL_JOIN), 'min_stock': {}})
    check('team member with work cannot be deleted', J('DELETE', '/api/team/%d' % sun['id'])[0] == 409)
    check('team member without work can be deleted', J('DELETE', '/api/team/%d' % J('POST', '/api/team', {'name': 'Temp'})[1]['id'])[0] == 200)

    print('backup and demo')
    st, bk = J('POST', '/api/backup')
    check('manual backup file exists', st == 200 and os.path.isfile(bk['path']))
    st, dm = J('POST', '/api/demo')
    check('demo data loads', st == 200 and dm['added'] == 1, dm)
    dd = J('GET', '/api/dashboard')[1]
    check('demo dashboard has attention items and team load', len(dd['attention']) >= 6 and len(dd['load']) >= 4, [g['key'] for g in dd['attention']])
    check('demo second load adds nothing', J('POST', '/api/demo')[1]['added'] == 0)
    n_real_people = len([p for p in J('GET', '/api/people')[1] if not p['name'] in ('Neha Verma', 'Rakesh G', 'New With Template')])
    st, _ = J('DELETE', '/api/demo')
    import sqlite3
    c = sqlite3.connect(m.DB_PATH)
    left = {t: c.execute('SELECT COUNT(*) FROM %s WHERE is_demo=1' % t).fetchone()[0] for t in ('team', 'people', 'accounts', 'assets', 'tickets', 'transports', 'purchases', 'renewals', 'routines', 'routine_log', 'history', 'asset_log', 'steps')}
    check('demo data removed completely', st == 200 and not any(left.values()), left)
    orphan = c.execute("SELECT COUNT(*) FROM history WHERE (ent='ticket' AND ent_id NOT IN (SELECT id FROM tickets)) OR (ent='asset' AND ent_id NOT IN (SELECT id FROM assets)) OR (ent='person' AND ent_id NOT IN (SELECT id FROM people))").fetchone()[0]
    check('no history of removed demo records is left behind', orphan == 0, orphan)
    real_t = c.execute('SELECT COUNT(*) FROM tickets').fetchone()[0]
    check('real data is untouched by demo removal', real_t >= 5 and c.execute("SELECT COUNT(*) FROM people WHERE name='Neha Verma'").fetchone()[0] == 1)
    c.close()
    check('sync can track every table (single column primary key)', all(len([r for r in sqlite3.connect(m.DB_PATH).execute('PRAGMA table_info(%s)' % t) if r[5]]) == 1 for t in
                                                                      [r[0] for r in sqlite3.connect(m.DB_PATH).execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")]))

    httpd.shutdown()
    shutil.rmtree(tmp, ignore_errors=True)
    print('\n%d passed, %d failed' % (PASS, FAIL))
    return 1 if FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
