#!/usr/bin/env python3
"""Drives the gate and the shell in a real (headless) Chromium. Saves screenshots to the folder given as argv[1]."""
import os
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import test_server as ts                      # noqa: E402
import test_e2e as e2e                        # noqa: E402
from playwright.sync_api import sync_playwright   # noqa: E402

check = ts.check


def main():
    shots = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp(prefix='tdshots_')
    os.makedirs(shots, exist_ok=True)
    tmp = tempfile.mkdtemp(prefix='tdui_')
    php = None
    pc = None
    try:
        site = ts.make_site(tmp, 'cloud', {'quota_mb': 50, 'max_file_mb': 20})
        port = ts.free_port()
        php = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', site], cwd=site, env=dict(os.environ, PHP_CLI_SERVER_WORKERS='4'),
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        assert ts.wait_up(port)
        pc = e2e.Pc(tmp, 'pc', 'http://127.0.0.1:%d/api.php' % port, 'fico')
        pc.start_gate()
        errors = []
        with sync_playwright() as p:
            br = p.chromium.launch()
            ctx = br.new_context(viewport={'width': 1360, 'height': 820}, device_scale_factor=1)
            page = ctx.new_page()
            page.on('console', lambda m: errors.append('console: ' + m.text) if m.type == 'error' else None)
            page.on('pageerror', lambda e: errors.append('pageerror: %s' % e))
            page.goto('http://127.0.0.1:%d/__enter?k=%s' % (pc.gate.port, pc.gate.key))
            page.wait_for_selector('#u')
            check('gate login screen loads with the installed FICO theme', page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()") == '#17745a')
            time.sleep(1.0)
            page.screenshot(path=os.path.join(shots, '01_login_fico.png'))

            page.click('text=Create an account')
            page.wait_for_selector('#m')
            page.select_option('#m', 'abap')
            time.sleep(0.5)
            check('choosing ABAP re-themes the screen', page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()") == '#0b6bcb')
            page.select_option('#m', 'mm')
            time.sleep(0.5)
            page.fill('#n', 'Bhawani Singh')
            page.fill('#u', 'Bhawani')
            page.fill('#p', 'short')
            page.fill('#p2', 'different')
            page.click('button[type=submit]')
            check('inline validation shows', 'At least 8' in page.inner_text('#p-err') and 'not the same' in page.inner_text('#p2-err'))
            page.screenshot(path=os.path.join(shots, '02_register_errors.png'))
            page.fill('#p', 'Passw0rd!x')
            page.fill('#p2', 'Passw0rd!x')
            page.click('button[type=submit]')
            page.wait_for_selector('#key')
            key = page.inner_text('#key')
            check('recovery key is shown', len(key) == 24)
            check('continue is disabled until the key is confirmed', page.is_disabled('text=Open my workspace'))
            page.screenshot(path=os.path.join(shots, '03_recovery_key.png'))
            page.check('#saved')
            with page.expect_navigation(timeout=20000):
                page.click('text=Open my workspace')
            page.wait_for_selector('#td-acct', timeout=20000)
            time.sleep(1.5)
            check('module app opened with the account block', 'Bhawani Singh' in page.inner_text('#td-acct') and 'MM Consultant' in page.inner_text('#td-acct'))
            check('sync chip shows saved', 'Saved' in page.inner_text('.td-chip'), page.inner_text('.td-chip'))
            page.screenshot(path=os.path.join(shots, '04_workspace_mm.png'))

            page.click('.td-btns >> text=About')
            page.wait_for_selector('dialog.td-about[open]')
            txt = page.inner_text('dialog.td-about')
            check('About shows name, role and company', 'Bhawani Singh' in txt and 'ABAP Developer at Mayur Uniquoters' in txt, txt[:300])
            time.sleep(0.8)
            page.screenshot(path=os.path.join(shots, '05_about.png'))
            page.click('dialog.td-about >> text=Close')

            page.click('.td-chip')
            page.wait_for_selector('dialog.td-small[open]')
            page.screenshot(path=os.path.join(shots, '06_sync_details.png'))
            page.click('dialog.td-small >> text=Close')

            # create a task through the module's own UI path (API) and watch the chip go through waiting -> saved
            page.evaluate("fetch('/api/tasks',{method:'POST',headers:{'X-TM':'1','Content-Type':'application/json'},body:JSON.stringify({title:'UI check task'})})")
            time.sleep(4)
            check('chip returns to Saved after a change', 'Saved' in page.inner_text('.td-chip'), page.inner_text('.td-chip'))

            page.click('.td-btns >> text=Sign out')
            page.wait_for_selector('dialog.td-small[open]')
            page.screenshot(path=os.path.join(shots, '07_signout_dialog.png'))
            with page.expect_navigation(timeout=20000):
                page.click('dialog.td-small >> button.td-primary')
            page.wait_for_selector('#u', timeout=20000)
            check('after sign out the sign-in screen is back', 'Sign in' in page.inner_text('#view'))
            page.screenshot(path=os.path.join(shots, '08_login_after_logout.png'))

            page.fill('#u', 'bhawani')
            page.fill('#p', 'Passw0rd!x')
            with page.expect_navigation(timeout=25000):
                page.click('button[type=submit]')
            page.wait_for_selector('#td-acct', timeout=25000)
            time.sleep(1)
            check('signing in again shows the data', page.evaluate("fetch('/api/tasks').then(r=>r.json()).then(t=>t.some(x=>x.title==='UI check task'))"))
            page.set_viewport_size({'width': 1100, 'height': 700})
            page.screenshot(path=os.path.join(shots, '09_workspace_small.png'))

            # narrow gate (phone-like) layout
            page2 = ctx.new_page()
            page2.set_viewport_size({'width': 420, 'height': 800})
            page2.goto('http://127.0.0.1:%d/' % pc.gate.port)
            time.sleep(1)
            page2.screenshot(path=os.path.join(shots, '10_gate_narrow.png'))
            # a wrong server address must say WHY, not only "check your internet"
            bad = []
            for name, addr in (('wrongaddr', 'http://127.0.0.1:%d/index.php' % port), ('deadport', 'http://127.0.0.1:1/api.php')):
                pcx = e2e.Pc(tmp, name, addr, 'basis')
                bad.append(pcx)
                pcx.start_gate()
                pg = ctx.new_page()
                pg.goto('http://127.0.0.1:%d/__enter?k=%s' % (pcx.gate.port, pcx.gate.key))
                pg.wait_for_selector('.banner, #banner, [role=alert], #u', timeout=20000)
                time.sleep(2)
                txt = pg.inner_text('body')
                if name == 'wrongaddr':
                    check('wrong address: the screen says the answer was unexpected and to check the address', 'unexpected answer' in txt and 'server address' in txt, txt[:300])
                else:
                    check('server unreachable: the screen shows the technical reason and the internet hint', 'Cannot reach the TaskDesk server (' in txt and 'Check your internet connection' in txt, txt[:300])
                pg.screenshot(path=os.path.join(shots, '11_gate_%s.png' % name))
            for pcx in bad:
                pcx.stop()
            br.close()
        real = [e for e in errors if 'favicon' not in e]
        check('no console or page errors', not real, real[:5])
    finally:
        if pc:
            pc.stop()
        if php and php.poll() is None:
            php.terminate()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nRESULT: %d passed, %d failed' % (ts.PASS, ts.FAIL))
    print('screenshots in', shots)
    return 1 if ts.FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
