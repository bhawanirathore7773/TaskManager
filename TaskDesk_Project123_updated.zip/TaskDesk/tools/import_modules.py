#!/usr/bin/env python3
"""
Copies the three finished task managers (ABAP, FICO, MM) into client/app/modules/<id>/ and adjusts the few texts
that talk about "this PC only" so they match the cloud-backed TaskDesk.

Usage:  python3 tools/import_modules.py [--src /home/claude]

A new module later = add another entry to MODULES (or just drop a folder with server.py, static/ and module.json
into client/app/modules/ by hand).
"""
import argparse
import json
import os
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEST = os.path.join(ROOT, 'client', 'app', 'modules')

MODULES = [
    dict(id='abap', src='ABAP_TaskManager', title='ABAP Developer', short='ABAP', tagline='Custom development for SAP: reports, enhancements, interfaces, forms',
         data_env='ABAP_TM_DATA', app_id='abap-task-manager', accent='#0b6bcb', shell='#0e2630', order=1),
    dict(id='fico', src='FICO_TaskManager', title='FICO Consultant', short='FICO', tagline='SAP Finance and Controlling: month-end, configuration, support',
         data_env='FICO_TM_DATA', app_id='fico-task-manager', accent='#17745a', shell='#15291f', order=2),
    dict(id='mm', src='MM_TaskManager', title='MM Consultant', short='MM', tagline='SAP Materials Management: procurement, inventory, invoice verification',
         data_env='MM_TM_DATA', app_id='mm-task-manager', accent='#4a54c7', shell='#1a1d3a', order=3),
]

TEXT_PATCHES = [
    ('static/js/views.js', 'Everything is stored on this PC in:', 'Your working copy on this PC is in:'),
    ('static/js/views.js', 'To move to another PC, copy the whole project folder.',
     'Your tasks and files are also kept safely in your TaskDesk cloud account. To work on another PC, install TaskDesk there and sign in.'),
]


# The stand-alone task managers let the whole page scroll, so the header and the sidebar moved up with it. Inside TaskDesk
# only the content area (#view) scrolls. Each entry: (old text, new text); they are applied to static/css/style.css.
LAYOUT_PATCHES = [
    ('html, body { height: 100%; }',
     'html, body { height: 100%; overflow: hidden; }   /* only #view scrolls, so the header and the sidebar stay where they are */'),
    ('#app { display: grid; grid-template-columns: 208px 1fr; height: 100%; }',
     '#app { display: grid; grid-template-columns: 208px minmax(0, 1fr); grid-template-rows: minmax(0, 1fr); height: 100%; }'),
    ('.main { display: flex; flex-direction: column; min-width: 0; height: 100%; }',
     '.main { display: flex; flex-direction: column; min-width: 0; min-height: 0; height: 100%; overflow: hidden; }'),
    ('.top { display: flex;', '.top { flex: none; position: relative; z-index: 20; display: flex;'),
    ('#view { flex: 1; overflow: auto;', '#view { flex: 1 1 0; min-height: 0; overflow: auto; overscroll-behavior: contain;'),
    ('@media print { .nav, .top, .iconbtn, .btn { display: none !important; } #app { display: block; } }',
     '@media print { .nav, .top, .iconbtn, .btn { display: none !important; } #app { display: block; } }\n'
     '@media print { html, body, #app, .main { height: auto; overflow: visible; } #view { overflow: visible; } }'),
]


def patch_layout(path, label):
    with open(path, encoding='utf-8') as f:
        s = f.read()
    for old, new in LAYOUT_PATCHES:
        if new in s:
            continue
        if s.count(old) != 1:
            raise SystemExit('Cannot find the layout rule in %s: %r' % (label, old))
        s = s.replace(old, new)
    with open(path, 'w', encoding='utf-8', newline='') as f:
        f.write(s)


def patch_text(path, old, new, label):
    with open(path, encoding='utf-8') as f:
        s = f.read()
    if old not in s:
        if new in s:
            return
        raise SystemExit('Cannot find text to change in %s: %r' % (label, old))
    s = s.replace(old, new)
    with open(path, 'w', encoding='utf-8', newline='') as f:
        f.write(s)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src', default='/home/claude')
    a = ap.parse_args()
    for m in MODULES:
        src = os.path.join(a.src, m['src'])
        dst = os.path.join(DEST, m['id'])
        if not os.path.isfile(os.path.join(src, 'server.py')):
            raise SystemExit('Missing source module: %s' % src)
        if os.path.isdir(dst):
            shutil.rmtree(dst)
        os.makedirs(dst)
        shutil.copy2(os.path.join(src, 'server.py'), os.path.join(dst, 'server.py'))
        shutil.copytree(os.path.join(src, 'static'), os.path.join(dst, 'static'))
        if os.path.isfile(os.path.join(src, 'app.ico')):
            shutil.copy2(os.path.join(src, 'app.ico'), os.path.join(dst, 'app.ico'))
        for rel, old, new in TEXT_PATCHES:
            patch_text(os.path.join(dst, rel), old, new, '%s/%s' % (m['id'], rel))
        patch_layout(os.path.join(dst, 'static', 'css', 'style.css'), '%s/static/css/style.css' % m['id'])
        meta = {k: v for k, v in m.items() if k != 'src'}
        meta['entry'] = 'server.py'
        meta['icon'] = 'static/icon.svg'
        with open(os.path.join(dst, 'module.json'), 'w', encoding='utf-8') as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)
            f.write('\n')
        print('imported', m['id'])


if __name__ == '__main__':
    main()
