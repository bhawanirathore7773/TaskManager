<?php
header('Content-Type: text/plain; charset=utf-8');
header('X-Content-Type-Options: nosniff');
echo "TaskDesk cloud API is running.\nOpen the TaskDesk desktop app to sign in.\n";
