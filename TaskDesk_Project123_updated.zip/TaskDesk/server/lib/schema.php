<?php
/* Database tables for the TaskDesk cloud API (MySQL / MariaDB for production, SQLite for tests). */

function td_schema_sql($driver)
{
    if ($driver === 'sqlite') {
        return array(
            'CREATE TABLE IF NOT EXISTS td_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                display_name TEXT NOT NULL,
                module TEXT NOT NULL,
                pass_hash TEXT NOT NULL,
                recovery_hash TEXT NOT NULL,
                rev INTEGER NOT NULL DEFAULT 0,
                bytes_used INTEGER NOT NULL DEFAULT 0,
                status INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                last_login TEXT NULL,
                expires_at TEXT NULL,
                quota_mb INTEGER NULL,
                max_file_mb INTEGER NULL,
                can_upload INTEGER NOT NULL DEFAULT 1,
                must_change_pw INTEGER NOT NULL DEFAULT 0,
                note TEXT NOT NULL DEFAULT \'\',
                created_by TEXT NOT NULL DEFAULT \'self\'
            )',
            'CREATE TABLE IF NOT EXISTS td_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                device TEXT NOT NULL,
                created_at TEXT NOT NULL,
                last_used TEXT NOT NULL,
                expires_at TEXT NOT NULL
            )',
            'CREATE INDEX IF NOT EXISTS ix_tokens_user ON td_tokens(user_id)',
            'CREATE TABLE IF NOT EXISTS td_records (
                user_id INTEGER NOT NULL,
                tbl TEXT NOT NULL,
                rid TEXT NOT NULL,
                data TEXT NOT NULL,
                deleted INTEGER NOT NULL DEFAULT 0,
                rev INTEGER NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (user_id, tbl, rid)
            )',
            'CREATE INDEX IF NOT EXISTS ix_records_rev ON td_records(user_id, rev)',
            'CREATE TABLE IF NOT EXISTS td_files (
                user_id INTEGER NOT NULL,
                rel_hash TEXT NOT NULL,
                rel TEXT NOT NULL,
                size INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (user_id, rel_hash)
            )',
            'CREATE TABLE IF NOT EXISTS td_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                k TEXT NOT NULL,
                ts INTEGER NOT NULL
            )',
            'CREATE INDEX IF NOT EXISTS ix_attempts ON td_attempts(kind, k, ts)',
            'CREATE TABLE IF NOT EXISTS td_settings (k TEXT PRIMARY KEY, v TEXT NOT NULL)',
            'CREATE TABLE IF NOT EXISTS td_owners (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                pass_hash TEXT NOT NULL,
                totp_secret TEXT NOT NULL DEFAULT \'\',
                totp_on INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL,
                last_login TEXT NULL
            )',
            'CREATE TABLE IF NOT EXISTS td_owner_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id INTEGER NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL,
                last_used TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                ip TEXT NOT NULL DEFAULT \'\'
            )',
            'CREATE TABLE IF NOT EXISTS td_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                target TEXT NOT NULL DEFAULT \'\',
                detail TEXT NOT NULL DEFAULT \'\'
            )',
        );
    }
    $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $bin = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_bin';
    return array(
        'CREATE TABLE IF NOT EXISTS td_users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(40) NOT NULL,
            display_name VARCHAR(100) NOT NULL,
            module VARCHAR(20) NOT NULL,
            pass_hash VARCHAR(255) NOT NULL,
            recovery_hash CHAR(64) NOT NULL,
            rev BIGINT UNSIGNED NOT NULL DEFAULT 0,
            bytes_used BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status TINYINT NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            last_login DATETIME NULL,
            expires_at DATETIME NULL,
            quota_mb INT UNSIGNED NULL,
            max_file_mb INT UNSIGNED NULL,
            can_upload TINYINT NOT NULL DEFAULT 1,
            must_change_pw TINYINT NOT NULL DEFAULT 0,
            note VARCHAR(255) NOT NULL DEFAULT \'\',
            created_by VARCHAR(20) NOT NULL DEFAULT \'self\',
            PRIMARY KEY (id),
            UNIQUE KEY uq_username (username)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_tokens (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            token_hash CHAR(64) NOT NULL,
            device VARCHAR(100) NOT NULL,
            created_at DATETIME NOT NULL,
            last_used DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_token (token_hash),
            KEY ix_tokens_user (user_id)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_records (
            user_id INT UNSIGNED NOT NULL,
            tbl VARCHAR(40) ' . $bin . ' NOT NULL,
            rid VARCHAR(120) ' . $bin . ' NOT NULL,
            data MEDIUMTEXT NOT NULL,
            deleted TINYINT NOT NULL DEFAULT 0,
            rev BIGINT UNSIGNED NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (user_id, tbl, rid),
            KEY ix_records_rev (user_id, rev)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_files (
            user_id INT UNSIGNED NOT NULL,
            rel_hash CHAR(64) NOT NULL,
            rel VARCHAR(500) ' . $bin . ' NOT NULL,
            size BIGINT UNSIGNED NOT NULL,
            sha256 CHAR(64) NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (user_id, rel_hash)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_attempts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            kind VARCHAR(16) NOT NULL,
            k VARCHAR(80) NOT NULL,
            ts INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY ix_attempts (kind, k, ts)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_settings (
            k VARCHAR(40) NOT NULL,
            v MEDIUMTEXT NOT NULL,
            PRIMARY KEY (k)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_owners (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(40) NOT NULL,
            pass_hash VARCHAR(255) NOT NULL,
            totp_secret VARCHAR(255) NOT NULL DEFAULT \'\',
            totp_on TINYINT NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            last_login DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_owner (username)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_owner_sessions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            owner_id INT UNSIGNED NOT NULL,
            token_hash CHAR(64) NOT NULL,
            created_at DATETIME NOT NULL,
            last_used DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            ip VARCHAR(45) NOT NULL DEFAULT \'\',
            PRIMARY KEY (id),
            UNIQUE KEY uq_osession (token_hash)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_audit (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            ts DATETIME NOT NULL,
            actor VARCHAR(40) NOT NULL,
            action VARCHAR(40) NOT NULL,
            target VARCHAR(80) NOT NULL DEFAULT \'\',
            detail VARCHAR(500) NOT NULL DEFAULT \'\',
            PRIMARY KEY (id),
            KEY ix_audit_ts (ts)
        )' . $tail,
    );
}

define('TD_SCHEMA_VERSION', 2);

function td_create_schema($pdo, $driver)
{
    foreach (td_schema_sql($driver) as $sql) {
        $pdo->exec($sql);
    }
    td_schema_finish($pdo, $driver);
}

/* Columns that version 1 databases do not have yet. */
function td_user_new_columns($driver)
{
    $txt = $driver === 'sqlite' ? 'TEXT' : 'VARCHAR(255)';
    $dt = $driver === 'sqlite' ? 'TEXT' : 'DATETIME';
    $int = $driver === 'sqlite' ? 'INTEGER' : 'INT UNSIGNED';
    $tiny = $driver === 'sqlite' ? 'INTEGER' : 'TINYINT';
    $vc20 = $driver === 'sqlite' ? 'TEXT' : 'VARCHAR(20)';
    return array(
        'expires_at' => $dt . ' NULL',
        'quota_mb' => $int . ' NULL',
        'max_file_mb' => $int . ' NULL',
        'can_upload' => $tiny . ' NOT NULL DEFAULT 1',
        'must_change_pw' => $tiny . ' NOT NULL DEFAULT 0',
        'note' => $txt . " NOT NULL DEFAULT ''",
        'created_by' => $vc20 . " NOT NULL DEFAULT 'self'",
    );
}

function td_table_columns($pdo, $driver, $table)
{
    $cols = array();
    if ($driver === 'sqlite') {
        foreach ($pdo->query('PRAGMA table_info(' . $table . ')')->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $cols[] = $r['name'];
        }
    } else {
        foreach ($pdo->query('SHOW COLUMNS FROM ' . $table)->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $cols[] = $r['Field'];
        }
    }
    return $cols;
}

/* Brings a database from an older version up to date (safe to run more than once, also by two requests at the same time). */
function td_migrate($pdo, $driver)
{
    foreach (td_schema_sql($driver) as $sql) {
        $pdo->exec($sql);                 // new tables only: every statement is CREATE ... IF NOT EXISTS
    }
    $have = td_table_columns($pdo, $driver, 'td_users');
    foreach (td_user_new_columns($driver) as $name => $def) {
        if (!in_array($name, $have, true)) {
            try {
                $pdo->exec('ALTER TABLE td_users ADD COLUMN ' . $name . ' ' . $def);
            } catch (Throwable $e) {
                // another request added it a moment ago
            }
        }
    }
    td_schema_finish($pdo, $driver);
}

/* Settings every installation has: the version of the tables and an id that identifies this server to the desktop apps. */
function td_schema_finish($pdo, $driver)
{
    $ins = $driver === 'sqlite' ? 'INSERT OR IGNORE INTO td_settings(k,v) VALUES(?,?)' : 'INSERT IGNORE INTO td_settings(k,v) VALUES(?,?)';
    $st = $pdo->prepare($ins);
    $st->execute(array('server_id', bin2hex(random_bytes(8))));
    $up = $pdo->prepare('UPDATE td_settings SET v=? WHERE k=?');
    $up->execute(array((string)TD_SCHEMA_VERSION, 'schema_version'));
    if ($up->rowCount() === 0) {
        $st->execute(array('schema_version', (string)TD_SCHEMA_VERSION));
    }
}
