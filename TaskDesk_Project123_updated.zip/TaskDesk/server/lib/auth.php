<?php
/* Accounts: register, login, logout, password change, recovery key. */

function td_valid_username($u)
{
    return (bool)preg_match('/^[a-z0-9][a-z0-9._-]{1,30}[a-z0-9]$/', $u);
}

function td_user_public($u)
{
    return array(
        'id' => (int)$u['id'],
        'username' => $u['username'],
        'display_name' => $u['display_name'],
        'module' => $u['module'],
    );
}

/* What the app needs to know about the limits of this account. */
function td_perms($u)
{
    return array(
        'can_upload' => (int)$u['can_upload'] === 1,
        'quota_mb' => td_user_quota_mb($u),
        'max_file_mb' => td_user_max_file_mb($u),
        'expires_at' => $u['expires_at'] ? substr($u['expires_at'], 0, 10) : '',
        'must_change_password' => (int)$u['must_change_pw'] === 1,
        'bytes_used' => (int)$u['bytes_used'],
    );
}

/* Refuses accounts the owner switched off, that wait for approval or whose access time has ended. */
function td_check_account($u)
{
    $st = (int)$u['status'];
    if ($st === 0) {
        td_fail(403, 'account_disabled', 'This account has been switched off. Please contact the administrator.');
    }
    if ($st === 2) {
        td_fail(403, 'account_pending', 'Your account is waiting for approval by the administrator.');
    }
    if (!empty($u['expires_at']) && strtotime($u['expires_at'] . ' UTC') < time()) {
        td_fail(403, 'account_expired', 'Your access ended on ' . substr($u['expires_at'], 0, 10) . '. Please contact the administrator.');
    }
}

function td_new_recovery_key()
{
    $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $out = '';
    for ($i = 0; $i < 20; $i++) {
        $out .= $alphabet[random_int(0, 31)];
        if ($i % 4 === 3 && $i < 19) {
            $out .= '-';
        }
    }
    return $out;
}

function td_norm_recovery($k)
{
    return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$k));
}

function td_check_password_rules($pw, $username)
{
    if (strlen($pw) < 8) {
        td_fail(400, 'weak_password', 'Password must be at least 8 characters.');
    }
    if (strlen($pw) > 200) {
        td_fail(400, 'weak_password', 'Password is too long.');
    }
    if (strtolower($pw) === strtolower($username)) {
        td_fail(400, 'weak_password', 'Password must not be the same as the username.');
    }
}

function td_issue_token($uid, $device)
{
    $c = td_config();
    $token = td_random_hex(32);
    $now = td_now();
    $exp = gmdate('Y-m-d H:i:s', time() + (int)$c['token_days'] * 86400);
    $device = substr(trim(preg_replace('/[^\p{L}\p{N} ._-]/u', '', (string)$device)), 0, 100);
    if ($device === '') {
        $device = 'Unknown device';
    }
    td_exec('INSERT INTO td_tokens(user_id, token_hash, device, created_at, last_used, expires_at) VALUES(?,?,?,?,?,?)',
        array($uid, td_token_hash($token), $device, $now, $now, $exp));
    // keep at most 20 signed-in devices per account: drop the oldest ones
    $keep = td_rows('SELECT id FROM td_tokens WHERE user_id=? ORDER BY last_used DESC LIMIT 20', array($uid));
    if (count($keep) >= 20) {
        $ids = array();
        foreach ($keep as $k) {
            $ids[] = (int)$k['id'];
        }
        td_exec('DELETE FROM td_tokens WHERE user_id=? AND id NOT IN (' . implode(',', $ids) . ')', array($uid));
    }
    return $token;
}

function td_request_token()
{
    foreach (array('HTTP_X_TD_TOKEN', 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION') as $k) {
        if (!empty($_SERVER[$k])) {
            $v = trim((string)$_SERVER[$k]);
            if (stripos($v, 'bearer ') === 0) {
                $v = trim(substr($v, 7));
            }
            if (preg_match('/^[a-f0-9]{64}$/', $v)) {
                return $v;
            }
        }
    }
    return '';
}

function td_require_user($allowPasswordChange = false)
{
    $token = td_request_token();
    if ($token === '') {
        td_fail(401, 'not_signed_in', 'Please sign in.');
    }
    $row = td_row('SELECT t.id AS token_id, t.last_used AS token_last_used, u.* FROM td_tokens t JOIN td_users u ON u.id=t.user_id
                   WHERE t.token_hash=? AND t.expires_at>?', array(td_token_hash($token), td_now()));
    if (!$row) {
        td_fail(401, 'not_signed_in', 'Your session has expired. Please sign in again.');
    }
    td_check_account($row);
    if (!$allowPasswordChange && (int)$row['must_change_pw'] === 1) {
        td_fail(403, 'password_change_required', 'Please choose a new password first.');
    }
    // sliding expiry: refresh at most once an hour
    if (strtotime($row['token_last_used'] . ' UTC') < time() - 3600) {
        $c = td_config();
        td_exec('UPDATE td_tokens SET last_used=?, expires_at=? WHERE id=?',
            array(td_now(), gmdate('Y-m-d H:i:s', time() + (int)$c['token_days'] * 86400), $row['token_id']));
    }
    return $row;
}

function td_route_register()
{
    td_method('POST');
    $c = td_config();
    if (!$c['allow_registration']) {
        td_fail(403, 'registration_closed', 'New accounts are not being created right now. Please contact the administrator.');
    }
    $in = td_input();
    $ip = td_client_ip();
    td_rate_guard('reg', $ip, 10, 3600);

    $username = strtolower(trim(td_str($in, 'username', 32)));
    $pw = td_str($in, 'password', 200);
    $display = trim(td_str($in, 'display_name', 80));
    $module = strtolower(trim(td_str($in, 'module', 20)));
    $device = td_str($in, 'device', 100);

    if (!td_valid_username($username)) {
        td_fail(400, 'bad_username', 'Username must be 3 to 32 characters: letters, numbers, dot, dash or underscore, starting and ending with a letter or number.');
    }
    td_check_password_rules($pw, $username);
    if (!in_array($module, $c['modules'], true)) {
        td_fail(400, 'bad_module', 'This module is not available on the server.');
    }
    if ($c['invite_code'] !== '') {
        if (!hash_equals((string)$c['invite_code'], td_str($in, 'invite', 100))) {
            td_rate_hit('reg', $ip);
            td_fail(403, 'bad_invite', 'The invite code is not correct.');
        }
    }
    if ($display === '') {
        $display = $username;
    }
    $display = function_exists('mb_substr') ? mb_substr($display, 0, 80, 'UTF-8') : substr($display, 0, 80);

    if (td_val('SELECT COUNT(*) FROM td_users WHERE username=?', array($username)) > 0) {
        td_fail(409, 'username_taken', 'This username is already taken. Please choose another.');
    }
    td_rate_hit('reg', $ip);
    $recovery = td_new_recovery_key();
    $pending = $c['registration'] === 'approval';
    try {
        td_exec('INSERT INTO td_users(username, display_name, module, pass_hash, recovery_hash, rev, bytes_used, status, created_at, last_login)
                 VALUES(?,?,?,?,?,0,0,?,?,?)',
            array($username, $display, $module, td_hash_password($pw), td_hmac(td_norm_recovery($recovery)), $pending ? 2 : 1, td_now(), td_now()));
    } catch (PDOException $e) {
        td_fail(409, 'username_taken', 'This username is already taken. Please choose another.');
    }
    $user = td_row('SELECT * FROM td_users WHERE username=?', array($username));
    td_audit('user:' . $username, $pending ? 'register_pending' : 'register', $username, $module);
    if ($pending) {
        td_json(array('ok' => true, 'pending' => true, 'user' => td_user_public($user), 'recovery_key' => $recovery));
    }
    $token = td_issue_token((int)$user['id'], $device);
    td_json(array('ok' => true, 'token' => $token, 'user' => td_user_public($user), 'recovery_key' => $recovery, 'perms' => td_perms($user)));
}

function td_route_login()
{
    td_method('POST');
    $in = td_input();
    $username = strtolower(trim(td_str($in, 'username', 32)));
    $pw = td_str($in, 'password', 200);
    $device = td_str($in, 'device', 100);
    $ip = td_client_ip();
    td_rate_guard('login-ip', $ip, 40, 900);
    td_rate_guard('login-user', $username, 8, 900);

    $user = td_row('SELECT * FROM td_users WHERE username=?', array($username));
    // a real (never matching) hash, so an unknown username costs the same time as a wrong password
    $hash = $user ? $user['pass_hash'] : '$2y$10$E15zo62g0Z.8TkcdFtY3/uJtjCTLKQEW5e8AvtOeQFutd0k4dJIfu';
    $ok = password_verify($pw, $hash);
    if (!$user || !$ok) {
        td_rate_hit('login-ip', $ip);
        td_rate_hit('login-user', $username);
        td_fail(401, 'bad_credentials', 'Username or password is not correct.');
    }
    td_check_account($user);            // the password is right, so it is fine to say why the account cannot be used
    if (password_needs_rehash($user['pass_hash'], PASSWORD_DEFAULT) && !defined('PASSWORD_ARGON2ID')) {
        td_exec('UPDATE td_users SET pass_hash=? WHERE id=?', array(td_hash_password($pw), $user['id']));
    }
    td_exec('UPDATE td_users SET last_login=? WHERE id=?', array(td_now(), $user['id']));
    $token = td_issue_token((int)$user['id'], $device);
    td_json(array('ok' => true, 'token' => $token, 'user' => td_user_public($user), 'perms' => td_perms($user),
        'must_change_password' => (int)$user['must_change_pw'] === 1));
}

function td_route_logout()
{
    td_method('POST');
    $token = td_request_token();
    if ($token !== '') {
        td_exec('DELETE FROM td_tokens WHERE token_hash=?', array(td_token_hash($token)));
    }
    td_json(array('ok' => true));
}

function td_route_me()
{
    td_method('GET');
    $u = td_require_user(true);
    td_json(array('ok' => true, 'user' => td_user_public($u), 'rev' => (int)$u['rev'], 'perms' => td_perms($u)));
}

function td_route_password()
{
    td_method('POST');
    $u = td_require_user(true);
    $in = td_input();
    td_rate_guard('pw-user', $u['username'], 8, 900);
    if (!password_verify(td_str($in, 'old_password', 200), $u['pass_hash'])) {
        td_rate_hit('pw-user', $u['username']);
        td_fail(403, 'bad_credentials', 'The current password is not correct.');
    }
    $new = td_str($in, 'new_password', 200);
    td_check_password_rules($new, $u['username']);
    if ((int)$u['must_change_pw'] === 1 && password_verify($new, $u['pass_hash'])) {
        td_fail(400, 'weak_password', 'Please choose a different password from the temporary one.');
    }
    td_exec('UPDATE td_users SET pass_hash=?, must_change_pw=0 WHERE id=?', array(td_hash_password($new), $u['id']));
    td_exec('DELETE FROM td_tokens WHERE user_id=? AND id<>?', array($u['id'], $u['token_id']));
    td_json(array('ok' => true));
}

function td_route_recover()
{
    td_method('POST');
    $in = td_input();
    $username = strtolower(trim(td_str($in, 'username', 32)));
    $ip = td_client_ip();
    td_rate_guard('rec-ip', $ip, 20, 3600);
    td_rate_guard('rec-user', $username, 5, 3600);
    $user = td_row('SELECT * FROM td_users WHERE username=?', array($username));
    $key = td_hmac(td_norm_recovery(td_str($in, 'recovery_key', 64)));
    if (!$user || !hash_equals($user['recovery_hash'], $key)) {
        td_rate_hit('rec-ip', $ip);
        td_rate_hit('rec-user', $username);
        td_fail(403, 'bad_recovery', 'The username or the recovery key is not correct.');
    }
    $new = td_str($in, 'new_password', 200);
    td_check_password_rules($new, $username);
    $recovery = td_new_recovery_key();
    td_exec('UPDATE td_users SET pass_hash=?, recovery_hash=?, must_change_pw=0 WHERE id=?',
        array(td_hash_password($new), td_hmac(td_norm_recovery($recovery)), $user['id']));
    td_exec('DELETE FROM td_tokens WHERE user_id=?', array($user['id']));
    td_json(array('ok' => true, 'recovery_key' => $recovery));
}
