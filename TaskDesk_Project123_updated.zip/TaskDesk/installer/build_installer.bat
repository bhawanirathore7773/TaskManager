@echo off
setlocal
cd /d "%~dp0"
title TaskDesk - Setup (.exe) banana
echo ============================================================
echo   TaskDesk: Setup (.exe) banana
echo   Internet chalu rakho. Pehli baar 3-5 minute lagte hain.
echo ============================================================
echo.

if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" goto haveinno
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" goto haveinno
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" goto haveinno
echo Inno Setup 6 (free) nahi mila. Ab install kar raha hoon...
winget install --id JRSoftware.InnoSetup -e --accept-package-agreements --accept-source-agreements
echo.
:haveinno

if not "%~1"=="" goto witharg
echo Apne server ka address likho (Hostinger wala), jaise:
echo    https://aapka-domain.com/taskdesk/api.php
echo.
set /p CLOUD=Address: 
if "%CLOUD%"=="" goto noaddr
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_installer.ps1" -CloudUrl "%CLOUD%"
goto done

:witharg
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_installer.ps1" %*
goto done

:noaddr
echo.
echo Address likhna zaroori hai (https:// se shuru). Dobara chalao.

:done
echo.
if exist "%~dp0..\dist\TaskDesk_Setup.exe" start "" "%~dp0..\dist"
pause
