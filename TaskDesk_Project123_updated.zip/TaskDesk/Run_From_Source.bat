@echo off
rem Starts TaskDesk straight from the source folder (for testing, needs Python 3.8+ installed).
rem The cloud address comes from client\app\taskdesk_config.json (or set TASKDESK_CLOUD first).
cd /d "%~dp0client\app"
where py >nul 2>nul && (py -3 launcher.pyw) || (python launcher.pyw)
