# MM Task Manager

Local PC par chalne wala task manager, specially SAP **MM (Materials Management) functional consultant** ke liye.
Internet ya database install karne ki zaroorat nahi. Sab kuch isi folder ke `data` me save hota hai.

Ye ABAP aur FICO app se **alag app** hai: alag folder, alag data, alag port. Teeno ek saath ek hi PC par bhi chal sakte hain.

---

## 1. Pehli baar setup (5 minute)

1. **Python 3.8 ya naya** hona chahiye. Check: Command Prompt me `python --version`.
   Nahi hai to https://www.python.org/downloads/ se install karo, aur installer me **"Add python.exe to PATH"** tick karo.
2. Poora `MM_TaskManager` folder kisi bhi jagah rakho, jaise `D:\MM_TaskManager`.
   (Zip ho to pehle **Extract All** karo, zip ke andar se mat chalao.)
3. `Create_Desktop_Icon.bat` par double-click karo. Desktop par **MM Task Manager** icon ban jayega.
4. Us icon par double-click karo. 2-3 second me dashboard ek alag window me khul jayega.

Window band karne ke kuch minute baad server apne aap band ho jata hai. Settings me "Stop the app" se turant bhi band kar sakte ho.

Pehli baar dashboard khaali hoga. **Settings > Load sample tasks** se 7 example MM tasks dekh sakte ho (month-end closing, blocked invoices, PO release strategy, storage location, PO print form...), phir **Remove sample tasks** se hata do.

---

## 2. Task ke types

| Type | Kab use karein |
|---|---|
| Support Issue / Ticket | User ne bola "GR post nahi ho raha", "PO release nahi ho raha", "invoice blocked", "account not found" |
| Configuration / Change Request | SPRO me naya setting: release strategy, movement type, tolerance, storage location, output type, field selection |
| Master Data / Mass Upload | Material, info record, source list, opening stock, MRP values ka bulk upload ya mass change |
| Report / MIS / Analysis | Open PO, stock ageing, GR/IR list, consumption. Pehle standard report/variant dekho |
| Functional Spec (to ABAP) | Standard se nahi ho sakta (PO print form, save par check, Z report): spec likho, ABAP developer banaye, tum UAT karo |
| Physical Inventory / Stock Audit | Yearly count, cycle counting, difference posting, vendor ke paas pada stock |
| Month-end / Year-end Activity | MM period closing, GR/IR review, stock reconciliation, old PR / PO review |
| Authorisation / Role | Role, temporary access (Basis ko exact T-code aur values do) |
| Other | Training, user guide, cutover / data migration, project kaam |

Modules: MM-PUR (Purchasing), MM-CON (Contracts, source list), MM-IM (Inventory), MM-IV (Invoice verification), MM-MD (Master data), MM-SRV (Services), MM-SUB (Subcontracting), MM-IMP (Import), MM-MRP (Planning), INT (FI / PP / SD / QM ke saath integration), GEN.

---

## 3. Naya task kaise add karein

**New task** button (ya keyboard par `N`):

1. **Type** chuno, phir **New / first time** ya **Change in existing setup**, aur module.
2. **Ready template** se shuru karo (**80 templates**: PO release strategy, price not picked, GR error, movement type, opening stock upload, blocked invoice, GR/IR clearing, material creation, subcontracting stock, OBYC account not found...). Ye scope, settings, **stock aur accounting effect**, logic aur T-codes bhar deta hai. Blank bhi shuru kar sakte ho.
3. **Requested by**: koi naam pehle se bhara nahi hai. Ek baar type karo, phir dropdown me suggest hoga. Module ke hisaab se **Department** khud aa jata hai (MM-IM = Stores, MM-PUR = Purchase, MM-IV = Accounts Payable...).
4. **Repeats**: month-end, GR/IR review jaise kaam me "Every month / quarter / year" chuno (neeche section 5).
5. **Dates**: received, start, due. `1 week`, `2 weeks` buttons se due date jaldi set hoti hai.
6. **How long will it take?**: type, complexity aur extras (multiple plants, volume, ABAP involved, reconciliation, upload, UAT, transport...) se estimate hours nikalta hai.
7. User ka mail, requirement Excel, screenshots yahin drop kar do. Task ke apne folder me save hote hain.

**Create task** ke baad Requirement page khulta hai.

### Requirement page
Har section me **Suggestions** button hai: us type aur module ke common points ek click me add hote hain.

- **Scope** (plant, storage location, purchasing org...), **Settings / output**
- **Stock aur accounting effect**: movement type, Dr / Cr, stock par asar. Issue me posted vs correct entry
- Business rule / logic, checks / validation, authorisation
- **T-codes, SPRO paths, tables** (module ke hisaab se suggest hote hain)
- Test scenarios, **Questions to the user** aur unke jawab
- **Paste list**: Excel se list copy karke ek saath add karo
- **Change in existing setup** me: purana setting, "what to change" points (tick karke done), aur **snapshot guide** (change se pehle kya screenshot / table download lena hai)

---

## 4. Task ke andar ke tabs

| Tab | Kya hai |
|---|---|
| Overview | Type, module, kisne bola, **Waiting for**, **Repeats**, dates, estimate, progress |
| Requirement | Upar wala analysis page |
| Checklist | Steps. Tick karne se progress bar badhta hai |
| Files | Screenshots, Excel, **before-change snapshot**, documents, test evidence. `Ctrl+V` se screenshot seedha paste |
| Transport & UAT | **UAT sign-off** (kisne accept kiya, kab), config transports (DEV / QAS / PRD), quality points, production ke baad problems |
| Solution info | T-code / SPRO path, kya configure kiya, scope, CR number, **kaise use karein**. Register isse banta hai |
| Time & notes | Kitne ghante lage, notes aur poori activity history |

**Snapshot:** Config badalne se pehle Files tab me category "Before-change snapshot" me SPRO screen ka screenshot (jaise release strategy CL24N) ya SE16N se table (T161, T156, T030, MARC...) ka Excel download upload kar do. Change galat gaya to wapas jana aasaan hota hai. Mass change ya upload se pehle purani values ki file zaroor rakho.

---

## 5. MM ke liye khaas features

**Waiting for (kisi ka intezaar):** Task kisi par atka ho (User / Stores, Purchase team, Vendor, ABAP developer, Basis, Finance consultant, PP / SD / QM consultant...) to Overview me "Waiting for" bharo. Task "Work on next" list se hat kar dashboard ke **Waiting on others** panel me aa jata hai, kitne din se wait hai ye dikhta hai (3 din ke baad laal). Jawab aane par box khali kar do.

**Repeat (baar baar aane wale kaam):** MM month-end, GR/IR review, stock reconciliation jaise task me "Repeats" set karo. Task finish (In Production ya Closed) karte hi **agla task khud ban jata hai**: due date aage, title me month badla hua ("Oct 2026" se "Nov 2026"), checklist ke steps untick, requirement points copy. Ek task se do baar agla nahi banta.

**UAT sign-off:** Transport & UAT tab me user ka naam aur date. History aur Register me "Signed off" dikhta hai. Sign-off mail Files me "Test evidence" me rakho.

**Finance consultant ke saath kaam:** Valuation class, OBYC account determination, GR/IR clearing jaise kaam FICO consultant ke saath milkar hote hain. Task me "Waiting for: Finance consultant" lagao aur INT module ke templates dekho.

**Library:** Templates aur **SAP reference** (har module ke T-codes, SPRO paths, reports, tables, BAPIs, authorisation objects, "good to know" notes).

---

## 6. Priority aur "pehle kya karna hai"

Dashboard ka **Work on next** list rank karta hai: priority, due date, kitne din se open hai, open quality points. Jo task kisi ka intezaar kar raha hai wo isme nahi aata.

| Light | Matlab |
|---|---|
| Lal: Overdue | Due date nikal gayi |
| Orange diamond: Not enough time | Bacha hua kaam > due date tak ka working time. Date badalni padegi |
| Orange: Due today / tomorrow | Urgent |
| Amber: N days left | Warning |
| Green: N days left | Theek hai |

**Settings** me apne productive ghante (default 6/din) aur working days (default Mon-Sat) sahi rakho. **This week** panel batata hai ki is hafte ka kaam tumhare time me aata hai ya nahi.

---

## 7. History aur Register

- **History > Completed work**: kya hua, kab production me gaya, sign-off, production ke baad problem, estimate vs actual time.
- **Register**: har setting / change ka T-code, kya configure hua, CR number, sign-off. Search karo, T-code copy karo.
- **Quality**: sab tasks ke open quality points aur production problems.
- **Settings > Export everything to Excel**: tasks, register, transports, issues, time log, requirement points.

---

## 8. Data kahan hai

Sab `MM_TaskManager\data` me:

```
data\taskmanager.db                 <- saare tasks, history (SQLite)
data\files\T-0003_PO_release_strategy_new_approval_level_a\
    1_Reference_Images\
    2_Excel_Requirement\
    3_Before_Change_Snapshot\
    4_Documents_FS_UserGuide\
    5_Test_UAT_Signoff\
    6_Other\
data\backups\                       <- har din automatic database backup (last 30)
data\trash\                         <- delete ki hui files / tasks yahan jaati hain
data\server.log                     <- problem ho to yahan dekho
```

- **Dhyan:** Is folder me company ka data (screenshots, vendor prices, reports) ho sakta hai. Company ki policy ke hisaab se hi pen drive / cloud par copy karo.
- **Naye PC par le jana:** poora `MM_TaskManager` folder copy kar do (data samet).

---

## 9. Keyboard shortcuts

| Key | Kaam |
|---|---|
| `N` | New task |
| `Ctrl+K` ya `/` | Search (task, code, T-code, naam, waiting for) |
| `Esc` | Task window band |
| `Ctrl+Enter` | New task form me Create |
| `Ctrl+V` | Task ke andar screenshot paste |

---

## 10. Problem aaye to

| Problem | Kya karein |
|---|---|
| "Python was not found" | Python install karo, "Add to PATH" tick karke |
| Icon dabane par kuch nahi khulta | `Run_With_Console.bat` chalao, ya `data\server.log` kholo |
| Page par "server is not running" | Window band karke icon se dobara kholo |
| Port busy | App 8800 se 8810 tak free port khud dhoondhta hai |
| Antivirus / firewall pooche | Ye sirf is PC par (127.0.0.1) chalta hai, bahar se koi nahi jud sakta |

---

## 11. Apne hisaab se badalna

SAP knowledge teen files me hai (`static\js\`), Notepad se edit kar sakte ho, phir window me `F5`:

- `kb.js`: task types, estimate hours, snapshot guide, **`people` aur `moduleOwners`** (module ke hisaab se kaun requirement deta hai: abhi khali hai, apne team ke naam daal do), `waitingOn` list.
- `kb_modules.js`: har module ke T-codes, SPRO paths, reports, tables, notes.
- `kb_templates.js`: ready templates. Format file ke upar likha hai.

**Zaroori:** T-codes, SPRO paths, movement types aur account keys (BSX, WRX, GBB...) sirf yaad dilane ke liye hain. Apne system par confirm karke hi use karo (ECC aur S/4HANA me thoda farak hota hai). Approval limits, tolerance aur duty / tax ka treatment hamesha business, Finance aur Tax team se likhit lo.

---

## Files ka map

```
server.py                       backend (Python, SQLite, koi install nahi)
launcher.pyw                    server start + window open
Launch_MM_TaskManager.vbs       icon isko chalata hai (console window nahi dikhta)
Create_Desktop_Icon.bat         desktop icon banata hai
Run_With_Console.bat            debugging ke liye
app.ico                         icon
static\                         dashboard (HTML, CSS, JavaScript)
```
