@echo off
rem Creates the desktop icon. Run this once.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create_Desktop_Icon.ps1"
echo.
pause
