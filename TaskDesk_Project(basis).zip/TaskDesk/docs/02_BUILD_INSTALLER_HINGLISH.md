# TaskDesk Installer banana (Hinglish guide)

Output: **`TaskDesk_Setup_1.1.0.exe`**. Ye normal Windows installer hai (wizard, Next, Next, Install).
Admin rights nahi chahiye, ye sirf current user ke folder me install hota hai.

Installer ke andar **Python 3.12 (embeddable)** bhi aa jata hai, to jis PC par install karoge wahan Python alag se
install karne ki zaroorat nahi.

> Pehle `docs/01_HOSTINGER_SETUP_HINGLISH.md` poora kar lo, kyunki installer me aapka server address **andar daalna** hota hai.
> Wo address installer ke andar pakka ho jata hai. App me koi "Server" option nahi hota, user ko kuch likhna nahi padta: install, desktop icon, login / create account, bas.

---

## Tareeka A: Apne Windows PC par (sabse seedha)

Ek baar ka setup:
1. **Inno Setup 6** install karo: https://jrsoftware.org/isdl.php (free).
2. Internet chalu rakho (build ke waqt official Python embeddable package download hota hai, aur uska checksum verify hota hai).

Build:
1. Project folder `TaskDesk` kholo, `installer` folder me jao.
2. PowerShell kholo (us folder me) aur ye chalao, apna address daalkar:

```powershell
.\build_installer.ps1 -CloudUrl "https://aapka-domain.com/taskdesk/api.php"
```

(Agar PowerShell script block kare to: `powershell -ExecutionPolicy Bypass -File .\build_installer.ps1 -CloudUrl "..."`)

3. Script ye karti hai: files stage karna, Python download + checksum check, self-test, Inno Setup se compile.
4. Tayyar installer milega: `dist\TaskDesk_Setup_1.1.0.exe` aur saath me `.sha256.txt` file.

Address baar baar na likhna ho to `client\app\taskdesk_config.json` me `cloud_url` badal do.

Baad me server ka address badalna ho to **naya installer banana zaroori nahi**: owner site se address announce karo (guide 06). Purane installed apps khud naye address par chali jaati hain.
Phir bhi agle installer me naya address daal dena achha rehta hai.

## Tareeka B: GitHub Actions (PC par kuch install kiye bina)

1. Project ko apne GitHub repo me push karo (private bhi chalega).
2. Repo > **Settings > Secrets and variables > Actions > Variables** me `TASKDESK_CLOUD_URL` naam ka variable banao
   aur apna API address daalo.
3. **Actions > Build TaskDesk installer > Run workflow** dabao (ya `v1.0.1` jaisa tag push karo).
4. Build khatam hone par **Artifacts** se `TaskDesk-Setup` download karo. Tag se chalaya ho to installer Release me khud lag jaata hai.

---

## Installer me kya hota hai (wizard steps)

1. Welcome
2. License
3. **Module choose karo**: dropdown me **ABAP Developer / FICO Consultant / MM Consultant / SAP BASIS / IT Support**.
   Neeche us module ka chhota description dikhta hai.
4. Install folder
5. Shortcuts: desktop icon, aur (optional) "Windows ke saath open karo"
6. Install, phir "Open TaskDesk now"

Update ke waqt installer pichla chuna hua module khud yaad rakhta hai.

## Module ke baare me seedhi baat (zaroor padho)

Aapne kaha tha ki dropdown se chuna hua module hi install ho. Design me ek zaroori baat hai:

- Dropdown se **default edition** tay hoti hai: shortcut ka icon, pehli screen ka theme, aur jab tak koi login nahi karta tab tak ka module.
- Chaaron modules ka code installer ke andar rehta hai. Wajah ye hai ki aapne ye bhi maanga tha ki ABAP wala account MM-wale PC par login kare to software
  **apne aap ABAP me badal jaye**. Ye tabhi ho sakta hai jab code PC par maujood ho (warna login ke baad internet se download karna padega).
- User ko hamesha **sirf apne account ka module** dikhta hai. Baaki modules ka data ya screen kabhi nahi khulta.

Agar aapko sach me "sirf ek module ki files" chahiye (chhota installer), to alag-alag 3 installers banaye ja sakte hain,
lekin tab cross-module auto-convert kaam nahi karega. Ye aapka faisla hai.

## SmartScreen warning (normal hai)

Installer **code-signed nahi** hai, isliye Windows pehli baar "Windows protected your PC" dikha sakta hai.
**More info > Run anyway** dabao. Ye har naye, unsigned software ke saath hota hai.
Isse hatane ke liye code-signing certificate lena padta hai (paid, har saal). Shuru me zaroori nahi hai.

Dusre logon ko dene se pehle `.sha256.txt` ka hash bhi share kar do, taki wo file verify kar sakein.

## Naya version release karna

1. `client/app/version.json` me version badhao (jaise `1.1.0`).
2. Naya installer build karo.
3. Server `config.php` me `latest_client` = `1.1.0`, `download_url` = installer ka link, `notice` = ek line.
4. Ab sabke desktop app me "TaskDesk 1.1.0 is available" banner aayega, Download button ke saath.
5. Purana version bilkul band karna ho (zaroori security fix) to `min_client` bhi `1.1.0` kar do.
6. Users naya installer chalate hain. **Data nahi jaata**, kyunki data `%LOCALAPPDATA%\TaskDesk` me hai aur installer use chhoota nahi.

## Test karne ke liye bina installer ke

`Run_From_Source.bat` double-click karo (PC par Python 3.8+ chahiye). Ye source se hi app chala deta hai.

## Uninstall

Windows Settings > Apps > TaskDesk > Uninstall. Aapka data aur cloud account safe rehte hain.
Local data bhi hatana ho to TaskDesk me **Sign out** dialog me "Also remove the copy of my data from this PC" tick karo.

## Jo yahan test nahi hua (honest list)

Ye pura system Linux par real PHP server, real browser aur do simulated PCs ke saath test hua hai.
Lekin **Windows installer, Windows DPAPI (session encryption) aur embeddable Python path** yahan Windows na hone ki wajah se chalaye nahi ja sake.
Pehle build ke baad ek saaf PC par install karke ye check karo:

1. Install ho jaye, **desktop par TaskDesk icon aaye**, double-click par login / create account screen khule (koi Server option na dikhe).
2. Register, phir band karo, phir dobara kholo. Login mangna nahi chahiye.
3. Sign out karo, login screen wapas aani chahiye.
4. Ek task banao, file attach karo, phir neeche left me sync chip "Saved, ..." (green) dikhna chahiye.

Agar kuch fail ho to `%LOCALAPPDATA%\TaskDesk\logs` ki files bhej dena.
