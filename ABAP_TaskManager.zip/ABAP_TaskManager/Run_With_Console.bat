@echo off
rem Starts the server in this window so you can see messages. Use it only if the normal icon does not work.
cd /d "%~dp0"
where py >nul 2>nul && (set PYCMD=py -3) || (set PYCMD=python)
start "" "http://127.0.0.1:8765/"
%PYCMD% server.py --port 8765
echo.
echo The server has stopped.
pause
