# ABAP Task Manager

Local PC par chalne wala task manager, specially ek ABAP developer ke liye.
Internet ya database install karne ki zaroorat nahi. Sab kuch isi folder ke `data` me save hota hai.

---

## 1. Pehli baar setup (5 minute)

1. **Python 3.8 ya naya** hona chahiye. Check: Command Prompt me `python --version`.
   Nahi hai to https://www.python.org/downloads/ se install karo, aur installer me **"Add python.exe to PATH"** tick karo.
2. Poora `ABAP_TaskManager` folder kisi bhi jagah rakho, jaise `D:\ABAP_TaskManager`.
   (Zip ho to pehle **Extract All** karo, zip ke andar se mat chalao.)
3. `Create_Desktop_Icon.bat` par double-click karo. Desktop par **ABAP Task Manager** icon ban jayega.
4. Us icon par double-click karo. 2-3 second me dashboard ek alag window me khul jayega.

Window band karne ke kuch minute baad server apne aap band ho jata hai. Settings me "Stop the app" se turant bhi band kar sakte ho.

Pehli baar dashboard khaali hoga. **Settings > Load sample tasks** se example tasks dekh sakte ho, phir **Remove sample tasks** se hata do.

---

## 2. Naya task kaise add karein

**New task** button (ya keyboard par `N`):

1. **Type** chuno: Report, Screen, Smartform, BDC, Enhancement, Interface, Issue ya Other. Phir **New** ya **Change in existing object**, aur module (MM, PP, SD...).
2. **Ready template** se shuru karo (44 templates: Stock Ageing, GRN Register, PO Print, BOM Upload, Gate Pass...). Ye selection fields, output columns, logic aur tables bhar deta hai. Template na chahiye to blank chhodo.
3. **Requested by**: module ke hisaab se naam khud aa jata hai (MM = Kashish Khandelwal, PP = Uday Sir). Badal sakte ho.
4. **Dates**: received, start, due. `1 week`, `2 weeks` buttons se due date jaldi set hoti hai.
5. **How long will it take?** par click karo: type, complexity aur extras (Excel download, authorisation, barcode...) se estimate hours nikalta hai.
6. Kashish ka bheja hua **Excel / images** yahin drop kar do. Wo task ke apne folder me save ho jate hain.

**Create task** ke baad task ka Requirement page khulta hai.

### Requirement page (analysis)
Har section me **Suggestions** button hai: us type aur module ke liye common points ek click me add hote hain.

- Selection screen fields, Output columns, Business logic, Validations, Authorization checks
- Tables / FMs / BAPIs / exits (module ke hisaab se suggest hote hain)
- Test scenarios
- **Questions to requester** (user se kya poochna hai) aur unke jawab
- **Paste list**: Excel se columns copy karke ek saath add karo
- **From Excel**: upload ki hui requirement Excel ki header row ko output columns bana do
- **Change in existing object** me: existing program/T-code, "what to change" points (tick karke done), aur **backup guide**

---

## 3. Task ke andar ke tabs

| Tab | Kya hai |
|---|---|
| Overview | Type, module, kisne bola, kisko date di, dates, estimate hours, progress (auto ya manual) |
| Requirement | Upar wala analysis page |
| Checklist | Steps. Tick karne se progress bar badhta hai |
| Files | Reference images, Excel, **Backup**, documents, test evidence. `Ctrl+V` se screenshot seedha paste hota hai |
| Release & quality | Transport (DEV / QAS / PRD, TR number, date), **quality points** (user ne testing me kya badalne ko kaha), **production ke baad problems** |
| Dev info | T-code, program name, package, version, tables, kya banaya, kaise use karein |
| Time & notes | Kitne ghante lage, notes aur poori activity history |

**Backup:** Existing report/screen/form badalne se pehle Files tab me category "Backup" chuno aur source (.txt), smartform (.xml) wagairah upload karo. Version/note likh sakte ho. Har task ka alag folder banta hai.

---

## 4. Priority aur "pehle kya banana hai"

Dashboard ka **Develop next** list ye cheezein dekhkar rank karta hai: priority, due date, kitne din se wait kar raha hai, aur open quality points.

Urgency light:

| Light | Matlab |
|---|---|
| Lal diamond: Overdue | Due date nikal gayi |
| Orange diamond: Not enough time | Bacha hua kaam > due date tak ka working time. Date badalni padegi ya help leni padegi |
| Orange: Due today / tomorrow | Urgent |
| Amber: N days left | Warning (Settings me din badal sakte ho) |
| Green: N days left | Theek hai |

"Not enough time" ke liye **Settings** me apne productive ghante (default 6/din) aur working days (default Mon-Sat) sahi rakho. Dashboard ka **This week** panel batata hai ki is hafte ka kaam tumhare time me aata hai ya nahi.

---

## 5. History aur Register (future ke liye)

- **History > Completed work**: kya kya ho gaya, kab production me gaya, production ke baad koi problem aayi ya nahi, estimate vs actual time.
- **Register**: har banayi hui cheez ka T-code, program name, kya karta hai. Search karo, ek click me T-code copy karo. Jo finished task me T-code ya naam missing hai, wahan "missing" dikhta hai.
- **Quality**: sab tasks ke open quality points aur production problems ek jagah.
- **Settings > Export everything to Excel**: tasks, register, transports, issues, time log, requirement points, 6 sheets.

---

## 6. Data kahan hai

Sab `ABAP_TaskManager\data` me:

```
data\taskmanager.db                 <- saare tasks, history (SQLite)
data\files\T-0007_Stock_Ageing\
    1_Reference_Images\
    2_Excel_Requirement\
    3_Backup\
    4_Documents\
    5_Test_Evidence\
    6_Other\
data\backups\                       <- har din automatic database backup (last 30)
data\trash\                         <- delete ki hui files / tasks yahan jaati hain
data\server.log                     <- problem ho to yahan dekho
```

- Task ke andar **Task folder** button se Explorer me wo folder khul jata hai.
- **Naye PC par le jana:** poora `ABAP_TaskManager` folder copy kar do (data samet).
- **Dhyan:** `data` folder ka kabhi kabhi copy pen drive / OneDrive par rakh lo. Ye tumhara asli kaam hai.

---

## 7. Keyboard shortcuts

| Key | Kaam |
|---|---|
| `N` | New task |
| `Ctrl+K` ya `/` | Search (task, code, T-code, program, naam) |
| `Esc` | Task window band |
| `Ctrl+Enter` | New task form me Create |
| `Ctrl+V` | Task ke andar screenshot paste (image reference me save) |

---

## 8. Problem aaye to

| Problem | Kya karein |
|---|---|
| "Python was not found" | Python install karo, "Add to PATH" tick karke (step 1) |
| Icon dabane par kuch nahi khulta | `Run_With_Console.bat` chalao. Jo error dikhe wo dekho, ya `data\server.log` kholo |
| Page par "server is not running" | Window band karke icon se dobara kholo |
| Port busy | App 8765 se 8775 tak free port khud dhoondhta hai |
| Antivirus / firewall pooche | Ye sirf is PC par (127.0.0.1) chalta hai, bahar se koi nahi jud sakta |

---

## 9. Apne hisaab se badalna

`static\js\kb.js` me SAP knowledge hai: templates, tables, T-codes, BAPIs, exits, questions, estimate hours. Notepad se edit karke apne templates ya naye modules add kar sakte ho. Har item ka format file me dikha hua hai. Save karke browser window refresh (`F5`) karo.

Naam ke default (MM = Kashish Khandelwal, PP = Uday Sir): `kb.js` me last ke paas `moduleOwners` aur `people`.

---

## Files ka map

```
server.py                  backend (Python, SQLite, koi install nahi)
launcher.pyw               server start + window open
Launch_TaskManager.vbs     icon isko chalata hai (console window nahi dikhta)
Create_Desktop_Icon.bat    desktop icon banata hai
Run_With_Console.bat       debugging ke liye
app.ico                    icon
static\                    dashboard (HTML, CSS, JavaScript)
```
