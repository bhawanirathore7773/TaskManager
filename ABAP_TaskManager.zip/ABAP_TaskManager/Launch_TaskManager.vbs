' ABAP Task Manager - starts the app without any console window.
' The desktop icon points to this file. It finds Python by itself.
Option Explicit
Dim sh, fso, dir, launcher, cmds, i, started
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
launcher = """" & dir & "\launcher.pyw"""
sh.CurrentDirectory = dir

' try the Windows "py" launcher first, then pythonw, then python
cmds = Array("pyw -3 ", "pythonw ", "python ")
started = False
On Error Resume Next
For i = 0 To UBound(cmds)
  Err.Clear
  sh.Run cmds(i) & launcher, 0, False
  If Err.Number = 0 Then
    started = True
    Exit For
  End If
Next
On Error GoTo 0

If Not started Then
  MsgBox "Python was not found on this PC." & vbCrLf & vbCrLf & _
         "1. Install Python 3.8 or newer from https://www.python.org/downloads/" & vbCrLf & _
         "2. Tick ""Add python.exe to PATH"" in the installer." & vbCrLf & _
         "3. Open ABAP Task Manager again.", vbExclamation, "ABAP Task Manager"
End If
