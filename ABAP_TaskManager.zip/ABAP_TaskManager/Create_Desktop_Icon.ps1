# Creates the "ABAP Task Manager" icon on the Desktop (and in the Start menu).
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$vbs  = Join-Path $here 'Launch_TaskManager.vbs'
$ico  = Join-Path $here 'app.ico'
$ws   = New-Object -ComObject WScript.Shell

function New-Shortcut($folder) {
    if (-not (Test-Path $folder)) { return $null }
    $path = Join-Path $folder 'ABAP Task Manager.lnk'
    $lnk = $ws.CreateShortcut($path)
    $lnk.TargetPath       = Join-Path $env:WINDIR 'System32\wscript.exe'
    $lnk.Arguments        = '"' + $vbs + '"'
    $lnk.WorkingDirectory = $here
    $lnk.Description      = 'ABAP Task Manager'
    if (Test-Path $ico) { $lnk.IconLocation = $ico }
    $lnk.Save()
    return $path
}

$desktop = [Environment]::GetFolderPath('Desktop')
$start   = [Environment]::GetFolderPath('Programs')
$a = New-Shortcut $desktop
$b = New-Shortcut $start
if ($a) { Write-Host "Desktop icon created: $a" }
if ($b) { Write-Host "Start menu entry created: $b" }
Write-Host ''
Write-Host 'Done. Double-click "ABAP Task Manager" on your desktop to start.'
