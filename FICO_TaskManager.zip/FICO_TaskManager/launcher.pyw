# -*- coding: utf-8 -*-
"""
FICO Task Manager launcher (double-click / desktop icon).

1. If the local server is already running, just open the window.
2. Otherwise start server.py in the background (no black console window).
3. Open the dashboard in an app-style window (Edge / Chrome without tabs and address bar).

The server stops by itself a few minutes after the window is closed.
"""
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser

APP_DIR = os.path.dirname(os.path.abspath(__file__))
SERVER = os.path.join(APP_DIR, 'server.py')
DATA = os.environ.get('FICO_TM_DATA') or os.path.join(APP_DIR, 'data')   # same rule as server.py
LOG = os.path.join(DATA, 'server.log')
PORTS = list(range(8780, 8791))
IDLE_EXIT_SECONDS = 600


def message(title, text):
    """Show an error to the user even when there is no console (pythonw)."""
    try:
        if os.name == 'nt':
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, text, title, 0x10)
            return
    except Exception:
        pass
    sys.stderr.write('%s\n%s\n' % (title, text))


def ping(port):
    try:
        with urllib.request.urlopen('http://127.0.0.1:%d/api/ping' % port, timeout=1.5) as r:
            return json.loads(r.read().decode('utf-8')).get('app') == 'fico-task-manager'
    except Exception:
        return False


def port_free(port):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(('127.0.0.1', port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def server_python():
    exe = sys.executable
    if os.name == 'nt':
        w = os.path.join(os.path.dirname(exe), 'pythonw.exe')
        if os.path.exists(w):
            return w
    return exe


def start_server(port):
    os.makedirs(DATA, exist_ok=True)
    log = open(LOG, 'a', encoding='utf-8', errors='replace')
    log.write('\n--- start %s on port %d ---\n' % (time.strftime('%Y-%m-%d %H:%M:%S'), port))
    log.flush()
    kw = {}
    if os.name == 'nt':
        kw['creationflags'] = 0x08000000 | 0x00000200      # CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP
    else:
        kw['start_new_session'] = True
    subprocess.Popen([server_python(), SERVER, '--port', str(port), '--idle-exit', str(IDLE_EXIT_SECONDS)],
                     cwd=APP_DIR, stdout=log, stderr=log, stdin=subprocess.DEVNULL, **kw)


def browsers():
    found = []
    if os.name == 'nt':
        for key in ('PROGRAMFILES', 'PROGRAMFILES(X86)', 'LOCALAPPDATA'):
            base = os.environ.get(key)
            if not base:
                continue
            found.append(os.path.join(base, 'Microsoft', 'Edge', 'Application', 'msedge.exe'))
            found.append(os.path.join(base, 'Google', 'Chrome', 'Application', 'chrome.exe'))
    elif sys.platform == 'darwin':
        found += ['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge']
    else:
        for n in ('google-chrome', 'chromium', 'chromium-browser', 'microsoft-edge'):
            p = shutil.which(n)
            if p:
                found.append(p)
    return [p for p in found if os.path.exists(p)]


def open_window(url):
    for exe in browsers():
        try:
            subprocess.Popen([exe, '--app=' + url, '--window-size=1400,880'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL)
            return
        except Exception:
            continue
    webbrowser.open(url)        # normal browser tab as the fallback


def main():
    port = next((p for p in PORTS if ping(p)), None)
    if port is None:
        port = next((p for p in PORTS if port_free(p)), None)
        if port is None:
            message('FICO Task Manager', 'No free port found between %d and %d.\nClose other local servers and try again.' % (PORTS[0], PORTS[-1]))
            return 1
        start_server(port)
        for _ in range(80):             # wait up to 20 seconds
            if ping(port):
                break
            time.sleep(0.25)
        else:
            message('FICO Task Manager could not start',
                    'The local server did not answer.\n\nCheck that Python 3.8 or newer is installed, then look at this log:\n%s' % LOG)
            return 1
    url = 'http://127.0.0.1:%d/' % port
    if os.environ.get('FICO_TM_NO_BROWSER'):
        print(url)
        return 0
    open_window(url)
    return 0


if __name__ == '__main__':
    sys.exit(main())
