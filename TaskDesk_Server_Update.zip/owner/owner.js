/* TaskDesk owner site. Plain JavaScript, no external files. Everything that comes from the server is put on the page with
   textContent (never as HTML), so a name like <script> is only ever shown as text. */
(function () {
  'use strict';

  var API = '../api.php';
  var S = { owner: null, users: { q: '', module: '', status: '', page: 1, per: 25 }, settings: null, pending: 0 };
  var root = document.getElementById('app');

  /* ---------- tiny helpers ---------- */
  function h(tag, attrs) {
    var el = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) return;
        if (k === 'class') el.className = v;
        else if (k === 'text') el.textContent = v;
        else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
        else if (k === 'value') el.value = v;
        else if (k === 'checked' || k === 'disabled' || k === 'selected') el[k] = !!v;
        else el.setAttribute(k, v === true ? '' : v);
      });
    }
    for (var i = 2; i < arguments.length; i++) add(el, arguments[i]);
    return el;
  }
  function add(el, c) {
    if (c === null || c === undefined || c === false) return;
    if (Array.isArray(c)) c.forEach(function (x) { add(el, x); });
    else if (c instanceof Node) el.appendChild(c);
    else el.appendChild(document.createTextNode(String(c)));
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
  function svg(path) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('fill', 'none'); s.setAttribute('stroke', 'currentColor');
    s.setAttribute('stroke-width', '1.8'); s.setAttribute('stroke-linecap', 'round'); s.setAttribute('stroke-linejoin', 'round');
    var p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', path); s.appendChild(p);
    return s;
  }
  var ICON = {
    dash: 'M4 13h6V4H4v9zm0 7h6v-5H4v5zm10 0h6V11h-6v9zm0-16v5h6V4h-6z',
    users: 'M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0zM4 20c0-3.3 3.6-5 8-5s8 1.7 8 5',
    set: 'M4 7h10M18 7h2M4 17h2M10 17h10M14 4v6M6 14v6',
    srv: 'M4 5h16v6H4zM4 13h16v6H4zM8 8h.01M8 16h.01',
    log: 'M7 4h10a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1zm2 4h6M9 12h6M9 16h4',
    me: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm-8 8a8 8 0 0 1 16 0'
  };
  var MOD_NAME = { abap: 'ABAP Developer', fico: 'FICO Consultant', mm: 'MM Consultant', basis: 'SAP BASIS / IT' };

  function utc(s) { return s ? new Date(String(s).replace(' ', 'T') + 'Z') : null; }
  function fmtDate(s) {
    var d = utc(s); if (!d || isNaN(d)) return '-';
    return d.toLocaleDateString(undefined, { day: '2-digit', month: 'short', year: 'numeric' }) + ', ' + d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  }
  function ago(s) {
    var d = utc(s); if (!d || isNaN(d)) return 'Never';
    var m = Math.floor((Date.now() - d.getTime()) / 60000);
    if (m < 1) return 'Just now'; if (m < 60) return m + ' min ago';
    if (m < 1440) return Math.floor(m / 60) + ' h ago';
    if (m < 43200) return Math.floor(m / 1440) + ' days ago';
    return fmtDate(s).split(',')[0];
  }
  function bytes(n) {
    n = Number(n) || 0;
    if (n < 1024) return n + ' B';
    var u = ['KB', 'MB', 'GB', 'TB']; var i = -1;
    do { n /= 1024; i++; } while (n >= 1024 && i < u.length - 1);
    return (n >= 100 ? n.toFixed(0) : n >= 10 ? n.toFixed(1) : n.toFixed(2)) + ' ' + u[i];
  }
  function modName(id) { return MOD_NAME[id] || (id ? id.toUpperCase() : '-'); }
  function modTag(id) { return h('span', { class: 'mod ' + (MOD_NAME[id] ? id : '') }, h('i'), modName(id)); }
  function todayStr() { var d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }

  function statusChip(u) {
    if (u.status === 0) return h('span', { class: 'chip bad', text: 'Blocked' });
    if (u.status === 2) return h('span', { class: 'chip warn', text: 'Waiting for approval' });
    if (u.expires_at && u.expires_at < todayStr()) return h('span', { class: 'chip bad', text: 'Access ended' });
    return h('span', { class: 'chip ok', text: 'Active' });
  }

  var toastTimer = null;
  function toast(msg, bad) {
    var old = document.querySelector('.toast'); if (old) old.remove();
    var t = h('div', { class: 'toast' + (bad ? ' bad' : ''), role: 'status', text: msg });
    document.body.appendChild(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.remove(); }, bad ? 6000 : 3200);
  }
  function copy(text) {
    function done() { toast('Copied'); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, function () { fallback(); });
    else fallback();
    function fallback() {
      var ta = h('textarea', { value: text, style: 'position:fixed;left:-999px' });
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (e) { toast('Select the text and copy it by hand', true); }
      ta.remove();
    }
  }

  /* ---------- server calls ---------- */
  function api(route, opt) {
    opt = opt || {};
    var url = API + '?r=' + route + (opt.query ? '&' + new URLSearchParams(opt.query).toString() : '');
    var init = { method: 'GET', credentials: 'same-origin', cache: 'no-store', headers: { 'X-TD-Owner': '1', 'Accept': 'application/json' } };
    if (opt.body !== undefined) { init.method = 'POST'; init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(opt.body); }
    return fetch(url, init).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (r.status === 401 && d.error === 'owner_not_signed_in' && !opt.quiet) {
          S.owner = null; showLogin(d.message || 'Please sign in.');
        }
        if (!r.ok || d.ok === false) { d.status = r.status; throw d; }
        return d;
      });
    }, function () { throw { error: 'offline', message: 'Cannot reach the server. Check your internet connection.' }; });
  }
  function fail(e) { toast((e && e.message) || 'Something went wrong.', true); }

  /* ---------- dialogs ---------- */
  function dialog(title, body, buttons, opt) {
    var dlg = h('dialog', null,
      h('div', { class: 'dh' }, h('h2', { text: title })),
      h('div', { class: 'db' }, body),
      h('div', { class: 'df' }, buttons || []));
    document.body.appendChild(dlg);
    dlg.addEventListener('close', function () { dlg.remove(); if (opt && opt.onclose) opt.onclose(); });
    dlg.addEventListener('cancel', function () { });
    dlg.showModal();
    return dlg;
  }
  function confirmBox(title, text, okLabel, danger) {
    return new Promise(function (resolve) {
      var dlg;
      var ok = h('button', { class: 'btn ' + (danger ? 'solid-danger' : 'primary'), type: 'button', text: okLabel, onclick: function () { dlg.close(); resolve(true); } });
      var no = h('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: function () { dlg.close(); } });
      dlg = dialog(title, h('p', { text: text, style: 'margin:6px 0 4px' }), [no, ok], { onclose: function () { resolve(false); } });
      no.focus();
    });
  }
  function credentialsBox(title, intro, rows) {
    var list = h('div', { class: 'cred' }, rows.map(function (r) {
      return h('div', { class: 'r' }, h('div', { class: 'k', text: r[0] }), h('div', { class: 'v', text: r[1] }),
        h('button', { class: 'btn small', type: 'button', text: 'Copy', onclick: function () { copy(r[1]); } }));
    }));
    var dlg;
    var all = h('button', { class: 'btn', type: 'button', text: 'Copy all', onclick: function () { copy(rows.map(function (r) { return r[0] + ': ' + r[1]; }).join('\n')); } });
    var done = h('button', { class: 'btn primary', type: 'button', text: 'I have saved this', onclick: function () { dlg.close(); } });
    dlg = dialog(title, [h('p', { text: intro, style: 'margin:6px 0 4px' }), list,
      h('p', { class: 'muted small', text: 'This is shown only once. The server keeps only a scrambled version and cannot show it again.', style: 'margin:6px 0 0' })], [all, done]);
  }

  /* ---------- sign-in ---------- */
  function showLogin(note) {
    document.title = 'Sign in - TaskDesk Owner';
    clear(root);
    var msg = h('div', { class: 'msg bad hidden', role: 'alert' });
    var code = h('div', { class: 'field hidden' }, h('label', { for: 'f-code', text: 'Code from your authenticator app' }),
      h('input', { id: 'f-code', type: 'text', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: 8 }));
    var user = h('input', { id: 'f-user', type: 'text', autocomplete: 'username', autocapitalize: 'none', spellcheck: 'false' });
    var pass = h('input', { id: 'f-pass', type: 'password', autocomplete: 'current-password' });
    var btn = h('button', { class: 'btn primary', type: 'submit', style: 'width:100%', text: 'Sign in' });
    var form = h('form', { novalidate: 'novalidate' }, msg,
      h('div', { class: 'field' }, h('label', { for: 'f-user', text: 'Owner username' }), user),
      h('div', { class: 'field' }, h('label', { for: 'f-pass', text: 'Password' }), pass), code, btn);
    var firstRun = h('div', { class: 'msg info hidden' });
    function show(t, kind) { msg.className = 'msg ' + (kind || 'bad'); msg.textContent = t; }
    if (note) show(note, 'info');
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      msg.className = 'msg bad hidden';
      btn.disabled = true; btn.textContent = 'Signing in...';
      api('owner/login', { quiet: true, body: { username: user.value.trim(), password: pass.value, code: code.querySelector('input').value } })
        .then(function (d) { S.owner = d.username; start(); })
        .catch(function (e) {
          btn.disabled = false; btn.textContent = 'Sign in';
          if (e.error === 'code_required') { code.classList.remove('hidden'); code.querySelector('input').focus(); show(e.message, 'info'); return; }
          show(e.message || 'Could not sign in.');
        });
    });
    root.appendChild(h('div', { class: 'login' }, h('div', { class: 'login-card' },
      h('div', { class: 'brand' }, h('div', { class: 'brand-mark' }, svg('M5 7h14M5 12h14M5 17h8')), h('div', null, h('b', { text: 'TaskDesk Owner' }), h('span', { text: 'Manage users, access and settings' }))),
      firstRun, form)));
    user.focus();
    api('owner/status', { quiet: true }).then(function (d) {
      if (!d.configured) {
        firstRun.className = 'msg warn';
        firstRun.textContent = 'No owner account exists on this server yet. A new install creates it in setup.php. On a server that was set up earlier, put a file named owner_reset.txt in the storage folder (line 1: username, line 2: password of 10+ characters) and reload this page.';
      }
    }).catch(function () { });
  }

  /* ---------- frame ---------- */
  var ROUTES = [
    ['dashboard', 'Dashboard', ICON.dash], ['users', 'Users', ICON.users], ['settings', 'Settings', ICON.set],
    ['server', 'Server and updates', ICON.srv], ['audit', 'Activity log', ICON.log], ['account', 'Owner account', ICON.me]
  ];
  var titleEl, pageEl, navEl;

  function frame() {
    clear(root);
    navEl = h('nav', { 'aria-label': 'Owner site' }, ROUTES.map(function (r) {
      return h('a', { href: '#/' + r[0], 'data-r': r[0] }, svg(r[2]), h('span', { text: r[1] }), r[0] === 'users' ? h('span', { class: 'count hidden', id: 'pend-count', title: 'Accounts waiting for approval' }) : null);
    }));
    titleEl = h('h1', { text: '' });
    pageEl = h('div', { class: 'page', tabindex: '-1' });
    root.appendChild(h('div', { class: 'shell' },
      h('aside', { class: 'rail' },
        h('div', { class: 'brand' }, h('div', { class: 'brand-mark' }, svg('M5 7h14M5 12h14M5 17h8')), h('div', null, h('b', { text: 'TaskDesk' }), h('span', { text: 'Owner site' }))),
        navEl,
        h('div', { class: 'rail-foot' }, 'Signed in as ', h('b', { text: S.owner || '' }))),
      h('div', { class: 'main' },
        h('header', { class: 'topbar' }, titleEl, h('div', { class: 'sp' }),
          h('button', { class: 'btn small', type: 'button', text: 'Sign out', onclick: signOut })),
        pageEl)));
  }
  function signOut() {
    api('owner/logout', { body: {}, quiet: true }).catch(function () { }).then(function () { S.owner = null; showLogin('You are signed out.'); });
  }
  function setPending(n) {
    S.pending = n;
    var c = document.getElementById('pend-count');
    if (c) { c.textContent = n; c.classList.toggle('hidden', !n); }
  }

  function route() {
    var name = (location.hash.replace(/^#\//, '').split('?')[0]) || 'dashboard';
    if (!ROUTES.some(function (r) { return r[0] === name; })) name = 'dashboard';
    var def = ROUTES.filter(function (r) { return r[0] === name; })[0];
    Array.prototype.forEach.call(navEl.querySelectorAll('a'), function (a) {
      if (a.getAttribute('data-r') === name) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    titleEl.textContent = def[1];
    document.title = def[1] + ' - TaskDesk Owner';
    clear(pageEl);
    pageEl.scrollTop = 0;
    var inner = h('div', { class: 'page-inner' });
    pageEl.appendChild(inner);
    ({ dashboard: viewDashboard, users: viewUsers, settings: viewSettings, server: viewServer, audit: viewAudit, account: viewAccount })[name](inner);
  }

  function loading(el) { clear(el); el.appendChild(h('p', { class: 'muted', text: 'Loading...' })); }

  /* ---------- dashboard ---------- */
  function viewDashboard(el) {
    loading(el);
    api('owner/dashboard').then(function (d) {
      setPending(d.by_status.pending);
      clear(el);
      function stat(v, l, href, attn) { return h('div', { class: 'stat' + (attn ? ' attn' : '') }, h('a', { href: href || '#/dashboard' }, h('div', { class: 'v', text: v }), h('div', { class: 'l', text: l }))); }
      el.appendChild(h('div', { class: 'stats' },
        stat(d.users, 'Users', '#/users'),
        stat(d.by_status.active, 'Active', '#/users'),
        stat(d.by_status.pending, 'Waiting for approval', '#/users', d.by_status.pending > 0),
        stat(d.by_status.blocked, 'Blocked', '#/users'),
        stat(d.signed_in_24h, 'Signed in, last 24 h'),
        stat(d.new_7d, 'New, last 7 days'),
        stat(bytes(d.bytes_used), 'Cloud storage used'),
        stat(d.devices, 'Signed-in devices')));
      if (d.expiring_7d) el.appendChild(h('div', { class: 'msg warn', text: d.expiring_7d + ' account' + (d.expiring_7d > 1 ? 's' : '') + ' will lose access within 7 days. Check the Users list.' }));
      var total = Math.max(1, d.users);
      var mods = Object.keys(d.by_module).sort();
      el.appendChild(h('div', { class: 'grid2' },
        h('div', { class: 'card' }, h('h2', { text: 'Users by module' }), h('p', { class: 'lede', text: 'Which edition each account uses.' }),
          mods.length ? h('div', { class: 'bars' }, mods.map(function (m) {
            var col = { abap: 'var(--abap)', fico: 'var(--fico)', mm: 'var(--mm)', basis: 'var(--basis)' }[m] || 'var(--other)';
            return h('div', { class: 'row' }, modTag(m), h('div', { class: 'track' }, h('div', { class: 'fill', style: 'width:' + Math.round(d.by_module[m] * 100 / total) + '%;background:' + col })), h('div', { class: 'num', text: d.by_module[m] }));
          })) : h('p', { class: 'muted', text: 'No users yet.' })),
        h('div', { class: 'card' }, h('h2', { text: 'Server health' }), h('p', { class: 'lede', text: 'What the owner site can see about this server.' }),
          h('ul', { class: 'checks' },
            healthRow('PHP', d.server.php, true),
            healthRow('Database', d.server.database === 'sqlite' ? 'SQLite (test)' : 'MySQL', true),
            healthRow('Secure connection (https)', d.server.https ? 'Yes' : 'No: set up SSL and Force HTTPS in hPanel', d.server.https),
            healthRow('File storage', d.server.storage_writable ? 'Writable' : 'Not writable', d.server.storage_writable),
            healthRow('Free disk space', d.server.disk_free === null ? 'Unknown' : bytes(d.server.disk_free), true),
            healthRow('Biggest file accepted', d.server.max_file_mb + ' MB', d.server.max_file_mb >= 20),
            healthRow('Files stored', d.files, true),
            healthRow('Server version', d.server.server_version, true)))));
    }).catch(function (e) { clear(el); el.appendChild(h('div', { class: 'msg bad', text: e.message || 'Could not load.' })); });
  }
  function healthRow(k, v, ok) {
    return h('li', null, h('span', { class: 'k', text: k }), h('span', { class: ok ? '' : 'chip warn', text: String(v) }));
  }

  /* ---------- users ---------- */
  var searchTimer = null;
  function viewUsers(el) {
    var q = S.users;
    var search = h('input', { type: 'search', placeholder: 'Search name or username', value: q.q, 'aria-label': 'Search users' });
    var mod = h('select', { 'aria-label': 'Module' }, h('option', { value: '', text: 'All modules' }),
      Object.keys(MOD_NAME).map(function (m) { return h('option', { value: m, text: MOD_NAME[m], selected: q.module === m }); }));
    var stat = h('select', { 'aria-label': 'Status' }, h('option', { value: '', text: 'Any status' }),
      h('option', { value: '1', text: 'Active', selected: q.status === '1' }), h('option', { value: '2', text: 'Waiting for approval', selected: q.status === '2' }),
      h('option', { value: '0', text: 'Blocked', selected: q.status === '0' }));
    var body = h('div');
    function reload() { q.page = 1; load(); }
    search.addEventListener('input', function () { clearTimeout(searchTimer); searchTimer = setTimeout(function () { q.q = search.value.trim(); reload(); }, 250); });
    mod.addEventListener('change', function () { q.module = mod.value; reload(); });
    stat.addEventListener('change', function () { q.status = stat.value; reload(); });
    el.appendChild(h('div', { class: 'toolbar' }, search, mod, stat, h('div', { class: 'sp' }),
      h('button', { class: 'btn primary', type: 'button', text: 'Add user', onclick: function () { addUser(load); } })));
    el.appendChild(body);

    function load() {
      var query = { page: q.page, per: q.per };
      if (q.q) query.q = q.q; if (q.module) query.module = q.module; if (q.status !== '') query.status = q.status;
      api('owner/users', { query: query }).then(function (d) {
        clear(body);
        if (!d.users.length) {
          body.appendChild(h('div', { class: 'tablewrap' }, h('div', { class: 'empty' }, q.q || q.module || q.status !== '' ? 'No user matches this search.' : 'No users yet. Add the first one with the button above, or share the installer so people can create their own account.')));
          return;
        }
        var rows = d.users.map(function (u) {
          var pct = Math.min(100, Math.round(u.bytes_used * 100 / (u.quota_effective_mb * 1048576)));
          var tr = h('tr', { class: 'click', tabindex: '0', onclick: function () { openUser(u.id, load); }, onkeydown: function (ev) { if (ev.key === 'Enter') openUser(u.id, load); } },
            h('td', null, h('div', { class: 'nm' }, h('b', { text: u.display_name }), h('span', { text: '@' + u.username + (u.created_by === 'owner' ? '  (added by you)' : '') }))),
            h('td', null, modTag(u.module)),
            h('td', null, statusChip(u), u.expires_at ? h('div', { class: 'muted small', text: 'Until ' + u.expires_at }) : null),
            h('td', null, h('span', { text: ago(u.last_login), title: fmtDate(u.last_login) })),
            h('td', null, h('div', { class: 'meter' }, h('span', { class: 'small num', text: bytes(u.bytes_used) + ' of ' + u.quota_effective_mb + ' MB' }), h('div', { class: 'track' }, h('div', { class: 'fill' + (pct > 85 ? ' hi' : ''), style: 'width:' + pct + '%' })))),
            h('td', { class: 'num', text: u.devices }));
          return tr;
        });
        body.appendChild(h('div', { class: 'tablewrap' }, h('table', null,
          h('thead', null, h('tr', null, ['User', 'Module', 'Status', 'Last sign-in', 'Storage', 'Devices'].map(function (t) { return h('th', { text: t }); }))),
          h('tbody', null, rows))));
        var pages = Math.max(1, Math.ceil(d.total / d.per));
        body.appendChild(h('div', { class: 'pager' }, h('span', { class: 'num', text: d.total + ' user' + (d.total === 1 ? '' : 's') }),
          h('button', { class: 'btn small', type: 'button', text: 'Previous', disabled: d.page <= 1, onclick: function () { q.page--; load(); } }),
          h('span', { class: 'num', text: 'Page ' + d.page + ' of ' + pages }),
          h('button', { class: 'btn small', type: 'button', text: 'Next', disabled: d.page >= pages, onclick: function () { q.page++; load(); } })));
      }).catch(function (e) { clear(body); body.appendChild(h('div', { class: 'msg bad', text: e.message || 'Could not load users.' })); });
    }
    load();
    api('owner/dashboard', { quiet: true }).then(function (d) { setPending(d.by_status.pending); }).catch(function () { });
  }

  function addUser(done) {
    var mods = (S.settings && S.settings.settings.modules) || Object.keys(MOD_NAME);
    var f = {
      username: h('input', { type: 'text', autocomplete: 'off', autocapitalize: 'none', spellcheck: 'false' }),
      name: h('input', { type: 'text', autocomplete: 'off' }),
      module: h('select', null, mods.map(function (m) { return h('option', { value: m, text: modName(m) }); })),
      password: h('input', { type: 'text', autocomplete: 'off', placeholder: 'Leave empty to create one' }),
      until: h('input', { type: 'date', min: todayStr() })
    };
    var err = h('div', { class: 'msg bad hidden', role: 'alert' });
    function field(label, input, hint) { return h('div', { class: 'field' }, h('label', { text: label }), input, hint ? h('div', { class: 'hint', text: hint }) : null); }
    var dlg;
    var save = h('button', { class: 'btn primary', type: 'button', text: 'Create user', onclick: function () {
      err.className = 'msg bad hidden'; save.disabled = true;
      api('owner/user/create', { body: { username: f.username.value, display_name: f.name.value, module: f.module.value, password: f.password.value, expires_at: f.until.value } })
        .then(function (d) {
          dlg.close(); done && done();
          credentialsBox('User created', 'Give these details to ' + d.user.display_name + '. They sign in with the installed TaskDesk and are asked to choose their own password.',
            [['Username', d.user.username], ['Temporary password', d.password], ['Recovery key', d.recovery_key]]);
        }).catch(function (e) { save.disabled = false; err.textContent = e.message || 'Could not create the user.'; err.className = 'msg bad'; });
    } });
    dlg = dialog('Add a user', [err, field('Username', f.username, '3 to 32 letters, numbers, dot, dash or underscore'), field('Full name', f.name), field('Module', f.module),
      field('Temporary password', f.password, 'The user must change it at the first sign-in.'), field('Access until (optional)', f.until, 'After this day the account stops working.')],
      [h('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: function () { dlg.close(); } }), save]);
    f.username.focus();
  }

  function openUser(id, done) {
    var scrim = h('div', { class: 'scrim' });
    var drawer = h('aside', { class: 'drawer', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'User details' });
    function close() { scrim.remove(); drawer.remove(); document.removeEventListener('keydown', esc); }
    function esc(ev) { if (ev.key === 'Escape' && !document.querySelector('dialog[open]')) close(); }
    scrim.addEventListener('click', close);
    document.addEventListener('keydown', esc);
    document.body.appendChild(scrim); document.body.appendChild(drawer);
    drawer.appendChild(h('div', { class: 'body' }, h('p', { class: 'muted', text: 'Loading...' })));

    function render(d) {
      var u = d.user, st = u.status;
      var f = {
        name: h('input', { type: 'text', value: u.display_name, maxlength: 80 }),
        module: h('select', null, moduleChoices(u.module).map(function (m) { return h('option', { value: m, text: modName(m), selected: m === u.module }); })),
        until: h('input', { type: 'date', value: u.expires_at || '' }),
        upload: h('input', { type: 'checkbox', checked: u.can_upload, id: 'u-up' }),
        quota: h('input', { type: 'number', min: 1, value: u.quota_mb === null ? '' : u.quota_mb, placeholder: 'Server default (' + u.quota_effective_mb + ')' }),
        maxfile: h('input', { type: 'number', min: 1, value: u.max_file_mb === null ? '' : u.max_file_mb, placeholder: 'Server default (' + u.max_file_effective_mb + ')' }),
        note: h('textarea', { maxlength: 255, value: u.note, placeholder: 'Only you see this' })
      };
      var statusBtns = {};
      function setStatus(v) { st = v; Object.keys(statusBtns).forEach(function (k) { statusBtns[k].setAttribute('aria-pressed', String(Number(k) === v)); }); }
      var seg = h('div', { class: 'seg', role: 'group', 'aria-label': 'Status' },
        [[1, 'Active', 'ok'], [0, 'Blocked', 'bad'], [2, 'Waiting', 'warn']].map(function (s) {
          var b = h('button', { type: 'button', class: s[2], 'aria-pressed': String(st === s[0]), text: s[1], onclick: function () { setStatus(s[0]); } });
          statusBtns[s[0]] = b; return b;
        }));
      var err = h('div', { class: 'msg bad hidden', role: 'alert' });
      var save = h('button', { class: 'btn primary', type: 'button', text: 'Save changes', onclick: function () {
        err.className = 'msg bad hidden'; save.disabled = true;
        api('owner/user/save', { body: { id: u.id, display_name: f.name.value, status: st, module: f.module.value, expires_at: f.until.value, can_upload: f.upload.checked, quota_mb: f.quota.value === '' ? 0 : Number(f.quota.value), max_file_mb: f.maxfile.value === '' ? 0 : Number(f.maxfile.value), note: f.note.value } })
          .then(function () { toast('Saved'); done && done(); return api('owner/user', { query: { id: u.id } }); })
          .then(function (nd) { render(nd); })
          .catch(function (e) { save.disabled = false; err.textContent = e.message || 'Could not save.'; err.className = 'msg bad'; drawer.querySelector('.body').scrollTop = 0; });
      } });
      function field(label, input, hint) { return h('div', { class: 'field' }, h('label', { text: label }), input, hint ? h('div', { class: 'hint', text: hint }) : null); }

      var devices = d.devices.length ? h('ul', { class: 'devices' }, d.devices.map(function (dv) {
        return h('li', null, h('div', { class: 'd' }, h('b', { text: dv.device }), h('span', { class: 'muted small', text: 'Last used ' + ago(dv.last_used) })),
          h('button', { class: 'btn small', type: 'button', text: 'Sign out', onclick: function () {
            api('owner/user/signout', { body: { id: u.id, token_id: dv.id } }).then(function () { toast('Device signed out'); done && done(); return api('owner/user', { query: { id: u.id } }); }).then(render).catch(fail);
          } }));
      })) : h('p', { class: 'muted', text: 'Not signed in on any device.' });

      clear(drawer);
      drawer.appendChild(h('header', null, h('div', null, h('h2', { text: u.display_name }), h('div', { class: 'muted' }, '@' + u.username, '  ', statusChip(u))), h('button', { class: 'x', type: 'button', 'aria-label': 'Close', text: '×', onclick: close })));
      drawer.appendChild(h('div', { class: 'body' }, err,
        h('div', { class: 'sec' }, h('h3', { text: 'Account' }),
          field('Full name', f.name),
          h('div', { class: 'grid2' }, field('Module', f.module, d.user.rev > 0 ? 'Can only change while the account is empty.' : 'Which edition opens when this user signs in.'),
            h('div', { class: 'field' }, h('label', { text: 'Status' }), seg)),
          h('p', { class: 'muted small', style: 'margin:0', text: 'Created ' + fmtDate(u.created_at) + (u.created_by === 'owner' ? ' by you' : '') + '. Last sign-in ' + (u.last_login ? fmtDate(u.last_login) : 'never') + '.' })),
        h('div', { class: 'sec' }, h('h3', { text: 'Access and limits' }),
          field('Access until', f.until, 'Empty means no end date. The account stops working after that day.'),
          h('div', { class: 'field' }, h('div', { class: 'switch' }, f.upload, h('label', { for: 'u-up', style: 'margin:0;font-weight:600', text: 'Can upload files' })), h('div', { class: 'hint', text: 'When off, tasks still sync but attachments stay on the PC only.' })),
          h('div', { class: 'grid2' }, field('Storage limit (MB)', f.quota, bytes(u.bytes_used) + ' used so far'), field('Biggest file (MB)', f.maxfile)),
          field('Your note', f.note)),
        h('div', { class: 'sec' }, h('h3', { text: 'Data' }),
          h('p', { class: 'muted', style: 'margin:0', text: d.records + ' records and ' + d.files + ' files are stored for this user.' })),
        h('div', { class: 'sec' }, h('h3', { text: 'Signed-in devices' }), devices,
          d.devices.length > 1 ? h('p', { style: 'margin:10px 0 0' }, h('button', { class: 'btn small', type: 'button', text: 'Sign out all devices', onclick: function () {
            api('owner/user/signout', { body: { id: u.id } }).then(function () { toast('All devices signed out'); done && done(); return api('owner/user', { query: { id: u.id } }); }).then(render).catch(fail);
          } })) : null),
        h('div', { class: 'sec' }, h('h3', { text: 'Help the user' }),
          h('div', { class: 'actions', style: 'display:flex;gap:10px;flex-wrap:wrap' },
            h('button', { class: 'btn', type: 'button', text: 'Set a temporary password', onclick: function () {
              confirmBox('Set a temporary password?', 'The user is signed out everywhere and must choose a new password at the next sign-in.', 'Set password').then(function (ok) {
                if (!ok) return;
                api('owner/user/reset_password', { body: { id: u.id } }).then(function (r) {
                  done && done(); credentialsBox('Temporary password', 'Give this to ' + u.display_name + '.', [['Username', u.username], ['Temporary password', r.password]]);
                  return api('owner/user', { query: { id: u.id } }).then(render);
                }).catch(fail);
              });
            } }),
            h('button', { class: 'btn', type: 'button', text: 'Issue a new recovery key', onclick: function () {
              confirmBox('Issue a new recovery key?', 'The old recovery key stops working. Use this when the user lost it.', 'Issue key').then(function (ok) {
                if (!ok) return;
                api('owner/user/new_recovery', { body: { id: u.id } }).then(function (r) { credentialsBox('New recovery key', 'Give this to ' + u.display_name + '.', [['Recovery key', r.recovery_key]]); }).catch(fail);
              });
            } }))),
        h('div', { class: 'sec' }, h('h3', { text: 'Delete' }),
          h('p', { class: 'muted', style: 'margin:0 0 10px', text: 'Removes the account, every task and every file of this user from the server. Copies on the user\'s PC are not touched. This cannot be undone.' }),
          h('button', { class: 'btn danger', type: 'button', text: 'Delete this user...', onclick: function () { deleteUser(u, function () { close(); done && done(); }); } }))));
      drawer.appendChild(h('footer', null, save, h('button', { class: 'btn', type: 'button', text: 'Close', onclick: close })));
    }

    (S.settings ? Promise.resolve() : api('owner/settings').then(function (s) { S.settings = s; }).catch(function () { }))
      .then(function () { return api('owner/user', { query: { id: id } }); })
      .then(render).catch(function (e) { fail(e); close(); });
  }

  function moduleChoices(current) {
    var list = ((S.settings && S.settings.settings.modules) || Object.keys(MOD_NAME)).slice();
    if (current && list.indexOf(current) < 0) list.push(current);
    return list;
  }

  function deleteUser(u, after) {
    var inp = h('input', { type: 'text', autocomplete: 'off', placeholder: u.username, 'aria-label': 'Type the username' });
    var err = h('div', { class: 'msg bad hidden' });
    var dlg;
    var go = h('button', { class: 'btn solid-danger', type: 'button', text: 'Delete forever', onclick: function () {
      go.disabled = true;
      api('owner/user/delete', { body: { id: u.id, confirm: inp.value } }).then(function () { dlg.close(); toast('User deleted'); after(); })
        .catch(function (e) { go.disabled = false; err.textContent = e.message || 'Could not delete.'; err.className = 'msg bad'; });
    } });
    dlg = dialog('Delete ' + u.display_name + '?', [err, h('p', { style: 'margin:6px 0 10px', text: 'All tasks and files of this user will be removed from the server. To confirm, type the username below.' }), inp],
      [h('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: function () { dlg.close(); } }), go]);
    inp.focus();
  }

  /* ---------- settings ---------- */
  function loadSettings() { return api('owner/settings').then(function (s) { S.settings = s; return s; }); }
  function saveSettings(body, btn) {
    if (btn) btn.disabled = true;
    return api('owner/settings/save', { body: body }).then(function (s) { S.settings = s; toast('Saved'); if (btn) btn.disabled = false; return s; })
      .catch(function (e) { if (btn) btn.disabled = false; fail(e); throw e; });
  }
  function viewSettings(el) {
    loading(el);
    loadSettings().then(function (s) {
      var c = s.settings;
      clear(el);

      /* new accounts */
      var reg = c.registration;
      var inv = h('input', { type: 'text', value: c.invite_code, autocomplete: 'off', placeholder: 'No invite code' });
      var radios = h('div', { class: 'radios' }, [
        ['open', 'Anyone with the app can create an account', 'People install TaskDesk, press Create account and start at once.'],
        ['approval', 'New accounts wait until you approve them', 'They can register but cannot use the app until you switch them on in Users.'],
        ['closed', 'Nobody can create an account', 'You add every user yourself with the Add user button.']
      ].map(function (r) {
        return h('label', null, h('input', { type: 'radio', name: 'reg', value: r[0], checked: reg === r[0], onchange: function () { reg = r[0]; } }), h('span', null, r[1], h('small', { text: r[2] })));
      }));
      var b1 = h('button', { class: 'btn primary', type: 'button', text: 'Save', onclick: function () { saveSettings({ registration: reg, invite_code: inv.value }, b1); } });
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'New accounts' }), h('p', { class: 'lede', text: 'Decide how people get an account.' }), radios,
        h('div', { class: 'field', style: 'max-width:340px;margin-top:8px' }, h('label', { text: 'Invite code (optional)' }), inv, h('div', { class: 'hint', text: 'If set, people must type this word when they create an account. Not needed when you approve accounts yourself.' })),
        h('div', { class: 'actions' }, b1)));

      /* modules */
      var known = Object.keys(s.known_modules);
      var all = known.concat(c.modules.filter(function (m) { return known.indexOf(m) < 0; }));
      var boxes = {};
      var chips = h('div', { class: 'chips-edit' }, all.map(function (m) {
        var inp = h('input', { type: 'checkbox', checked: c.modules.indexOf(m) >= 0 }); boxes[m] = inp;
        return h('label', null, inp, s.known_modules[m] || m);
      }));
      var extra = h('input', { type: 'text', placeholder: 'New module id, for example sd', maxlength: 20, style: 'max-width:240px' });
      var b2 = h('button', { class: 'btn primary', type: 'button', text: 'Save', onclick: function () {
        var list = all.filter(function (m) { return boxes[m].checked; });
        var x = extra.value.trim().toLowerCase(); if (x && list.indexOf(x) < 0) list.push(x);
        saveSettings({ modules: list }, b2).then(function () { route(); }).catch(function () { });
      } });
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'Modules' }), h('p', { class: 'lede', text: 'The editions people may choose when they create an account. A module you add here must also be inside the installer people use.' }),
        chips, h('div', { class: 'field', style: 'margin-top:12px' }, h('label', { text: 'Add a module that is not in the list' }), extra), h('div', { class: 'actions' }, b2)));

      /* limits */
      var q = h('input', { type: 'number', min: 50, value: c.quota_mb }), mf = h('input', { type: 'number', min: 1, value: c.max_file_mb }), td = h('input', { type: 'number', min: 1, max: 3650, value: c.token_days });
      var b3 = h('button', { class: 'btn primary', type: 'button', text: 'Save', onclick: function () { saveSettings({ quota_mb: Number(q.value), max_file_mb: Number(mf.value), token_days: Number(td.value) }, b3).then(function () { route(); }).catch(function () { }); } });
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'Default limits' }), h('p', { class: 'lede', text: 'Apply to everyone. You can give one person more or less on their user page.' }),
        h('div', { class: 'grid3' },
          h('div', { class: 'field' }, h('label', { text: 'Storage per user (MB)' }), q),
          h('div', { class: 'field' }, h('label', { text: 'Biggest file (MB)' }), mf, h('div', { class: 'hint', text: 'This server accepts files up to ' + s.effective_max_file_mb + ' MB at the moment (PHP limit post_max_size).' })),
          h('div', { class: 'field' }, h('label', { text: 'Stay signed in for (days)' }), td, h('div', { class: 'hint', text: 'Counted from the last time the app was used.' }))),
        h('div', { class: 'actions' }, b3)));

      /* maintenance */
      var mt = h('input', { type: 'checkbox', checked: c.maintenance, id: 'mt' });
      var mm = h('input', { type: 'text', value: c.maintenance_message, maxlength: 300, placeholder: 'TaskDesk is being updated. Please try again in a few minutes.' });
      var b4 = h('button', { class: 'btn primary', type: 'button', text: 'Save', onclick: function () { saveSettings({ maintenance: mt.checked, maintenance_message: mm.value }, b4); } });
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'Maintenance' }), h('p', { class: 'lede', text: 'Pauses syncing for everyone, for example while you move or update the server. Apps keep working on the PC and upload later. The owner site stays available.' }),
        h('div', { class: 'switch', style: 'margin-bottom:12px' }, mt, h('label', { for: 'mt', style: 'font-weight:600', text: 'Maintenance mode' })),
        h('div', { class: 'field' }, h('label', { text: 'Message shown to users' }), mm), h('div', { class: 'actions' }, b4)));
    }).catch(function (e) { clear(el); el.appendChild(h('div', { class: 'msg bad', text: e.message || 'Could not load.' })); });
  }

  /* ---------- server and updates ---------- */
  function viewServer(el) {
    loading(el);
    loadSettings().then(function (s) {
      var c = s.settings;
      clear(el);
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'Server address' }),
        h('p', { class: 'lede', text: 'This address is built into the TaskDesk installer. Users never type it: the app opens, they sign in or create an account, and the server checks them.' }),
        h('div', { class: 'field' }, h('label', { text: 'Address of this server' }),
          h('div', { class: 'addr' }, h('code', { text: s.detected_api_url }), h('button', { class: 'btn small', type: 'button', text: 'Copy', onclick: function () { copy(s.detected_api_url); } }))),
        h('p', { class: 'muted small', style: 'margin:0', text: 'Server ID ' + s.server_id + '. Apps use it to be sure they talk to the right server.' })));

      var nu = h('input', { type: 'text', value: c.api_url, placeholder: 'https://new-domain.com/taskdesk/api.php', autocomplete: 'off', spellcheck: 'false' });
      var b = h('button', { class: 'btn primary', type: 'button', text: 'Announce this address', onclick: function () {
        var v = nu.value.trim();
        (v ? confirmBox('Move all apps to a new address?', 'Every installed app will switch to ' + v + ' the next time it connects. The new address must already serve this same TaskDesk server and database, and the old address must keep working for a few weeks. Apps check the new address first and stay on the old one if it does not answer.', 'Announce', false) : Promise.resolve(true)).then(function (ok) {
          if (ok) saveSettings({ api_url: v }, b).then(function () { route(); }).catch(function () { });
        });
      } });
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'Moving to a new address' }),
        h('p', { class: 'lede', text: 'If your website moves to another domain or folder, announce the new address here. Installed apps follow it by themselves, so nobody has to reinstall. New installers should be built with the new address.' }),
        c.api_url ? h('div', { class: 'msg info', text: 'Currently announced to all apps: ' + c.api_url }) : h('div', { class: 'msg info', text: 'Nothing announced. Apps use the address inside their installer.' }),
        h('div', { class: 'field' }, h('label', { text: 'New address' }), nu, h('div', { class: 'hint', text: 'Must start with https:// and end with api.php. Leave empty and save to stop announcing.' })),
        h('div', { class: 'actions' }, b)));

      var lt = h('input', { type: 'text', value: c.latest_client, placeholder: '1.1.0' }), mn = h('input', { type: 'text', value: c.min_client, placeholder: '1.0.0' });
      var dl = h('input', { type: 'text', value: c.download_url, placeholder: 'https://.../TaskDesk_Setup_1.1.0.exe' }), nt = h('input', { type: 'text', value: c.notice, maxlength: 500, placeholder: 'A short message every user sees in the app' });
      var b2 = h('button', { class: 'btn primary', type: 'button', text: 'Save', onclick: function () { saveSettings({ latest_client: lt.value, min_client: mn.value, download_url: dl.value, notice: nt.value }, b2); } });
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'Updates and messages' }),
        h('p', { class: 'lede', text: 'When you publish a new installer, put its version and link here. Users see an update banner with a Download button. Raise the oldest allowed version only when an old app must stop syncing.' }),
        h('div', { class: 'grid2' },
          h('div', { class: 'field' }, h('label', { text: 'Latest version' }), lt), h('div', { class: 'field' }, h('label', { text: 'Oldest version still allowed' }), mn)),
        h('div', { class: 'field' }, h('label', { text: 'Download link of the installer' }), dl),
        h('div', { class: 'field' }, h('label', { text: 'Message for all users (optional)' }), nt), h('div', { class: 'actions' }, b2)));
    }).catch(function (e) { clear(el); el.appendChild(h('div', { class: 'msg bad', text: e.message || 'Could not load.' })); });
  }

  /* ---------- activity log ---------- */
  var AUDIT_TEXT = {
    owner_login: 'Owner signed in', owner_login_failed: 'Failed owner sign-in', user_save: 'User changed', user_create: 'User added', user_delete: 'User deleted',
    user_reset_password: 'Temporary password set', user_new_recovery: 'New recovery key issued', user_signout: 'Devices signed out', settings_save: 'Settings changed',
    owner_password: 'Owner password changed', totp_on: 'Two-step sign-in turned on', totp_off: 'Two-step sign-in turned off', owner_reset_file: 'Owner password reset by file',
    register: 'Account created', register_pending: 'Account created, waiting for approval'
  };
  function viewAudit(el) {
    var q = h('input', { type: 'search', placeholder: 'Search the log', 'aria-label': 'Search the log' });
    var body = h('div'); var t = null;
    function load() {
      api('owner/audit', { query: { per: 200, q: q.value.trim() } }).then(function (d) {
        clear(body);
        if (!d.items.length) { body.appendChild(h('div', { class: 'tablewrap' }, h('div', { class: 'empty', text: 'Nothing here yet.' }))); return; }
        body.appendChild(h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, ['When', 'Who', 'What', 'About', 'Details'].map(function (x) { return h('th', { text: x }); }))),
          h('tbody', null, d.items.map(function (r) { return h('tr', null, h('td', { text: fmtDate(r.ts), class: 'num' }), h('td', { text: r.actor }), h('td', { text: AUDIT_TEXT[r.action] || r.action }), h('td', { text: r.target }), h('td', { class: 'muted', text: r.detail })); })))));
      }).catch(function (e) { clear(body); body.appendChild(h('div', { class: 'msg bad', text: e.message || 'Could not load.' })); });
    }
    q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(load, 250); });
    el.appendChild(h('div', { class: 'toolbar' }, q)); el.appendChild(body); load();
  }

  /* ---------- owner account ---------- */
  function viewAccount(el) {
    loading(el);
    api('owner/me').then(function (me) {
      clear(el);
      var o = h('input', { type: 'password', autocomplete: 'current-password' }), n = h('input', { type: 'password', autocomplete: 'new-password' }), n2 = h('input', { type: 'password', autocomplete: 'new-password' });
      var err = h('div', { class: 'msg bad hidden' });
      var b = h('button', { class: 'btn primary', type: 'button', text: 'Change password', onclick: function () {
        err.className = 'msg bad hidden';
        if (n.value !== n2.value) { err.textContent = 'The two new passwords are not the same.'; err.className = 'msg bad'; return; }
        b.disabled = true;
        api('owner/password', { body: { old_password: o.value, new_password: n.value } }).then(function () { toast('Password changed. Other sessions were signed out.'); o.value = n.value = n2.value = ''; b.disabled = false; })
          .catch(function (e) { b.disabled = false; err.textContent = e.message || 'Could not change the password.'; err.className = 'msg bad'; });
      } });
      el.appendChild(h('div', { class: 'card' }, h('h2', { text: 'Owner password' }), h('p', { class: 'lede', text: 'Signed in as ' + me.username + '. Use a long password that you use nowhere else.' }), err,
        h('div', { class: 'grid3' }, h('div', { class: 'field' }, h('label', { text: 'Current password' }), o), h('div', { class: 'field' }, h('label', { text: 'New password (10+ characters)' }), n), h('div', { class: 'field' }, h('label', { text: 'Repeat new password' }), n2)),
        h('div', { class: 'actions' }, b)));

      var card = h('div', { class: 'card' });
      el.appendChild(card);
      function twoStep() {
        clear(card);
        card.appendChild(h('h2', { text: 'Two-step sign-in' }));
        if (me.totp) {
          var pw = h('input', { type: 'password', autocomplete: 'current-password' }), cd = h('input', { type: 'text', inputmode: 'numeric', maxlength: 8, autocomplete: 'off' });
          var e2 = h('div', { class: 'msg bad hidden' });
          var off = h('button', { class: 'btn danger', type: 'button', text: 'Turn off', onclick: function () {
            api('owner/totp/disable', { body: { password: pw.value, code: cd.value } }).then(function () { me.totp = false; toast('Two-step sign-in is off'); twoStep(); })
              .catch(function (e) { e2.textContent = e.message || 'Could not turn it off.'; e2.className = 'msg bad'; });
          } });
          card.appendChild(h('div', { class: 'msg ok', text: 'On. Signing in needs a 6 digit code from your authenticator app.' }));
          card.appendChild(e2);
          card.appendChild(h('div', { class: 'grid2' }, h('div', { class: 'field' }, h('label', { text: 'Password' }), pw), h('div', { class: 'field' }, h('label', { text: 'Current code' }), cd)));
          card.appendChild(h('div', { class: 'actions' }, off));
        } else {
          card.appendChild(h('p', { class: 'lede', text: 'Adds a 6 digit code from an authenticator app (Google Authenticator, Microsoft Authenticator, Authy) to the password. Strongly recommended, because this site controls every account.' }));
          var pw2 = h('input', { type: 'password', autocomplete: 'current-password' });
          var e3 = h('div', { class: 'msg bad hidden' });
          card.appendChild(e3);
          card.appendChild(h('div', { class: 'field', style: 'max-width:320px' }, h('label', { text: 'Your password' }), pw2));
          card.appendChild(h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', text: 'Set up two-step sign-in', onclick: function () {
            api('owner/totp/begin', { body: { password: pw2.value } }).then(function (d) {
              clear(card);
              var cd2 = h('input', { type: 'text', inputmode: 'numeric', maxlength: 8, autocomplete: 'off', style: 'max-width:200px' });
              var e4 = h('div', { class: 'msg bad hidden' });
              card.appendChild(h('h2', { text: 'Two-step sign-in' }));
              card.appendChild(h('p', { class: 'lede', text: 'In your authenticator app choose "Add account" and "Enter a setup key". Use the key below (account name TaskDesk Owner, time based). Then type the 6 digit code the app shows.' }));
              card.appendChild(h('div', { class: 'addr' }, h('code', { text: d.secret.replace(/(.{4})/g, '$1 ').trim() }), h('button', { class: 'btn small', type: 'button', text: 'Copy', onclick: function () { copy(d.secret); } })));
              card.appendChild(h('p', { class: 'muted small', text: 'Phone with the authenticator app on it? Open this link there: ' + d.uri, style: 'word-break:break-all' }));
              card.appendChild(e4);
              card.appendChild(h('div', { class: 'field', style: 'margin-top:12px' }, h('label', { text: 'Code from the app' }), cd2));
              card.appendChild(h('div', { class: 'actions' }, h('button', { class: 'btn primary', type: 'button', text: 'Turn on', onclick: function () {
                api('owner/totp/enable', { body: { code: cd2.value } }).then(function () { me.totp = true; toast('Two-step sign-in is on'); twoStep(); })
                  .catch(function (e) { e4.textContent = e.message || 'The code is not correct.'; e4.className = 'msg bad'; });
              } }), h('button', { class: 'btn', type: 'button', text: 'Cancel', onclick: twoStep })));
              cd2.focus();
            }).catch(function (e) { e3.textContent = e.message || 'Could not start.'; e3.className = 'msg bad'; });
          } })));
        }
      }
      twoStep();
    }).catch(function (e) { clear(el); el.appendChild(h('div', { class: 'msg bad', text: e.message || 'Could not load.' })); });
  }

  /* ---------- start ---------- */
  function start() {
    frame();
    window.removeEventListener('hashchange', route);
    window.addEventListener('hashchange', route);
    if (!location.hash) location.hash = '#/dashboard'; else route();
    api('owner/dashboard', { quiet: true }).then(function (d) { setPending(d.by_status.pending); }).catch(function () { });
  }

  api('owner/status', { quiet: true }).then(function (d) {
    if (d.signed_in) { S.owner = d.username; start(); } else showLogin();
  }).catch(function (e) {
    showLogin();
    var m = document.querySelector('.login-card form');
    if (m) m.insertBefore(h('div', { class: 'msg bad', text: (e && e.message) || 'Cannot reach the server.' }), m.firstChild);
  });
})();
