<?php
/*
 * Owner console API. Used only by the owner site (owner/index.html) - the desktop apps never call these routes.
 *
 * Sign-in: username + password (+ a 6 digit code when two-step sign-in is on). The session is an HttpOnly,
 * SameSite=Strict cookie. Every change must carry the header  X-TD-Owner: 1  (a web page of another site cannot send it).
 */

// ---------------------------------------------------------------- small helpers
function td_known_modules()
{
    return array('abap' => 'ABAP Developer', 'fico' => 'FICO Consultant', 'mm' => 'MM Consultant', 'basis' => 'SAP BASIS / IT');
}

function td_valid_module_id($m)
{
    return (bool)preg_match('/^[a-z][a-z0-9]{1,19}$/', $m);
}

function td_random_password($n = 10)
{
    $alphabet = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $out = '';
    for ($i = 0; $i < $n; $i++) {
        $out .= $alphabet[random_int(0, strlen($alphabet) - 1)];
    }
    return $out;
}

function td_b32_encode($bin)
{
    $alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($bin) as $ch) {
        $bits .= str_pad(decbin(ord($ch)), 8, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 5) as $chunk) {
        $out .= $alpha[bindec(str_pad($chunk, 5, '0', STR_PAD_RIGHT))];
    }
    return $out;
}

function td_b32_decode($s)
{
    $alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $s = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $s));
    $bits = '';
    foreach (str_split($s) as $ch) {
        $bits .= str_pad(decbin(strpos($alpha, $ch)), 5, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) === 8) {
            $out .= chr(bindec($byte));
        }
    }
    return $out;
}

function td_totp_at($secretBin, $counter)
{
    $hash = hash_hmac('sha1', pack('N*', 0) . pack('N*', $counter), $secretBin, true);
    $off = ord($hash[19]) & 0x0f;
    $code = ((ord($hash[$off]) & 0x7f) << 24) | (ord($hash[$off + 1]) << 16) | (ord($hash[$off + 2]) << 8) | ord($hash[$off + 3]);
    return str_pad((string)($code % 1000000), 6, '0', STR_PAD_LEFT);
}

function td_totp_ok($secretB32, $code)
{
    $code = preg_replace('/\D/', '', (string)$code);
    if (strlen($code) !== 6) {
        return false;
    }
    $bin = td_b32_decode($secretB32);
    $t = (int)floor(time() / 30);
    for ($i = -1; $i <= 1; $i++) {
        if (hash_equals(td_totp_at($bin, $t + $i), $code)) {
            return true;
        }
    }
    return false;
}

/* The two-step secret is stored encrypted with a key made from config.php's secret. */
function td_seal($plain)
{
    $key = hash('sha256', 'seal|' . td_config()['secret'], true);
    if (function_exists('openssl_encrypt')) {
        $iv = random_bytes(12);
        $tag = '';
        $ct = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($ct !== false) {
            return 'g:' . base64_encode($iv . $tag . $ct);
        }
    }
    return 'p:' . base64_encode($plain);
}

function td_unseal($s)
{
    if (strpos($s, 'p:') === 0) {
        return (string)base64_decode(substr($s, 2));
    }
    if (strpos($s, 'g:') !== 0 || !function_exists('openssl_decrypt')) {
        return '';
    }
    $raw = base64_decode(substr($s, 2));
    if ($raw === false || strlen($raw) < 29) {
        return '';
    }
    $key = hash('sha256', 'seal|' . td_config()['secret'], true);
    $r = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return $r === false ? '' : $r;
}

function td_detected_api_url()
{
    $scheme = td_is_https() ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'your-domain.com';
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    return $scheme . '://' . $host . $dir . '/api.php';
}

function td_url_ok($url, $allowEmpty = true)
{
    if ($url === '') {
        return $allowEmpty;
    }
    if (strlen($url) > 400 || !filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }
    $p = parse_url($url);
    if (!$p || empty($p['host'])) {
        return false;
    }
    if ($p['scheme'] === 'https') {
        return true;
    }
    return $p['scheme'] === 'http' && in_array($p['host'], array('127.0.0.1', 'localhost'), true);
}

function td_rm_tree($dir)
{
    if (!is_dir($dir)) {
        return;
    }
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) {
        if ($f->isDir() && !$f->isLink()) {
            @rmdir($f->getPathname());
        } else {
            @unlink($f->getPathname());
        }
    }
    @rmdir($dir);
}

// ---------------------------------------------------------------- owner accounts and sessions
function td_owner_count()
{
    return (int)td_val('SELECT COUNT(*) FROM td_owners');
}

/*
 * Way in when the owner password is lost, and the way to create the first owner on a server that was set up
 * before the owner site existed: put a file  owner_reset.txt  into the storage folder (File Manager),
 * line 1 = owner username, line 2 = new password. The next visit to the owner site applies it and deletes the file.
 */
function td_owner_apply_reset_file()
{
    $f = td_storage_dir() . '/owner_reset.txt';
    if (!is_file($f)) {
        return;
    }
    $lines = preg_split('/\r\n|\r|\n/', trim((string)@file_get_contents($f)));
    if (!@unlink($f)) {
        td_log('owner_reset.txt could not be removed, ignored');
        return;
    }
    $user = strtolower(trim(isset($lines[0]) ? $lines[0] : ''));
    $pw = isset($lines[1]) ? rtrim($lines[1], "\r\n") : '';
    if (!td_valid_username($user) || strlen($pw) < 10) {
        td_log('owner_reset.txt ignored: needs a username and a password of 10+ characters');
        return;
    }
    $row = td_row('SELECT id FROM td_owners WHERE username=?', array($user));
    if ($row) {
        td_exec("UPDATE td_owners SET pass_hash=?, totp_on=0, totp_secret='' WHERE id=?", array(td_hash_password($pw), $row['id']));
        td_exec('DELETE FROM td_owner_sessions WHERE owner_id=?', array($row['id']));
    } else {
        td_exec('INSERT INTO td_owners(username, pass_hash, created_at) VALUES(?,?,?)', array($user, td_hash_password($pw), td_now()));
    }
    td_audit('system', 'owner_reset_file', $user, 'owner password set from owner_reset.txt');
}

function td_owner_cookie($token, $expires)
{
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
    setcookie('tdo', $token, array(
        'expires' => $expires,
        'path' => $dir === '' ? '/' : $dir,
        'secure' => td_is_https(),
        'httponly' => true,
        'samesite' => 'Strict',
    ));
}

function td_owner_require()
{
    $tok = isset($_COOKIE['tdo']) ? (string)$_COOKIE['tdo'] : '';
    if (!preg_match('/^[a-f0-9]{64}$/', $tok)) {
        td_fail(401, 'owner_not_signed_in', 'Please sign in.');
    }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET' && ($_SERVER['HTTP_X_TD_OWNER'] ?? '') !== '1') {
        td_fail(403, 'bad_request', 'Missing header.');
    }
    $row = td_row('SELECT s.id AS sid, s.last_used AS s_last, o.* FROM td_owner_sessions s JOIN td_owners o ON o.id=s.owner_id
                   WHERE s.token_hash=? AND s.expires_at>?', array(td_token_hash($tok), td_now()));
    if (!$row || strtotime($row['s_last'] . ' UTC') < time() - 3600) {
        if ($row) {
            td_exec('DELETE FROM td_owner_sessions WHERE id=?', array($row['sid']));
        }
        td_fail(401, 'owner_not_signed_in', 'Your session ended. Please sign in again.');
    }
    if (strtotime($row['s_last'] . ' UTC') < time() - 60) {
        td_exec('UPDATE td_owner_sessions SET last_used=? WHERE id=?', array(td_now(), $row['sid']));
    }
    return $row;
}

function td_owner_status()
{
    td_method('GET');
    td_owner_apply_reset_file();
    $signed = false;
    $name = '';
    $tok = isset($_COOKIE['tdo']) ? (string)$_COOKIE['tdo'] : '';
    if (preg_match('/^[a-f0-9]{64}$/', $tok)) {
        $row = td_row('SELECT o.username, o.totp_on FROM td_owner_sessions s JOIN td_owners o ON o.id=s.owner_id WHERE s.token_hash=? AND s.expires_at>? AND s.last_used>?',
            array(td_token_hash($tok), td_now(), gmdate('Y-m-d H:i:s', time() - 3600)));
        if ($row) {
            $signed = true;
            $name = $row['username'];
        }
    }
    td_json(array('ok' => true, 'configured' => td_owner_count() > 0, 'signed_in' => $signed, 'username' => $name));
}

function td_owner_login()
{
    td_method('POST');
    td_owner_apply_reset_file();
    $in = td_input();
    $ip = td_client_ip();
    $user = strtolower(trim(td_str($in, 'username', 40)));
    td_rate_guard('own-ip', $ip, 30, 900);
    td_rate_guard('own-user', $user, 6, 900);
    $row = td_row('SELECT * FROM td_owners WHERE username=?', array($user));
    $hash = $row ? $row['pass_hash'] : '$2y$10$E15zo62g0Z.8TkcdFtY3/uJtjCTLKQEW5e8AvtOeQFutd0k4dJIfu';
    $ok = password_verify(td_str($in, 'password', 200), $hash);
    if (!$row || !$ok) {
        td_rate_hit('own-ip', $ip);
        td_rate_hit('own-user', $user);
        td_audit('anonymous', 'owner_login_failed', $user, $ip);
        td_fail(401, 'bad_credentials', 'Username, password or code is not correct.');
    }
    if ((int)$row['totp_on'] === 1) {
        $code = td_str($in, 'code', 12);
        if (trim($code) === '') {
            td_json(array('ok' => false, 'error' => 'code_required', 'message' => 'Enter the 6 digit code from your authenticator app.'), 401);
        }
        if (!td_totp_ok(td_unseal($row['totp_secret']), $code)) {
            td_rate_hit('own-ip', $ip);
            td_rate_hit('own-user', $user);
            td_audit('anonymous', 'owner_login_failed', $user, 'wrong code');
            td_fail(401, 'bad_credentials', 'Username, password or code is not correct.');
        }
    }
    $token = td_random_hex(32);
    td_exec('INSERT INTO td_owner_sessions(owner_id, token_hash, created_at, last_used, expires_at, ip) VALUES(?,?,?,?,?,?)',
        array($row['id'], td_token_hash($token), td_now(), td_now(), gmdate('Y-m-d H:i:s', time() + 12 * 3600), $ip));
    td_exec('UPDATE td_owners SET last_login=? WHERE id=?', array(td_now(), $row['id']));
    td_owner_cookie($token, time() + 12 * 3600);
    td_audit($row['username'], 'owner_login', '', $ip);
    td_json(array('ok' => true, 'username' => $row['username'], 'totp' => (int)$row['totp_on'] === 1));
}

function td_owner_logout()
{
    td_method('POST');
    $tok = isset($_COOKIE['tdo']) ? (string)$_COOKIE['tdo'] : '';
    if (preg_match('/^[a-f0-9]{64}$/', $tok)) {
        td_exec('DELETE FROM td_owner_sessions WHERE token_hash=?', array(td_token_hash($tok)));
    }
    td_owner_cookie('', time() - 3600);
    td_json(array('ok' => true));
}

function td_owner_change_password($o)
{
    td_method('POST');
    $in = td_input();
    td_rate_guard('own-pw', $o['username'], 6, 900);
    if (!password_verify(td_str($in, 'old_password', 200), $o['pass_hash'])) {
        td_rate_hit('own-pw', $o['username']);
        td_fail(403, 'bad_credentials', 'The current password is not correct.');
    }
    $new = td_str($in, 'new_password', 200);
    if (strlen($new) < 10) {
        td_fail(400, 'weak_password', 'The owner password needs at least 10 characters.');
    }
    td_exec('UPDATE td_owners SET pass_hash=? WHERE id=?', array(td_hash_password($new), $o['id']));
    td_exec('DELETE FROM td_owner_sessions WHERE owner_id=? AND id<>?', array($o['id'], $o['sid']));
    td_audit($o['username'], 'owner_password', '', '');
    td_json(array('ok' => true));
}

function td_owner_totp($o, $step)
{
    td_method('POST');
    $in = td_input();
    if ($step === 'begin') {
        if (!password_verify(td_str($in, 'password', 200), $o['pass_hash'])) {
            td_fail(403, 'bad_credentials', 'The password is not correct.');
        }
        if ((int)$o['totp_on'] === 1) {
            td_fail(409, 'already_on', 'Two-step sign-in is already on.');
        }
        $secret = td_b32_encode(random_bytes(20));
        td_exec('UPDATE td_owners SET totp_secret=? WHERE id=?', array(td_seal($secret), $o['id']));
        $uri = 'otpauth://totp/' . rawurlencode('TaskDesk Owner:' . $o['username']) . '?secret=' . $secret . '&issuer=' . rawurlencode('TaskDesk Owner');
        td_json(array('ok' => true, 'secret' => $secret, 'uri' => $uri));
    }
    if ($step === 'enable') {
        $secret = td_unseal($o['totp_secret']);
        if ($secret === '' || !td_totp_ok($secret, td_str($in, 'code', 12))) {
            td_fail(400, 'bad_code', 'The code is not correct. Check the time on your phone and try again.');
        }
        td_exec('UPDATE td_owners SET totp_on=1 WHERE id=?', array($o['id']));
        td_audit($o['username'], 'totp_on', '', '');
        td_json(array('ok' => true));
    }
    if ($step === 'disable') {
        if (!password_verify(td_str($in, 'password', 200), $o['pass_hash'])) {
            td_fail(403, 'bad_credentials', 'The password is not correct.');
        }
        if ((int)$o['totp_on'] === 1 && !td_totp_ok(td_unseal($o['totp_secret']), td_str($in, 'code', 12))) {
            td_fail(400, 'bad_code', 'The code is not correct.');
        }
        td_exec("UPDATE td_owners SET totp_on=0, totp_secret='' WHERE id=?", array($o['id']));
        td_audit($o['username'], 'totp_off', '', '');
        td_json(array('ok' => true));
    }
    td_fail(404, 'unknown_call', 'Unknown call.');
}

// ---------------------------------------------------------------- dashboard
function td_owner_dashboard()
{
    td_method('GET');
    $now = td_now();
    $byStatus = array('active' => 0, 'blocked' => 0, 'pending' => 0);
    foreach (td_rows('SELECT status, COUNT(*) AS n FROM td_users GROUP BY status') as $r) {
        $k = (int)$r['status'] === 1 ? 'active' : ((int)$r['status'] === 2 ? 'pending' : 'blocked');
        $byStatus[$k] = (int)$r['n'];
    }
    $byModule = array();
    foreach (td_rows('SELECT module, COUNT(*) AS n FROM td_users GROUP BY module') as $r) {
        $byModule[$r['module']] = (int)$r['n'];
    }
    $storage = td_storage_dir();
    $free = @disk_free_space($storage);
    td_json(array(
        'ok' => true,
        'users' => array_sum($byStatus),
        'by_status' => $byStatus,
        'by_module' => $byModule,
        'new_7d' => (int)td_val('SELECT COUNT(*) FROM td_users WHERE created_at>?', array(gmdate('Y-m-d H:i:s', time() - 7 * 86400))),
        'signed_in_24h' => (int)td_val('SELECT COUNT(*) FROM td_users WHERE last_login>?', array(gmdate('Y-m-d H:i:s', time() - 86400))),
        'expiring_7d' => (int)td_val('SELECT COUNT(*) FROM td_users WHERE expires_at IS NOT NULL AND expires_at>? AND expires_at<?',
            array($now, gmdate('Y-m-d H:i:s', time() + 7 * 86400))),
        'devices' => (int)td_val('SELECT COUNT(*) FROM td_tokens WHERE expires_at>?', array($now)),
        'bytes_used' => (int)td_val('SELECT COALESCE(SUM(bytes_used),0) FROM td_users'),
        'files' => (int)td_val('SELECT COUNT(*) FROM td_files'),
        'server' => array(
            'php' => PHP_VERSION,
            'database' => td_driver(),
            'storage_writable' => is_dir($storage) && is_writable($storage),
            'disk_free' => $free === false ? null : (int)$free,
            'post_max_size' => td_ini_bytes('post_max_size'),
            'max_file_mb' => td_max_file_mb(),
            'https' => td_is_https(),
            'server_version' => TD_SERVER_VERSION,
        ),
    ));
}

// ---------------------------------------------------------------- users
function td_owner_user_view($r)
{
    return array(
        'id' => (int)$r['id'],
        'username' => $r['username'],
        'display_name' => $r['display_name'],
        'module' => $r['module'],
        'status' => (int)$r['status'],
        'created_at' => $r['created_at'],
        'created_by' => $r['created_by'],
        'last_login' => $r['last_login'],
        'expires_at' => $r['expires_at'] ? substr($r['expires_at'], 0, 10) : '',
        'quota_mb' => $r['quota_mb'] === null ? null : (int)$r['quota_mb'],
        'max_file_mb' => $r['max_file_mb'] === null ? null : (int)$r['max_file_mb'],
        'quota_effective_mb' => td_user_quota_mb($r),
        'max_file_effective_mb' => td_user_max_file_mb($r),
        'can_upload' => (int)$r['can_upload'] === 1,
        'must_change_pw' => (int)$r['must_change_pw'] === 1,
        'note' => $r['note'],
        'bytes_used' => (int)$r['bytes_used'],
        'rev' => (int)$r['rev'],
        'devices' => isset($r['devices']) ? (int)$r['devices'] : 0,
    );
}

function td_owner_users_list()
{
    td_method('GET');
    $where = array();
    $par = array(td_now());
    $q = strtolower(trim(isset($_GET['q']) ? (string)$_GET['q'] : ''));
    if ($q !== '') {
        $where[] = '(INSTR(LOWER(u.username), ?) > 0 OR INSTR(LOWER(u.display_name), ?) > 0)';
        $par[] = $q;
        $par[] = $q;
    }
    if (!empty($_GET['module'])) {
        $where[] = 'u.module=?';
        $par[] = (string)$_GET['module'];
    }
    if (isset($_GET['status']) && $_GET['status'] !== '') {
        $where[] = 'u.status=?';
        $par[] = (int)$_GET['status'];
    }
    $w = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
    $total = (int)td_val('SELECT COUNT(*) FROM td_users u' . $w, array_slice($par, 1));
    $per = max(1, min(100, isset($_GET['per']) ? (int)$_GET['per'] : 25));
    $page = max(1, isset($_GET['page']) ? (int)$_GET['page'] : 1);
    $rows = td_rows('SELECT u.*, (SELECT COUNT(*) FROM td_tokens t WHERE t.user_id=u.id AND t.expires_at>?) AS devices
                     FROM td_users u' . $w . ' ORDER BY u.id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $par);
    $out = array();
    foreach ($rows as $r) {
        $out[] = td_owner_user_view($r);
    }
    td_json(array('ok' => true, 'total' => $total, 'page' => $page, 'per' => $per, 'users' => $out));
}

function td_owner_get_user($id)
{
    $u = td_row('SELECT * FROM td_users WHERE id=?', array((int)$id));
    if (!$u) {
        td_fail(404, 'no_such_user', 'This user does not exist.');
    }
    return $u;
}

function td_owner_user_detail()
{
    td_method('GET');
    $u = td_owner_get_user(isset($_GET['id']) ? (int)$_GET['id'] : 0);
    $u['devices'] = (int)td_val('SELECT COUNT(*) FROM td_tokens WHERE user_id=? AND expires_at>?', array($u['id'], td_now()));
    $dev = array();
    foreach (td_rows('SELECT id, device, created_at, last_used FROM td_tokens WHERE user_id=? AND expires_at>? ORDER BY last_used DESC', array($u['id'], td_now())) as $t) {
        $dev[] = array('id' => (int)$t['id'], 'device' => $t['device'], 'created_at' => $t['created_at'], 'last_used' => $t['last_used']);
    }
    td_json(array(
        'ok' => true,
        'user' => td_owner_user_view($u),
        'devices' => $dev,
        'records' => (int)td_val('SELECT COUNT(*) FROM td_records WHERE user_id=? AND deleted=0', array($u['id'])),
        'files' => (int)td_val('SELECT COUNT(*) FROM td_files WHERE user_id=?', array($u['id'])),
    ));
}

function td_user_has_data($u)
{
    return (int)$u['rev'] > 0 || (int)td_val('SELECT COUNT(*) FROM td_files WHERE user_id=?', array($u['id'])) > 0;
}

function td_owner_optional_int($in, $key, $max)
{
    if (!array_key_exists($key, $in) || $in[$key] === null || $in[$key] === '' || (int)$in[$key] === 0) {
        return null;
    }
    $n = (int)$in[$key];
    if ($n < 1 || $n > $max) {
        td_fail(400, 'bad_value', 'The value for ' . $key . ' is not valid.');
    }
    return $n;
}

function td_owner_user_save($o)
{
    td_method('POST');
    $in = td_input();
    $u = td_owner_get_user(isset($in['id']) ? (int)$in['id'] : 0);
    $c = td_config();
    $set = array();
    $par = array();
    $changes = array();

    if (array_key_exists('display_name', $in)) {
        $d = trim(td_str($in, 'display_name', 80));
        if ($d === '') {
            td_fail(400, 'bad_value', 'The name cannot be empty.');
        }
        $d = function_exists('mb_substr') ? mb_substr($d, 0, 80, 'UTF-8') : substr($d, 0, 80);
        $set[] = 'display_name=?';
        $par[] = $d;
    }
    if (array_key_exists('status', $in)) {
        $st = (int)$in['status'];
        if (!in_array($st, array(0, 1, 2), true)) {
            td_fail(400, 'bad_value', 'Status is not valid.');
        }
        if ($st !== (int)$u['status']) {
            $changes[] = 'status ' . (int)$u['status'] . '->' . $st;
        }
        $set[] = 'status=?';
        $par[] = $st;
    }
    if (array_key_exists('module', $in) && (string)$in['module'] !== $u['module']) {
        $m = strtolower(trim(td_str($in, 'module', 20)));
        if (!td_valid_module_id($m) || !in_array($m, $c['modules'], true)) {
            td_fail(400, 'bad_module', 'This module is not enabled on the server.');
        }
        if (td_user_has_data($u)) {
            td_fail(409, 'module_has_data', 'This user already has data in the ' . $u['module'] . ' module. The module can only be changed while the account is empty. Create a new account for the other module instead.');
        }
        $changes[] = 'module ' . $u['module'] . '->' . $m;
        $set[] = 'module=?';
        $par[] = $m;
    }
    if (array_key_exists('expires_at', $in)) {
        $e = trim(td_str($in, 'expires_at', 10));
        if ($e === '') {
            $set[] = 'expires_at=NULL';
        } else {
            $dt = DateTime::createFromFormat('Y-m-d', $e);
            if (!$dt || $dt->format('Y-m-d') !== $e) {
                td_fail(400, 'bad_value', 'The date must look like 2027-03-31.');
            }
            $set[] = 'expires_at=?';
            $par[] = $e . ' 23:59:59';
            $changes[] = 'access until ' . $e;
        }
    }
    if (array_key_exists('quota_mb', $in)) {
        $set[] = 'quota_mb=?';
        $par[] = td_owner_optional_int($in, 'quota_mb', 1000000);
    }
    if (array_key_exists('max_file_mb', $in)) {
        $set[] = 'max_file_mb=?';
        $par[] = td_owner_optional_int($in, 'max_file_mb', 100000);
    }
    if (array_key_exists('can_upload', $in)) {
        $set[] = 'can_upload=?';
        $par[] = !empty($in['can_upload']) ? 1 : 0;
        if ((!empty($in['can_upload']) ? 1 : 0) !== (int)$u['can_upload']) {
            $changes[] = 'uploads ' . (!empty($in['can_upload']) ? 'on' : 'off');
        }
    }
    if (array_key_exists('note', $in)) {
        $set[] = 'note=?';
        $par[] = substr(trim(td_str($in, 'note', 255)), 0, 255);
    }
    if (!count($set)) {
        td_fail(400, 'nothing_to_save', 'Nothing was changed.');
    }
    $par[] = $u['id'];
    td_exec('UPDATE td_users SET ' . implode(', ', $set) . ' WHERE id=?', $par);
    td_audit($o['username'], 'user_save', $u['username'], implode('; ', $changes));
    $u = td_owner_get_user($u['id']);
    td_json(array('ok' => true, 'user' => td_owner_user_view($u)));
}

function td_owner_user_create($o)
{
    td_method('POST');
    $in = td_input();
    $c = td_config();
    $username = strtolower(trim(td_str($in, 'username', 32)));
    $module = strtolower(trim(td_str($in, 'module', 20)));
    $display = trim(td_str($in, 'display_name', 80));
    if (!td_valid_username($username)) {
        td_fail(400, 'bad_username', 'Username must be 3 to 32 characters: letters, numbers, dot, dash or underscore, starting and ending with a letter or number.');
    }
    if (!in_array($module, $c['modules'], true)) {
        td_fail(400, 'bad_module', 'This module is not enabled on the server.');
    }
    $pw = td_str($in, 'password', 200);
    $generated = false;
    if ($pw === '') {
        $pw = td_random_password(10);
        $generated = true;
    }
    td_check_password_rules($pw, $username);
    if ($display === '') {
        $display = $username;
    }
    if (td_val('SELECT COUNT(*) FROM td_users WHERE username=?', array($username)) > 0) {
        td_fail(409, 'username_taken', 'This username is already taken.');
    }
    $recovery = td_new_recovery_key();
    $exp = trim(td_str($in, 'expires_at', 10));
    $expSql = null;
    if ($exp !== '') {
        $dt = DateTime::createFromFormat('Y-m-d', $exp);
        if (!$dt || $dt->format('Y-m-d') !== $exp) {
            td_fail(400, 'bad_value', 'The date must look like 2027-03-31.');
        }
        $expSql = $exp . ' 23:59:59';
    }
    td_exec('INSERT INTO td_users(username, display_name, module, pass_hash, recovery_hash, rev, bytes_used, status, created_at, last_login, expires_at, must_change_pw, created_by)
             VALUES(?,?,?,?,?,0,0,1,?,NULL,?,1,?)',
        array($username, function_exists('mb_substr') ? mb_substr($display, 0, 80, 'UTF-8') : substr($display, 0, 80), $module, td_hash_password($pw),
            td_hmac(td_norm_recovery($recovery)), td_now(), $expSql, 'owner'));
    $u = td_row('SELECT * FROM td_users WHERE username=?', array($username));
    td_audit($o['username'], 'user_create', $username, $module);
    td_json(array('ok' => true, 'user' => td_owner_user_view($u), 'password' => $pw, 'generated' => $generated, 'recovery_key' => $recovery));
}

function td_owner_user_reset_password($o)
{
    td_method('POST');
    $in = td_input();
    $u = td_owner_get_user(isset($in['id']) ? (int)$in['id'] : 0);
    $pw = td_str($in, 'password', 200);
    if ($pw === '') {
        $pw = td_random_password(10);
    }
    td_check_password_rules($pw, $u['username']);
    td_exec('UPDATE td_users SET pass_hash=?, must_change_pw=1 WHERE id=?', array(td_hash_password($pw), $u['id']));
    td_exec('DELETE FROM td_tokens WHERE user_id=?', array($u['id']));
    td_audit($o['username'], 'user_reset_password', $u['username'], '');
    td_json(array('ok' => true, 'password' => $pw));
}

function td_owner_user_new_recovery($o)
{
    td_method('POST');
    $in = td_input();
    $u = td_owner_get_user(isset($in['id']) ? (int)$in['id'] : 0);
    $key = td_new_recovery_key();
    td_exec('UPDATE td_users SET recovery_hash=? WHERE id=?', array(td_hmac(td_norm_recovery($key)), $u['id']));
    td_audit($o['username'], 'user_new_recovery', $u['username'], '');
    td_json(array('ok' => true, 'recovery_key' => $key));
}

function td_owner_user_signout($o)
{
    td_method('POST');
    $in = td_input();
    $u = td_owner_get_user(isset($in['id']) ? (int)$in['id'] : 0);
    if (!empty($in['token_id'])) {
        $n = td_exec('DELETE FROM td_tokens WHERE user_id=? AND id=?', array($u['id'], (int)$in['token_id']));
    } else {
        $n = td_exec('DELETE FROM td_tokens WHERE user_id=?', array($u['id']));
    }
    td_audit($o['username'], 'user_signout', $u['username'], $n . ' device(s)');
    td_json(array('ok' => true, 'removed' => $n));
}

function td_owner_user_delete($o)
{
    td_method('POST');
    $in = td_input();
    $u = td_owner_get_user(isset($in['id']) ? (int)$in['id'] : 0);
    if (strtolower(td_str($in, 'confirm', 40)) !== $u['username']) {
        td_fail(400, 'confirm_needed', 'Type the username to confirm that this account and all its data should be deleted.');
    }
    $uid = (int)$u['id'];
    td_begin();
    try {
        td_exec('DELETE FROM td_records WHERE user_id=?', array($uid));
        td_exec('DELETE FROM td_files WHERE user_id=?', array($uid));
        td_exec('DELETE FROM td_tokens WHERE user_id=?', array($uid));
        td_exec('DELETE FROM td_users WHERE id=?', array($uid));
        td_commit();
    } catch (Throwable $e) {
        td_rollback();
        td_log('user delete failed: ' . $e->getMessage());
        td_fail(500, 'server_error', 'The user could not be deleted.');
    }
    td_rm_tree(td_storage_dir() . '/u' . $uid);
    td_audit($o['username'], 'user_delete', $u['username'], 'all data removed');
    td_json(array('ok' => true));
}

// ---------------------------------------------------------------- settings
function td_owner_settings_get()
{
    td_method('GET');
    td_json(td_owner_settings_payload());
}

function td_owner_settings_payload()
{
    $c = td_config();
    $all = td_settings_all();
    return array(
        'ok' => true,
        'settings' => array(
            'registration' => $c['registration'],
            'invite_code' => (string)$c['invite_code'],
            'quota_mb' => (int)$c['quota_mb'],
            'max_file_mb' => (int)$c['max_file_mb'],
            'token_days' => (int)$c['token_days'],
            'modules' => array_values($c['modules']),
            'latest_client' => (string)$c['latest_client'],
            'min_client' => (string)$c['min_client'],
            'download_url' => (string)$c['download_url'],
            'notice' => (string)$c['notice'],
            'maintenance' => (bool)$c['maintenance'],
            'maintenance_message' => (string)$c['maintenance_message'],
            'api_url' => (string)$c['api_url'],
        ),
        'known_modules' => td_known_modules(),
        'detected_api_url' => td_detected_api_url(),
        'server_id' => isset($all['server_id']) ? $all['server_id'] : '',
        'effective_max_file_mb' => td_max_file_mb(),
        'post_max_size' => td_ini_bytes('post_max_size'),
    );
}

function td_owner_version_ok($v)
{
    return $v === '' || (bool)preg_match('/^\d{1,4}(\.\d{1,4}){0,3}$/', $v);
}

function td_owner_settings_save($o)
{
    td_method('POST');
    $in = td_input();
    $new = array();
    $changed = array();
    if (isset($in['registration'])) {
        if (!in_array($in['registration'], array('open', 'approval', 'closed'), true)) {
            td_fail(400, 'bad_value', 'Registration must be open, approval or closed.');
        }
        $new['registration'] = $in['registration'];
    }
    if (array_key_exists('invite_code', $in)) {
        $new['invite_code'] = substr(trim(td_str($in, 'invite_code', 100)), 0, 100);
    }
    foreach (array('quota_mb' => array(50, 1000000), 'max_file_mb' => array(1, 100000), 'token_days' => array(1, 3650)) as $k => $lim) {
        if (array_key_exists($k, $in)) {
            $n = (int)$in[$k];
            if ($n < $lim[0] || $n > $lim[1]) {
                td_fail(400, 'bad_value', $k . ' must be between ' . $lim[0] . ' and ' . $lim[1] . '.');
            }
            $new[$k] = (string)$n;
        }
    }
    if (isset($in['modules'])) {
        if (!is_array($in['modules'])) {
            td_fail(400, 'bad_value', 'Modules is not valid.');
        }
        $mods = array();
        foreach ($in['modules'] as $m) {
            $m = strtolower(trim((string)$m));
            if (!td_valid_module_id($m)) {
                td_fail(400, 'bad_value', 'A module name is not valid: use lower case letters and numbers.');
            }
            if (!in_array($m, $mods, true)) {
                $mods[] = $m;
            }
        }
        if (!count($mods)) {
            td_fail(400, 'bad_value', 'Keep at least one module enabled.');
        }
        $new['modules'] = json_encode($mods);
    }
    foreach (array('latest_client', 'min_client') as $k) {
        if (array_key_exists($k, $in)) {
            $v = trim(td_str($in, $k, 20));
            if (!td_owner_version_ok($v)) {
                td_fail(400, 'bad_value', 'A version looks like 1.2.0.');
            }
            $new[$k] = $v;
        }
    }
    $latest = isset($new['latest_client']) ? $new['latest_client'] : (string)td_config()['latest_client'];
    $min = isset($new['min_client']) ? $new['min_client'] : (string)td_config()['min_client'];
    if ($latest !== '' && $min !== '' && version_compare($min, $latest, '>')) {
        td_fail(400, 'bad_value', 'The oldest allowed version cannot be newer than the latest version.');
    }
    if (array_key_exists('download_url', $in)) {
        $u = trim(td_str($in, 'download_url', 400));
        if (!td_url_ok($u)) {
            td_fail(400, 'bad_value', 'The download link must start with https://');
        }
        $new['download_url'] = $u;
    }
    if (array_key_exists('notice', $in)) {
        $new['notice'] = substr(trim(td_str($in, 'notice', 500)), 0, 500);
    }
    if (array_key_exists('maintenance', $in)) {
        $new['maintenance'] = !empty($in['maintenance']) ? '1' : '0';
    }
    if (array_key_exists('maintenance_message', $in)) {
        $new['maintenance_message'] = substr(trim(td_str($in, 'maintenance_message', 300)), 0, 300);
    }
    if (array_key_exists('api_url', $in)) {
        $u = trim(td_str($in, 'api_url', 400));
        if (!td_url_ok($u)) {
            td_fail(400, 'bad_value', 'The server address must start with https:// (for example https://your-domain.com/taskdesk/api.php).');
        }
        if ($u !== '' && !preg_match('#/api\.php$#', parse_url($u, PHP_URL_PATH) ?: '')) {
            td_fail(400, 'bad_value', 'The server address must end with api.php');
        }
        $new['api_url'] = $u;
    }
    $before = td_settings_all();
    foreach ($new as $k => $v) {
        if (!isset($before[$k]) || (string)$before[$k] !== (string)$v) {
            $changed[] = $k;
        }
        td_setting_set($k, $v);
    }
    if (count($changed)) {
        td_audit($o['username'], 'settings_save', '', implode(', ', $changed));
    }
    td_json(td_owner_settings_payload());
}

function td_owner_audit()
{
    td_method('GET');
    $per = max(1, min(300, isset($_GET['per']) ? (int)$_GET['per'] : 100));
    $page = max(1, isset($_GET['page']) ? (int)$_GET['page'] : 1);
    $q = strtolower(trim(isset($_GET['q']) ? (string)$_GET['q'] : ''));
    $w = '';
    $par = array();
    if ($q !== '') {
        $w = ' WHERE INSTR(LOWER(actor), ?) > 0 OR INSTR(LOWER(action), ?) > 0 OR INSTR(LOWER(target), ?) > 0';
        $par = array($q, $q, $q);
    }
    $rows = td_rows('SELECT ts, actor, action, target, detail FROM td_audit' . $w . ' ORDER BY id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), $par);
    td_json(array('ok' => true, 'items' => $rows, 'page' => $page, 'per' => $per));
}

// ---------------------------------------------------------------- router
function td_owner_route($route)
{
    switch ($route) {
        case 'owner/status':
            td_owner_status();
            return;
        case 'owner/login':
            td_owner_login();
            return;
    }
    $o = td_owner_require();
    switch ($route) {
        case 'owner/logout':
            td_owner_logout();
            return;
        case 'owner/dashboard':
            td_owner_dashboard();
            return;
        case 'owner/users':
            td_owner_users_list();
            return;
        case 'owner/user':
            td_owner_user_detail();
            return;
        case 'owner/user/save':
            td_owner_user_save($o);
            return;
        case 'owner/user/create':
            td_owner_user_create($o);
            return;
        case 'owner/user/reset_password':
            td_owner_user_reset_password($o);
            return;
        case 'owner/user/new_recovery':
            td_owner_user_new_recovery($o);
            return;
        case 'owner/user/signout':
            td_owner_user_signout($o);
            return;
        case 'owner/user/delete':
            td_owner_user_delete($o);
            return;
        case 'owner/settings':
            td_owner_settings_get();
            return;
        case 'owner/settings/save':
            td_owner_settings_save($o);
            return;
        case 'owner/audit':
            td_owner_audit();
            return;
        case 'owner/password':
            td_owner_change_password($o);
            return;
        case 'owner/totp/begin':
            td_owner_totp($o, 'begin');
            return;
        case 'owner/totp/enable':
            td_owner_totp($o, 'enable');
            return;
        case 'owner/totp/disable':
            td_owner_totp($o, 'disable');
            return;
        case 'owner/me':
            td_method('GET');
            td_json(array('ok' => true, 'username' => $o['username'], 'totp' => (int)$o['totp_on'] === 1));
            return;
    }
    td_fail(404, 'unknown_call', 'Unknown API call.');
}
