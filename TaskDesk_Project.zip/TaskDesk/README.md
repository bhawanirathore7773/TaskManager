# TaskDesk

One installable Windows desktop product for SAP consultants. It combines three task managers
(**ABAP Developer**, **FICO Consultant**, **MM Consultant**) behind a single sign-in, with all data backed up to your
own Hostinger database through a PHP API.

Author: **Bhawani Singh, ABAP Developer at Mayur Uniquoters**

## What it does

- Installs like normal software (Inno Setup wizard). A dropdown in the wizard picks the module edition.
- First launch: create an ID and password. The sign-in persists. Sign out brings the login screen back.
- Sign in with an account of another module and the software converts itself to that module.
- Everything is stored locally (instant screens, works offline) and replicated to the cloud in the background.
- Files (images, Excel, PDF) stay in local per-task folders and are uploaded; on a new PC they are restored on sign-in.
- An About section for every user.
- New modules can be added later without touching the sync or login code.

## Folders

| Folder | Content |
|---|---|
| `server/` | PHP 7.4+ / MySQL cloud API. Upload this to Hostinger. |
| `client/app/` | The desktop app: gate (login), module host, sync engine, shell UI, the three modules. |
| `installer/` | Inno Setup script and the PowerShell build script. |
| `tests/` | `test_server.py` (99), `test_e2e.py` (79), `test_ui.py` (12). |
| `tools/` | `import_modules.py` copies the three original task managers into `client/app/modules/`. |
| `docs/` | Guides (below). |

## Start here

1. `docs/01_HOSTINGER_SETUP_HINGLISH.md`: put the server on Hostinger (about 15 minutes).
2. `docs/02_BUILD_INSTALLER_HINGLISH.md`: build `TaskDesk_Setup_1.0.0.exe` with your server address.
3. `docs/03_USER_GUIDE_HINGLISH.md`: how users work with it.
4. `docs/04_ARCHITECTURE.md`: design, security, limits (English).
5. `docs/05_ADD_NEW_MODULE.md`: how to add a module.

## Quick try from source (no installer)

```
set TASKDESK_CLOUD=https://your-domain.com/taskdesk/api.php
Run_From_Source.bat
```
(needs Python 3.8+ on that PC)

## Known limits

Single active device assumed (two PCs creating rows offline at once can collide); last writer wins per row; the Windows installer,
DPAPI and embedded Python were not run on Windows during development; the MySQL schema was tested through SQLite only; the installer is unsigned
(SmartScreen warning). Details in `docs/04_ARCHITECTURE.md`.
