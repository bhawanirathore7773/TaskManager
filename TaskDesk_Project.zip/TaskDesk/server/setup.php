<?php
/*
 * TaskDesk server setup (run once).
 * Upload the "server" folder to your hosting, open this page in the browser, fill the database details
 * from hPanel > Databases, press "Install". The page then closes itself.
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');

require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/schema.php';

function h($s)
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function page($title, $body)
{
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Frame-Options: DENY');
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        . '<meta name="robots" content="noindex"><title>' . h($title) . '</title><style>'
        . ':root{--ink:#1b1f2a;--sub:#5b6275;--line:#dfe3ec;--bg:#f3f5fa;--acc:#3b4cca;--ok:#1b7f4b;--bad:#b3261e}'
        . '*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.55 "Segoe UI",system-ui,sans-serif}'
        . '.wrap{max-width:720px;margin:0 auto;padding:32px 16px 64px}h1{font-size:26px;margin:0 0 4px}.sub{color:var(--sub);margin:0 0 24px}'
        . '.card{background:#fff;border:1px solid var(--line);border-radius:10px;padding:20px 22px;margin-bottom:18px}'
        . 'h2{font-size:16px;margin:0 0 12px}label{display:block;font-weight:600;margin:12px 0 4px}'
        . 'input[type=text],input[type=password],input[type=number]{width:100%;padding:9px 11px;border:1px solid #c7cdda;border-radius:7px;font:inherit}'
        . 'input:focus{outline:2px solid var(--acc);outline-offset:1px}small{color:var(--sub);display:block;margin-top:3px}'
        . '.row{display:flex;gap:14px;flex-wrap:wrap}.row>div{flex:1 1 200px}'
        . 'button{background:var(--acc);color:#fff;border:0;border-radius:8px;padding:11px 22px;font:inherit;font-weight:600;cursor:pointer}'
        . '.chk{list-style:none;padding:0;margin:0}.chk li{padding:4px 0}.ok{color:var(--ok);font-weight:700}.bad{color:var(--bad);font-weight:700}'
        . '.err{background:#fdecea;border:1px solid #f1b8b4;color:#7a1712;padding:11px 14px;border-radius:8px;margin-bottom:16px}'
        . 'code,.url{background:#eef1f8;padding:2px 7px;border-radius:5px;font-family:Consolas,monospace;word-break:break-all}'
        . '.opt label{display:inline-flex;align-items:center;gap:6px;font-weight:500;margin:4px 14px 4px 0}'
        . '</style></head><body><div class="wrap">' . $body . '</div></body></html>';
    exit;
}

$configFile = td_root() . '/config.php';
if (is_file($configFile)) {
    page('TaskDesk setup', '<h1>TaskDesk server</h1><p class="sub">Already set up.</p><div class="card"><p>This server is installed. '
        . 'For safety please <b>delete setup.php</b> from the server (File Manager in hPanel).</p></div>');
}

$known = array('abap' => 'ABAP developer', 'fico' => 'FICO consultant', 'mm' => 'MM consultant');

$checks = array();
$checks[] = array('PHP version 7.4 or newer (found ' . PHP_VERSION . ')', version_compare(PHP_VERSION, '7.4.0', '>='));
$checks[] = array('Database driver (pdo_mysql)', extension_loaded('pdo_mysql'));
$checks[] = array('JSON support', function_exists('json_encode'));
$checks[] = array('Can write to this folder (for config.php)', is_writable(td_root()));
$postMb = td_ini_bytes('post_max_size') > 0 ? (int)floor(td_ini_bytes('post_max_size') / 1048576) : 0;
$notes = array();
if ($postMb > 0 && $postMb < 40) {
    $notes[] = 'PHP post_max_size is ' . $postMb . ' MB, so the biggest file that can be uploaded is about ' . max(1, $postMb - 1) . ' MB. '
        . 'Raise post_max_size and upload_max_filesize (hPanel > Advanced > PHP Configuration > PHP Options) to 128M or more if users will attach big PDFs or Excel files.';
}
$allOk = true;
foreach ($checks as $c) {
    if (!$c[1]) {
        $allOk = false;
    }
}

$defaultStorage = td_root() . '/storage';
if (preg_match('#^(.*)/public_html(/|$)#', str_replace('\\', '/', td_root()), $m)) {
    $defaultStorage = $m[1] . '/taskdesk_storage';
}

$error = '';
$v = array(
    'host' => 'localhost', 'name' => '', 'user' => '', 'pass' => '', 'storage' => $defaultStorage,
    'invite' => '', 'quota' => 2048, 'maxfile' => 500, 'open' => 1, 'modules' => array('abap', 'fico', 'mm'),
);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $allOk) {
    $v['host'] = trim((string)($_POST['host'] ?? 'localhost'));
    $v['name'] = trim((string)($_POST['name'] ?? ''));
    $v['user'] = trim((string)($_POST['user'] ?? ''));
    $v['pass'] = (string)($_POST['pass'] ?? '');
    $v['storage'] = rtrim(str_replace('\\', '/', trim((string)($_POST['storage'] ?? ''))), '/');
    $v['invite'] = trim((string)($_POST['invite'] ?? ''));
    $v['quota'] = max(50, (int)($_POST['quota'] ?? 2048));
    $v['maxfile'] = max(1, (int)($_POST['maxfile'] ?? 500));
    $v['open'] = !empty($_POST['open']) ? 1 : 0;
    $v['modules'] = array();
    foreach ($known as $k => $label) {
        if (!empty($_POST['mod_' . $k])) {
            $v['modules'][] = $k;
        }
    }
    if ($v['name'] === '' || $v['user'] === '') {
        $error = 'Please fill the database name and the database user.';
    } elseif (!count($v['modules'])) {
        $error = 'Select at least one module.';
    } elseif ($v['storage'] === '') {
        $error = 'Please give a storage folder.';
    } else {
        try {
            $pdo = new PDO('mysql:host=' . $v['host'] . ';dbname=' . $v['name'] . ';charset=utf8mb4', $v['user'], $v['pass'], array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            ));
            td_create_schema($pdo, 'mysql');
            $pdo->query('SELECT COUNT(*) FROM td_users')->fetch();
        } catch (Throwable $e) {
            $error = 'Could not connect to the database or create the tables. Check the name, user and password in hPanel > Databases. (' . $e->getMessage() . ')';
        }
        if ($error === '') {
            if (!is_dir($v['storage'])) {
                @mkdir($v['storage'], 0755, true);
            }
            if (!is_dir($v['storage']) || !is_writable($v['storage'])) {
                // fall back to a folder next to the API
                $v['storage'] = td_root() . '/storage';
                if (!is_dir($v['storage'])) {
                    @mkdir($v['storage'], 0755, true);
                }
            }
            if (!is_dir($v['storage']) || !is_writable($v['storage'])) {
                $error = 'The storage folder cannot be created or written. Create it in File Manager and try again.';
            }
        }
        if ($error === '') {
            @file_put_contents($v['storage'] . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n");
            @file_put_contents($v['storage'] . '/index.html', '');
            $cfg = array(
                'db' => array('driver' => 'mysql', 'host' => $v['host'], 'name' => $v['name'], 'user' => $v['user'], 'pass' => $v['pass']),
                'storage' => $v['storage'],
                'secret' => bin2hex(random_bytes(32)),
                'modules' => $v['modules'],
                'allow_registration' => (bool)$v['open'],
                'invite_code' => $v['invite'],
                'quota_mb' => $v['quota'],
                'max_file_mb' => $v['maxfile'],
                'token_days' => 90,
                'require_https' => true,
                'latest_client' => '1.0.0',
                'min_client' => '1.0.0',
                'download_url' => '',
                'notice' => '',
            );
            $php = "<?php\n// Written by setup.php on " . gmdate('Y-m-d H:i') . " UTC. Keep this file private.\nreturn " . var_export($cfg, true) . ";\n";
            if (@file_put_contents($configFile, $php, LOCK_EX) === false) {
                $error = 'Could not write config.php in this folder. Check folder permissions in File Manager.';
            } else {
                @chmod($configFile, 0640);
                $scheme = td_is_https() ? 'https' : 'http';
                $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'your-domain.com';
                $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
                $apiUrl = $scheme . '://' . $host . $dir . '/api.php';
                $renamed = @rename(__FILE__, __FILE__ . '.done');
                page('TaskDesk setup finished', '<h1>All set</h1><p class="sub">The TaskDesk server is ready.</p>'
                    . '<div class="card"><h2>Server address for the desktop app</h2><p><span class="url">' . h($apiUrl) . '</span></p>'
                    . '<p>Put this address in <code>client/app/taskdesk_config.json</code> before building the installer, '
                    . 'or type it under "Advanced" on the login screen of the app.</p></div>'
                    . '<div class="card"><h2>Next</h2><ul><li>' . ($renamed ? 'setup.php was closed automatically.' : '<b>Delete setup.php</b> now (File Manager).') . '</li>'
                    . '<li>Open <span class="url">' . h($apiUrl) . '?r=health&amp;deep=1</span> - you should see <code>"ok":true</code>, <code>"db":true</code>, <code>"storage":true</code>.</li>'
                    . '<li>Your files are stored in <code>' . h($v['storage']) . '</code>.</li></ul></div>');
            }
        }
    }
}

$body = '<h1>TaskDesk server setup</h1><p class="sub">One time setup. Takes about two minutes.</p>';
$body .= '<div class="card"><h2>Server check</h2><ul class="chk">';
foreach ($checks as $c) {
    $body .= '<li>' . ($c[1] ? '<span class="ok">OK</span>' : '<span class="bad">Problem</span>') . ' &nbsp;' . h($c[0]) . '</li>';
}
$body .= '</ul>';
foreach ($notes as $n) {
    $body .= '<p style="margin:10px 0 0;color:#8a5a00">' . h($n) . '</p>';
}
$body .= '</div>';
if (!$allOk) {
    $body .= '<div class="err">Fix the problems above first (hPanel > Advanced > PHP Configuration), then reload this page.</div>';
    page('TaskDesk setup', $body);
}
if ($error !== '') {
    $body .= '<div class="err">' . h($error) . '</div>';
}
$body .= '<form method="post" autocomplete="off"><div class="card"><h2>Database</h2>'
    . '<p style="margin:0;color:#5b6275">Create a MySQL database in hPanel &gt; Databases &gt; Management, then type its details here.</p>'
    . '<div class="row"><div><label>Database name</label><input type="text" name="name" value="' . h($v['name']) . '" required></div>'
    . '<div><label>Database user</label><input type="text" name="user" value="' . h($v['user']) . '" required></div></div>'
    . '<div class="row"><div><label>Database password</label><input type="password" name="pass" value=""></div>'
    . '<div><label>Database host</label><input type="text" name="host" value="' . h($v['host']) . '"><small>Keep "localhost" on Hostinger.</small></div></div></div>'
    . '<div class="card"><h2>Who can use it</h2><div class="opt">';
foreach ($known as $k => $label) {
    $body .= '<label><input type="checkbox" name="mod_' . h($k) . '" value="1"' . (in_array($k, $v['modules'], true) ? ' checked' : '') . '> ' . h($label) . '</label>';
}
$body .= '</div><label><span class="opt"><label style="margin:0"><input type="checkbox" name="open" value="1"' . ($v['open'] ? ' checked' : '') . '> Anyone with the app can create an account</label></span></label>'
    . '<label>Invite code (optional)</label><input type="text" name="invite" value="' . h($v['invite']) . '">'
    . '<small>If you set a word here, only people who know it can create an account.</small></div>'
    . '<div class="card"><h2>Storage</h2><label>Folder for uploaded files</label><input type="text" name="storage" value="' . h($v['storage']) . '">'
    . '<small>A folder outside public_html is safest. It is created if it does not exist.</small>'
    . '<div class="row"><div><label>Space per user (MB)</label><input type="number" name="quota" value="' . (int)$v['quota'] . '"></div>'
    . '<div><label>Biggest single file (MB)</label><input type="number" name="maxfile" value="' . (int)$v['maxfile'] . '"></div></div></div>'
    . '<button type="submit">Install</button></form>';
page('TaskDesk setup', $body);
