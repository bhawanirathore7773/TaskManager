<?php
/*
 * TaskDesk cloud API - single entry point.
 * Calls look like  api.php?r=auth/login  (works on every hosting, no URL rewriting needed).
 */
error_reporting(E_ALL);
ini_set('display_errors', '0');

require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/schema.php';
require __DIR__ . '/lib/auth.php';
require __DIR__ . '/lib/sync.php';
require __DIR__ . '/lib/files.php';

set_exception_handler(function ($e) {
    td_log('uncaught ' . get_class($e) . ': ' . $e->getMessage() . ' at ' . basename($e->getFile()) . ':' . $e->getLine());
    td_fail(500, 'server_error', 'Something went wrong on the server. Please try again.');
});

$cfg = td_config();
if ($cfg['require_https'] && !td_is_https()) {
    td_fail(400, 'https_required', 'This server only accepts secure (https) connections.');
}

$route = isset($_GET['r']) ? trim((string)$_GET['r'], '/') : '';

// refuse very old desktop versions (the health call is always allowed so the app can tell the user to update)
if ($route !== 'health' && $route !== '') {
    $client = isset($_SERVER['HTTP_X_TD_CLIENT']) ? preg_replace('/[^0-9.]/', '', (string)$_SERVER['HTTP_X_TD_CLIENT']) : '';
    if ($client !== '' && version_compare($client, (string)$cfg['min_client'], '<')) {
        td_fail(426, 'upgrade_required', 'Please install the latest TaskDesk version to keep syncing.');
    }
}

switch ($route) {
    case 'health':
        td_method('GET');
        $out = array(
            'ok' => true,
            'app' => 'taskdesk-api',
            'api' => TD_API_VERSION,
            'server' => TD_SERVER_VERSION,
            'time' => td_now(),
            'modules' => array_values($cfg['modules']),
            'registration' => (bool)$cfg['allow_registration'],
            'invite_required' => $cfg['invite_code'] !== '',
            'latest_client' => (string)$cfg['latest_client'],
            'min_client' => (string)$cfg['min_client'],
            'download_url' => (string)$cfg['download_url'],
            'notice' => (string)$cfg['notice'],
            'max_file_mb' => td_max_file_mb($cfg),
            'quota_mb' => (int)$cfg['quota_mb'],
        );
        if (isset($_GET['deep'])) {
            td_val('SELECT COUNT(*) FROM td_users');
            $out['db'] = true;
            $dir = td_storage_dir();
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
            $out['storage'] = is_dir($dir) && is_writable($dir);
        }
        td_json($out);
        break;
    case 'auth/register':
        td_route_register();
        break;
    case 'auth/login':
        if (mt_rand(1, 100) === 1) {
            td_purge_old();
        }
        td_route_login();
        break;
    case 'auth/logout':
        td_route_logout();
        break;
    case 'auth/me':
        td_route_me();
        break;
    case 'auth/password':
        td_route_password();
        break;
    case 'auth/recover':
        td_route_recover();
        break;
    case 'sync/push':
        td_route_push();
        break;
    case 'sync/pull':
        td_route_pull();
        break;
    case 'sync/status':
        td_route_status();
        break;
    case 'files/put':
        td_route_file_put();
        break;
    case 'files/get':
        td_route_file_get();
        break;
    case 'files/del':
        td_route_file_del();
        break;
    case 'files/list':
        td_route_file_list();
        break;
    default:
        td_fail(404, 'unknown_call', 'Unknown API call.');
}
