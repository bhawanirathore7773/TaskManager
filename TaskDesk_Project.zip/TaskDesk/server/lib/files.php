<?php
/*
 * File storage. A file is addressed by its relative path inside the user's data folder
 * (for example  T-0003_PO_release/2_Excel_Requirement/list.xlsx ).
 * On disk the file is stored under a keyed hash of that path, so no user supplied text ever becomes a disk path.
 */

function td_clean_rel($rel)
{
    $rel = str_replace('\\', '/', (string)$rel);
    if ($rel === '' || strlen($rel) > 400 || $rel[0] === '/' || preg_match('/[\x00-\x1f]/', $rel)) {
        return null;
    }
    foreach (explode('/', $rel) as $seg) {
        if ($seg === '' || $seg === '.' || $seg === '..' || substr($seg, -1) === ' ') {
            return null;
        }
    }
    return $rel;
}

function td_rel_hash($uid, $rel)
{
    return td_hmac('file|' . (int)$uid . '|' . $rel);
}

function td_blob_path($uid, $relHash)
{
    return td_user_dir($uid) . '/f/' . substr($relHash, 0, 2) . '/' . $relHash;
}

function td_param_rel()
{
    $rel = td_clean_rel(isset($_GET['rel']) ? $_GET['rel'] : '');
    if ($rel === null) {
        td_fail(400, 'bad_path', 'The file path is not valid.');
    }
    return $rel;
}

function td_route_file_put()
{
    td_method('POST');
    $u = td_require_user();
    $c = td_config();
    $uid = (int)$u['id'];
    $rel = td_param_rel();
    $sha = isset($_GET['sha']) ? strtolower((string)$_GET['sha']) : '';
    if ($sha !== '' && !preg_match('/^[a-f0-9]{64}$/', $sha)) {
        td_fail(400, 'bad_sha', 'The checksum is not valid.');
    }
    $len = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : -1;
    $maxMb = td_max_file_mb($c);
    $maxFile = $maxMb * 1048576;
    if ($len > $maxFile) {
        td_fail(413, 'file_too_large', 'This file is larger than ' . $maxMb . ' MB, the most this server accepts.');
    }
    $relHash = td_rel_hash($uid, $rel);
    $old = td_row('SELECT size FROM td_files WHERE user_id=? AND rel_hash=?', array($uid, $relHash));
    $oldSize = $old ? (int)$old['size'] : 0;
    $quota = (int)$c['quota_mb'] * 1048576;
    if ($len >= 0 && (int)$u['bytes_used'] - $oldSize + $len > $quota) {
        td_fail(413, 'quota_exceeded', 'Your cloud storage is full (' . (int)$c['quota_mb'] . ' MB).');
    }
    @set_time_limit(0);
    $dir = td_user_dir($uid);
    $tmp = $dir . '/tmp/' . td_random_hex(8);
    $in = fopen('php://input', 'rb');
    $out = fopen($tmp, 'wb');
    if (!$in || !$out) {
        td_fail(500, 'server_error', 'Could not write the file.');
    }
    $ctx = hash_init('sha256');
    $size = 0;
    $tooBig = false;
    while (!feof($in)) {
        $chunk = fread($in, 1048576);
        if ($chunk === false || $chunk === '') {
            break;
        }
        $size += strlen($chunk);
        if ($size > $maxFile || (int)$u['bytes_used'] - $oldSize + $size > $quota) {
            $tooBig = true;
            break;
        }
        hash_update($ctx, $chunk);
        fwrite($out, $chunk);
    }
    fclose($in);
    fclose($out);
    if ($tooBig) {
        @unlink($tmp);
        td_fail(413, 'quota_exceeded', 'The file is too large or your cloud storage is full.');
    }
    $actual = hash_final($ctx);
    if ($sha !== '' && $sha !== $actual) {
        @unlink($tmp);
        td_fail(422, 'checksum_mismatch', 'The upload was damaged on the way. Try again.');
    }
    if ($len >= 0 && $size !== $len) {
        @unlink($tmp);
        td_fail(400, 'upload_interrupted', 'The upload was interrupted. Try again.');
    }
    $final = td_blob_path($uid, $relHash);
    if (!is_dir(dirname($final))) {
        @mkdir(dirname($final), 0755, true);
    }
    if (!@rename($tmp, $final)) {
        if (!@copy($tmp, $final)) {
            @unlink($tmp);
            td_fail(500, 'server_error', 'Could not store the file.');
        }
        @unlink($tmp);
    }
    try {
        td_begin();
        if (td_driver() === 'sqlite') {
            td_exec('INSERT INTO td_files(user_id,rel_hash,rel,size,sha256,updated_at) VALUES(?,?,?,?,?,?)
                     ON CONFLICT(user_id,rel_hash) DO UPDATE SET rel=excluded.rel,size=excluded.size,sha256=excluded.sha256,updated_at=excluded.updated_at',
                array($uid, $relHash, $rel, $size, $actual, td_now()));
        } else {
            td_exec('INSERT INTO td_files(user_id,rel_hash,rel,size,sha256,updated_at) VALUES(?,?,?,?,?,?)
                     ON DUPLICATE KEY UPDATE rel=VALUES(rel),size=VALUES(size),sha256=VALUES(sha256),updated_at=VALUES(updated_at)',
                array($uid, $relHash, $rel, $size, $actual, td_now()));
        }
        td_exec('UPDATE td_users SET bytes_used = bytes_used + ? WHERE id=?', array($size - $oldSize, $uid));
        td_commit();
    } catch (Throwable $e) {
        td_rollback();
        td_log('file put failed for user ' . $uid . ': ' . $e->getMessage());
        td_fail(500, 'server_error', 'Could not save the file record.');
    }
    td_json(array('ok' => true, 'size' => $size, 'sha256' => $actual));
}

function td_route_file_get()
{
    td_method('GET');
    $u = td_require_user();
    $uid = (int)$u['id'];
    $rel = td_param_rel();
    $relHash = td_rel_hash($uid, $rel);
    $row = td_row('SELECT size, sha256 FROM td_files WHERE user_id=? AND rel_hash=?', array($uid, $relHash));
    $path = td_blob_path($uid, $relHash);
    if (!$row || !is_file($path)) {
        td_fail(404, 'file_not_found', 'This file is not in the cloud.');
    }
    @set_time_limit(0);
    @ini_set('zlib.output_compression', 'Off');
    while (ob_get_level() > 0) {
        @ob_end_clean();
    }
    td_send_headers('application/octet-stream');
    header('Content-Length: ' . filesize($path));
    header('X-TD-SHA256: ' . $row['sha256']);
    $f = fopen($path, 'rb');
    while ($f && !feof($f)) {
        echo fread($f, 1048576);
        flush();
    }
    if ($f) {
        fclose($f);
    }
    exit;
}

function td_route_file_del()
{
    td_method('POST');
    $u = td_require_user();
    $uid = (int)$u['id'];
    $in = td_input();
    $rel = td_clean_rel(td_str($in, 'rel', 400));
    if ($rel === null) {
        td_fail(400, 'bad_path', 'The file path is not valid.');
    }
    $relHash = td_rel_hash($uid, $rel);
    $row = td_row('SELECT size FROM td_files WHERE user_id=? AND rel_hash=?', array($uid, $relHash));
    if ($row) {
        $path = td_blob_path($uid, $relHash);
        if (is_file($path)) {
            $trash = td_user_dir($uid) . '/trash/' . time() . '_' . substr($relHash, 0, 16);
            if (!@rename($path, $trash)) {
                @unlink($path);
            }
        }
        td_exec('DELETE FROM td_files WHERE user_id=? AND rel_hash=?', array($uid, $relHash));
        td_exec('UPDATE td_users SET bytes_used = CASE WHEN bytes_used > ? THEN bytes_used - ? ELSE 0 END WHERE id=?',
            array((int)$row['size'], (int)$row['size'], $uid));
    }
    td_json(array('ok' => true));
}

function td_route_file_list()
{
    td_method('GET');
    $u = td_require_user();
    $rows = td_rows('SELECT rel, size, sha256 FROM td_files WHERE user_id=? ORDER BY rel', array((int)$u['id']));
    $out = array();
    foreach ($rows as $r) {
        $out[] = array('rel' => $r['rel'], 'size' => (int)$r['size'], 'sha' => $r['sha256']);
    }
    td_json(array('ok' => true, 'files' => $out));
}

// removes trash older than 30 days; called now and then
function td_purge_old()
{
    try {
        td_exec('DELETE FROM td_tokens WHERE expires_at<?', array(td_now()));
        $base = td_storage_dir();
        foreach ((array)glob($base . '/u*/trash/*') as $f) {
            if (is_file($f) && filemtime($f) < time() - 30 * 86400) {
                @unlink($f);
            }
        }
        foreach ((array)glob($base . '/u*/tmp/*') as $f) {
            if (is_file($f) && filemtime($f) < time() - 86400) {
                @unlink($f);
            }
        }
    } catch (Throwable $e) {
        // housekeeping only
    }
}
