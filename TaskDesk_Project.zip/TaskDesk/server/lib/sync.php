<?php
/*
 * Generic record sync. The desktop app sends rows of its local tables as JSON documents.
 * The server keeps one document per (user, table, row id) and gives every change a growing revision number,
 * so a device can ask "what changed after revision N".
 */

function td_valid_table($t)
{
    return (bool)preg_match('/^[A-Za-z_][A-Za-z0-9_]{0,39}$/', $t);
}

function td_upsert_record_sql()
{
    if (td_driver() === 'sqlite') {
        return 'INSERT INTO td_records(user_id,tbl,rid,data,deleted,rev,updated_at) VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(user_id,tbl,rid) DO UPDATE SET data=excluded.data, deleted=excluded.deleted, rev=excluded.rev, updated_at=excluded.updated_at';
    }
    return 'INSERT INTO td_records(user_id,tbl,rid,data,deleted,rev,updated_at) VALUES(?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE data=VALUES(data), deleted=VALUES(deleted), rev=VALUES(rev), updated_at=VALUES(updated_at)';
}

function td_route_push()
{
    td_method('POST');
    $u = td_require_user();
    $in = td_input(8 * 1024 * 1024);
    $ops = isset($in['ops']) && is_array($in['ops']) ? $in['ops'] : null;
    if ($ops === null) {
        td_fail(400, 'bad_request', 'ops is missing.');
    }
    if (count($ops) > 500) {
        td_fail(400, 'too_many_ops', 'Send at most 500 changes per request.');
    }
    $clean = array();
    foreach ($ops as $op) {
        if (!is_array($op)) {
            td_fail(400, 'bad_op', 'A change is not valid.');
        }
        $t = isset($op['t']) ? (string)$op['t'] : '';
        $id = isset($op['id']) ? (string)$op['id'] : '';
        $kind = isset($op['op']) ? (string)$op['op'] : '';
        if (!td_valid_table($t) || $id === '' || strlen($id) > 120 || ($kind !== 'put' && $kind !== 'del')) {
            td_fail(400, 'bad_op', 'A change is not valid.');
        }
        if ($kind === 'put') {
            if (!isset($op['d']) || !is_array($op['d']) || count($op['d']) === 0) {
                td_fail(400, 'bad_op', 'A change has no data.');
            }
            $json = json_encode($op['d'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false || strlen($json) > 1048576) {
                td_fail(413, 'record_too_large', 'One record is too large (limit 1 MB).');
            }
            $clean[] = array($t, $id, $json, 0);
        } else {
            $clean[] = array($t, $id, 'null', 1);
        }
    }
    $uid = (int)$u['id'];
    $now = td_now();
    $sql = td_upsert_record_sql();
    try {
        td_begin();
        $forUpdate = td_driver() === 'mysql' ? ' FOR UPDATE' : '';
        $rev = (int)td_val('SELECT rev FROM td_users WHERE id=?' . $forUpdate, array($uid));
        $st = td_db()->prepare($sql);
        foreach ($clean as $c) {
            $rev++;
            $st->execute(array($uid, $c[0], $c[1], $c[2], $c[3], $rev, $now));
        }
        td_exec('UPDATE td_users SET rev=? WHERE id=?', array($rev, $uid));
        td_commit();
    } catch (Throwable $e) {
        td_rollback();
        td_log('push failed for user ' . $uid . ': ' . $e->getMessage());
        td_fail(500, 'server_error', 'Could not save the changes. Try again.');
    }
    td_json(array('ok' => true, 'applied' => count($clean), 'rev' => $rev));
}

function td_route_pull()
{
    td_method('GET');
    $u = td_require_user();
    $since = isset($_GET['since']) ? (int)$_GET['since'] : 0;
    if ($since < 0) {
        $since = 0;
    }
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 500;
    if ($limit < 1) {
        $limit = 1;
    }
    if ($limit > 2000) {
        $limit = 2000;
    }
    $rows = td_rows('SELECT tbl, rid, data, deleted, rev FROM td_records WHERE user_id=? AND rev>? ORDER BY rev ASC LIMIT ' . $limit,
        array((int)$u['id'], $since));
    $parts = array();
    $last = $since;
    foreach ($rows as $r) {
        $last = (int)$r['rev'];
        $d = ((int)$r['deleted'] === 1) ? 'null' : $r['data'];
        $parts[] = '{"t":' . json_encode($r['tbl']) . ',"id":' . json_encode($r['rid'], JSON_UNESCAPED_UNICODE) . ',"del":' . (int)$r['deleted'] . ',"rev":' . $last . ',"d":' . $d . '}';
    }
    $serverRev = (int)td_val('SELECT rev FROM td_users WHERE id=?', array((int)$u['id']));
    td_send_headers();
    echo '{"ok":true,"last":' . $last . ',"server_rev":' . $serverRev . ',"more":' . (count($rows) >= $limit ? 'true' : 'false') . ',"records":[' . implode(',', $parts) . ']}';
    exit;
}

function td_route_status()
{
    td_method('GET');
    $u = td_require_user();
    $c = td_config();
    $uid = (int)$u['id'];
    td_json(array(
        'ok' => true,
        'rev' => (int)$u['rev'],
        'records' => (int)td_val('SELECT COUNT(*) FROM td_records WHERE user_id=? AND deleted=0', array($uid)),
        'files' => (int)td_val('SELECT COUNT(*) FROM td_files WHERE user_id=?', array($uid)),
        'bytes_used' => (int)$u['bytes_used'],
        'quota_bytes' => (int)$c['quota_mb'] * 1048576,
    ));
}
