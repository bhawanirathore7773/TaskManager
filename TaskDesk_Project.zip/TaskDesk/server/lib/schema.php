<?php
/* Database tables for the TaskDesk cloud API (MySQL / MariaDB for production, SQLite for tests). */

function td_schema_sql($driver)
{
    if ($driver === 'sqlite') {
        return array(
            'CREATE TABLE IF NOT EXISTS td_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                display_name TEXT NOT NULL,
                module TEXT NOT NULL,
                pass_hash TEXT NOT NULL,
                recovery_hash TEXT NOT NULL,
                rev INTEGER NOT NULL DEFAULT 0,
                bytes_used INTEGER NOT NULL DEFAULT 0,
                status INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL,
                last_login TEXT NULL
            )',
            'CREATE TABLE IF NOT EXISTS td_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                token_hash TEXT NOT NULL UNIQUE,
                device TEXT NOT NULL,
                created_at TEXT NOT NULL,
                last_used TEXT NOT NULL,
                expires_at TEXT NOT NULL
            )',
            'CREATE INDEX IF NOT EXISTS ix_tokens_user ON td_tokens(user_id)',
            'CREATE TABLE IF NOT EXISTS td_records (
                user_id INTEGER NOT NULL,
                tbl TEXT NOT NULL,
                rid TEXT NOT NULL,
                data TEXT NOT NULL,
                deleted INTEGER NOT NULL DEFAULT 0,
                rev INTEGER NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (user_id, tbl, rid)
            )',
            'CREATE INDEX IF NOT EXISTS ix_records_rev ON td_records(user_id, rev)',
            'CREATE TABLE IF NOT EXISTS td_files (
                user_id INTEGER NOT NULL,
                rel_hash TEXT NOT NULL,
                rel TEXT NOT NULL,
                size INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (user_id, rel_hash)
            )',
            'CREATE TABLE IF NOT EXISTS td_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kind TEXT NOT NULL,
                k TEXT NOT NULL,
                ts INTEGER NOT NULL
            )',
            'CREATE INDEX IF NOT EXISTS ix_attempts ON td_attempts(kind, k, ts)',
        );
    }
    $tail = ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';
    $bin = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_bin';
    return array(
        'CREATE TABLE IF NOT EXISTS td_users (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(40) NOT NULL,
            display_name VARCHAR(100) NOT NULL,
            module VARCHAR(20) NOT NULL,
            pass_hash VARCHAR(255) NOT NULL,
            recovery_hash CHAR(64) NOT NULL,
            rev BIGINT UNSIGNED NOT NULL DEFAULT 0,
            bytes_used BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status TINYINT NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            last_login DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_username (username)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_tokens (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            token_hash CHAR(64) NOT NULL,
            device VARCHAR(100) NOT NULL,
            created_at DATETIME NOT NULL,
            last_used DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_token (token_hash),
            KEY ix_tokens_user (user_id)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_records (
            user_id INT UNSIGNED NOT NULL,
            tbl VARCHAR(40) ' . $bin . ' NOT NULL,
            rid VARCHAR(120) ' . $bin . ' NOT NULL,
            data MEDIUMTEXT NOT NULL,
            deleted TINYINT NOT NULL DEFAULT 0,
            rev BIGINT UNSIGNED NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (user_id, tbl, rid),
            KEY ix_records_rev (user_id, rev)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_files (
            user_id INT UNSIGNED NOT NULL,
            rel_hash CHAR(64) NOT NULL,
            rel VARCHAR(500) ' . $bin . ' NOT NULL,
            size BIGINT UNSIGNED NOT NULL,
            sha256 CHAR(64) NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (user_id, rel_hash)
        )' . $tail,
        'CREATE TABLE IF NOT EXISTS td_attempts (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            kind VARCHAR(16) NOT NULL,
            k VARCHAR(80) NOT NULL,
            ts INT UNSIGNED NOT NULL,
            PRIMARY KEY (id),
            KEY ix_attempts (kind, k, ts)
        )' . $tail,
    );
}

function td_create_schema($pdo, $driver)
{
    foreach (td_schema_sql($driver) as $sql) {
        $pdo->exec($sql);
    }
}
