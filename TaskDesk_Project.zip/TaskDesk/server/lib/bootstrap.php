<?php
/*
 * TaskDesk cloud API - core helpers (PHP 7.4 or newer, MySQL / MariaDB).
 * Nothing in this file prints anything by itself.
 */

define('TD_API_VERSION', 1);
define('TD_SERVER_VERSION', '1.0.0');

function td_root()
{
    return dirname(__DIR__);
}

function td_defaults()
{
    return array(
        'db' => array('driver' => 'mysql', 'host' => 'localhost', 'name' => '', 'user' => '', 'pass' => '', 'path' => ''),
        'storage' => td_root() . '/storage',
        'secret' => '',
        'modules' => array('abap', 'fico', 'mm'),
        'allow_registration' => true,
        'invite_code' => '',
        'quota_mb' => 2048,
        'max_file_mb' => 500,
        'token_days' => 90,
        'require_https' => true,
        'latest_client' => '1.0.0',
        'min_client' => '1.0.0',
        'download_url' => '',
        'notice' => '',
    );
}

function td_config()
{
    static $cfg = null;
    if ($cfg !== null) {
        return $cfg;
    }
    $file = td_root() . '/config.php';
    if (!is_file($file)) {
        td_fail(503, 'not_installed', 'The server is not set up yet. Open setup.php in your browser first.');
    }
    $loaded = require $file;
    if (!is_array($loaded)) {
        td_fail(500, 'bad_config', 'config.php is damaged.');
    }
    $def = td_defaults();
    $cfg = array_merge($def, $loaded);
    $cfg['db'] = array_merge($def['db'], isset($loaded['db']) && is_array($loaded['db']) ? $loaded['db'] : array());
    if (strlen((string)$cfg['secret']) < 32) {
        td_fail(500, 'bad_config', 'config.php has no secret.');
    }
    return $cfg;
}

// ---------------------------------------------------------------- output
function td_send_headers($type = 'application/json; charset=utf-8')
{
    if (!headers_sent()) {
        header('Content-Type: ' . $type);
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: no-referrer');
    }
}

function td_json($data, $status = 200)
{
    http_response_code($status);
    td_send_headers();
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function td_fail($status, $code, $message)
{
    td_json(array('ok' => false, 'error' => $code, 'message' => $message), $status);
}

function td_log($msg)
{
    try {
        $dir = td_storage_dir() . '/logs';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        @file_put_contents($dir . '/api.log', gmdate('Y-m-d H:i:s') . ' ' . $msg . "\n", FILE_APPEND | LOCK_EX);
    } catch (Throwable $e) {
        // logging must never break a request
    }
}

// ---------------------------------------------------------------- request helpers
function td_method($want)
{
    $m = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
    if ($m !== $want) {
        header('Allow: ' . $want);
        td_fail(405, 'method_not_allowed', 'Use ' . $want . ' for this call.');
    }
}

function td_ini_bytes($name)
{
    $v = trim((string)ini_get($name));
    if ($v === '') {
        return 0;
    }
    $n = (float)$v;
    $unit = strtolower(substr($v, -1));
    if ($unit === 'g') {
        $n *= 1073741824;
    } elseif ($unit === 'm') {
        $n *= 1048576;
    } elseif ($unit === 'k') {
        $n *= 1024;
    }
    return (int)$n;
}

/* Biggest file the server really accepts: the configured limit, but never more than PHP itself lets through (post_max_size). */
function td_max_file_mb($cfg = null)
{
    $cfg = $cfg ? $cfg : td_config();
    $mb = (int)$cfg['max_file_mb'];
    $post = td_ini_bytes('post_max_size');
    if ($post > 0) {
        $mb = min($mb, max(1, (int)floor(($post - 1048576) / 1048576)));
    }
    return $mb;
}

function td_input($maxBytes = 12582912)
{
    $len = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
    if ($len > $maxBytes) {
        td_fail(413, 'too_large', 'Request is too large.');
    }
    $raw = file_get_contents('php://input', false, null, 0, $maxBytes + 1);
    if ($raw === false || $raw === '') {
        return array();
    }
    if (strlen($raw) > $maxBytes) {
        td_fail(413, 'too_large', 'Request is too large.');
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        td_fail(400, 'bad_json', 'The request body is not valid JSON.');
    }
    return $data;
}

function td_str($arr, $key, $max = 200)
{
    if (!isset($arr[$key]) || !is_scalar($arr[$key])) {
        return '';
    }
    $s = (string)$arr[$key];
    if (strlen($s) > $max * 4) {
        $s = substr($s, 0, $max * 4);
    }
    return $s;
}

function td_client_ip()
{
    return isset($_SERVER['REMOTE_ADDR']) ? substr((string)$_SERVER['REMOTE_ADDR'], 0, 45) : '0.0.0.0';
}

function td_is_https()
{
    if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') {
        return true;
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') {
        return true;
    }
    return isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443;
}

function td_now()
{
    return gmdate('Y-m-d H:i:s');
}

// ---------------------------------------------------------------- database
function td_driver()
{
    $c = td_config();
    return $c['db']['driver'] === 'sqlite' ? 'sqlite' : 'mysql';
}

function td_db()
{
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    $c = td_config();
    $d = $c['db'];
    try {
        if ($d['driver'] === 'sqlite') {
            $pdo = new PDO('sqlite:' . $d['path']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->exec('PRAGMA busy_timeout = 15000');
            $pdo->exec('PRAGMA journal_mode = WAL');
        } else {
            $dsn = 'mysql:host=' . $d['host'] . ';dbname=' . $d['name'] . ';charset=utf8mb4';
            $pdo = new PDO($dsn, $d['user'], $d['pass'], array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false,
            ));
        }
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        td_log('db connect failed: ' . $e->getMessage());
        td_fail(503, 'db_unavailable', 'The database is not reachable right now. Try again in a minute.');
    }
    return $pdo;
}

function td_q($sql, $params = array())
{
    $st = td_db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function td_row($sql, $params = array())
{
    $r = td_q($sql, $params)->fetch();
    return $r === false ? null : $r;
}

function td_rows($sql, $params = array())
{
    return td_q($sql, $params)->fetchAll();
}

function td_val($sql, $params = array())
{
    $r = td_q($sql, $params)->fetch(PDO::FETCH_NUM);
    return $r === false ? null : $r[0];
}

function td_exec($sql, $params = array())
{
    return td_q($sql, $params)->rowCount();
}

function td_begin()
{
    if (td_driver() === 'sqlite') {
        td_db()->exec('BEGIN IMMEDIATE');
    } else {
        td_db()->beginTransaction();
    }
}

function td_commit()
{
    if (td_driver() === 'sqlite') {
        td_db()->exec('COMMIT');
    } else {
        td_db()->commit();
    }
}

function td_rollback()
{
    try {
        if (td_driver() === 'sqlite') {
            td_db()->exec('ROLLBACK');
        } else {
            if (td_db()->inTransaction()) {
                td_db()->rollBack();
            }
        }
    } catch (Throwable $e) {
        // nothing to roll back
    }
}

// ---------------------------------------------------------------- storage
function td_storage_dir()
{
    $c = td_config();
    return rtrim(str_replace('\\', '/', (string)$c['storage']), '/');
}

function td_user_dir($uid)
{
    $d = td_storage_dir() . '/u' . (int)$uid;
    foreach (array($d, $d . '/f', $d . '/tmp', $d . '/trash') as $p) {
        if (!is_dir($p)) {
            @mkdir($p, 0755, true);
        }
    }
    return $d;
}

// ---------------------------------------------------------------- abuse protection
function td_rate_count($kind, $key, $windowSec)
{
    return (int)td_val('SELECT COUNT(*) FROM td_attempts WHERE kind=? AND k=? AND ts>?', array($kind, $key, time() - $windowSec));
}

function td_rate_hit($kind, $key)
{
    td_exec('INSERT INTO td_attempts(kind,k,ts) VALUES(?,?,?)', array($kind, $key, time()));
    if (mt_rand(1, 50) === 1) {
        td_exec('DELETE FROM td_attempts WHERE ts<?', array(time() - 86400));
    }
}

function td_rate_guard($kind, $key, $max, $windowSec)
{
    if (td_rate_count($kind, $key, $windowSec) >= $max) {
        header('Retry-After: ' . $windowSec);
        td_fail(429, 'too_many_attempts', 'Too many attempts. Please wait a few minutes and try again.');
    }
}

// ---------------------------------------------------------------- crypto helpers
function td_random_hex($bytes = 32)
{
    return bin2hex(random_bytes($bytes));
}

function td_token_hash($token)
{
    return hash('sha256', $token);
}

function td_hmac($value)
{
    $c = td_config();
    return hash_hmac('sha256', $value, (string)$c['secret']);
}

function td_hash_password($pw)
{
    $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
    $h = @password_hash($pw, $algo);
    if (!is_string($h) || $h === '') {
        $h = password_hash($pw, PASSWORD_DEFAULT);
    }
    return $h;
}
