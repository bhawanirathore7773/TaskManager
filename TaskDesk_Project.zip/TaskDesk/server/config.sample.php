<?php
/*
 * TaskDesk server settings.
 * You normally do NOT edit this by hand: open setup.php in the browser and it writes config.php for you.
 * Use this file only if you want to set things up manually (copy it to config.php and fill it in).
 */
return array(
    'db' => array(
        'driver' => 'mysql',
        'host' => 'localhost',
        'name' => 'u123456789_taskdesk',
        'user' => 'u123456789_taskdesk',
        'pass' => 'change-me',
    ),

    // Where uploaded files are kept. Best place: a folder OUTSIDE public_html.
    'storage' => '/home/u123456789/taskdesk_storage',

    // Long random text, used to protect file names and recovery keys. Never share it, never change it later.
    'secret' => 'put-64-random-characters-here-0123456789abcdef0123456789abcdef',

    // Modules the server accepts. Add a new key here when you release a new module.
    'modules' => array('abap', 'fico', 'mm'),

    'allow_registration' => true,     // false = nobody can create a new account
    'invite_code' => '',              // set a word here to allow only people who know it to register
    'quota_mb' => 2048,               // cloud space per user
    'max_file_mb' => 500,             // biggest single file
    'token_days' => 90,               // a device stays signed in this long after its last use
    'require_https' => true,

    // Shown to the desktop app so it can tell users that a new version exists
    'latest_client' => '1.0.0',
    'min_client' => '1.0.0',
    'download_url' => '',
    'notice' => '',
);
