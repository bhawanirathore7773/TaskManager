# -*- coding: utf-8 -*-
"""The saved sign-in of this Windows user (one account at a time)."""
import os
import time

from . import paths, secure


def _file():
    return os.path.join(paths.home(), 'session.json')


def load():
    """Returns {'server','user','token'} or None."""
    d = paths.read_json(_file())
    if not d or not d.get('token') or not d.get('user'):
        return None
    try:
        token = secure.unprotect(d['token'])
    except Exception:
        return None
    return {'server': d.get('server', ''), 'user': d['user'], 'token': token, 'signed_in_at': d.get('signed_in_at', 0)}


def save(server, user, token):
    paths.write_json(_file(), {
        'version': 1, 'server': server, 'user': user,
        'token': secure.protect(token), 'signed_in_at': int(time.time()),
    })
    try:
        if os.name != 'nt':
            os.chmod(_file(), 0o600)
    except OSError:
        pass


def clear():
    try:
        os.remove(_file())
    except OSError:
        pass
