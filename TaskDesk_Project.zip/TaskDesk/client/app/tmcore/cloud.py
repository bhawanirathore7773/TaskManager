# -*- coding: utf-8 -*-
"""HTTP client for the TaskDesk cloud API (PHP + MySQL on the hosting)."""
import hashlib
import json
import os
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request


class CloudError(Exception):
    def __init__(self, status, code, message):
        Exception.__init__(self, message)
        self.status = status
        self.code = code
        self.message = message


class Offline(CloudError):
    def __init__(self, message='No connection to the TaskDesk server.'):
        CloudError.__init__(self, 0, 'offline', message)


class AuthExpired(CloudError):
    def __init__(self, message='Please sign in again.'):
        CloudError.__init__(self, 401, 'not_signed_in', message)


class UpgradeRequired(CloudError):
    def __init__(self, message='Please install the latest TaskDesk version.'):
        CloudError.__init__(self, 426, 'upgrade_required', message)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            b = f.read(1 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


class Cloud:
    def __init__(self, base_url, token=None, client_version='0', device='This PC'):
        self.base = (base_url or '').strip()
        self.token = token
        self.client_version = client_version
        self.device = device
        self._ctx = ssl.create_default_context()

    def configured(self):
        return self.base.lower().startswith(('http://', 'https://')) and 'YOUR-DOMAIN' not in self.base

    # ------------------------------------------------------------------ low level
    def _url(self, route, query=None):
        sep = '&' if '?' in self.base else '?'
        u = self.base + sep + 'r=' + urllib.parse.quote(route, safe='/')
        if query:
            u += '&' + urllib.parse.urlencode(query)
        return u

    def _headers(self, extra=None):
        h = {'X-TD-Client': self.client_version, 'Accept': 'application/json', 'User-Agent': 'TaskDesk/' + self.client_version}
        if self.token:
            h['X-TD-Token'] = self.token
        if extra:
            h.update(extra)
        return h

    def _open(self, req, timeout):
        try:
            return urllib.request.urlopen(req, timeout=timeout, context=self._ctx)
        except urllib.error.HTTPError as e:
            return e
        except (urllib.error.URLError, socket.timeout, ConnectionError, ssl.SSLError, OSError) as e:
            reason = getattr(e, 'reason', e)
            raise Offline('Cannot reach the TaskDesk server (%s).' % (reason,))

    @staticmethod
    def _raise_for(status, payload):
        try:
            d = json.loads(payload.decode('utf-8'))
        except Exception:
            d = {}
        code = d.get('error') or 'http_%d' % status
        msg = d.get('message') or 'The server answered with an error (%d).' % status
        if status == 401:
            raise AuthExpired(msg)
        if status == 426:
            raise UpgradeRequired(msg)
        raise CloudError(status, code, msg)

    def call(self, route, method='GET', body=None, query=None, timeout=30):
        data = None
        hdr = {}
        if body is not None:
            data = json.dumps(body, ensure_ascii=False).encode('utf-8')
            hdr['Content-Type'] = 'application/json; charset=utf-8'
        req = urllib.request.Request(self._url(route, query), data=data, method=method, headers=self._headers(hdr))
        resp = self._open(req, timeout)
        try:
            payload = resp.read()
            status = resp.status if hasattr(resp, 'status') else resp.getcode()
        finally:
            resp.close()
        if status >= 400:
            self._raise_for(status, payload)
        try:
            d = json.loads(payload.decode('utf-8'))
        except Exception:
            raise CloudError(status, 'bad_response', 'The server sent an unexpected answer. Check the server address.')
        if not isinstance(d, dict) or d.get('ok') is False:
            raise CloudError(status, (d or {}).get('error', 'bad_response'), (d or {}).get('message', 'Unexpected answer from the server.'))
        return d

    # ------------------------------------------------------------------ account
    def health(self, timeout=10):
        return self.call('health', timeout=timeout)

    def register(self, username, password, module, display_name='', invite=''):
        return self.call('auth/register', 'POST', {'username': username, 'password': password, 'module': module,
                                                   'display_name': display_name, 'invite': invite, 'device': self.device})

    def login(self, username, password):
        return self.call('auth/login', 'POST', {'username': username, 'password': password, 'device': self.device})

    def recover(self, username, recovery_key, new_password):
        return self.call('auth/recover', 'POST', {'username': username, 'recovery_key': recovery_key, 'new_password': new_password})

    def logout(self):
        return self.call('auth/logout', 'POST', {}, timeout=10)

    def me(self):
        return self.call('auth/me')

    def change_password(self, old, new):
        return self.call('auth/password', 'POST', {'old_password': old, 'new_password': new})

    # ------------------------------------------------------------------ records
    def push(self, ops):
        return self.call('sync/push', 'POST', {'ops': ops}, timeout=60)

    def pull(self, since, limit=500):
        return self.call('sync/pull', query={'since': int(since), 'limit': int(limit)}, timeout=60)

    def status(self):
        return self.call('sync/status')

    # ------------------------------------------------------------------ files
    def file_put(self, rel, path, sha=None):
        size = os.path.getsize(path)
        sha = sha or sha256_file(path)
        with open(path, 'rb') as f:
            hdr = self._headers({'Content-Type': 'application/octet-stream', 'Content-Length': str(size)})
            req = urllib.request.Request(self._url('files/put', {'rel': rel, 'sha': sha}), data=f, method='POST', headers=hdr)
            resp = self._open(req, 120)
            try:
                payload = resp.read()
                status = resp.status if hasattr(resp, 'status') else resp.getcode()
            finally:
                resp.close()
        if status >= 400:
            self._raise_for(status, payload)
        return sha

    def file_get(self, rel, dest, expect_sha=None):
        """Downloads to a temporary file next to dest, checks the checksum, then moves it into place."""
        req = urllib.request.Request(self._url('files/get', {'rel': rel}), headers=self._headers())
        resp = self._open(req, 120)
        status = resp.status if hasattr(resp, 'status') else resp.getcode()
        if status >= 400:
            try:
                payload = resp.read()
            finally:
                resp.close()
            self._raise_for(status, payload)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        tmp = dest + '.tdpart'
        h = hashlib.sha256()
        try:
            with open(tmp, 'wb') as f:
                while True:
                    b = resp.read(1 << 20)
                    if not b:
                        break
                    h.update(b)
                    f.write(b)
        except (socket.timeout, ConnectionError, OSError) as e:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise Offline('The download was interrupted (%s).' % (e,))
        finally:
            resp.close()
        got = h.hexdigest()
        want = (expect_sha or resp.headers.get('X-TD-SHA256') or '').lower()
        if want and want != got:
            try:
                os.remove(tmp)
            except OSError:
                pass
            raise CloudError(0, 'checksum_mismatch', 'The downloaded file was damaged. It will be tried again.')
        os.replace(tmp, dest)
        return got

    def file_del(self, rel):
        return self.call('files/del', 'POST', {'rel': rel})

    def file_list(self):
        return self.call('files/list', timeout=60)['files']
