# -*- coding: utf-8 -*-
"""
Runs ONE task manager module for the signed-in user.

The module itself (modules/<id>/server.py) is used exactly as it was built: its own database, API and screens.
This host
  * points the module at the user's data folder,
  * adds change tracking + the background sync engine,
  * adds the small /__td/ API used by the account / sync / About parts of the screen,
  * protects the local server with a random key (only the TaskDesk window knows it).
"""
import argparse
import hmac
import importlib.util
import json
import os
import shutil
import socket
import sys
import threading
import time
from http.cookies import SimpleCookie
from urllib.parse import parse_qs, unquote, urlparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tmcore import paths, session                      # noqa: E402
from tmcore.cloud import Cloud, CloudError              # noqa: E402
from tmcore.engine import Engine                        # noqa: E402
from tmcore.syncdb import SyncDB                        # noqa: E402

SHELL_DIR = os.path.join(paths.APP_ROOT, 'shell_static')


class Ctx:
    mod = None
    meta = None
    engine = None
    cloud = None
    sdb = None
    user = None
    server = ''
    key = ''
    port = 0
    gate_url = ''
    health = {}
    auth_lost = False
    wipe_root = None
    stopping = False


C = Ctx()


def load_module(meta):
    entry = os.path.join(meta['dir'], meta.get('entry', 'server.py'))
    spec = importlib.util.spec_from_file_location('td_module_' + meta['id'], entry)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def authorized(handler):
    if not C.key:
        return True
    raw = handler.headers.get('Cookie') or ''
    try:
        ck = SimpleCookie(raw)
    except Exception:
        return False
    m = ck.get('tdk_%d' % C.port)
    return bool(m) and hmac.compare_digest(m.value, C.key)


def about_data():
    a = paths.read_json(os.path.join(paths.APP_ROOT, 'about.json'), {}) or {}
    a['version'] = paths.version()
    return a


def update_info():
    h = C.health or {}
    latest = str(h.get('latest_client') or '')
    cur = paths.version()

    def tup(v):
        try:
            return tuple(int(x) for x in v.split('.'))
        except Exception:
            return (0,)
    return {'available': bool(latest) and tup(latest) > tup(cur), 'latest': latest, 'url': h.get('download_url') or '', 'notice': h.get('notice') or ''}


def health_loop():
    while not C.stopping:
        try:
            C.health = C.cloud.health(timeout=10)
        except Exception:
            pass
        for _ in range(6 * 3600):
            if C.stopping:
                return
            time.sleep(1)


def state_json():
    snap = C.engine.snapshot()
    snap['auth_lost'] = C.auth_lost or snap.get('state') == 'auth'
    mod = C.meta
    return {
        'ok': True,
        'user': C.user,
        'module': {k: mod.get(k) for k in ('id', 'title', 'short', 'accent', 'shell', 'tagline')},
        'version': paths.version(),
        'server': C.server,
        'sync': snap,
        'update': update_info(),
        'time': int(time.time()),
    }


def do_logout(handler, body):
    wipe = bool(body.get('wipe'))
    force = bool(body.get('force'))
    ok = C.engine.flush(25)
    pending = C.engine.snapshot().get('pending', 0)
    if not ok and pending and not force:
        handler.send_json({'ok': False, 'pending': pending,
                           'error': '%d change(s) are not uploaded yet. Connect to the internet and try again, or sign out anyway (your changes stay on this PC and upload the next time you sign in).' % pending}, 409)
        return
    try:
        C.cloud.logout()
    except Exception:
        pass
    session.clear()
    if wipe:
        C.wipe_root = paths.user_root(C.user['id'], C.user['username'], C.server)
    handler.send_json({'ok': True, 'redirect': C.gate_url})
    threading.Thread(target=shutdown_soon, daemon=True).start()


def shutdown_soon(delay=0.7):
    time.sleep(delay)
    C.stopping = True
    httpd = C.mod.SERVER.get('httpd')
    if httpd:
        httpd.shutdown()


def serve_shell_file(handler, name, ctype):
    p = os.path.join(SHELL_DIR, name)
    if not os.path.isfile(p):
        handler.send_json({'error': 'Not found'}, 404)
        return
    if ctype.startswith('text/') or 'javascript' in ctype:
        ctype += '; charset=utf-8'
    handler.send_file(p, ctype)


def shell_route(handler, method, path, parsed):
    q = {k: v[0] for k, v in parse_qs(parsed.query, keep_blank_values=True).items()}
    if method == 'GET':
        if path == '/__td/shell.js':
            return serve_shell_file(handler, 'shell.js', 'application/javascript')
        if path == '/__td/shell.css':
            return serve_shell_file(handler, 'shell.css', 'text/css')
        if path == '/__td/state':
            return handler.send_json(state_json())
        if path == '/__td/about':
            return handler.send_json(about_data())
        if path == '/__td/problems':
            return handler.send_json({'ok': True, 'items': C.sdb.recent_problems(30)})
        return handler.send_json({'error': 'Unknown endpoint'}, 404)
    # every change needs the same header the module itself requires
    if handler.headers.get('X-TM') != '1':
        handler.close_connection = True
        return handler.send_json({'error': 'Missing X-TM header'}, 403)
    body = handler.json_body() if method == 'POST' else {}
    if method == 'POST' and path == '/__td/sync':
        snap = C.engine.sync_now(wait=25)
        return handler.send_json({'ok': True, 'sync': snap})
    if method == 'POST' and path == '/__td/logout':
        return do_logout(handler, body)
    if method == 'POST' and path == '/__td/stop':
        handler.send_json({'ok': True})
        threading.Thread(target=shutdown_soon, args=(0.2,), daemon=True).start()
        return
    if method == 'POST' and path == '/__td/verify':
        threading.Thread(target=lambda: C.engine.verify_files(), daemon=True).start()
        return handler.send_json({'ok': True})
    return handler.send_json({'error': 'Unknown endpoint'}, 404)


def patch_module(mod):
    H = mod.Handler
    orig_handle = H.handle_any
    orig_static = H.serve_static
    orig_file_abs = mod.file_abs

    def handle_any(self, method):
        mod.SERVER['last_seen'] = time.time()
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        try:
            if not self.host_ok():
                self.close_connection = True
                return self.send_json({'error': 'Forbidden host'}, 403)
            if path == '/__td/ping' and method == 'GET':
                return self.send_json({'ok': True, 'app': 'taskdesk-module', 'module': C.meta['id'], 'port': C.port})
            if path == '/__td/enter' and method == 'GET':
                q = {k: v[0] for k, v in parse_qs(parsed.query).items()}
                if C.key and not hmac.compare_digest(q.get('k', ''), C.key):
                    return self.send_json({'error': 'Forbidden'}, 403)
                nxt = q.get('next', '/')
                if not nxt.startswith('/') or nxt.startswith('//'):
                    nxt = '/'
                self.send_response(302)
                self.send_header('Location', nxt)
                self.send_header('Set-Cookie', 'tdk_%d=%s; Path=/; HttpOnly; SameSite=Strict' % (C.port, C.key))
                self.send_header('Content-Length', '0')
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                return
            if not authorized(self):
                if method != 'GET':
                    self.close_connection = True
                body = b'<!doctype html><meta charset="utf-8"><title>TaskDesk</title><body style="font:16px Segoe UI,sans-serif;padding:48px">Please open TaskDesk from its desktop icon or the Start menu.</body>'
                self.send_response(403)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if path.startswith('/__td/'):
                self.body_consumed = False
                try:
                    return shell_route(self, method, path, parsed)
                finally:
                    if method != 'GET' and not getattr(self, 'body_consumed', False):
                        self.close_connection = True
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
            return
        except Exception as e:
            try:
                self.send_json({'error': 'Server error: %s' % e}, 500)
            except Exception:
                self.close_connection = True
            return
        C.engine.touch()
        if method != 'GET' and not C.engine.first_done.is_set():
            C.engine.first_done.wait(5)     # right after start: let the first pull finish so new ids cannot clash with another PC's
        orig_handle(self, method)
        if method in ('POST', 'PUT', 'DELETE'):
            C.engine.poke()

    def serve_static(self, path):
        if path in ('', '/', '/index.html'):
            full = os.path.join(mod.STATIC_DIR, 'index.html')
            with open(full, encoding='utf-8') as f:
                html = f.read()
            html = html.replace('</head>', '<link rel="stylesheet" href="/__td/shell.css">\n</head>', 1)
            html = html.replace('</body>', '<script src="/__td/shell.js"></script>\n</body>', 1)
            return self.send_bytes(html.encode('utf-8'), 'text/html; charset=utf-8')
        return orig_static(self, path)

    def file_abs(row):
        try:
            return orig_file_abs(row)
        except mod.ApiError as e:
            if e.status == 404 and row['rel_path'] and C.engine.ensure_local(row['rel_path']):
                return orig_file_abs(row)
            raise

    H.handle_any = handle_any
    H.serve_static = serve_static
    mod.file_abs = file_abs


def device_name():
    try:
        return '%s (%s)' % (socket.gethostname(), os.environ.get('USERNAME') or os.environ.get('USER') or 'user')
    except Exception:
        return 'This PC'


def main():
    for n in ('stdout', 'stderr'):
        if getattr(sys, n) is None:
            setattr(sys, n, open(os.devnull, 'w'))
    ap = argparse.ArgumentParser()
    ap.add_argument('--module', required=True)
    ap.add_argument('--port', type=int, default=0)
    ap.add_argument('--idle-exit', type=int, default=0)
    a = ap.parse_args()

    sess = session.load()
    if not sess:
        sys.stderr.write('Not signed in.\n')
        return 3
    mods = paths.modules()
    meta = mods.get(a.module)
    if not meta:
        sys.stderr.write('Module %s is not part of this installation.\n' % a.module)
        return 4
    user = sess['user']
    data_dir = paths.user_data_dir(user['id'], user['username'], sess['server'])
    os.makedirs(data_dir, exist_ok=True)
    os.environ[meta['data_env']] = data_dir

    C.meta, C.user, C.server = meta, user, sess['server']
    C.key = os.environ.get('TD_LOCAL_KEY', '')
    C.gate_url = os.environ.get('TD_GATE_URL', '')

    mod = load_module(meta)
    C.mod = mod
    mod.init_all()
    C.sdb = SyncDB(mod.DB_PATH, mod.FILES_DIR)
    C.sdb.install()
    C.cloud = Cloud(sess['server'], sess['token'], paths.version(), device_name())
    cats = list(getattr(mod, 'CATS', {}).values())

    def lost():
        C.auth_lost = True
    C.engine = Engine(C.sdb, C.cloud, user, cats=cats, on_auth_lost=lost, fast_seconds=int(os.environ.get('TD_SYNC_FAST', '20')))

    patch_module(mod)
    httpd = mod.LocalServer(('127.0.0.1', a.port), mod.Handler)
    httpd.daemon_threads = True
    C.port = httpd.server_address[1]
    mod.SERVER['httpd'] = httpd
    mod.SERVER['last_seen'] = time.time()
    if a.idle_exit:
        threading.Thread(target=mod.idle_watch, args=(httpd, a.idle_exit), daemon=True).start()
    threading.Thread(target=health_loop, daemon=True).start()
    C.engine.start()
    sys.stdout.write('TASKDESK_READY port=%d module=%s\n' % (C.port, meta['id']))
    sys.stdout.flush()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        C.stopping = True
        try:
            if not C.wipe_root:
                C.engine.flush(20)
        except Exception:
            pass
        C.engine.stop()
        try:
            httpd.server_close()
        except Exception:
            pass
        if C.wipe_root:
            time.sleep(0.3)
            shutil.rmtree(C.wipe_root, ignore_errors=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
