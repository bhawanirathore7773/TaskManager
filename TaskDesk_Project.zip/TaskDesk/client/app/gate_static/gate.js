/* TaskDesk gate: sign in, create account, recover password, About. No external resources (works offline). */
(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const LOGO = '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 7h14M5 12h14M5 17h8"/></svg>';
  const DESK = {
    abap: { h: 'Every ABAP request,<br>one desk.', cards: [
      ['T-0042', 'Gate pass out: partial release logic', '#6aa7ff', 'In Progress', 'SE38', 62],
      ['T-0041', 'Scroll dump on screen 9002', '#f2b01e', 'Unit Testing', 'SE80', 80],
      ['T-0038', 'Sales order report: plant filter', '#4cc38a', 'UAT', 'SE11', 92]] },
    fico: { h: 'Every FICO close,<br>one desk.', cards: [
      ['T-0042', 'Month-end closing, November', '#6ad0a3', 'In Progress', 'F.01', 55],
      ['T-0040', 'Vendor payment run blocked', '#f2b01e', 'Analysis', 'F110', 30],
      ['T-0037', 'New GL account for freight', '#6aa7ff', 'UAT', 'FS00', 85]] },
    mm: { h: 'Every MM request,<br>one desk.', cards: [
      ['T-0042', '9 invoices blocked: price variance', '#9aa5ff', 'Analysis', 'MRBR', 35],
      ['T-0040', 'PO release strategy, new level', '#f2b01e', 'UAT', 'CL24N', 78],
      ['T-0036', 'Physical inventory, plant 1000', '#4cc38a', 'In Progress', 'MI01', 58]] },
  };
  let ST = null;           // server answer of /api/state
  let moduleId = '';       // module that drives the colours
  let busy = false;

  /* ---------- tiny helpers ---------- */
  function h(tag, attrs) {
    const el = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'html') el.innerHTML = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else if (k === 'value') el.value = v;
      else el.setAttribute(k, v === true ? '' : v);
    }
    for (let i = 2; i < arguments.length; i++) {
      const kids = [].concat(arguments[i]);
      for (const c of kids) if (c != null && c !== false) el.append(c.nodeType ? c : document.createTextNode(String(c)));
    }
    return el;
  }
  async function api(path, body) {
    const opt = body === undefined ? {} : { method: 'POST', headers: { 'X-TM': '1', 'Content-Type': 'application/json' }, body: JSON.stringify(body) };
    let r;
    try { r = await fetch(path, opt); } catch (e) { throw { message: 'The TaskDesk background service is not answering. Close this window and open TaskDesk again.' }; }
    let d = {};
    try { d = await r.json(); } catch (e) { /* ignore */ }
    if (!r.ok || d.ok === false) throw { code: d.error, message: d.message || d.error || ('Error ' + r.status) };
    return d;
  }
  const modInfo = (id) => (ST && ST.modules.find((m) => m.id === id)) || null;

  function theme(id) {
    const m = modInfo(id);
    if (!m) return;
    moduleId = id;
    const r = document.documentElement.style;
    r.setProperty('--accent', m.accent);
    r.setProperty('--shell', m.shell);
    $('#logo').innerHTML = LOGO;
    const d = DESK[id] || DESK.mm;
    $('#pitch-h').innerHTML = d.h;
    $('#pitch-p').textContent = m.tagline + '.';
    $('#stack').replaceChildren(...d.cards.map((c) => h('li', { class: 'tcard', style: '--st:' + c[2] },
      h('div', { class: 't1' }, h('code', null, c[0]), h('span', null, c[1])),
      h('div', { class: 't2' }, h('span', { class: 'chip' }, c[3]), h('span', null, c[4])),
      h('div', { class: 'bar' }, h('i', { style: 'width:' + c[5] + '%' })))));
    $('#desk-foot').textContent = m.title + ' edition';
    if (!document.documentElement.classList.contains('themed')) requestAnimationFrame(() => requestAnimationFrame(() => document.documentElement.classList.add('themed')));
  }

  /* ---------- screens ---------- */
  function setView(...kids) { $('#view').replaceChildren(...kids); const f = $('#view input:not([type=checkbox])'); if (f) f.focus(); }
  function banner(text, bad, action) {
    const b = $('#banner');
    if (!text) { b.classList.add('hide'); return; }
    b.className = 'banner' + (bad ? ' bad' : '');
    b.replaceChildren(text, action ? ' ' : null, action || null);
  }
  function field(id, label, opts) {
    opts = opts || {};
    const input = opts.select ? h('select', { id: id }, opts.options.map((o) => h('option', { value: o[0] }, o[1])))
      : h('input', { id: id, type: opts.type || 'text', autocomplete: opts.auto || 'off', spellcheck: 'false', placeholder: opts.ph || '', maxlength: opts.max || 200, autocapitalize: 'off' });
    if (opts.value) input.value = opts.value;
    if (opts.lower) input.addEventListener('input', () => { const p = input.selectionStart; input.value = input.value.toLowerCase(); try { input.setSelectionRange(p, p); } catch (e) { /* ignore */ } });
    const wrap = h('div', { class: 'field' }, h('label', { for: id }, label));
    if (opts.type === 'password') {
      const tog = h('button', { type: 'button', tabindex: '-1', onclick: () => { const on = input.type === 'password'; input.type = on ? 'text' : 'password'; tog.textContent = on ? 'Hide' : 'Show'; } }, 'Show');
      wrap.append(h('div', { class: 'pw' }, input, tog));
    } else wrap.append(input);
    if (opts.hint) wrap.append(h('div', { class: 'hint' }, opts.hint));
    wrap.append(h('div', { class: 'err', id: id + '-err' }));
    return wrap;
  }
  function fieldError(id, msg) {
    const w = $('#' + id).closest('.field');
    w.classList.toggle('bad', !!msg);
    $('#' + id + '-err').textContent = msg || '';
  }
  function formMsg(text, kind) {
    const old = $('#form-msg');
    if (old) old.remove();
    if (!text) return;
    $('#view form').prepend(h('div', { id: 'form-msg', class: 'msg ' + (kind || 'bad'), role: 'alert' }, text));
  }
  function submitting(btn, on, label) { busy = on; btn.disabled = on; btn.textContent = on ? 'Please wait' : label; }

  function viewLogin(note) {
    const btn = h('button', { class: 'btn primary', type: 'submit' }, 'Sign in');
    const form = h('form', { onsubmit: async (e) => {
      e.preventDefault();
      if (busy) return;
      const u = $('#u').value.trim().toLowerCase(), p = $('#p').value;
      fieldError('u', u ? '' : 'Enter your username'); fieldError('p', p ? '' : 'Enter your password');
      if (!u || !p) return;
      submitting(btn, true, 'Sign in'); formMsg('');
      try {
        const r = await api('/api/login', { username: u, password: p });
        go(r.url, r.user);
      } catch (err) { formMsg(err.message); submitting(btn, false, 'Sign in'); }
    } },
      note ? h('div', { class: 'msg info' }, note) : null,
      field('u', 'Username', { auto: 'username', max: 32, lower: true }), field('p', 'Password', { type: 'password', auto: 'current-password' }), btn,
      h('p', { class: 'alt' }, h('button', { class: 'lnk', type: 'button', onclick: () => viewRegister() }, 'Create an account'), h('button', { class: 'lnk', type: 'button', onclick: () => viewRecover() }, 'Forgot password?')));
    setView(h('h2', null, 'Sign in'), h('p', { class: 'lede' }, 'Use your TaskDesk username and password.'), form);
    if (!ST.configured) formMsg('The server address is not set yet. Open "Server" at the bottom of this page.', 'info');
  }

  function viewRegister() {
    const opts = ST.modules.map((m) => [m.id, m.title + ' - ' + m.tagline.split(':')[0]]);
    const btn = h('button', { class: 'btn primary', type: 'submit' }, 'Create account');
    const needInvite = ST.health && ST.health.invite_required;
    const form = h('form', { onsubmit: async (e) => {
      e.preventDefault();
      if (busy) return;
      const name = $('#n').value.trim(), u = $('#u').value.trim().toLowerCase(), p = $('#p').value, p2 = $('#p2').value, mod = $('#m').value;
      let ok = true;
      const bad = (id, m) => { fieldError(id, m); if (m) ok = false; };
      bad('u', /^[a-z0-9][a-z0-9._-]{1,30}[a-z0-9]$/.test(u) ? '' : 'Use 3 to 32 letters, numbers, dot, dash or underscore');
      bad('p', p.length >= 8 ? '' : 'At least 8 characters');
      bad('p2', p === p2 ? '' : 'The two passwords are not the same');
      if (needInvite) bad('inv', $('#inv').value.trim() ? '' : 'Ask the administrator for the invite code');
      if (!ok) return;
      submitting(btn, true, 'Create account'); formMsg('');
      try {
        const r = await api('/api/register', { display_name: name, username: u, password: p, module: mod, invite: needInvite ? $('#inv').value.trim() : '' });
        viewRecoveryKey(r.recovery_key, 'Your account is ready', 'Open my workspace', () => go(r.url, r.user));
      } catch (err) { formMsg(err.message); submitting(btn, false, 'Create account'); }
    } },
      field('n', 'Your name', { auto: 'name', max: 80, ph: 'As you want it shown in the app' }),
      field('m', 'I work as', { select: true, options: opts, value: moduleId }),
      field('u', 'Username', { auto: 'username', max: 32, lower: true, hint: 'Lower case. You will use this to sign in on any PC.' }),
      h('div', { class: 'row2' }, field('p', 'Password', { type: 'password', auto: 'new-password' }), field('p2', 'Repeat password', { type: 'password', auto: 'new-password' })),
      needInvite ? field('inv', 'Invite code', { max: 100 }) : null, btn,
      h('p', { class: 'alt' }, h('button', { class: 'lnk', type: 'button', onclick: () => viewLogin() }, 'I already have an account')));
    setView(h('h2', null, 'Create your account'), h('p', { class: 'lede' }, 'The role you pick decides which TaskDesk edition opens when you sign in.'), form);
    $('#m').addEventListener('change', (e) => theme(e.target.value));
    if (ST.health && ST.health.registration === false) formMsg('New accounts are closed on this server. Ask the administrator.', 'bad');
  }

  function viewRecoveryKey(key, title, cta, next) {
    const done = h('input', { type: 'checkbox', id: 'saved' });
    const btn = h('button', { class: 'btn primary', type: 'button', disabled: true, onclick: next }, cta);
    done.addEventListener('change', () => { btn.disabled = !done.checked; });
    setView(h('h2', null, title),
      h('p', { class: 'lede' }, 'Keep this recovery key somewhere safe. It is the only way to set a new password if you forget it, and it is shown only now.'),
      h('div', { class: 'key', id: 'key' }, key),
      h('div', { class: 'keyrow' },
        h('button', { class: 'btn', type: 'button', onclick: async (e) => { try { await navigator.clipboard.writeText(key); e.target.textContent = 'Copied'; } catch (x) { e.target.textContent = 'Select and copy it'; } } }, 'Copy'),
        h('button', { class: 'btn', type: 'button', onclick: () => {
          const a = h('a', { href: URL.createObjectURL(new Blob(['TaskDesk recovery key\r\n' + key + '\r\n'], { type: 'text/plain' })), download: 'TaskDesk-recovery-key.txt' });
          document.body.append(a); a.click(); a.remove();
        } }, 'Save as file')),
      h('label', { class: 'chk' }, done, h('span', null, 'I have saved my recovery key.')), btn);
  }

  function viewRecover() {
    const btn = h('button', { class: 'btn primary', type: 'submit' }, 'Set new password');
    const form = h('form', { onsubmit: async (e) => {
      e.preventDefault();
      if (busy) return;
      const u = $('#u').value.trim().toLowerCase(), k = $('#k').value.trim(), p = $('#p').value;
      let ok = true;
      const bad = (id, m) => { fieldError(id, m); if (m) ok = false; };
      bad('u', u ? '' : 'Enter your username'); bad('k', k.replace(/[^A-Za-z0-9]/g, '').length === 20 ? '' : 'The key has 20 letters and numbers'); bad('p', p.length >= 8 ? '' : 'At least 8 characters');
      if (!ok) return;
      submitting(btn, true, 'Set new password'); formMsg('');
      try {
        const r = await api('/api/recover', { username: u, recovery_key: k, new_password: p });
        viewRecoveryKey(r.recovery_key, 'Password changed', 'Back to sign in', () => viewLogin('Your password was changed. Sign in with the new password.'));
      } catch (err) { formMsg(err.message); submitting(btn, false, 'Set new password'); }
    } },
      field('u', 'Username', { auto: 'username', max: 32, lower: true }), field('k', 'Recovery key', { max: 40, ph: 'XXXX-XXXX-XXXX-XXXX-XXXX' }),
      field('p', 'New password', { type: 'password', auto: 'new-password' }), btn,
      h('p', { class: 'alt' }, h('button', { class: 'lnk', type: 'button', onclick: () => viewLogin() }, 'Back to sign in')));
    setView(h('h2', null, 'Reset your password'), h('p', { class: 'lede' }, 'Enter the recovery key you saved when you created the account. You get a new key afterwards.'), form);
  }

  function viewOpening(name, mod) {
    setView(h('div', { class: 'spin', role: 'progressbar', 'aria-label': 'Opening' }), h('h2', null, name ? 'Welcome back, ' + name : 'Opening your workspace'),
      h('p', { class: 'lede' }, 'Opening your ' + (mod ? mod.title : 'TaskDesk') + ' desk.'));
  }
  function viewOpenError(err) {
    setView(h('h2', null, 'Could not open your workspace'), h('div', { class: 'msg bad', role: 'alert' }, err.message || 'Unknown problem'),
      h('div', { class: 'keyrow' },
        h('button', { class: 'btn', type: 'button', onclick: autoOpen }, 'Try again'),
        h('button', { class: 'btn', type: 'button', onclick: async () => { try { await api('/api/signout', {}); } catch (e) { /* ignore */ } ST.session = null; viewLogin(); } }, 'Sign in as someone else')));
  }
  function go(url, user) {
    const m = user && modInfo(user.module);
    if (m) theme(m.id);
    viewOpening(user && user.display_name, m);
    setTimeout(() => { location.href = url; }, 350);
  }
  async function autoOpen() {
    const u = ST.session.user;
    theme(u.module in (ST.modules.reduce((a, m) => (a[m.id] = 1, a), {})) ? u.module : moduleId);
    viewOpening(u.display_name, modInfo(u.module));
    try { const r = await api('/api/open', {}); location.href = r.url; } catch (e) { viewOpenError(e); }
  }

  /* ---------- About + server dialogs ---------- */
  async function showAbout() {
    const dlg = $('#dlg-about');
    let a;
    try { a = await api('/api/about'); } catch (e) { a = { product: 'TaskDesk', version: ST.version, author: {} }; }
    const au = a.author || {};
    const initials = (au.name || 'T').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
    const contact = [['Email', au.email, 'mailto:' + au.email], ['Phone', au.phone], ['Website', au.website, au.website], ['LinkedIn', au.linkedin, au.linkedin]].filter((c) => c[1]);
    dlg.replaceChildren(
      h('div', { class: 'ab-head' }, h('span', { class: 'logo', html: LOGO }), h('div', null, h('h2', null, a.product || 'TaskDesk'), h('p', null, a.tagline || ''))),
      h('div', { class: 'ab-body' },
        h('section', null, h('h3', null, 'About the software'), h('p', null, a.summary || '')),
        h('section', null, h('h3', null, 'Designed and developed by'),
          h('div', { class: 'author' }, h('div', { class: 'avatar', 'aria-hidden': 'true' }, initials),
            h('div', null, h('b', null, au.name || ''), h('div', { class: 'role' }, [au.title, au.company].filter(Boolean).join(' at ')),
              au.bio ? h('p', { class: 'bio' }, au.bio) : null,
              contact.length ? h('div', { class: 'contact' }, contact.map((c) => c[2] && /^(mailto:|https?:)/.test(c[2]) ? h('a', { href: c[2], target: '_blank', rel: 'noopener' }, c[1]) : h('span', null, c[0] + ': ' + c[1]))) : null))),
        (a.features || []).length ? h('section', null, h('h3', null, 'What you get'), h('ul', { class: 'feat' }, a.features.map((f) => h('li', null, h('b', null, f.title), h('span', null, f.text))))) : null,
        a.privacy ? h('section', null, h('h3', null, 'Your data'), h('p', null, a.privacy)) : null,
        (a.legal || []).length ? h('section', { class: 'legal' }, a.legal.map((t) => h('div', null, t))) : null),
      h('div', { class: 'ab-foot' }, h('span', null, a.copyright || ''), h('span', null, 'Version ' + (a.version || ''), '  '), h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Close')));
    dlg.showModal();
    dlg.scrollTop = 0;
  }
  function showServer() {
    const dlg = $('#dlg-server');
    const inp = h('input', { id: 'srv', type: 'url', value: ST.configured ? ST.server : '', placeholder: 'https://your-domain.com/taskdesk/api.php', style: 'width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:8px;background:var(--card);min-height:42px' });
    const out = h('div', { class: 'hint', style: 'min-height:20px;margin:10px 0', role: 'status' });
    dlg.replaceChildren(h('h2', { style: 'margin:0 0 6px;font-size:19px' }, 'TaskDesk server'),
      h('p', { style: 'margin:0 0 14px;color:var(--ink-2)' }, 'The web address of your TaskDesk cloud (given when the server was set up).'),
      inp, out,
      h('div', { class: 'keyrow' }, h('button', { class: 'btn', type: 'button', onclick: () => dlg.close() }, 'Cancel'),
        h('button', { class: 'btn primary', type: 'button', style: 'width:auto;flex:1', onclick: async (e) => {
          out.textContent = 'Checking...';
          try { const r = await api('/api/server', { url: inp.value.trim() }); out.textContent = r.health && r.health.ok ? 'Connected.' : (r.health && r.health.message) || 'Saved, but the server did not answer.'; await refresh(); if (r.health && r.health.ok) setTimeout(() => dlg.close(), 700); }
          catch (err) { out.textContent = err.message; }
        } }, 'Save and test')));
    dlg.showModal();
  }

  /* ---------- start ---------- */
  function drawStatus() {
    $('#ver').textContent = 'v' + ST.version;
    if (ST.update && ST.update.available) {
      banner('TaskDesk ' + ST.update.latest + ' is available.', false, ST.update.url ? h('a', { href: ST.update.url, target: '_blank', rel: 'noopener' }, 'Download') : null);
    } else if (ST.update && ST.update.notice) banner(ST.update.notice, false);
    else if (ST.configured && ST.health && ST.health.ok === false) banner('Cannot reach the TaskDesk server. Check your internet connection.', true, h('button', { class: 'lnk', type: 'button', onclick: async () => { await refresh(); route(); } }, 'Try again'));
    else banner('');
  }
  async function refresh() { ST = await api('/api/refresh', {}); drawStatus(); return ST; }
  function route() {
    if (ST.session) return autoOpen();
    viewLogin();
  }
  async function start() {
    $('#btn-about').addEventListener('click', showAbout);
    $('#btn-server').addEventListener('click', showServer);
    for (const d of document.querySelectorAll('dialog')) d.addEventListener('click', (e) => { if (e.target === d) d.close(); });
    try { ST = await api('/api/state'); } catch (e) { setView(h('h2', null, 'TaskDesk'), h('div', { class: 'msg bad' }, e.message)); return; }
    theme(ST.install_module);
    drawStatus();
    route();
  }
  start();
})();
