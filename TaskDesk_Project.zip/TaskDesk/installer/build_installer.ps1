﻿<#
  Builds TaskDesk_Setup_<version>.exe

  Usage (PowerShell or double-click build_installer.bat):
     .\build_installer.ps1 -CloudUrl "https://your-domain.com/taskdesk/api.php"

  What it does
     1. copies client\app to build\stage\app and writes your cloud address into it
     2. downloads the official Python "embeddable" package (pinned version, checksum checked) to build\stage\python
     3. runs a self test with that Python
     4. compiles installer\taskdesk.iss with Inno Setup  ->  dist\TaskDesk_Setup_<version>.exe  (+ SHA-256 file)
#>
param(
    [string]$CloudUrl = '',
    [string]$Version = '',
    [string]$PythonVersion = '3.12.10',
    [string]$PythonMd5 = 'fe8ef205f2e9c3ba44d0cf9954e1abd3',
    [switch]$AllowPlaceholder
)
$ErrorActionPreference = 'Stop'
$root  = Split-Path -Parent $PSScriptRoot
$app   = Join-Path $root 'client\app'
$build = Join-Path $root 'build'
$stage = Join-Path $build 'stage'
$cache = Join-Path $build 'cache'
$dist  = Join-Path $root 'dist'

function Step($t) { Write-Host ''; Write-Host "== $t" -ForegroundColor Cyan }

if (-not $Version) { $Version = (Get-Content (Join-Path $app 'version.json') -Raw | ConvertFrom-Json).version }
Write-Host "TaskDesk version $Version"

# ---------------------------------------------------------------- 1. stage the program files
Step 'Preparing program files'
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Force -Path $stage, $cache, $dist | Out-Null
robocopy $app (Join-Path $stage 'app') /E /XD __pycache__ /XF *.pyc install.json /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { throw "Copy failed (robocopy code $LASTEXITCODE)" }

$cfgPath = Join-Path $stage 'app\taskdesk_config.json'
$cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json
if ($CloudUrl) { $cfg.cloud_url = $CloudUrl }
if ($cfg.cloud_url -match 'YOUR-DOMAIN' -and -not $AllowPlaceholder) {
    throw "The cloud address is not set. Run:  .\build_installer.ps1 -CloudUrl `"https://your-domain.com/taskdesk/api.php`"  (or edit client\app\taskdesk_config.json)"
}
if ($cfg.cloud_url -notmatch '^https://' -and -not $AllowPlaceholder) { throw "The cloud address must start with https://" }
($cfg | ConvertTo-Json) | Set-Content -Path $cfgPath -Encoding UTF8
$ver = Get-Content (Join-Path $stage 'app\version.json') -Raw | ConvertFrom-Json
$ver.version = $Version
($ver | ConvertTo-Json) | Set-Content -Path (Join-Path $stage 'app\version.json') -Encoding UTF8
Write-Host "Cloud address: $($cfg.cloud_url)"

# ---------------------------------------------------------------- 2. embeddable Python
Step "Python $PythonVersion (embeddable, 64-bit)"
$zip = Join-Path $cache "python-$PythonVersion-embed-amd64.zip"
if (-not (Test-Path $zip)) {
    $url = "https://www.python.org/ftp/python/$PythonVersion/python-$PythonVersion-embed-amd64.zip"
    Write-Host "Downloading $url"
    Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing
}
if ($PythonVersion -eq '3.12.10' -or $PythonMd5) {
    $md5 = (Get-FileHash $zip -Algorithm MD5).Hash.ToLower()
    if ($md5 -ne $PythonMd5.ToLower()) { Remove-Item $zip -Force; throw "Checksum of the Python download does not match (got $md5). Download removed - run again." }
    Write-Host "Checksum OK ($md5)"
}
Expand-Archive -Path $zip -DestinationPath (Join-Path $stage 'python') -Force
$py = Join-Path $stage 'python\python.exe'

# ---------------------------------------------------------------- 3. self test with the packaged Python
Step 'Self test'
& $py (Join-Path $stage 'app\tmcore\selftest.py')
if ($LASTEXITCODE -ne 0) { throw 'The self test failed. See the lines marked FAIL above.' }

# ---------------------------------------------------------------- 4. Inno Setup
Step 'Compiling the installer'
$iscc = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
    "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $iscc) { $c = Get-Command iscc -ErrorAction SilentlyContinue; if ($c) { $iscc = $c.Source } }
if (-not $iscc) {
    throw "Inno Setup 6 was not found. Install it (free) from https://jrsoftware.org/isdl.php  or run:  winget install JRSoftware.InnoSetup"
}
& $iscc "/DAppVersion=$Version" "/DStageDir=$stage" (Join-Path $root 'installer\taskdesk.iss')
if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed (code $LASTEXITCODE)" }

$exe = Join-Path $dist "TaskDesk_Setup_$Version.exe"
$hash = (Get-FileHash $exe -Algorithm SHA256).Hash.ToLower()
"$hash  TaskDesk_Setup_$Version.exe" | Set-Content -Path (Join-Path $dist "TaskDesk_Setup_$Version.sha256.txt") -Encoding ASCII
Step 'Done'
Write-Host "Installer : $exe"
Write-Host "SHA-256   : $hash"
Write-Host ('Size      : {0:N1} MB' -f ((Get-Item $exe).Length / 1MB))
