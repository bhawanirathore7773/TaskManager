; TaskDesk installer (Inno Setup 6). Build with installer\build_installer.bat - it prepares the staging folder first.
; Per-user install: no administrator rights, nothing is written outside the user's own folders.

#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif
#ifndef StageDir
  #define StageDir "..\build\stage"
#endif
#define AppName "TaskDesk"

[Setup]
AppId={{B7D0A5E2-6C1F-4F0B-9A55-3D2E8C41A7F1}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher=Bhawani Singh
VersionInfoVersion={#AppVersion}
VersionInfoCompany=Bhawani Singh
VersionInfoDescription=TaskDesk Setup
VersionInfoProductName=TaskDesk
DefaultDirName={localappdata}\Programs\TaskDesk
UsePreviousAppDir=yes
DefaultGroupName=TaskDesk
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\dist
OutputBaseFilename=TaskDesk_Setup_{#AppVersion}
SetupIconFile=taskdesk.ico
UninstallDisplayIcon={app}\TaskDesk.ico
UninstallDisplayName={#AppName}
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
LicenseFile=..\LICENSE.txt
CloseApplications=no
RestartApplications=no
SetupMutex=TaskDeskSetupMutex

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Messages]
WelcomeLabel2=This will install [name/ver] on your computer.%n%nTaskDesk keeps your SAP tasks, notes and files in one place on this PC, and safely in your own cloud account so you can continue on any computer.%n%nNo administrator rights are needed.

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop icon"; GroupDescription: "Shortcuts:"
Name: "autostart"; Description: "Open TaskDesk when I sign in to Windows"; GroupDescription: "Shortcuts:"; Flags: unchecked

[InstallDelete]
; old program files are replaced completely on an update. Your data (%LOCALAPPDATA%\TaskDesk) is never touched.
Type: filesandordirs; Name: "{app}\python"
Type: filesandordirs; Name: "{app}\app\tmcore"
Type: filesandordirs; Name: "{app}\app\modules"
Type: filesandordirs; Name: "{app}\app\gate_static"
Type: filesandordirs; Name: "{app}\app\shell_static"

[Files]
Source: "{#StageDir}\python\*"; DestDir: "{app}\python"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "{#StageDir}\app\*"; DestDir: "{app}\app"; Excludes: "__pycache__,*.pyc,install.json"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "taskdesk.ico"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\TaskDesk"; Filename: "{app}\python\pythonw.exe"; Parameters: """{app}\app\launcher.pyw"""; WorkingDir: "{app}\app"; IconFilename: "{app}\app\modules\{code:GetModule}\app.ico"; Comment: "Open TaskDesk"
Name: "{autodesktop}\TaskDesk"; Filename: "{app}\python\pythonw.exe"; Parameters: """{app}\app\launcher.pyw"""; WorkingDir: "{app}\app"; IconFilename: "{app}\app\modules\{code:GetModule}\app.ico"; Comment: "Open TaskDesk"; Tasks: desktopicon

[Registry]
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "TaskDesk"; ValueData: """{app}\python\pythonw.exe"" ""{app}\app\launcher.pyw"""; Flags: uninsdeletevalue; Tasks: autostart

[Run]
Filename: "{app}\python\pythonw.exe"; Parameters: """{app}\app\launcher.pyw"""; WorkingDir: "{app}\app"; Description: "Open TaskDesk now"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{app}\python\pythonw.exe"; Parameters: """{app}\app\launcher.pyw"" --quit"; Flags: runhidden; RunOnceId: "StopTaskDesk"

[Code]
var
  ModulePage: TWizardPage;
  ModuleCombo: TNewComboBox;
  ModuleDesc: TNewStaticText;

function ModuleId(I: Integer): String;
begin
  case I of
    0: Result := 'abap';
    1: Result := 'fico';
  else
    Result := 'mm';
  end;
end;

function ModuleIndex(const Id: String): Integer;
begin
  if Id = 'abap' then Result := 0
  else if Id = 'fico' then Result := 1
  else Result := 2;
end;

{ used by the shortcuts: {code:GetModule} }
function GetModule(Param: String): String;
begin
  Result := ModuleId(ModuleCombo.ItemIndex);
end;

procedure ModuleChanged(Sender: TObject);
begin
  case ModuleCombo.ItemIndex of
    0: ModuleDesc.Caption := 'Custom development for SAP: reports, enhancements, interfaces, forms and transports.';
    1: ModuleDesc.Caption := 'SAP Finance and Controlling: month-end closing, configuration, reconciliation and support.';
  else
    ModuleDesc.Caption := 'SAP Materials Management: procurement, inventory, invoice verification and master data.';
  end;
end;

{ the module chosen by an earlier installation, so an update keeps it }
function PreviousModule: String;
var
  Raw: AnsiString;
  S: String;
  P: Integer;
begin
  Result := '';
  if LoadStringFromFile(ExpandConstant('{localappdata}\Programs\TaskDesk\app\install.json'), Raw) then
  begin
    S := String(Raw);
    P := Pos('"module"', S);
    if P > 0 then
    begin
      S := Copy(S, P + 8, 40);
      if Pos('abap', S) > 0 then Result := 'abap'
      else if Pos('fico', S) > 0 then Result := 'fico'
      else if Pos('mm', S) > 0 then Result := 'mm';
    end;
  end;
end;

procedure InitializeWizard;
var
  Lbl, Note: TNewStaticText;
  Wanted: String;
begin
  ModulePage := CreateCustomPage(wpLicense, 'Choose your SAP module',
    'Which role will you use TaskDesk for on this PC?');

  Lbl := TNewStaticText.Create(ModulePage);
  Lbl.Parent := ModulePage.Surface;
  Lbl.Caption := 'SAP module:';
  Lbl.Left := 0;
  Lbl.Top := 0;

  ModuleCombo := TNewComboBox.Create(ModulePage);
  ModuleCombo.Parent := ModulePage.Surface;
  ModuleCombo.Style := csDropDownList;
  ModuleCombo.Left := 0;
  ModuleCombo.Top := Lbl.Top + Lbl.Height + ScaleY(6);
  ModuleCombo.Width := ModulePage.SurfaceWidth;
  ModuleCombo.Items.Add('ABAP Developer');
  ModuleCombo.Items.Add('FICO Consultant');
  ModuleCombo.Items.Add('MM Consultant');
  ModuleCombo.OnChange := @ModuleChanged;

  ModuleDesc := TNewStaticText.Create(ModulePage);
  ModuleDesc.Parent := ModulePage.Surface;
  ModuleDesc.AutoSize := False;
  ModuleDesc.WordWrap := True;
  ModuleDesc.Left := 0;
  ModuleDesc.Top := ModuleCombo.Top + ModuleCombo.Height + ScaleY(12);
  ModuleDesc.Width := ModulePage.SurfaceWidth;
  ModuleDesc.Height := ScaleY(40);

  Note := TNewStaticText.Create(ModulePage);
  Note.Parent := ModulePage.Surface;
  Note.AutoSize := False;
  Note.WordWrap := True;
  Note.Left := 0;
  Note.Top := ModuleDesc.Top + ModuleDesc.Height + ScaleY(16);
  Note.Width := ModulePage.SurfaceWidth;
  Note.Height := ScaleY(70);
  Note.Caption := 'This sets the edition that opens first and the first choice on the "Create account" screen. ' +
    'You can sign in with an account of another module at any time: TaskDesk then switches to that edition by itself.';

  Wanted := ExpandConstant('{param:MODULE|}');
  if Wanted = '' then Wanted := PreviousModule;
  if Wanted = '' then Wanted := 'mm';
  ModuleCombo.ItemIndex := ModuleIndex(Wanted);
  ModuleChanged(nil);
end;

{ close a running TaskDesk before its files are replaced }
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Py, Launcher: String;
  Code: Integer;
begin
  Result := '';
  Py := ExpandConstant('{app}\python\pythonw.exe');
  Launcher := ExpandConstant('{app}\app\launcher.pyw');
  if FileExists(Py) and FileExists(Launcher) then
  begin
    Exec(Py, '"' + Launcher + '" --quit', ExpandConstant('{app}\app'), SW_HIDE, ewWaitUntilTerminated, Code);
    Sleep(1500);
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
var
  Json: String;
begin
  if CurStep = ssPostInstall then
  begin
    Json := '{' + #13#10 +
            '  "module": "' + ModuleId(ModuleCombo.ItemIndex) + '",' + #13#10 +
            '  "version": "{#AppVersion}"' + #13#10 +
            '}' + #13#10;
    SaveStringToFile(ExpandConstant('{app}\app\install.json'), Json, False);
  end;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if CurUninstallStep = usPostUninstall then
  begin
    if MsgBox('Also delete the TaskDesk data stored on this PC (saved sign-in, local copy of your tasks and files)?' + #13#10 + #13#10 +
              'Your data in the TaskDesk cloud is not affected. It comes back when you sign in again.',
              mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
      DelTree(ExpandConstant('{localappdata}\TaskDesk'), True, True, True);
  end;
end;
