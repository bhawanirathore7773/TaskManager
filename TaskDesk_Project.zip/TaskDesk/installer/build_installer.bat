@echo off
rem Builds the TaskDesk setup file. Example:  build_installer.bat -CloudUrl "https://your-domain.com/taskdesk/api.php"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_installer.ps1" %*
echo.
pause
