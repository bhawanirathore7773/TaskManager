#!/usr/bin/env python3
"""
End-to-end test of the whole product with the REAL PHP API and two separate "PCs" (two TASKDESK_HOME folders).
Run:  python3 tests/test_e2e.py
"""
import http.client
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
APP = os.path.join(ROOT, 'client', 'app')
sys.path.insert(0, HERE)
import test_server as ts                                   # noqa: E402

check = ts.check


def wait_for(fn, timeout=30, step=0.3):
    end = time.time() + timeout
    last = None
    while time.time() < end:
        try:
            last = fn()
            if last:
                return last
        except Exception as e:      # noqa: BLE001
            last = None
        time.sleep(step)
    return last


class Local:
    """A local TaskDesk server (gate or module) reached with its key cookie."""

    def __init__(self, port, key):
        self.port, self.key = port, key

    def call(self, method, path, body=None, raw=None, headers=None, cookie=True, write_header=True):
        h = {}
        if cookie:
            h['Cookie'] = 'tdk_%d=%s' % (self.port, self.key)
        if method != 'GET' and write_header:
            h['X-TM'] = '1'
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            h['Content-Type'] = 'application/json'
        if raw is not None:
            data = raw
            h['Content-Type'] = 'application/octet-stream'
        if headers:
            h.update(headers)
        req = urllib.request.Request('http://127.0.0.1:%d%s' % (self.port, path), data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                return r.status, r.read(), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read(), dict(e.headers)

    def j(self, *a, **k):
        st, payload, _ = self.call(*a, **k)
        try:
            return st, json.loads(payload.decode('utf-8'))
        except Exception:
            return st, {'_raw': payload[:300]}


class Pc:
    """One simulated Windows PC: its own TASKDESK_HOME and its own gate process."""

    def __init__(self, tmp, name, cloud_url, install_module='mm'):
        self.home = os.path.join(tmp, name)
        os.makedirs(self.home)
        self.env = dict(os.environ, TASKDESK_HOME=self.home, TASKDESK_CLOUD=cloud_url, TASKDESK_INSTALL_MODULE=install_module,
                        TD_SYNC_FAST='2', PYTHONUNBUFFERED='1')
        self.gate_proc = None
        self.gate = None
        self.mod = None

    def start_gate(self):
        self.gate_proc = subprocess.Popen([sys.executable, os.path.join(APP, 'tmcore', 'gate.py'), '--idle-exit', '3600'], cwd=APP, env=self.env,
                                          stdout=open(os.path.join(self.home, 'gate.out'), 'w'), stderr=subprocess.STDOUT)
        info = wait_for(lambda: json.load(open(os.path.join(self.home, 'run', 'gate.json'))), 15)
        self.gate = Local(info['port'], info['key'])
        assert wait_for(lambda: self.gate.call('GET', '/__gate/ping', cookie=False)[0] == 200, 10)

    def attach(self, url):
        """url = http://127.0.0.1:PORT/__td/enter?k=KEY&next=/"""
        from urllib.parse import urlparse, parse_qs
        u = urlparse(url)
        self.mod = Local(u.port, parse_qs(u.query)['k'][0])
        self.mod_url = url

    def token(self):
        old = os.environ.get('TASKDESK_HOME')
        os.environ['TASKDESK_HOME'] = self.home
        sys.path.insert(0, APP)
        try:
            from tmcore import session
            s = session.load()
            return s['token'] if s else None
        finally:
            if old is None:
                os.environ.pop('TASKDESK_HOME', None)
            else:
                os.environ['TASKDESK_HOME'] = old

    def state(self):
        st, d = self.mod.j('GET', '/__td/state')
        return d if st == 200 else {}

    def settled(self, timeout=40):
        def ok():
            s = self.state().get('sync', {})
            return s.get('state') == 'idle' and s.get('pending') == 0 and not s.get('restore_active') and s.get('dl_left') == 0 and s.get('last_sync')
        return wait_for(ok, timeout)

    def data_dir(self):
        users = os.path.join(self.home, 'users')
        if not os.path.isdir(users):
            return None
        names = [n for n in os.listdir(users)]
        return names

    def stop(self):
        if self.gate_proc and self.gate_proc.poll() is None:
            self.gate_proc.send_signal(signal.SIGTERM)
            try:
                self.gate_proc.wait(timeout=40)
            except Exception:
                self.gate_proc.kill()


def main():
    tmp = tempfile.mkdtemp(prefix='tde2e_')
    php = None
    pcs = []
    try:
        site = ts.make_site(tmp, 'cloud', {'quota_mb': 50, 'max_file_mb': 20})
        port = ts.free_port()
        env = dict(os.environ, PHP_CLI_SERVER_WORKERS='6')

        def start_php():
            p = subprocess.Popen(['php', '-S', '127.0.0.1:%d' % port, '-t', site], cwd=site, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            assert ts.wait_up(port)
            return p
        php = start_php()
        cloud_url = 'http://127.0.0.1:%d/api.php' % port
        capi = ts.Api(port)

        pc1 = Pc(tmp, 'pc1', cloud_url, 'mm')
        pc2 = Pc(tmp, 'pc2', cloud_url, 'mm')
        pcs += [pc1, pc2]
        pc1.start_gate()
        pc2.start_gate()

        print('gate on PC 1')
        st, d = pc1.gate.j('GET', '/api/state')
        check('gate state ok', st == 200 and d['ok'] and d['configured'] and d['health']['ok'], d)
        check('three modules offered, MM is the installed default', [m['id'] for m in d['modules']] == ['abap', 'fico', 'mm'] and d['install_module'] == 'mm', d['modules'])
        check('no session yet', d['session'] is None)
        st, _p, _h = pc1.gate.call('GET', '/api/state', cookie=False)
        check('gate refuses requests without the key', st == 403, st)
        st, _p, h = pc1.gate.call('GET', '/__enter?k=wrong', cookie=False)
        check('gate refuses a wrong key', st == 403, st)
        st, d = pc1.gate.j('POST', '/api/login', {'username': 'nobody', 'password': 'whatever1'})
        check('login with unknown user shows a clear message', st == 400 and 'not correct' in d.get('message', ''), (st, d))
        st, d = pc1.gate.j('POST', '/api/register', {'username': 'x', 'password': 'Passw0rd!x', 'module': 'mm'})
        check('register validation message passes through', st == 400 and d.get('error') == 'bad_username', (st, d))
        st, p, h = pc1.gate.call('GET', '/')
        check('gate page is served', st == 200 and b'TaskDesk' in p, st)
        st, d = pc1.gate.j('GET', '/api/about')
        check('about has author details', d['author']['name'] == 'Bhawani Singh' and 'Mayur Uniquoters' in d['author']['company'] and d['author']['title'] == 'ABAP Developer', d)

        print('register on PC 1 (MM installed)')
        st, r = pc1.gate.j('POST', '/api/register', {'username': 'bhawani', 'password': 'Passw0rd!x', 'module': 'mm', 'display_name': 'Bhawani Singh'})
        check('registered and workspace started', st == 200 and r['ok'] and r['url'] and len(r['recovery_key']) == 24, r)
        pc1.attach(r['url'])
        recovery = r['recovery_key']
        check('session saved on this PC', pc1.token() is not None)
        sess_text = open(os.path.join(pc1.home, 'session.json')).read()
        check('token is not stored as plain text in session.json', pc1.token() not in sess_text)

        print('module workspace on PC 1')
        # the browser first visits /__td/enter?k=... and receives the cookie
        conn = http.client.HTTPConnection('127.0.0.1', pc1.mod.port, timeout=10)
        conn.request('GET', '/__td/enter?k=%s&next=/' % pc1.mod.key)
        resp = conn.getresponse()
        check('enter sets an HttpOnly SameSite cookie and redirects', resp.status == 302 and 'HttpOnly' in resp.getheader('Set-Cookie', '') and 'SameSite=Strict' in resp.getheader('Set-Cookie', ''), (resp.status, resp.getheader('Set-Cookie')))
        conn.close()
        st, p, h = pc1.mod.call('GET', '/')
        html = p.decode('utf-8')
        check('module page has the TaskDesk shell injected', st == 200 and '/__td/shell.js' in html and '/__td/shell.css' in html and 'MM Task Manager' in html, st)
        st, p, h = pc1.mod.call('GET', '/__td/shell.js')
        check('shell.js is served', st == 200 and b'TaskDesk shell' in p)
        st, d = pc1.mod.j('GET', '/__td/state')
        check('state shows user + module', st == 200 and d['user']['username'] == 'bhawani' and d['module']['id'] == 'mm' and d['module']['title'] == 'MM Consultant', d)
        st, p, h = pc1.mod.call('GET', '/api/tasks', cookie=False)
        check('module API refuses requests without the key', st == 403, st)
        st, p, h = pc1.mod.call('GET', '/api/tasks', headers={'Host': 'evil.example.com'})
        check('module API refuses a foreign Host header', st == 403, st)
        st, p, h = pc1.mod.call('POST', '/api/tasks', body={'title': 'x'}, write_header=False)
        check('changes without the X-TM header are refused', st == 403, st)
        st, d = pc1.mod.j('GET', '/__td/ping')
        check('ping works without a key and shows no data', st == 200 and d['module'] == 'mm' and 'user' not in d, d)
        check('first sync cycle completes', pc1.settled(), pc1.state().get('sync'))

        print('create data on PC 1: tasks, checklist, file')
        st, t1 = pc1.mod.j('POST', '/api/tasks', {'title': 'PO release हिंदी test', 'task_type': 'config', 'checklist': ['Step one', 'Step two']})
        check('task created', st == 200 and t1['task']['id'] == 1, (st, str(t1)[:200]))
        tid = t1['task']['id']
        blob = os.urandom(150000)
        st, up = pc1.mod.j('POST', '/api/tasks/%d/files?name=requirement.xlsx&category=excel' % tid, raw=blob)
        check('file uploaded to the local task folder', st == 200 and up['rel_path'].endswith('2_Excel_Requirement/requirement.xlsx'), (st, up))
        rel = up['rel_path']
        img = os.urandom(5000)
        st, up2 = pc1.mod.j('POST', '/api/tasks/%d/files?name=screen.png&category=image' % tid, raw=img)
        st, _ = pc1.mod.j('POST', '/api/tasks/%d/time' % tid, {'log_date': '2026-11-20', 'hours': 1.5, 'note': 'analysis'})
        st, t2 = pc1.mod.j('POST', '/api/tasks', {'title': 'Second task'})
        check('settles after the writes', pc1.settled(), pc1.state().get('sync'))
        tok = pc1.token()
        st, d = capi.j('sync/pull', token=tok, query='since=0&limit=2000')
        tabs = {}
        for rec in d['records']:
            tabs.setdefault(rec['t'], []).append(rec)
        check('cloud has both tasks', len([r for r in tabs.get('tasks', []) if not r['del']]) == 2, {k: len(v) for k, v in tabs.items()})
        check('cloud task keeps Hindi text', any(r['d'] and 'PO release हिंदी test' == r['d']['title'] for r in tabs['tasks']))
        check('cloud has checklist, time log, files rows and history', len(tabs.get('checklist', [])) == 2 and len(tabs.get('timelog', [])) == 1 and len(tabs.get('files', [])) == 2 and len(tabs.get('history', [])) >= 3,
              {k: len(v) for k, v in tabs.items()})
        st, d = capi.j('files/list', token=tok)
        rels = sorted(f['rel'] for f in d['files'])
        check('both files are in the cloud under their folder paths', rels == sorted([rel, up2['rel_path']]), d)
        st, payload, h = capi.call('files/get', token=tok, query='rel=' + urllib.request.quote(rel))
        check('cloud file content is identical', payload == blob)

        print('update and delete on PC 1')
        st, _ = pc1.mod.j('PUT', '/api/tasks/%d' % tid, {'title': 'PO release renamed', 'priority': 'high'})
        st, _ = pc1.mod.j('PUT', '/api/files/%d' % up2['id'], {'category': 'backup'})   # moves the file to another folder
        check('settled after update', pc1.settled(), pc1.state().get('sync'))
        st, d = capi.j('sync/pull', token=tok, query='since=0&limit=2000')
        trec = [r for r in d['records'] if r['t'] == 'tasks' and r['id'] == str(tid)][0]
        check('cloud sees the renamed task', trec['d']['title'] == 'PO release renamed' and trec['d']['priority'] == 'high', trec)
        st, d = capi.j('files/list', token=tok)
        rels2 = sorted(f['rel'] for f in d['files'])
        check('moved file: new path in cloud, old path gone', any('3_Before_Change_Snapshot/screen.png' in r for r in rels2) and not any('1_Reference_Images/screen.png' in r for r in rels2), rels2)

        print('sign out on PC 1 and sign in on PC 2 (new PC: restore everything)')
        st, d = pc1.mod.j('POST', '/__td/logout', {})
        check('logout answers with the gate address', st == 200 and d['ok'] and '/__enter?k=' in d['redirect'], d)
        check('session removed from PC 1', wait_for(lambda: pc1.token() is None, 10))
        check('module process ended after logout', wait_for(lambda: ts.socket.socket().connect_ex(('127.0.0.1', pc1.mod.port)) != 0, 15))
        st, d = pc1.gate.j('GET', '/api/state')
        check('gate shows no session after logout', d['session'] is None)

        st, r2 = pc2.gate.j('POST', '/api/login', {'username': 'bhawani', 'password': 'Passw0rd!x'})
        check('login on PC 2', st == 200 and r2['ok'] and r2['user']['module'] == 'mm', r2)
        pc2.attach(r2['url'])
        check('restore finishes on PC 2', pc2.settled(60), pc2.state().get('sync'))
        st, tasks = pc2.mod.j('GET', '/api/tasks')
        titles = sorted(t['title'] for t in tasks)
        check('PC 2 has the same tasks', titles == ['PO release renamed', 'Second task'], titles)
        st, det = pc2.mod.j('GET', '/api/tasks/%d' % tid)
        check('checklist, files and time log came along', len(det['checklist']) == 2 and len(det['files']) == 2 and len(det['time']) == 1, {k: len(v) for k, v in det.items() if isinstance(v, list)})
        users = os.listdir(os.path.join(pc2.home, 'users'))
        data2 = os.path.join(pc2.home, 'users', users[0], 'data')
        folder = [t for t in tasks if t['id'] == tid][0]['folder']
        for sub in ('1_Reference_Images', '2_Excel_Requirement', '3_Before_Change_Snapshot', '4_Documents_FS_UserGuide', '5_Test_UAT_Signoff', '6_Other'):
            if not os.path.isdir(os.path.join(data2, 'files', folder, sub)):
                check('folder %s exists on PC 2' % sub, False)
                break
        else:
            check('all task folders were re-created like on the first PC', True)
        check('file on PC 2 is byte-identical', open(os.path.join(data2, 'files', rel), 'rb').read() == blob)
        moved = [f for f in det['files'] if f['filename'] == 'screen.png'][0]
        check('moved file is in the new folder on PC 2 and not in the old', os.path.isfile(os.path.join(data2, 'files', moved['rel_path'])) and '3_Before_Change_Snapshot' in moved['rel_path']
              and not os.path.exists(os.path.join(data2, 'files', up2['rel_path'])), moved)
        fx = [f for f in det['files'] if f['filename'] == 'requirement.xlsx'][0]
        st, payload, h = pc2.mod.call('GET', '/files/%d' % fx['id'])
        check('file opens through the module on PC 2', st == 200 and payload == blob, st)
        import sqlite3
        c = sqlite3.connect(os.path.join(data2, 'taskmanager.db'))
        check('local database is healthy', c.execute('PRAGMA integrity_check').fetchone()[0] == 'ok' and c.execute('PRAGMA foreign_key_check').fetchall() == [])
        check('restore left nothing waiting to upload (no echo)', c.execute('SELECT COUNT(*) FROM _td_outbox').fetchone()[0] == 0)
        c.close()

        print('two PCs signed in at once: changes travel both ways')
        st, r1 = pc1.gate.j('POST', '/api/login', {'username': 'bhawani', 'password': 'Passw0rd!x'})
        pc1.attach(r1['url'])
        tok = pc1.token()
        check('PC 1 signs in again and is quick (incremental)', pc1.settled(30), pc1.state().get('sync'))
        st, t3 = pc2.mod.j('POST', '/api/tasks', {'title': 'Made on PC 2'})
        st, up3 = pc2.mod.j('POST', '/api/tasks/%d/files?name=note.pdf&category=doc' % t3['task']['id'], raw=b'%PDF-1.4 fake pdf from pc2')
        pc2.settled(30)
        check('PC 1 receives the new task from PC 2', wait_for(lambda: any(t['title'] == 'Made on PC 2' for t in pc1.mod.j('GET', '/api/tasks')[1]), 30))
        users1 = os.listdir(os.path.join(pc1.home, 'users'))
        fpath1 = os.path.join(pc1.home, 'users', users1[0], 'data', 'files', up3['rel_path'])
        check('and its file is downloaded to PC 1', wait_for(lambda: os.path.isfile(fpath1) and open(fpath1, 'rb').read() == b'%PDF-1.4 fake pdf from pc2', 30))
        st, _ = pc1.mod.j('PUT', '/api/tasks/%d' % t3['task']['id'], {'title': 'Renamed on PC 1'})
        check('PC 2 receives the rename from PC 1', wait_for(lambda: any(t['title'] == 'Renamed on PC 1' for t in pc2.mod.j('GET', '/api/tasks')[1]), 30))
        st, _ = pc2.mod.j('DELETE', '/api/tasks/%d' % t3['task']['id'])
        check('delete on PC 2 reaches PC 1 (task and file gone)', wait_for(lambda: not any(t['id'] == t3['task']['id'] for t in pc1.mod.j('GET', '/api/tasks')[1]) and not os.path.exists(fpath1), 30))
        st, d = capi.j('files/list', token=tok)
        check('deleted task left no file in the cloud', not any('Made_on_PC_2' in f['rel'] for f in d['files']), [f['rel'] for f in d['files']])

        print('offline work and catching up')
        php.send_signal(signal.SIGTERM)
        php.wait(timeout=10)
        st, t4 = pc1.mod.j('POST', '/api/tasks', {'title': 'Written while offline'})
        st, up4 = pc1.mod.j('POST', '/api/tasks/%d/files?name=offline.xlsx&category=excel' % t4['task']['id'], raw=b'offline bytes')
        check('the app keeps working offline (instant local save)', st == 200)
        pc1.mod.j('POST', '/__td/sync', {})
        s = pc1.state()['sync']
        check('state says offline with changes waiting', s['state'] == 'offline' and s['pending'] > 0, s)
        st, d = pc1.mod.j('POST', '/__td/logout', {})
        check('sign out is refused while changes are not uploaded', st == 409 and d['pending'] > 0, (st, d))
        php = start_php()
        st, d = pc1.mod.j('POST', '/__td/sync', {})
        check('back online: everything uploads', pc1.settled(40), pc1.state().get('sync'))
        st, d = capi.j('files/list', token=tok)
        check('offline file reached the cloud', any(f['rel'] == up4['rel_path'] for f in d['files']), [f['rel'] for f in d['files']])
        check('PC 2 gets the offline work', wait_for(lambda: any(t['title'] == 'Written while offline' for t in pc2.mod.j('GET', '/api/tasks')[1]), 30))

        print('different module account on the same PC converts the desk')
        st, d = pc1.mod.j('POST', '/__td/logout', {})
        check('PC 1 signs out', st == 200)
        wait_for(lambda: ts.socket.socket().connect_ex(('127.0.0.1', pc1.mod.port)) != 0, 15)
        st, ra = pc1.gate.j('POST', '/api/register', {'username': 'ravi.abap', 'password': 'Another#Pass1', 'module': 'abap', 'display_name': 'Ravi'})
        check('ABAP account created on a PC installed for MM', st == 200 and ra['user']['module'] == 'abap', ra)
        pc1.attach(ra['url'])
        st, d = pc1.mod.j('GET', '/__td/state')
        check('the ABAP desk opened (module follows the account)', d['module']['id'] == 'abap' and d['module']['title'] == 'ABAP Developer', d.get('module'))
        st, p, h = pc1.mod.call('GET', '/')
        check('ABAP screen served', b'ABAP' in p and b'/__td/shell.js' in p)
        st, tasks = pc1.mod.j('GET', '/api/tasks')
        check('the new ABAP account does not see MM data', tasks == [], tasks)
        pc1.settled(30)
        st, d = pc1.mod.j('POST', '/__td/logout', {'wipe': True})
        check('sign out with "remove data from this PC"', st == 200)
        check('local data of that account is removed', wait_for(lambda: not any(n.startswith('u2_') for n in os.listdir(os.path.join(pc1.home, 'users'))), 15), os.listdir(os.path.join(pc1.home, 'users')))
        st, r1 = pc1.gate.j('POST', '/api/login', {'username': 'bhawani', 'password': 'Passw0rd!x'})
        pc1.attach(r1['url'])
        check('signing in as MM user switches back to the MM desk', pc1.state().get('module', {}).get('id') == 'mm')

        print('persistent login: gate reopens the workspace without asking again')
        pc1.mod.j('POST', '/__td/sync', {})
        st, d = pc1.gate.j('GET', '/api/state')
        check('gate knows the saved session', d['session'] and d['session']['user']['username'] == 'bhawani', d['session'])
        st, d = pc1.gate.j('POST', '/api/open', {})
        check('open returns the running workspace (no second process)', st == 200 and d['url'].split('?')[0].split('/__')[0] == 'http://127.0.0.1:%d' % pc1.mod.port, d)

        print('password recovery through the gate')
        st, d = pc2.mod.j('POST', '/__td/logout', {})
        st, d = pc2.gate.j('POST', '/api/recover', {'username': 'bhawani', 'recovery_key': recovery, 'new_password': 'NewPass#12345'})
        check('recover with the saved key', st == 200 and d['recovery_key'] and d['recovery_key'] != recovery, d)
        st, d = pc2.gate.j('POST', '/api/login', {'username': 'bhawani', 'password': 'Passw0rd!x'})
        check('old password no longer works', st == 400, (st, d))
        st, d = pc2.gate.j('POST', '/api/login', {'username': 'bhawani', 'password': 'NewPass#12345'})
        check('new password works', st == 200 and d['ok'], d)
        pc2.attach(d['url'])
        check('session on PC 1 was revoked by the password reset (sign-in expired)', wait_for(lambda: (pc1.mod.j('POST', '/__td/sync', {}) and pc1.state().get('sync', {}).get('state') == 'auth'), 30), pc1.state().get('sync'))
        s = pc1.state()
        check('shell is told to ask for sign-in', s.get('sync', {}).get('auth_lost') is True, s.get('sync'))
        st, d = pc1.mod.j('POST', '/__td/logout', {'force': True})
        check('forced sign out works with an expired token', st == 200, (st, d))
        st, d = pc1.gate.j('GET', '/api/state')
        check('gate shows the sign-in screen again', d['session'] is None)

        print('closing everything with the launcher (used by the installer before an update / uninstall)')
        launcher = os.path.join(APP, 'launcher.pyw')
        subprocess.run([sys.executable, launcher, '--quit'], env=pc2.env, timeout=120)
        check('gate process ended', wait_for(lambda: pc2.gate_proc.poll() is not None, 40))
        check('gate announcement file removed', wait_for(lambda: not os.path.exists(os.path.join(pc2.home, 'run', 'gate.json')), 10))
        check('module process ended too (port closed)', wait_for(lambda: ts.socket.socket().connect_ex(('127.0.0.1', pc2.mod.port)) != 0, 20))
        r = subprocess.run([sys.executable, launcher, '--quit'], env=pc2.env, timeout=60)
        check('quit with nothing running is harmless', r.returncode == 0)

    finally:
        for p in pcs:
            p.stop()
        if php and php.poll() is None:
            php.terminate()
        shutil.rmtree(tmp, ignore_errors=True)
    print('\nRESULT: %d passed, %d failed' % (ts.PASS, ts.FAIL))
    return 1 if ts.FAIL else 0


if __name__ == '__main__':
    sys.exit(main())
