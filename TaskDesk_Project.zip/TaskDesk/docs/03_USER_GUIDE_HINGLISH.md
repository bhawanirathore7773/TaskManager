# TaskDesk: user guide (Hinglish)

## Pehli baar

1. `TaskDesk_Setup_x.y.z.exe` chalao. Wizard me **module** chuno (ABAP / FICO / MM) aur Install karo.
2. TaskDesk khulega. **Create an account** dabao:
   - Name, Username (3 se 32 akshar: a-z, 0-9, dot, dash, underscore), Password (kam se kam 8 akshar).
   - Module dropdown me apna role chuno. Dropdown badalte hi screen ka rang aur card badal jaate hain.
3. **Recovery key** dikhegi (jaise `ABCD-EFGH-JKLM-NPQR-STUV`). Isko **abhi** kisi safe jagah (phone note, password manager) me save karo.
   Password bhoolne par ye hi ek raasta hai. Ye dobara nahi dikhegi.
4. Bas. Ab TaskDesk aapke module ke task manager me khul jaata hai.

## Rozana use

- App kholo, seedha andar. **Dobara login nahi maangta**, jab tak aap Sign out na karo.
- Task manager me tasks, checklist, time log, transport, files sab pehle jaise hi hai. Sab kuch PC par turant khulta hai.
- Neeche left me **account block** hai: aapka naam, module, aur sync chip.

### Sync chip ka matlab

| Chip | Matlab |
|---|---|
| Saved, 2 min ago (green) | Sab cloud me save hai |
| Syncing... | Upload/download chal raha hai |
| N changes waiting | Kuch changes abhi upload hone baaki hain, thodi der me ho jayenge |
| Offline, N waiting | Internet nahi hai. App chalti rahegi, net aate hi upload ho jayega |
| Sync problem | Kuch ek record ya file upload nahi ho paayi. Chip dabao, details dikhengi |
| Sign in again | Session expire ho gaya (ya password dusre PC par badla). Dobara login karo |
| Update needed | Naya TaskDesk version install karna hoga |

## Files (images, Excel, PDF)

- Files PC par pehle jaise **task ke folder** me rehti hain.
- Attach, rename ya delete karoge to PC aur cloud dono me badalta hai.
- Naye PC par login karoge to folders aur files cloud se wapas ban jaate hain. Badi files background me utarti hain, aur jo file aap khologe wo turant pehle utar jaati hai.

## Doosre PC par kaam karna

1. Naye PC par TaskDesk install karo (koi bhi module chun lo).
2. Apne username aur password se login karo.
3. Agar aapka account kisi dusre module ka hai (jaise PC par MM install hai, aur aapka account ABAP ka), to TaskDesk **apne aap ABAP task manager me badal jaata hai**.
4. Aapka poora data aur files wapas aa jaate hain. Progress screen par dikhta hai.

## Sign out

- Neeche left me account block > **Sign out** (wahin **Sync now** aur **About** bhi hain).
- Normal sign out me PC par data rehta hai (agle login par fast khulega).
- **Shared / office ka common PC** ho to "Also remove the copy of my data from this PC" tick karo.
- Sign out se pehle app bacha hua kaam upload kar deta hai. Agar internet nahi hai aur kuch upload baaki hai, to wo bata dega, aur aap chaho to phir bhi sign out kar sakte ho.

## Password bhool gaye

Login screen par **Forgot password?** > username + recovery key + naya password.
Naya password banne par **nayi recovery key** milti hai (purani band ho jaati hai) aur baaki sab devices sign out ho jaate hain.

## About

Login screen ke neeche **About TaskDesk** (ya app ke andar account block ka **About** button) dabao: product ki jaankari, features, privacy, aur author: **Bhawani Singh, ABAP Developer at Mayur Uniquoters**.
Ye sabhi users ko dikhta hai.

## Privacy

- Cloud me: tasks, notes, checklist, time entries, history aur aapki attach ki hui files.
- Nahi: SAP password ya SAP system ka koi connection. TaskDesk SAP se data nahi padhta.
- Login token Windows (DPAPI) se encrypt karke aapke user folder me rakha jaata hai.
- Local app sirf aapke PC par chalta hai (127.0.0.1) aur random key ke bina koi dusra program ya website use nahi khol sakti.

## Limit (honest)

- **Ek time par ek hi PC par kaam karo.** Agar do PC par same account se, dono offline rehkar, naye tasks banaoge to unke number/ID takra sakte hain. Online rehte hue do PC chalana theek hai.
- Ek hi record dono PC par badla ho to **aakhri save jeet'ta hai**.
- Pehle ke alag-alag (standalone) task manager ka purana data TaskDesk me automatically nahi aata. Iske liye alag importer banana padega.
