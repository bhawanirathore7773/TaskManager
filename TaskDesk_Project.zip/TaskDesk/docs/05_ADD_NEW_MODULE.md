# Adding a new module (for example "HCM" or "SD")

A module is one folder under `client/app/modules/<id>/`. No change is needed in the gate, the sync engine or the installer code
(except the optional wizard text below).

## 1. Folder layout

```
client/app/modules/sd/
    module.json
    server.py          the module's local web server (same shape as the existing three)
    static/            index.html, js, css, icon.svg
    app.ico            optional: shortcut icon
```

## 2. module.json

```json
{
  "id": "sd",
  "title": "SD Consultant",
  "short": "SD",
  "tagline": "SAP Sales and Distribution: orders, pricing, delivery, billing",
  "data_env": "SD_TM_DATA",
  "app_id": "sd-task-manager",
  "accent": "#b4541a",
  "shell": "#2b1a10",
  "order": 4,
  "entry": "server.py",
  "icon": "static/icon.svg"
}
```

- `id`: lower-case, 2 to 20 letters/digits. This is also what the server stores per account.
- `data_env`: the environment variable your `server.py` reads for its data folder. TaskDesk sets it per user.
- `accent` / `shell`: colours used by the gate card and the account block.
- `order`: position in the registration dropdown.

## 3. What `server.py` must provide

TaskDesk imports the file and uses these names (copy any existing module as the starting point):

| Name | Used for |
|---|---|
| `DATA_DIR = os.environ.get('SD_TM_DATA') or ...` | location of the data (set to the user's folder) |
| `DB_PATH`, `FILES_DIR` | SQLite file and the root of attached files |
| `STATIC_DIR` | folder holding `index.html` (TaskDesk injects `shell.css` and `shell.js` into it) |
| `CATS` (dict) | file category to sub-folder name; used to re-create folders on a new PC |
| `init_all()` | creates folders and the schema (idempotent) |
| `Handler` | `BaseHTTPRequestHandler` subclass with `handle_any(method)`, `serve_static(path)`, `host_ok()`, `send_json`, `send_bytes` |
| `LocalServer` | `ThreadingHTTPServer` subclass |
| `file_abs(row)` | absolute path of an attachment row (TaskDesk wraps it to download on demand) |
| `idle_watch(httpd, seconds)` | optional idle shutdown |
| `SERVER` | dict with `last_seen` and `httpd` |
| `ApiError` | exception your handlers raise for 4xx errors |

Rules that keep sync working:

1. **Every table needs a single-column primary key.** (Triggers are generated automatically for all of them.)
2. Store attachments as files under `FILES_DIR/<task folder>/<category folder>/...` and keep their relative path in a table column.
   The task table needs a `folder` column so the folders can be rebuilt.
3. Use only the Python standard library (the installer ships the stock embeddable Python).
4. Write only inside `DATA_DIR`.
5. Any write request from the UI must send the header `X-TM: 1` (as the existing modules do).

## 4. Register it

1. Server: add `'sd'` to `modules` in `server/config.php`. (A fresh `setup.php` run offers the known list; for a new id, edit `config.php` directly.)
2. Installer wizard text: in `installer/taskdesk.iss`, extend `ModuleId`, `ModuleIndex`, the combo items and the description text.
   (The module still works for registered users without this step; the step only adds it to the install dropdown.)
3. Registration dropdown and auto-convert need nothing: they read `modules/` from disk.
4. Bump `client/app/version.json`, build a new installer, then in `config.php` set `latest_client` and `download_url`.

## 5. Update flow for users

- Users who already have TaskDesk see the "is available" banner and install the new version over the old one. Their data is untouched.
- An account created for the new module on an old PC cannot open it until that PC is updated. The gate says so instead of failing silently.

## 6. Test it

1. Run from source (`Run_From_Source.bat`, or `python client/app/launcher.pyw`).
2. Register an account for the new module and create a task with a file.
3. Run `tests/test_e2e.py` after adding your module to its module list. It proves restore on a second PC and sign-out wipe for your module too.
