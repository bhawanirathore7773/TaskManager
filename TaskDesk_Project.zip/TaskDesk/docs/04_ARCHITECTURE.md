# TaskDesk architecture

This document is for whoever maintains TaskDesk (including future you). User-facing guides are in Hinglish (01 to 03).

## 1. Goals and the decisions that follow from them

| Goal | Decision |
|---|---|
| Installs like normal Windows software | Inno Setup 6 per-user installer, bundles the pinned Python 3.12 embeddable package. No admin rights, no Python needed on the PC. |
| Instant screens, fast reads and writes | **Local-first.** Each module keeps its own SQLite database on the PC and serves its UI from `127.0.0.1`. The cloud is a replica, never in the request path of a screen. |
| Data in the Hostinger database through an API | PHP 7.4+ API on the existing Hostinger Web hosting, MySQL through PDO. |
| Files stay in local folders as before, and are restored on login | Files are real files in per-task folders. Their bytes go to the server's storage folder; the folder structure is rebuilt from the task rows and the module's category map. |
| One product, three modules, one login | `modules/<id>/` registry. The **account** has a module. The gate starts that module for the session. |
| Future modules | Drop a folder in `modules/`, add the id to the server `modules` list, ship a new installer. |

The three original task managers are used **unmodified** (`server.py` + `static/`). TaskDesk patches them at run time
(`tmcore/module_host.py: patch_module`) and adds sync through SQLite triggers, so there is one code path for all modules.

## 2. Components

```
 Windows PC                                                         Hostinger
┌──────────────────────────────────────────────────────┐        ┌───────────────────────┐
│ launcher.pyw  ──starts/finds──▶  GATE  (tmcore/gate.py)│        │ public_html/taskdesk/ │
│   opens Edge/Chrome --app window     login, register,  │        │   api.php  (router)   │
│                                      recover, About    │        │   lib/*.php           │
│                                        │ starts        │        │                       │
│                                        ▼               │ HTTPS  │ MySQL                 │
│                            MODULE HOST (module_host.py)│◀──────▶│   td_users td_tokens  │
│                              patched module server.py  │  JSON  │   td_records td_files │
│                              SQLite + triggers (outbox)│  +raw  │   td_attempts         │
│                              SYNC ENGINE (engine.py)   │  files │ storage/ (outside web │
│                              local files/ folders      │        │   root): file blobs   │
└──────────────────────────────────────────────────────┘        └───────────────────────┘
```

### 2.1 Gate (`tmcore/gate.py`)
Login, register (with the module dropdown), recovery key screen, password recovery, About, Server address. It listens on
`127.0.0.1:8750-8759` (or a random port) and announces itself in `run/gate.json`. After a successful sign-in it starts one
**module child** for the account's module and redirects the window to it. It exits after 300 s without a window.

### 2.2 Module host (`tmcore/module_host.py`)
One child process per signed-in session. It loads `modules/<id>/server.py` with `importlib`, points its data folder
(`data_env`) at `%LOCALAPPDATA%\TaskDesk\users\u<id>_<username>_<serverhash>\data`, installs sync triggers, starts the engine, and
serves the module UI with two extra assets (`/__td/shell.js`, `/__td/shell.css`) injected into `index.html`:
account block, sync chip, About, Sign out, banners, restore progress.

### 2.3 Sync engine (`tmcore/engine.py`, `syncdb.py`, `cloud.py`)
See section 4.

### 2.4 Cloud API (`server/`)
Single entry `api.php?r=<route>` (no URL rewriting needed on any host). Routes:

| Route | Purpose |
|---|---|
| `health` (`&deep=1`) | version info, limits, `latest_client`, `min_client`, notice. Always allowed (also for old clients). |
| `auth/register`, `auth/login`, `auth/logout`, `auth/me`, `auth/password`, `auth/recover` | accounts, sessions |
| `sync/push`, `sync/pull`, `sync/status` | row replication, per-user increasing `rev` |
| `files/put`, `files/get`, `files/del`, `files/list` | file bytes |

## 3. Local security

- The gate and every module server bind to `127.0.0.1` only.
- Each requires a random per-launch key. It arrives once through `/__enter?k=` or `/__td/enter?k=` and is kept as an
  `HttpOnly; SameSite=Strict` cookie `tdk_<port>`. Another program or web page cannot use the local API without the key.
- The `Host` header is validated (DNS-rebinding protection). All writes require the header `X-TM: 1`.
- `/__td/ping` and `/__gate/ping` are public but return no data.
- The session token is stored in `session.json`, encrypted with Windows **DPAPI** (`dpapi:` prefix). On non-Windows
  (tests, source runs) it falls back to `plain:` with `chmod 600`.
- Sign out deletes the token locally and revokes it on the server; optionally wipes the user's folder.

## 4. Sync design

### 4.1 Change capture
SQLite triggers are generated for **every table with a single-column primary key** and re-created when the schema signature changes
(`_td_meta.trg_sig`). Each insert/update/delete adds a row to `_td_outbox` with op `u` (upsert), `d` (delete) or `f`
(file path changed; the old path is kept in `info`). Because the triggers are generic, a new module needs no sync code.

Support tables: `_td_meta` (applying flag, last_rev, last_verify), `_td_files` (rel, size, mtime_ns, sha256), `_td_log`.

### 4.2 Push
- **State based:** the engine reads the *current* row for each outbox key (or sends a delete if it is gone), so repeated edits coalesce into one record.
- Chunks of at most 200 ops or 3 MB.
- **Poison-record isolation:** a failing chunk is split in half until the single bad record is found; it is logged as a "problem" and dropped so it cannot block everything behind it.
- Order: file bytes first, then rows, then remote deletes of files.

### 4.3 Pull
- The server numbers every change per user (`rev`, strictly increasing). The client asks for everything after its `last_rev`.
- Applied in **one transaction** with `applying=1` (triggers do not echo back) and foreign keys off, using `INSERT ... ON CONFLICT DO UPDATE`.
- **Local wins:** a row that still has a pending local change is skipped; push always runs before pull.
- Echo suppression: when `server_rev - applied_count == last_rev` the client's own push is the only change, so it just advances `last_rev`.
- If the server `rev` is lower than local (server restored from an older backup) `last_rev` is reset to 0 and everything is re-compared.
- A `UNIQUE` conflict on `tasks.code` is logged and skipped.

### 4.4 Files
- Local files are scanned and compared with `_td_files` (size, mtime, sha256). The server stores bytes under an HMAC of the relative path, so no user text ever becomes a server path.
- Download queue in the background plus `ensure_local` on demand: when the user opens a file that is not on this PC yet, it is fetched first.
- Self-heal `verify_files` every 12 h compares local state with the server list.
- Upload is streamed; size is limited by `max_file_mb` = min(config, `post_max_size` - 1 MB), and the user's `quota_mb`.

### 4.5 Restore on a new PC
`last_rev == 0` triggers a restore: all rows are pulled with progress counters; folders are re-created from `tasks.folder` plus the module's `CATS`
map; files then download in the background.

### 4.6 States and timing
`starting`, `syncing`, `idle`, `offline`, `error`, `auth`, `upgrade`. Fast loop every 20 s (env `TD_SYNC_FAST`), slow loop 90 s, exponential
back-off after failures, flush on sign out and on shutdown. The first non-GET request after start waits (up to 5 s) for the first pull to finish.

## 5. Server design and security

- **Passwords:** `password_hash` (bcrypt/argon2 default). Login for an unknown user verifies against a real dummy hash so timing does not reveal accounts.
- **Rate limits** (`td_attempts`): 8 bad logins lock that username for 15 min; per-IP limits on login, register and recovery.
- **Recovery key:** 20 characters (`XXXX-XXXX-XXXX-XXXX-XXXX`), stored only as an HMAC. Using it rotates it, changes the password and revokes all sessions.
- **Tokens:** 256-bit random, stored as a hash, 90-day sliding expiry, max 20 devices per account.
- **Transport:** `require_https` (honours `X-Forwarded-Proto`).
- **Isolation:** every query is scoped by `user_id`. File paths are HMACs. Storage is outside `public_html` by default.
- **Hardening:** `.htaccess` denies `config.php` and logs; JSON-only errors; no stack traces to clients; `nosniff`, `X-Frame-Options`, no referrer.
- **Version control:** `min_client` makes old clients receive HTTP 426 and the app shows "Update needed"; `latest_client` only shows a banner.
- **Tombstones:** deletes are kept as records so offline PCs delete correctly when they come back.

## 6. Hosting analysis

| Option | Verdict |
|---|---|
| Hostinger **Web hosting** (existing plan) | **Fits.** PHP + MySQL. This is what the API targets. |
| Python/Django on Web hosting | Not available (Python is VPS only). |
| Node.js on Web hosting | Only on selected plans. Not needed. |
| Hostinger **VPS** | Needed only to move the API to Python/Django or for large scale. The desktop app talks to a documented JSON contract, so the server can be replaced without touching the client. |

## 7. Data layout on a PC

```
%LOCALAPPDATA%\TaskDesk\
   session.json            (DPAPI-protected token)
   run\gate.json
   logs\
   users\u<id>_<username>_<serverhash6>\data\
       taskmanager.db   files\<task folder>\<category>\...   backups\   trash\
%LOCALAPPDATA%\Programs\TaskDesk\       (program files, replaced on update; python\, app\)
```
Env `TASKDESK_HOME` relocates the first tree (used by the tests to simulate several PCs).

## 8. Tests

| Suite | Checks | What it covers |
|---|---|---|
| `tests/test_server.py` | 99 | real `php -S` on SQLite: auth, rate limits, rev/pull/push, tombstones, files, quota, size limits, recovery, upgrade gate, path attacks |
| `tests/test_e2e.py` | 79 | two simulated PCs against the real API: first sync, restore on a new PC, module auto-convert, offline then online, conflicts, files, logout/wipe, recovery |
| `tests/test_ui.py` | 12 | headless Chromium: gate flows, theming, About, shell account block, screenshots |

Run: `python3 tests/test_server.py` (needs `php` CLI), `python3 tests/test_e2e.py`, `NODE_PATH=$(npm root -g) python3 tests/test_ui.py <shots-dir>` (needs Playwright).

## 9. Known limits (be honest with users)

1. **Single active device assumption.** Row ids come from each PC's own SQLite counters. Two PCs creating rows at the same time while both are offline can use the same id; the later push wins that row. A guard covers the short window right after start, but not long offline periods on two PCs.
2. Conflicts are **last writer wins per row** (not per field).
3. The MySQL schema was written for MySQL/MariaDB but only exercised against SQLite in tests. First real install: open `?r=health&deep=1` and register a test user.
4. The installer, DPAPI and the embedded-Python start-up path were not run on Windows during development. See the checklist in doc 02.
5. The installer is unsigned: Windows SmartScreen will warn on first run.
6. The old stand-alone task managers' data is not imported automatically.
7. All three modules ship in every install (needed for auto-convert). The wizard choice sets the default edition and icon.

## 10. Roadmap ideas

- Importer from the old stand-alone folders into a TaskDesk account.
- Code signing; automatic in-app update download.
- Per-field merge, or server-assigned ids, to remove limit 1.
- Optional VPS/Django API with the same contract.
