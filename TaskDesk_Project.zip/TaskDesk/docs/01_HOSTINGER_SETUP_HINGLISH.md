# TaskDesk Server: Hostinger par setup (Hinglish guide)

Ye guide aapke **Hostinger Web hosting** plan ke liye hai. Aapke plan me PHP aur MySQL milta hai, aur TaskDesk ka API
exactly isi par chalne ke liye bana hai. **Naya plan ya VPS lene ki zaroorat nahi hai.**

Poora kaam lagbhag 10-15 minute ka hai.

---

## Step 1: Domain / folder decide karo

API ka address kuch aisa hoga:

```
https://aapka-domain.com/taskdesk/api.php
```

Agar aap alag subdomain chahte ho (jaise `taskdesk.aapka-domain.com`), to hPanel me pehle subdomain bana lo.
Dono tarah se kaam karta hai. Is guide me `public_html/taskdesk/` folder use kiya gaya hai.

## Step 2: MySQL database banao

1. hPanel kholo, apni website ke saamne **Manage** dabao.
2. Left menu me **Databases > Management** (ya **MySQL Databases**) kholo.
3. **Create new database** me ye bharo:
   - Database name: `taskdesk`
   - Username: `taskdesk`
   - Password: koi strong password (isko copy karke rakh lo)
4. **Create** dabao.

Hostinger naam ke aage apna prefix laga deta hai, jaise `u123456789_taskdesk`. List me jo **poora naam** dikhe,
wahi aage use hoga (database name aur username dono).

## Step 3: Server files upload karo

1. hPanel me **Files > File Manager** kholo.
2. `public_html` ke andar `taskdesk` naam ka folder banao.
3. Is project ke `server` folder ke **andar ki saari files aur folders** (`api.php`, `index.php`, `setup.php`,
   `config.sample.php`, `.htaccess`, `lib/`) us `taskdesk` folder me upload karo.
   Sabse aasaan: `TaskDesk_Server.zip` upload karo aur File Manager me **Extract** dabao.
4. Check karo ki `.htaccess` file aayi hai (hidden files dikhane ka option File Manager settings me hota hai).

## Step 4: HTTPS force karo

hPanel > **Security > SSL** me apne domain ka SSL active hona chahiye. Phir **Force HTTPS** ON kar do.
TaskDesk server http connection ko reject karta hai, kyunki password aur token plain text me nahi jaane chahiye.

## Step 5: Setup page chalao

Browser me kholo:

```
https://aapka-domain.com/taskdesk/setup.php
```

- Upar ke checks sab hare (ok) hone chahiye: PHP 7.4+, pdo_mysql, JSON, folder writable.
- **Database host**: `localhost`
- **Database name / user / password**: Step 2 wale poore naam aur password.
- **Storage folder**: page khud `public_html` ke **bahar** ka folder suggest karta hai
  (jaise `/home/u123456789/taskdesk_storage`). Ise waise hi rehne do. Files web se direct nahi khul sakti.
- **Invite code** (optional): agar sirf aap aur jinko aap code do wahi account bana sakein, to koi shabd likh do.
  Khali chhodoge to koi bhi register kar sakta hai.
- **Space per user** aur **max file size**: default 2048 MB aur 500 MB theek hai.

**Install** dabao. Success page aayega.

## Step 6: setup.php delete karo

File Manager se `taskdesk/setup.php` delete kar do. Ye zaroori hai. Ye file sirf ek baar ke liye hoti hai.

## Step 7: Check karo ki sab chal raha hai

Browser me kholo:

```
https://aapka-domain.com/taskdesk/api.php?r=health&deep=1
```

Aisa JSON dikhna chahiye:

```json
{"ok":true,"app":"taskdesk-api", ... "db":true,"storage":true, "max_file_mb": ...}
```

- `"db": true` = database connect ho gaya.
- `"storage": true` = files ka folder writable hai.
- `max_file_mb` = abhi server kitni badi file accept karega.

## Step 8: Badi files ke liye PHP limit badhao

Agar `max_file_mb` chhota dikhe (jaise 1 ya 7), to PDF/Excel upload fail ho sakte hain.
hPanel > **Advanced > PHP Configuration > PHP Options** me:

- `post_max_size` = `128M`
- `upload_max_filesize` = `128M`
- `max_execution_time` = `300`

Save karo, phir `?r=health` dobara kholo. `max_file_mb` badh jana chahiye.
(Server khud `post_max_size` ke hisaab se limit tay karta hai, isliye galat error nahi aayega.)

---

## Apna address desktop app me daalna

Installer banate waqt ye address andar daal diya jaata hai (guide 02 dekho):

```
https://aapka-domain.com/taskdesk/api.php
```

Agar installer ke baad address badalna ho, to login screen par **Server** button se bhi badal sakte ho.

---

## Rozana ke kaam

| Kaam | Kaise |
|---|---|
| Backup | hPanel > Databases me database ka **backup/export**, aur `taskdesk_storage` folder ki copy. Hostinger ke automatic backups bhi plan ke hisaab se chalte hain. |
| Naye registrations band karna | `config.php` me `'allow_registration' => false` |
| Space ya file limit badalna | `config.php` me `quota_mb`, `max_file_mb` |
| Naya module add hua | `config.php` ke `modules` list me naya naam jodo |
| Users ko naya version dilana | `config.php` me `latest_client`, `download_url`, `notice` bharo. Purane version ko rokna ho to `min_client` badhao. |
| Koi error dikhe | Storage folder ke andar `taskdesk_storage/logs/api.log` dekho. Ye `public_html` ke bahar hai, isliye web se nahi khulti. |

## Agar kuch na chale

- **500 / blank page**: PHP version 7.4 ya usse upar rakho (hPanel > Advanced > PHP Configuration).
- **"https_required"**: SSL / Force HTTPS ON karo.
- **`"db": false`**: `config.php` me database ka naam, user ya password galat hai. Hostinger ka prefix (`u123456789_`) mat bhoolo.
- **Login pe "Server not reachable"**: URL galat hai ya `.htaccess` upload nahi hui. Health URL browser me kholke dekho.
- **config.php dobara banana ho**: File Manager se `config.php` delete karo, `setup.php` wapas upload karo.

## VPS kab chahiye?

Abhi bilkul nahi. Sirf tab jab future me server Python (Django) me likhna ho, ya hazaaron users ho jayein.
Tab Hostinger **VPS** (KVM 1 ya 2) lena. Desktop app ka API contract wahi rahega, isliye app me kuch nahi badlega.
